//******************************************************************************
// @(R)   
//		���ʊ֐�
//		
//		(���̊֐����L�q����t�@�C���擪��***_FUNC_DEFINE���`���邱�ƁB)
// @(X)
//
//  Copyright (c) Hitachi Power Solutions Co., Ltd. All rights reserved.
//******************************************************************************
//******** �ύX���� ************************************************************
//ver 1.0	2025.11.10	���ō쐬
//ver 2.0	2026.10.01	EEPROM�p�����[�^�����ǉ�
//******************************************************************************
/* �������֐� */
#ifndef INIT_FUNC_DEFINE
extern void ini_cpu(void);			//����I/O�[�q�ݒ�
extern void ini_ioport(void);		//����I/O�[�q������
extern void ini_global(void);		//�O���[�o���ϐ�������
#endif

/* �^�C�}�[�֐� */
#ifndef TIMER_FUNC_DEFINE
extern ER EntryTimer10ms(UW interval_time, ID evt_id,  UINT bitptn);
extern ER CancelTimer10ms(ID evt_id, UINT bitptn);
extern ER set_rtc_time(UB *t);		//ver2.0add
extern void get_rtc_time(void);		//ver2.0add
#endif

/* EEPROM�֐� */
#ifndef EEPROM_FUNC_DEFINE
extern ER eep_mac_read(UB *macaddr);
//ver2.0add-start-
extern void eep_byte_write(unsigned long addr, unsigned char *buf, int size);	
extern void eep_byte_read(unsigned long addr, unsigned char *buf, int size);	
extern void eep_copy_para(void);												
extern ER eep_check_para(void);													
extern void eep_get_para(UB pno,UB area,UB *get_data);							
extern void eep_set_para(UB pno,UB *set_data);									
extern void eep_reset_para(void);												
extern UH eep_crcget(UH val);													
extern UH eep_modbus_crc_16(UW len, UB *data);									
extern ER eep_rw_check(void);													
extern void eep_reset_iniflg(void);												
extern void eep_reset_romver(void);												
extern void eep_reset_err(void);												
extern void eep_read_init_all(void);											
extern ER eep_write_para(UB no, UH val);										
extern ER eep_init_para(UB no);													
extern ER eep_chk_range(UB no, UH val);											
extern ER eep_clear_err_all(void);												
//ver2.0add-end-



#endif


/* �f�o�b�O�֐� */
#ifndef DEBUG_FUNC_DEFINE
extern void DebugOut(char *str);
extern void DebugOut_time(void);
extern void DebugOut_ito0X(char *s , unsigned short n);
extern void DebugOut_lto0X(char *s , unsigned long n);
extern void DebugOut_itou(char *s , unsigned short n);
extern void DebugOut_ltou(char *s , unsigned long n);
extern void DebugOut_itod(char *s , short n);
extern void DebugOut_ltod(char *s , long n);
extern void DebugOut_itou_fit(char *s , unsigned short n);
extern void DebugOut_ltou_fit(char *s , unsigned long n);
extern void DebugOut_LF(void);
#endif

/* END */
