#
# NORTi4
# Network Library makefile for Renesas C
#

### PATH ###

INC = ..\..\..\INC
SRC = ..\..\..\SRC

### FILES ###

LIBFILE  = n4nrxv1b.lib
SRCFILE  = $(SRC)\nonet.c $(SRC)\nonetip.c $(SRC)\nonicmp.c $(SRC)\nonearp.c \
           $(SRC)\noneudp.c $(SRC)\nontcp1.c $(SRC)\nontcp2.c $(SRC)\nonelan.c \
           $(SRC)\nonitod.c $(SRC)\nonslib.c $(SRC)\nonigmp.c $(SRC)\noneipf.c \
           $(SRC)\nonloop.c $(SRC)\noneraw.c $(SRC)\nonigmp3.c
INCFILE  = $(INC)\nonet.h $(INC)\nonetc.h $(INC)\nonets.h $(INC)\nonloop.h $(INC)\nonelan.h
MAKEFILE = n4nrxv1b.mak
CMDFILE  = n4nrxv1b.sub

### COMMAND ###

CC       = ccrx
CFLAGS   = -isa=rxv1 -endian=big -optimize=2 -size -include=$(INC) -nologo \
           -change_message=information=20170 -avoid_cross_boundary_prefetch -debug
LIB      = rlink
LIBFLAGS = -subcommand=$(CMDFILE)

$(LIBFILE) : $(SRCFILE) $(INCFILE) $(MAKEFILE) $(CMDFILE)
	$(CC) $(CFLAGS) $(SRC)\nonet.c
	$(CC) $(CFLAGS) $(SRC)\nonetip.c
	$(CC) $(CFLAGS) $(SRC)\nonicmp.c
	$(CC) $(CFLAGS) $(SRC)\nonearp.c
	$(CC) $(CFLAGS) $(SRC)\noneudp.c
	$(CC) $(CFLAGS) $(SRC)\nontcp1.c
	$(CC) $(CFLAGS) $(SRC)\nontcp2.c
	$(CC) $(CFLAGS) $(SRC)\noneraw.c
	$(CC) $(CFLAGS) $(SRC)\nonelan.c
	$(CC) $(CFLAGS) $(SRC)\nonitod.c
	$(CC) $(CFLAGS) $(SRC)\nonslib.c
	$(CC) $(CFLAGS) $(SRC)\nonigmp.c
	$(CC) $(CFLAGS) $(SRC)\nonigmp3.c
	$(CC) $(CFLAGS) $(SRC)\noneipf.c
	$(CC) $(CFLAGS) -define=LAN_EXT_DEV -output=obj=LAN_EXT_DEV.obj $(SRC)\nonloop.c
	$(CC) $(CFLAGS) -define=ETH_CH=1,LAN_EXT_DEV -output=obj=LAN_EXT_DEV1.obj $(SRC)\nonloop.c
	$(CC) $(CFLAGS) -define=ETH_CH=2,LAN_EXT_DEV -output=obj=LAN_EXT_DEV2.obj $(SRC)\nonloop.c
	$(CC) $(CFLAGS) -define=ETH_CH=3,LAN_EXT_DEV -output=obj=LAN_EXT_DEV3.obj $(SRC)\nonloop.c
	$(LIB) $(LIBFLAGS)
	del *.obj

# end
