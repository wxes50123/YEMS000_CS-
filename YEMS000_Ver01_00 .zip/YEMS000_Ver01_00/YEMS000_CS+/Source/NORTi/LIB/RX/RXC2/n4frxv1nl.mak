# Create n4frxv1nl.lib with Renesas C

### PATH ###

SRC = ..\..\..\SRC
INC = ..\..\..\INC

### FILES ###

LIBFILE  = n4frxv1nl.lib
SRCFILE  = $(SRC)\n4crx600.src $(SRC)\noknl4.c
INCFILE  = $(INC)\kernel.h $(INC)\nosys4.h $(INC)\n4rrx.h
MAKEFILE = n4frxv1nl.mak
CMDFILE  = n4frxv1nl.sub

### COMMAND ###

CC       = ccrx
CFLAGS   = -isa=rxv1 -nofpu -endian=little -optimize=2 -size -include=$(INC) -nologo \
           -change_message=information=20170 -avoid_cross_boundary_prefetch
AS       = asrx
AFLAGS   = -isa=rxv1 -nofpu -endian=little -define=HOOK=0
LIB      = rlink
LIBFLAGS = -subcommand=$(CMDFILE)

$(LIBFILE) : $(SRCFILE) $(INCFILE) $(MAKEFILE) $(CMDFILE)
	$(AS) $(SRC)\n4crx600.src $(AFLAGS) -output=n4crx600.obj
	$(AS) $(SRC)\ent_int.src $(AFLAGS) -output=ent_int.obj
	$(CC) $(CFLAGS) -define=ERC=0,OS_CORE     -output=obj=os_core.obj     $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_TSK  -output=obj=V4_CRE_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_TSK  -output=obj=V3_CRE_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CAN_TSK  -output=obj=V4_CAN_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_TSK  -output=obj=V4_DEL_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_ACT_TSK  -output=obj=V4_ACT_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STA_TSK  -output=obj=V4_STA_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_EXT_TSK  -output=obj=V4_EXT_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_EXD_TSK  -output=obj=V4_EXD_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TER_TSK  -output=obj=V4_TER_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DIS_DSP  -output=obj=V4_DIS_DSP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_DIS_DSP  -output=obj=V3_DIS_DSP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_ENA_DSP  -output=obj=V4_ENA_DSP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_ENA_DSP  -output=obj=V3_ENA_DSP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CHG_PRI  -output=obj=V4_CHG_PRI.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_GET_PRI  -output=obj=V4_GET_PRI.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_ROT_RDQ  -output=obj=V4_ROT_RDQ.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REL_WAI  -output=obj=V4_REL_WAI.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_GET_TID  -output=obj=V4_GET_TID.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_VGET_TID -output=obj=V3_VGET_TID.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_TSK  -output=obj=V4_REF_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_TSK  -output=obj=V3_REF_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_TST  -output=obj=V4_REF_TST.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SUS_TSK  -output=obj=V4_SUS_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_RSM_TSK  -output=obj=V4_RSM_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TSLP_TSK -output=obj=V4_TSLP_TSK.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_WUP_TSK  -output=obj=V4_WUP_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CAN_WUP  -output=obj=V4_CAN_WUP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CAN_WUP  -output=obj=V3_CAN_WUP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_VCAN_WUP -output=obj=V3_VCAN_WUP.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_SEM  -output=obj=V4_CRE_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_SEM  -output=obj=V3_CRE_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_SEM  -output=obj=V4_DEL_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SIG_SEM  -output=obj=V4_SIG_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TWAI_SEM -output=obj=V4_TWAI_SEM.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_SEM  -output=obj=V4_REF_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_SEM  -output=obj=V3_REF_SEM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_FLG  -output=obj=V3_CRE_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_FLG  -output=obj=V4_CRE_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_FLG  -output=obj=V4_DEL_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SET_FLG  -output=obj=V4_SET_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CLR_FLG  -output=obj=V4_CLR_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TWAI_FLG -output=obj=V4_TWAI_FLG.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_FLG  -output=obj=V4_REF_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_FLG  -output=obj=V3_REF_FLG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_MBX  -output=obj=V4_CRE_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_MBX  -output=obj=V3_CRE_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_MBX  -output=obj=V4_DEL_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SND_MBX  -output=obj=V4_SND_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TRCV_MBX -output=obj=V4_TRCV_MBX.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_MBX  -output=obj=V4_REF_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_MBX  -output=obj=V3_REF_MBX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_MBF  -output=obj=V4_CRE_MBF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_MBF  -output=obj=V3_CRE_MBF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_MBF  -output=obj=V4_DEL_MBF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TSND_MBF -output=obj=V4_TSND_MBF.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TRCV_MBF -output=obj=V4_TRCV_MBF.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_TRCV_MBF -output=obj=V3_TRCV_MBF.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_MBF  -output=obj=V4_REF_MBF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_MBF  -output=obj=V3_REF_MBF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_POR  -output=obj=V4_CRE_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_POR  -output=obj=V3_CRE_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_POR  -output=obj=V4_DEL_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TCAL_POR -output=obj=V4_TCAL_POR.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_TCAL_POR -output=obj=V3_TCAL_POR.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TACP_POR -output=obj=V4_TACP_POR.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_TACP_POR -output=obj=V3_TACP_POR.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_FWD_POR  -output=obj=V4_FWD_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_RPL_RDV  -output=obj=V4_RPL_RDV.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_POR  -output=obj=V4_REF_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_POR  -output=obj=V3_REF_POR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_RDV  -output=obj=V4_REF_RDV.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_LOC_CPU  -output=obj=V4_LOC_CPU.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_UNL_CPU  -output=obj=V4_UNL_CPU.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_LOC_CPU  -output=obj=V3_LOC_CPU.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_UNL_CPU  -output=obj=V3_UNL_CPU.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SNS_CTX  -output=obj=V4_SNS_CTX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SNS_LOC  -output=obj=V4_SNS_LOC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SNS_DSP  -output=obj=V4_SNS_DSP.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SNS_DPN  -output=obj=V4_SNS_DPN.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CHG_IMS  -output=obj=V3_CHG_IMS.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_IMS  -output=obj=V3_REF_IMS.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_MPL  -output=obj=V4_CRE_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_MPL  -output=obj=V3_CRE_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_MPL  -output=obj=V4_DEL_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TGET_MPL -output=obj=V4_TGET_MPL.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REL_MPL  -output=obj=V4_REL_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_MPL  -output=obj=V4_REF_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_MPL  -output=obj=V3_REF_MPL.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_MPF  -output=obj=V4_CRE_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_MPF  -output=obj=V4_DEL_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TGET_MPF -output=obj=V4_TGET_MPF.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REL_MPF  -output=obj=V4_REL_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_MPF  -output=obj=V4_REF_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_CRE_MPF  -output=obj=V3_CRE_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_MPF  -output=obj=V3_REF_MPF.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SET_TIM  -output=obj=V4_SET_TIM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_GET_TIM  -output=obj=V4_GET_TIM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_SET_TIM  -output=obj=V3_SET_TIM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_GET_TIM  -output=obj=V3_GET_TIM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DLY_TSK  -output=obj=V4_DLY_TSK.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_DEF_CYC  -output=obj=V3_DEF_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_ACT_CYC  -output=obj=V3_ACT_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_CYC  -output=obj=V3_REF_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_CYC  -output=obj=V4_CRE_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_CYC  -output=obj=V4_DEL_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STA_CYC  -output=obj=V4_STA_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STP_CYC  -output=obj=V4_STP_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_CYC  -output=obj=V4_REF_CYC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_ALM  -output=obj=V4_CRE_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_ALM  -output=obj=V4_DEL_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STA_ALM  -output=obj=V4_STA_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STP_ALM  -output=obj=V4_STP_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_ALM  -output=obj=V4_REF_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_DEF_ALM  -output=obj=V3_DEF_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_ALM  -output=obj=V3_REF_ALM.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEF_OVR  -output=obj=V4_DEF_OVR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STA_OVR  -output=obj=V4_STA_OVR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_STP_OVR  -output=obj=V4_STP_OVR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_OVR  -output=obj=V4_REF_OVR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_ISR  -output=obj=V4_CRE_ISR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_ISR  -output=obj=V4_DEL_ISR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_ISR  -output=obj=V4_REF_ISR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_RET_TMR  -output=obj=V3_RET_TMR.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_SYS  -output=obj=V4_REF_SYS.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_CFG  -output=obj=V4_REF_CFG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_REF_CFG  -output=obj=V3_REF_CFG.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEF_TEX  -output=obj=V4_DEF_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_RAS_TEX  -output=obj=V4_RAS_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DIS_TEX  -output=obj=V4_DIS_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_ENA_TEX  -output=obj=V4_ENA_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SNS_TEX  -output=obj=V4_SNS_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_TEX  -output=obj=V4_REF_TEX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_DTQ  -output=obj=V4_CRE_DTQ.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_DTQ  -output=obj=V4_DEL_DTQ.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_SND_DTQ  -output=obj=V4_SND_DTQ.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_FSND_DTQ -output=obj=V4_FSND_DTQ.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TRCV_DTQ -output=obj=V4_TRCV_DTQ.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_DTQ  -output=obj=V4_REF_DTQ.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CRE_MTX  -output=obj=V4_CRE_MTX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_TLOC_MTX -output=obj=V4_TLOC_MTX.obj $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_UNL_MTX  -output=obj=V4_UNL_MTX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEL_MTX  -output=obj=V4_DEL_MTX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_MTX  -output=obj=V4_REF_MTX.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_MUTEX    -output=obj=V4_MUTEX.obj    $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_REF_VER  -output=obj=V4_REF_VER.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V3_GET_VER  -output=obj=V3_GET_VER.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_DEF_SVC  -output=obj=V4_DEF_SVC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,V4_CAL_SVC  -output=obj=V4_CAL_SVC.obj  $(SRC)\noknl4.c
	$(CC) $(CFLAGS) -define=ERC=0,SIG_OVR     -output=obj=SIG_OVR.obj     $(SRC)\noknl4.c
	$(LIB) $(LIBFLAGS)
	del *.obj

# end
