/******************************************************************************
* NORTi Network LOOPBACK I/F(process internal) �h���C�o                       *
*                                                                             *
*  Copyright (c) 2001-2016 MiSPO Co., Ltd.                                    *
*  All rights reserved.                                                       *
*                                                                             *
* 2001-02-12 Created                                                OK(MiSPO) *
* 2003-05-30 Modified for Multichannel stack                                  *
* 2005-02-15 Added lan_ext_dev function.                                 A.K  *
* 2005-05-13 Modified V3 -> V4                                           A.K  *
* 2008-10-16 The blank at the end of line is deleted.                      FY *
* 2013-12-24 Added vcan_wup() after also tslp_tsk() to clear excessive        *
*                        wake-up request in lan_wai_rcv() & lan_wai_snd()  FY *
* 2014-10-20 Extened LAN driver interface to 4 channels from 2 channels    FY *
* 2015-11-04 Removed lan_ini0/4()~lan_ext_dev0/4() declaration             FY *
* 2016-03-28 Added include of nonelan.h                                    FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif

#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"
#include "nonelan.h"
#include "nonloop.h"

/* �v���g�R���X�^�b�N I/F �Ē�` */

#if DIF_NUM == 0
#elif DIF_NUM == 1
#define lan_ini     lan_ini1
#define lan_wai_rcv lan_wai_rcv1
#define lan_wai_snd lan_wai_snd1
#define lan_get_len lan_get_len1
#define lan_get_pkt lan_get_pkt1
#define lan_skp_pkt lan_skp_pkt1
#define lan_get_end lan_get_end1
#define lan_set_len lan_set_len1
#define lan_put_pkt lan_put_pkt1
#define lan_put_dmy lan_put_dmy1
#define lan_put_end lan_put_end1
#define lan_ext_dev lan_ext_dev1
#elif DIF_NUM == 2
#define lan_ini     lan_ini2
#define lan_wai_rcv lan_wai_rcv2
#define lan_wai_snd lan_wai_snd2
#define lan_get_len lan_get_len2
#define lan_get_pkt lan_get_pkt2
#define lan_skp_pkt lan_skp_pkt2
#define lan_get_end lan_get_end2
#define lan_set_len lan_set_len2
#define lan_put_pkt lan_put_pkt2
#define lan_put_dmy lan_put_dmy2
#define lan_put_end lan_put_end2
#define lan_ext_dev lan_ext_dev2
#elif DIF_NUM == 3
#define lan_ini     lan_ini3
#define lan_wai_rcv lan_wai_rcv3
#define lan_wai_snd lan_wai_snd3
#define lan_get_len lan_get_len3
#define lan_get_pkt lan_get_pkt3
#define lan_skp_pkt lan_skp_pkt3
#define lan_get_end lan_get_end3
#define lan_set_len lan_set_len3
#define lan_put_pkt lan_put_pkt3
#define lan_put_dmy lan_put_dmy3
#define lan_put_end lan_put_end3
#define lan_ext_dev lan_ext_dev3
#endif

#ifndef LAN_EXT_DEV

/* ���[�U�[��`�̊֐�/�}�N�� */

#ifndef ALIGN
#define ALIGN(p,n)  ((((UW)(p)) + (((UW)(n)) - 1)) & (~(((UW)(n)) - 1)))
                   /* �A���C�������g�����}�N��
                    *  p: �v�Z�O�A�h���X
                    *  n: ���E�l(2�ׂ̂���ł��邱��)
                    */
#endif

#define TX_BUF_NUM    16                /* Tx buffer number */
#define RX_BUF_NUM    16                /* Rx buffer number */
#define TX_BUF_SIZ    1520             /* Tx buffer size(boundary is 16) */
#define RX_BUF_SIZ    1520             /* Rx buffer size(boundary is 16) */

/* �����ϐ� */

static IIF_BD  RxBD[RX_BUF_NUM+1];     /* ��MBD(�A���C�����g�̂��� +1) */
static IIF_BD *TxBD = RxBD;            /* ���MBD(��M�ɓ���) */
static IIF_BD *pRxBD;                  /* ��MBD�J�����g�A�h���X for handling */
static IIF_BD *pRxBD2;                 /* ��MBD�J�����g�A�h���X for API */
static IIF_BD *pTxBD;                  /* ���MBD�J�����g�A�h���X */

                                       /* 16byte���E�ɍ��킹�邽�� +16 */
static UB  RxBuf[RX_BUF_NUM * RX_BUF_SIZ +16];  /* ��Mbuffer */
static UB *TxBuf = RxBuf;              /* ���Mbuffer(��M�ɓ���) */
static UB *pRxBuf;                     /* ��MBuffer�J�����g�A�h���X for working */
static UB *pTxBuf;                     /* ���MBuffer�J�����g�A�h���X for working */
static ID tx_wtskid;                   /* ���M�҂��^�X�NID */
static ID rx_wtskid;                   /* ��M�҂��^�X�NID */

#ifdef EXCLUSIVE_CTRL
#define WUP_RX() {\
    UINT psw;\
    psw = vdis_psw();\
    if (rx_wtskid){\
        wup_tsk(rx_wtskid);\
        rx_wtskid = 0;\
    }\
    vset_psw(psw);\
}
#define WUP_TX() {\
    UINT psw;\
    psw = vdis_psw();\
    if (tx_wtskid){\
        wup_tsk(tx_wtskid);\
        tx_wtskid = 0;\
    }\
    vset_psw(psw);\
}
#else
#define WUP_RX() {\
    if (rx_wtskid){\
        wup_tsk(rx_wtskid);\
        rx_wtskid = 0;\
    }\
}
#define WUP_TX() {\
    if (tx_wtskid){\
        wup_tsk(tx_wtskid);\
        tx_wtskid = 0;\
    }\
}
#endif

/*****************************************************************************
* �o�b�t�@�f�B�X�N���v�^�̏�����
*
******************************************************************************/
static void BD_init(void)
{
    int i;
    IIF_BD *current;

    pTxBD  = (IIF_BD *)(ALIGN(TxBD, sizeof(IIF_BD)));
    pRxBD  = (IIF_BD *)(ALIGN(RxBD, sizeof(IIF_BD)));
    pTxBuf = (UB *)(ALIGN(TxBuf, 16));
    pRxBuf = (UB *)(ALIGN(RxBuf, 16));

    current = pTxBD;
    for (i = 0; i < TX_BUF_NUM; i++, current++) {
        current->status = 0;
        current->len    = 0;
        current->buf_p  = pTxBuf;
        pTxBuf += TX_BUF_SIZ;
        current->next   = current + 1;  /* LINK to next BD */
    }
    current--;
    current->status |= BD_DL;    /* LAST descripter */
    current->next    = pTxBD;    /* LINK to 1st BD */

    pTxBuf = NULL;
    pRxBD2 = NULL;
    pRxBuf = NULL;
}

/*****************************************************************************
* LAN �R���g���[��������
*
******************************************************************************/

ER lan_ini(UB *macaddr)
{
    BD_init();

    nif_loop_back = NI_LOOP;

    return E_OK;
}

/*****************************************************************************
* ��M�����ݑ҂�
*
******************************************************************************/

ER lan_wai_rcv(TMO tmout)
{
    ER ercd = E_OK;
#ifdef EXCLUSIVE_CTRL
    UINT psw;
#endif

    for (;;) {
        if (!!(pRxBD->status & BD_ACT)) {
            pRxBD2 = pRxBD;        /* set current RxBD for working */
            pRxBuf = pRxBD->buf_p; /* set current buffer for working */
            pRxBD  = pRxBD->next;  /* set next BD to current */
            return E_OK;
        }
      #ifdef EXCLUSIVE_CTRL
        psw = vdis_psw();
        rx_wtskid = vget_tid();
        vcan_wup();
        vset_psw(psw);
        ercd = tslp_tsk(tmout);
        psw = vdis_psw();
        vcan_wup();
        rx_wtskid = 0;
        vset_psw(psw);
      #else
        rx_wtskid = vget_tid();
        vcan_wup();
        ercd = tslp_tsk(tmout);
        vcan_wup();
        rx_wtskid = 0;
      #endif
        if (ercd != E_OK && ercd != E_TMOUT)  /* by forced wake up */
            return -1;        /* as error */
        if (ercd == E_TMOUT)
            break;
    }
    return ercd;
}

/*****************************************************************************
* ���M�����ݑ҂�
*
******************************************************************************/

ER lan_wai_snd(TMO tmout)
{
    ER ercd = E_OK;
#ifdef EXCLUSIVE_CTRL
    UINT psw;
#endif

    for (;;) {
        if (!(pTxBD->status & BD_ACT)) {  /* Tx OK */
            pTxBD->len = 0;
            pTxBuf = pTxBD->buf_p;
            return E_OK;
        }
      #ifdef EXCLUSIVE_CTRL
        psw = vdis_psw();
        tx_wtskid = vget_tid();
        vcan_wup();
        vset_psw(psw);
        ercd = tslp_tsk(tmout);
        psw = vdis_psw();
        vcan_wup();
        tx_wtskid = 0;
        vset_psw(psw);
      #else
        tx_wtskid = vget_tid();
        vcan_wup();
        ercd = tslp_tsk(tmout);
        vcan_wup();
        tx_wtskid = 0;
      #endif
        if (ercd != E_OK && ercd != E_TMOUT)    /* by forced wake up */
            return -1;          /* as error */
        if (ercd == E_TMOUT)
            break;
    }
    return ercd;
}

/*****************************************************************************
* ��M�p�P�b�g���𓾂�
*
******************************************************************************/

ER lan_get_len(UH *len)
{
    if (!pRxBD2)
        *len = 0;
    else
        *len = pRxBD2->len;
    return E_OK;
}

/*****************************************************************************
* ��M�p�P�b�g�ǂݏo��
*
* buf   �ǂݏo�����߂̃o�b�t�@
* len   �ǂݏo���o�C�g��
******************************************************************************/

ER lan_get_pkt(void *buf, int len)
{
    if (!pRxBuf)  /* no available RxBD */
        return -1;

    memcpy(buf, pRxBuf, len);
    pRxBuf += len;
    return E_OK;
}

/*****************************************************************************
* ��M�p�P�b�g�ǂݏo���I��
*
******************************************************************************/

ER lan_get_end()
{
    if (pRxBD2) {
        pRxBD2->len    = 0;
        pRxBD2->status = (pRxBD2->status & BD_DL);
        WUP_TX();  /* indicated to Tx */
    }
    pRxBD2 = NULL;
    pRxBuf = NULL;
    return E_OK;
}

/*****************************************************************************
* ��M�p�P�b�g�ǂݔ�΂�
*
* len   ��M�p�P�b�g�̖��ǃo�C�g��
******************************************************************************/

ER lan_skp_pkt(int len)
{
    int remain;

    if (!pRxBD2)  /* no available RxBD */
        return E_OK;

    remain = (int)((UW)pRxBuf - (UW)pRxBD2->buf_p);  /* �ǂݏo������ */
    remain = (int)((UINT)pRxBD2->len) - remain;      /* �c�萔 */
    if (remain > 0) {
        if (remain <= len) {
            pRxBD2->len    = 0;
            pRxBD2->status = (pRxBD2->status & BD_DL);
            pRxBD2 = NULL;
            pRxBuf = NULL;
            WUP_TX();  /* indicated to Tx */
        }
        else {
            pRxBuf += len;
        }
    }
    else {
        pRxBD2->len    = 0;
        pRxBD2->status = (pRxBD2->status & BD_DL);
        pRxBD2 = NULL;
        pRxBuf = NULL;
        WUP_TX();  /* indicated to Tx */
    }
    return E_OK;
}

/*****************************************************************************
* ���M�p�P�b�g����ݒ�
*
******************************************************************************/

ER lan_set_len(int len)
{
    if (!pTxBuf)
        return -1;

    pTxBD->len = len;
    return E_OK;
}

/*****************************************************************************
* ���M�p�P�b�g��������
*
* data      �������ރf�[�^
* len       �f�[�^�̃o�C�g���i> 0�j
******************************************************************************/

ER lan_put_pkt(const void *data, int len)
{
    if (!pTxBuf)
        return -1;

    memcpy(pTxBuf, data, len);
    pTxBuf += len;
    return E_OK;
}

/*****************************************************************************
* ���M�p�P�b�g��60�o�C�g�����̏ꍇ�̃_�~�[��������
*
* len       �_�~�[�f�[�^�̃o�C�g���i> 0�j
******************************************************************************/

ER lan_put_dmy(int len)
{
    if (!pTxBuf)
        return -1;

    memset(pTxBuf, 0, len);
    pTxBuf += len;
    return E_OK;
}

/*****************************************************************************
* ���M�p�P�b�g�������ݏI��
*
******************************************************************************/

ER lan_put_end(void)
{
    pTxBD->status = ((pTxBD->status & BD_DL)|BD_ACT);
                                 /* changed active of Fin. BD */
    pTxBD = pTxBD->next;         /* set next BD to current */
    WUP_RX();                    /* indicated to Rx */

    return E_OK;
}
#else

/*****************************************************************************
* Terminate the interface
*
******************************************************************************/

ER lan_ext_dev(void)
{
    return E_OK;
}
#endif
/* end */
