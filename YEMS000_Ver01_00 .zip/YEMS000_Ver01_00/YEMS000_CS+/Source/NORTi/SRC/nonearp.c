/******************************************************************************
* NORTi TCP/IP Stack - ARP Module                                             *
*                                                                             *
*  Copyright (c) 1999-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-12 Created                                                          *
* 2001-01-22 Added support for multi home and multi channel                   *
* 2001-02-13 Corrected ARP entry overlfow                                     *
* 2003-04-14 Added arp_req_retry, ini_arp_tab, clr_arp_tab,                   *
*                                  arp_add_entry, arp_del_entry functions     *
* 2004-04-20 Corrected ARP cache updating for new entries in set_arp_tab      *
* 2004-10-25 Modified arp_req_retry modified                               PK *
* 2005-04-04 ARP table seperated for each interface                        AK *
* 2005-05-10 Modified arp_def_cbk for interface check                      AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2005-09-29 Fixed arp_res_reception() to send pending packet immediately     *
*             when receiving ARP res. from gateway, w/o ARP timer waiting  AK *
* 2007-07-12 Corrected arp_req_reception()                                 OK *
*                   In the response, pkt->sha is used for the DEST-MAC        *
* 2008-03-04 Replaced tcpip_critical() from tcpip_cretical() of old-style  OK *
* 2008-04-24 Modified chk_callback()                                       OM *
*              the ARP packet is able to be checked                           *
*            Created arp_rel_pkt()                                            *
* 2008-10-16 The blank at the end of line is deleted                       FY *
* 2008-11-30 is_my_ipaddr: Modified for IGMPv3 Source filtering            GS *
* 2009-02-03 Modified arp_del_byname                                       IS *
* 2009-02-03 Modified clr_arp_entry                                        IS *
* 2009-09-02 Modified processing ARP packet from the same IP address       KZ *
* 2009-09-02 Fixed ARP table info mismatching between SNMP and TCP/IP      KZ *
* 2009-12-21 Fixed packet misorder when new data is transmitted               *
*                                immediately after receiving ARP reply     KZ *
* 2010-01-14 Fixed the problem that a number of ARP table entry of same       *
*            IP address is created by arp_add_entry() and arp_add_byname() KZ *
* 2010-07-14 Replaced wait macro with MSEC2TICK macro                      FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2012-03-28 Changed packet read size from 46 to 28 bytes in arp_reception FY *
* 2012-03-28 Removed unnecessary clear to zero of pkt->tpa in arp_request  FY *
* 2012-03-28 Removed unnecessary static declaration of n in set_arp_table  FY *
* 2012-06-08 Added static routing support when multiple gateways are used  GS *
* 2014-07-04 Fixed arp_reception() not to add different network ARP entry  FY *
* 2014-10-20 Removed ini_arp_table(), and modified ARP table access        FY *
* 2015-05-27 Added NIF type check before ARP table access and style adjust PB *
* 2015-07-02 Made arp_reception() accept ARP from gateway on diff network  FY *
* 2015-07-08 Canceled ini_arp_table() removing, and made it usable as API  FY *
* 2015-08-05 Fixed nif_ini_arp() to skip initialization ARP table             *
*                                             when nif->arp_table is NULL  FY *
* 2015-11-13 Added missing NULL check of nif->arp_table in val_arp_table() FY *
* 2018-04-27 Fixed set_arp_table NULL access when all ARP elapsed time = 0 FY *
* 2021-06-08 Moved IP send task waking code to wup_snd_tsk() in nontip.c   FY *
* 2021-06-22 Merged arp_req_retry()'s ARP retry process to val_arp_table() FY *
* 2021-06-22 Removed unworking code for ARP flood in ref_arp_table_sub()   FY *
* 2021-06-22 Added ref_macaddr() called from ip_set_hdr4() for ARP request FY *
* 2021-06-22 Modifiled set_arp_table() to manage timeout of each ARP reply FY *
* 2021-06-22 Changed ARP retry queue from mailbox (nif->rmbxid) to            *
*                   linked list (nif->arp_waiting) in arp_res_reception()  FY *
* 2021-06-22 Removed arp_request() 3rd param CEP unused in new retry way   FY *
* 2021-06-22 Made arp_reception() update existing entry when GARP received,   *
*              and accept differrent network ARP only via default gateway  FY *
* 2021-09-15 Added multi/broadcast check to discard it in arp_reception()  FY *
* 2022-04-05 Gathered ARP entry clear process to clr_arp_entry_sub(), and     *
*             added calling it when retry over occuers in val_arp_table()  FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

const UB unknown_addr[]   = { 0, 0, 0, 0, 0, 0 };
const UB eth_broad_addr[] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static void clr_arp_entry_sub(T_ARP_TABLE *);
static UW search_gateway(T_NIF *, UW);

/******************************************************************************
* Module Name   : arp_internal_error                                          *
* Purpose       : This function is called by ARP layer whenever an internal   *
*                 error occurs. The DEBUG option must be enabled for this.    *
* Arguments     : ER ercd - Error code.                                       *
* Return value  : Returns a value after process the Error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

#ifndef DEBUG
ER arp_internal_error(ER ercd)
{
    return tcpip_internal_error(ercd);
}
#endif

/******************************************************************************
* Module Name   : ini_arp_table                                               *
* Purpose       : This function initializes all ARP caches with default       *
*                 values.                                                     *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER ini_arp_table(void)
{
    T_NIF* nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_default();
    while (nif) {
        nif_ini_arp(nif);
        nif = nif->next;
    }

    return tcpip_critical(FALSE, &save_pri);
}

/******************************************************************************
* Module Name   : nif_ini_arp                                                 *
* Purpose       : This function initializes specified NIF's ARP cache with    *
*                 default values.                                             *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

void nif_ini_arp(T_NIF *nif)
{
    T_ARP_TABLE *t;
    int i;

    t = nif->arp_table;
    if (t == NULL)
        return;
    for (i = 0; i < ARP_TABLE_CNT; i++)
        clr_arp_entry_sub(t++);
}

/******************************************************************************
* Module Name   : val_arp_table                                               *
* Purpose       : This function periodically checks the ARP cache timeout. If *
*                 any entry other than static entry is timed out then it will *
*                 be cleared from cache.                                      *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

void val_arp_table(void)
{
    T_ARP_TABLE *t;
    UW ctime, rtime;
    T_NIF *nif;
    int i;

    ctime = ip_timer;

    /* check elapsed time for ARP entry */
    for (nif = getnif_default(); nif != NULL; nif = nif->next) {
        if (nif->type != NI_ETH)
            continue;
        t = nif->arp_table;
        if (t == NULL)
            continue;
        for (i = 0; i < ARP_TABLE_CNT; i++, t++) {
            if (t->ipaddr == 0 || t->atype == ARP_STATIC)
                continue;
            rtime = ctime - t->etime;

            if (memcmp(t->macaddr, unknown_addr, 6) == 0) {
                /* check ARP entry timed out */
                if (rtime >= ARP_RET_INTVAL * (1 + t->rtycnt)) {
                    if (t->rtycnt++ >= ARP_RETRY) {
                        arp_retry_over(nif, t->ipaddr);
                        SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);
                        clr_arp_entry_sub(t);
                    } else {
                        arp_request(nif, t->ipaddr);
                    }
                }
            } else {
                /* check for ARP cache timeout */
                if (rtime >= ARP_CACHE_TOUT) {
                    SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);
                    clr_arp_entry_sub(t);
                } else {
                    rtime = ctime - t->ftime;
                    /* check for ARP flood timeout */
                    if (rtime >= ARP_FLUSH_TOUT) {
                        SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);
                        clr_arp_entry_sub(t);
                    }
                }
            }
        }
    }
}

/******************************************************************************
* Module Name   : ref_arp_table                                               *
* Purpose       : This function is used to search an ip and mac address pair  *
*                 in the ARP cache.                                           *
* Arguments     : T_NIF *nif  - Network Interface address.                    *
*                 UB *macaddr - Hardware address to be searched.              *
*                 UW ipaddr   - IP address to be searched.                    *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

static ER ref_arp_table_sub(T_NIF *nif, UB *macaddr, UW ipaddr)
{
    T_ARP_TABLE *t;
    int i;

    t = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        if (t->ipaddr == ipaddr) {
            if (memcmp(t->macaddr, unknown_addr, 6) != 0) {
               if (macaddr != NULL)
                   memcpy(macaddr, t->macaddr, 6);
                t->etime = ip_timer;
                return E_OK;
            }
            return E_PAR;       /* waiting ARP response */
        }
        t++;
    }
    return E_OBJ;
}

ER ref_arp_table(T_NIF *nif, UB *macaddr, UW ipaddr)
{
    if (nif->type != NI_ETH)
        return E_OBJ;

    if (!is_same_network(nif, ipaddr)) {
        ipaddr = search_gateway(nif, ipaddr);
        if (ipaddr == 0) {
            ipaddr = byte4_to_long(nif->gateway);
            if (ipaddr == 0)
                return E_OBJ;
        }
    }

    return ref_arp_table_sub(nif, macaddr, ipaddr);
}

/******************************************************************************
* Module Name   : ref_macaddr                                                 *
* Purpose       : This function is used to get MAC address                    *
* Arguments     : T_NIF *nif  - Network Interface address.                    *
*                 UB *macaddr - Hardware address to be searched.              *
*                 UW ipaddr   - IP address to be searched.                    *
* Return value  : E_OK on success otherwise returns error code.               *
*                 -1 wait for ARP response                                    *
* Author        : FY                                                          *
* Date          : 2020                                                        *
******************************************************************************/

ER ref_macaddr(T_NIF *nif, UB *macaddr, UW ipaddr)
{
    ER ercd;
    if ((ercd = ref_arp_table(nif, macaddr, ipaddr)) != E_OBJ)
        return ercd;

    if (arp_request(nif, ipaddr)) {
        set_arp_table(nif, ipaddr, unknown_addr);
        return E_PAR;
    }

    return E_OBJ;
}

/******************************************************************************
* Module Name   : set_arp_table                                               *
* Purpose       : This function updates the specified ipaddr and mac address  *
*                 in the ARP cache. If ARP cache is full then an old entry    *
*                 will be deleted. This function also validates the ARP entry *
*                 before update it to the ARP cache.                          *
* Arguments     : T_NIF *nif  - Network Interface address.                    *
*                 UW ipaddr   - IP address to be updated.                     *
*                 UB *macaddr - Hardware address to be updated.               *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

void set_arp_table(T_NIF *nif, UW ipaddr, const UB *macaddr)
{
    T_ARP_TABLE *t, *t2;
    int i;
    UW rtime;

    /* should not add an invalid IP address */
    if (ipaddr == 0 || is_broadcast(nif, ipaddr))
        return;

    /* should not add an invalid MAC address */
    if (macaddr == NULL)
        return;

    /* update if entry already exists */
    t = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        if (t->ipaddr == ipaddr) {
            /* should not update STATIC entries */
            if (t->atype == ARP_STATIC)
                return;
            goto L2;
        }
        t++;
    }

    /* search for empty entry */
    t = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        if (t->ipaddr == 0)
            goto L1;
        t++;
    }

    /* if ARP cache is full then delete the oldest entry */
    rtime = 0;
    t2 = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        if (t2->atype != ARP_STATIC && ip_timer - t2->etime >= rtime) {
            t = t2;
            rtime = ip_timer - t2->etime + 1;
        }
        t2++;
    }

    SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);

    /* update the new values in the ARP cache */
L1:
    t->atype = ARP_DYNAMIC;
    t->ipaddr = ipaddr;
    t->rtycnt = 0;
    SNMP_UPDNTM(SNMP_NTMT_DYNAMIC, nif->ch, t->ipaddr, (UB *)macaddr);
L2:
    if (memcmp(t->macaddr, macaddr, 6)) {
        memcpy(t->macaddr, macaddr, 6);
        /* set time for new entry */
        t->etime = ip_timer;
        /* set ARP force timeout */
        t->ftime = t->etime;
        SNMP_UPDNTM(SNMP_NTMT_DYNAMIC, nif->ch, t->ipaddr, t->macaddr);
    } else if (memcmp(macaddr, unknown_addr, 6) == 0) {
        /* set time for ARP retry */
        t->etime = ip_timer;
    }
}

/******************************************************************************
* Module Name   : add_arp_entry                                               *
* Purpose       : To create an ipaddr-mac entry in the ARP table.             *
* Arguments     : T_NIF *nif  - Interface in which the entry to be made.      *
*                 UW ipaddr   - IP address to be added.                       *
*                 UB *macaddr - Hardware address to be added.                 *
*                 UW type     - Type of ARP entry. (Static or Dynamic)        *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER add_arp_entry(T_NIF *nif, UW ipaddr, UB *macaddr, UW type)
{
    T_ARP_TABLE *t, *t2, *free_entry;
    UW rtime;
    int i, n;
    ER ercd;

    if (nif == NULL)
        return E_OBJ;

    /* check host IP address */
    if (ipaddr == byte4_to_long(nif->ipaddr))
        return E_OBJ;

    /* check mac address and invalid IP address */
    if (macaddr == NULL || ipaddr == 0)
        return E_PAR;

    /* check ARP entry type */
    if (!(type == ARP_STATIC || type == ARP_DYNAMIC))
        return E_OBJ;

    ercd = E_OK;

    /* should not fill all ARP entries as STATIC */
    if (type == ARP_STATIC) {
        t = nif->arp_table;
        n = 2;
        for (i = 0; i < ARP_TABLE_CNT; i++) {
            if (t->atype == ARP_STATIC)
                n++;
            if (n > ARP_TABLE_CNT) {
                ercd = E_NOMEM;
                goto END1;
            }
            t++;
        }
    }

    /* search for a free entry and add in it */
    free_entry = NULL;
    t = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        /* IP address already exists, overwrite */
        if (t->ipaddr == ipaddr)
            goto END;
        /* check for free entry */
        else if (free_entry == NULL && t->ipaddr == 0)
            free_entry = t;
        t++;
    }
    if (free_entry != NULL) {
        t = free_entry;
        goto END;
    }

    /* no free space, find and use old ARP entry */
    rtime = 0;
    t2 = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        if (t2->atype != ARP_STATIC && ip_timer - t2->etime >= rtime) {
            t = t2;
            rtime = ip_timer - t2->etime + 1;
        }
        t2++;
    }

    SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);

END:
    /* copy the new entry values */
    memcpy(t->macaddr, macaddr, 6);
    t->ipaddr = ipaddr;
    t->atype = (UB)type;
    t->etime = ip_timer;
    t->ftime = t->etime;
    if (type == ARP_STATIC) {
        SNMP_UPDNTM(SNMP_NTMT_STATIC, nif->ch, ipaddr, macaddr);
    } else {
        SNMP_UPDNTM(SNMP_NTMT_DYNAMIC, nif->ch, ipaddr, macaddr);
    }
END1:
    return ercd;
}

/******************************************************************************
* Module Name   : clr_arp_entry                                               *
* Purpose       : To delete an ipaddr-mac entry from the ARP table.           *
* Arguments     : T_NIF *nif - Interface in which the entry is to be searched *
*                 UW ipaddr  - IP address to be deleted.                      *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER clr_arp_entry(T_NIF *nif, UW ipaddr)
{
    T_ARP_TABLE *t;
    int i;

    if (nif == NULL || nif->type != NI_ETH)
        return E_PAR;

    if (ipaddr == 0)
        return E_OBJ;

    /* search and remove the entry from ARP table */
    t = nif->arp_table;
    for (i = 0; i < ARP_TABLE_CNT; i++) {
        /* check for IP address */
        if (t->ipaddr == ipaddr) {
            SNMP_UPDNTM(SNMP_NTMT_DELETE, nif->ch, t->ipaddr, t->macaddr);
            clr_arp_entry_sub(t);
            return E_OK;
        }
        t++;
    }

    return E_OBJ;
}

static void clr_arp_entry_sub(T_ARP_TABLE *t)
{
    t->ipaddr = t->etime = t->ftime = 0;
    t->atype = ARP_UNKNOWN;
    memset(t->macaddr, 0, 6);
}

/******************************************************************************
* Module Name   : arp_rel_pkt                                                 *
* Purpose       : return of ARP packet.                                       *
* Arguments     : T_ARP *pkt - Pointer to the ARP packet.                     *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

ER arp_rel_pkt(T_ARP *pkt)
{
    return rel_mpf(pkt->ctl.mpfid, pkt);
}

/******************************************************************************
* Module Name   : chk_callback                                                *
* Purpose       : This function invokes if any callback function defined for  *
*                 ARP process whenever it receives an invalid packet.         *
* Arguments     : T_ARP *pkt - Pointer to the invalid packet.                 *
* Return value  : NULL - If return value of callback function is NULL         *
*                 ARP packet - return the packet if other than NULL           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static VP chk_callback(T_ARP *pkt)
{
    ARP_CALLBACK func;
    T_ARP_CB *b;

    b = pARP_CB;
    while (b != NULL) {
        func = (ARP_CALLBACK)b->callback;
        if (func != (ARP_CALLBACK)NULL)
            if ((pkt = (*func)(pkt)) == NULL)
                return pkt;
        b = b->next;
    }
    return pkt;
}

/******************************************************************************
* Module Name   : arp_req_reception                                           *
* Purpose       : This function will be called whenever host receives an ARP  *
*                 request packet. This function process the request and sends *
*                 a ARP reply in response.                                    *
* Arguments     : T_ARP *pkt - Received ARP packet.                           *
* Return value  : NULL on success or returns the packet if any error occurs.  *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static VP arp_req_reception(T_ARP *pkt)
{
    UW ipaddr;
    ER ercd;
    T_NIF *nif;

    nif = pkt->ctl.nif;

    ipaddr = byte4_to_long(pkt->tpa);

    if (!is_my_ipaddr(nif, ipaddr, 0))
        return chk_callback(pkt);

    pkt->ope = htons(ARP_RES);
    memcpy(pkt->tha, pkt->sha, 6);          /* target hardware address */
    memcpy(pkt->tpa, pkt->spa, 4);          /* target protocol address */

    memcpy(pkt->eth.da, pkt->sha, 6);       /* DA(MAC) replace to SHA */

    memcpy(pkt->sha, nif->hwaddr, 6);       /* source hardware address */
    long_to_byte4(pkt->spa, ipaddr);        /* source protocol address */

    pkt->eth.etype = htons(ETYPE_ARP);

    SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifInNUcastPkts, 1);

    ercd = snd_mbx(nif->smbxid, (T_MSG *)pkt);
    if (ercd != E_OK) {
        arp_internal_error(ercd);
        return pkt;
    }
    return NULL;
}

/******************************************************************************
* Module Name   : arp_res_reception                                           *
* Purpose       : This function will be called whenever host receives an ARP  *
*                 reply packet. This function checks the IP retry mail box    *
*                 for any pending packet is waiting for this ARP reply.       *
* Arguments     : T_ARP *pkt - Received ARP packet.                           *
* Return value  : Returns the ARP packet.                                     *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
*               : 2005/Sep/29 Processing of Gateway reply is corrected    A.K *
******************************************************************************/

static VP arp_res_reception(T_ARP *pkt)
{
    T_IP4 *pre, *p;
    T_NIF *nif;
    UW ipaddr, myip, mask, gateway;
    BOOL flg = FALSE;

    nif = pkt->ctl.nif;

    if (nif == NULL)
        return pkt;

    ipaddr  = byte4_to_long(pkt->spa);
    mask    = byte4_to_long(nif->mask);
    myip    = byte4_to_long(nif->ipaddr);
    gateway = byte4_to_long(nif->gateway);

    /* poll all the packets in the queue */
    pre = (T_IP4 *)&nif->arp_waiting;
    p = pre->next;
    while (p != NULL) {
        if (ntohl(p->ip.da) == ipaddr) {
            /* destination matches, send to ip_snd_tsk */
            pre->next = (VP)p->next;
            net_set_transmission_pkt(nif, (T_CTL_PKT*)p);
            p = (T_IP4 *)pre->next;
            flg = TRUE;
        } else if (gateway == ipaddr && ((ntohl(p->ip.da) & mask) != (myip & mask))) {
            /* gateway reply, send any pending packet with different network */
            pre->next = (VP)p->next;
            net_set_transmission_pkt(nif, (T_CTL_PKT*)p);
            p = (T_IP4 *)pre->next;
            flg = TRUE;
        } else {
            pre = p;
            p = (T_IP4 *)p->next;
        }
    }

    /* when the packet was set to the queue of packet that retries transmission
       and send mailbox is empty, send the message to wake IP send task up. */
    if (flg == TRUE)
        wup_snd_tsk(nif);

    return pkt;
}

/******************************************************************************
* Module Name   : arp_reception                                               *
* Purpose       : This function will be called by IP receive task whenever an *
*                 ARP packet is received. It process the ARP packet and also  *
*                 updates the ARP cache if required.                          *
* Arguments     : T_ARP *pkt - Received ARP packet.                           *
* Return value  : Returns the ARP packet.                                     *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

VP arp_reception(T_ARP *pkt)
{
    T_NIF *nif;
    UW spa, tpa;

    nif = pkt->ctl.nif;

    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, &pkt->htype, ARP_HEADER_SZ, ARP_HEADER_SZ))
        return pkt;

    if (ntohs(pkt->htype) != 1
     || ntohs(pkt->ptype) != ETYPE_IP4
     || pkt->hlen != 6
     || pkt->plen != 4)
        return pkt;

    /* discard if NIF is not Ethernet type */
    if (nif->type != NI_ETH)
        return pkt;

    /* discard if sender MAC address is invalid */
    if (memcmp(pkt->sha, eth_broad_addr, 6) == 0)
        return pkt;

    /* discard if sender and host have the same MAC address */
    if (memcmp(pkt->sha, nif->hwaddr, 6) == 0)
        return pkt;

    /* discard if sender and host have the same IP address */
    if (memcmp(pkt->spa, nif->ipaddr, 4) == 0) {
        /* interrupt if chk_callback returns NULL */
        if ((pkt = chk_callback(pkt)) == NULL)
            return pkt;

        if (ntohs(pkt->ope) == ARP_REQ) {
            /* receiving an ARP request packet, the arp module(this) sends
               an arp reply packet. */
            memcpy(pkt->tpa, nif->ipaddr, 4);
            pkt = arp_req_reception(pkt);
        }
        return pkt;
    }

    /* discard if target IP address is multi/broadcast address */

    tpa = byte4_to_long(pkt->tpa);
    if ((tpa & 0xF0000000) == 0xE0000000 ||
        is_broadcast(nif, tpa))
        return pkt;

    /* update existing entry or add new entry */

    spa = byte4_to_long(pkt->spa);
    if (spa == 0) { /* gratuitous ARP */
        spa = tpa;
        if (ref_arp_table(nif, NULL, spa) != E_OBJ)
            set_arp_table(nif, spa, pkt->sha);
        return pkt;
    }

    if (is_same_network(nif, spa) || spa == byte4_to_long(nif->gateway)) {
        if (ref_arp_table_sub(nif, NULL, spa) != E_OBJ || is_my_ipaddr(nif, tpa, 0))
            set_arp_table(nif, spa, pkt->sha);
        if (ntohs(pkt->ope) == ARP_RES)
            return arp_res_reception(pkt);
    }
    if (ntohs(pkt->ope) == ARP_REQ)
        return arp_req_reception(pkt);
    return pkt;
}

/******************************************************************************
* Module Name   : arp_request                                                 *
* Purpose       : This function constructs an ARP request with specified IP   *
*                 address and transmits it to the IP send message box.        *
* Arguments     : T_NIF *nif - Network interface address.                     *
*                 UW ipaddr  - Destination IP address.                        *
* Return value  : TRUE on success or returns FALSE.                           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

BOOL arp_request(T_NIF *nif, UW ipaddr)
{
    T_ARP *pkt;
    UW mask, gateway, myip, gw;
    ER ercd;

    mask    = byte4_to_long(nif->mask);
    myip    = byte4_to_long(nif->ipaddr);
    gateway = byte4_to_long(nif->gateway);
    if ((ipaddr & mask) != (myip & mask)) {
        gw = search_gateway(nif, ipaddr);
        if (gw != 0) {
            ipaddr = gw;       /* static route */
        } else {
            if (gateway != 0) {
                ipaddr = gateway;
            } else {
                arp_internal_error(-1);
                return FALSE;
            }
        }
    }

    ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
    if (ercd != E_OK) {
        if (ercd != E_TMOUT)
            arp_internal_error(ercd);
        return FALSE;
    }
    memset(pkt, 0, sizeof (T_ARP));
    pkt->ctl.mpfid = (H)ID_ETH_MPF;
    pkt->ctl.nif = nif; /* 11Jan2005 TCP_EXT */

    pkt->eth.len = ARP_PACKET_SZ;
    memset(pkt->eth.da, -1, 6);
    memcpy(pkt->eth.sa, nif->hwaddr, 6);
    pkt->eth.etype = htons(ETYPE_ARP);

    pkt->htype = htons(1);
    pkt->ptype = htons(ETYPE_IP4);
    pkt->hlen = 6;
    pkt->plen = 4;
    pkt->ope = htons(ARP_REQ);
    memcpy(pkt->sha, nif->hwaddr, 6);
    memcpy(pkt->spa, nif->ipaddr, 4);       /* local IP address */

    long_to_byte4(pkt->tpa, ipaddr);

    SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutNUcastPkts, 1);
    SNMP_BYPCNT(snmp_mibbyp_ifX[nif->ch].ifOutBroadcastPkts, 1);
    SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutBroadcastPkts, 1);

    ercd = snd_mbx(nif->smbxid, (T_MSG *)pkt);
    if (ercd != E_OK) {
        arp_internal_error(ercd);
        ercd = rel_mpf(pkt->ctl.mpfid, pkt);
        if (ercd != E_OK) {
            arp_internal_error(ercd);
            dly_tsk(MSEC2TICK(1000));
        }
        return FALSE;
    }
    return TRUE;
}

/******************************************************************************
* Module Name   : arp_def_cbk                                                 *
* Purpose       : This function is used to add or remove a callback function  *
*                 for ARP process.                                            *
* Arguments     : T_ARP_CB *b           - ARP callback control block.         *
*                 ARP_CALLBACK callback - Callback function.                  *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER arp_def_cbk(T_ARP_CB *b, ARP_CALLBACK callback)
{
    T_ARP_CB *bb, *bbb;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK; /* no interface available */
    }

    bbb = (T_ARP_CB *)&pARP_CB;
    bb = bbb->next;

    /* remove IP control block if callback is NULL */
    if (callback == (ARP_CALLBACK)NULL) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;
                break;
            }
            bbb = bb;
            bb = bb->next;
        }
    } else {
        /* chain IP control block */
        b->callback = (FP)callback;
        for (;;) {
            if (bb == NULL) {
                b->next = NULL;
                bbb->next = b;
                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }

    return tcpip_critical(FALSE, &save_pri);
}

/******************************************************************************
* Module Name   : arp_snd_req                                                 *
* Purpose       : ARP API to send an ARP request from the default interface.  *
* Arguments     : UW ipaddr  - Destination ip address.                        *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_snd_req(UW ipaddr)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    if (ipaddr == 0)
        return E_PAR;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_default();
    while (nif) {
        if (nif->type == NI_ETH)
            break;
        nif = nif->next;
    }

    if (nif == NULL) {
        ercd = E_OBJ;
        goto END;
    }

    if (arp_request(nif, ipaddr))
        ercd = E_OK;
    else
        ercd = E_OBJ;

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : arp_req_byname                                              *
* Purpose       : ARP API to send an ARP request from specific interface.     *
* Arguments     : const char *name - Interface to be used to send ARP packet. *
*                 UW ipaddr        - Destination ip address.                  *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_req_byname(const char *name, UW ipaddr)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    if (ipaddr == 0)
        return E_PAR;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_from_name(name);
    if (nif == NULL) {
        ercd = E_OBJ;
        goto END;
    }

    if (arp_request(nif, ipaddr))
        ercd = E_OK;
    else
        ercd = E_OBJ;

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : arp_add_entry                                               *
* Purpose       : ARP API to create an ipaddr-mac entry in ARP Table.         *
* Arguments     : UW ipaddr   - ipaddress to be added.                        *
*                 UB *macaddr - Hardware address to be added.                 *
*                 UW type     - Type of ARP entry. (Static or Dynamic)        *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_add_entry(UW ipaddr, UB *macaddr, UW type)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_default();
    while (nif) {
        if (nif->type == NI_ETH)
            break;
        nif = nif->next;
    }

    if (nif == NULL) {
        ercd = E_OBJ;
        goto END;
    }

    ercd = add_arp_entry(nif, ipaddr, macaddr, type);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : arp_add_byname                                              *
* Purpose       : ARP API to create an ipaddr-mac entry in ARP Table.         *
* Arguments     : const char *name - Interface to create the entry.           *
*                 UW ipaddr   - ipaddress to be added.                        *
*                 UB *macaddr - Hardware address to be added.                 *
*                 UW type     - Type of ARP entry. (Static or Dynamic)        *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_add_byname(const char *name, UW ipaddr, UB *macaddr, UW type)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_from_name(name);
    if (nif == NULL || nif->type != NI_ETH) {
        ercd = E_OBJ;
        goto END;
    }

    ercd = add_arp_entry(nif, ipaddr, macaddr, type);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}


/******************************************************************************
* Module Name   : arp_del_entry                                               *
* Purpose       : ARP API to delete the ipaddr-mac entry from ARP Table.      *
* Arguments     : UW ipaddr   - ipaddress to be deleted.                      *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_del_entry(UW ipaddr)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_default();
    while (nif) {
        if (nif->type == NI_ETH)
            break;
        nif = nif->next;
    }

    if (nif == NULL) {
        ercd = E_OBJ;
        goto END;
    }

    ercd = clr_arp_entry(nif, ipaddr);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : arp_del_byname                                              *
* Purpose       : ARP API to delete the ipaddr-mac entry from ARP Table.      *
* Arguments     : const char *name - Interface to delete the entry.           *
*                 UW ipaddr   - ipaddress to be deleted.                      *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : AK                                                          *
* Date          : 2005                                                        *
******************************************************************************/

ER arp_del_byname(const char *name, UW ipaddr)
{
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_from_name(name);
    if (nif == NULL) {
        ercd = E_OBJ;
        goto END;
    }

    ercd = clr_arp_entry(nif, ipaddr);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Initialize Routing Table
*
******************************************************************************/

void ini_route_table(void)
{
    int i;

    for (i = 0; i < ROUTE_TABLE_CNT; i++) {
        route_table[i].nif = NULL;
        route_table[i].dstnet = 0;
        route_table[i].netmask = 0;
        route_table[i].gwaddr = 0;
    }
    return;
}

/*****************************************************************************
* Select Gateway Address
*
******************************************************************************/

static UW search_gateway(T_NIF *nif, UW ipaddr)
{
    int i;

    for (i = 0; i < ROUTE_TABLE_CNT; i++) {
        if (route_table[i].nif == nif &&
            (route_table[i].netmask & ipaddr) == route_table[i].dstnet)
            return route_table[i].gwaddr;
    }
    return 0;
}

/*****************************************************************************
* Add IPv4 Static Route
*
******************************************************************************/

ER add_route(T_NIF *nif, UW dstnet, UW netmask, UW gwaddr)
{
    /* adds static route to routing table
       returns E_OBJ, if route already exists
       returns E_NOID, if routing table is full. */

    int i, j;
    ER  ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (nif == NULL) {
        nif = getnif_default();
        if (nif == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
    }

    j = -1;
    for (i = 0; i < ROUTE_TABLE_CNT; i++) {
        if (route_table[i].nif == nif && route_table[i].netmask == netmask &&
            route_table[i].dstnet == (dstnet & netmask)) {
           tcpip_critical(FALSE, &save_pri);
           return E_OBJ;       /* route already exists */
        }
        if (j == -1 && route_table[i].nif == NULL)
            j = i;
    }

    if (j != -1) {
        route_table[j].nif = nif;
        route_table[j].dstnet = dstnet & netmask;
        route_table[j].netmask = netmask;
        route_table[j].gwaddr = gwaddr;
    } else {
        ercd = E_NOID;
    }
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Delete IPv4 Static Route
*
******************************************************************************/

ER del_route(T_NIF *nif, UW dstnet, UW netmask)
{
    /* deletes static route from routing table
       returns E_NOEXS, if route does not exist */

    int i;
    ER  ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (nif == NULL) {
        nif = getnif_default();
        if (nif == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
    }

    for (i = 0; i < ROUTE_TABLE_CNT; i++) {
        if (route_table[i].nif == nif && route_table[i].netmask == netmask &&
            route_table[i].dstnet == (dstnet & netmask)) {
            route_table[i].nif = NULL;
            route_table[i].dstnet = 0;
            route_table[i].netmask = 0;
            route_table[i].gwaddr = 0;
            tcpip_critical(FALSE, &save_pri);
            return E_OK;
        }
    }
    tcpip_critical(FALSE, &save_pri);
    return E_NOEXS;
}

/* end */
