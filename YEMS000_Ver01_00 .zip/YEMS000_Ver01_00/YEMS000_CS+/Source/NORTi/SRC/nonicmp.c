/******************************************************************************
* NORTi TCP/IP Stack - ICMP Module                                            *
*                                                                             *
*  Copyright (c) 1998-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1998-11-23 Created.                                                         *
* 2000-10-03 Ver. 4.02 Release                                                *
* 2001-01-22 Last Update. (Supported multi home and multi channel)            *
* 2002-01-31 Added support for IP reassembling (ICMP reception modified)      *
* 2002-11-29 Fixed Memory pool for IP reassembly                              *
* 2003-05-30 Modified icmp_snd_dat for Loop back interface                    *
* 2003-06-18 Modified icmp_reception for callback function                    *
* 2004-07-01 Modified for IPv6 Stack                                       PK *
* 2004-07-12 icmp_snd_dat updated for interface selection                     *
* 2005-04-04 Added tcpip_cretical in icmp_snd_dat                          AK *
* 2005-05-10 Modified ICMP API's for interface check                       AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2005-10-01 Fixed pkt->ctl.cep issue for icmp_snd_dat & icmp_can_snd      AK *
* 2006-07-28 Fixed checksum issue 0 Vs 0xFFFF                              AK *
* 2007-02-18 Modified for all ICMP packet through  to callback function    OK *
* 2008-03-04 Replaced tcpip_critical() from tcpip_cretical() of old-style  OK *
* 2008-10-16 The blank at the end of line is deleted.                      FY *
* 2008-11-30 is_my_ipaddr: Modified for IGMPv3 Source filtering            GS *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2012-07-05 Modified icmp_snd_data to get NIF with static route to remote FY *
* 2012-11-13 Modified icmp_checksum(), icmp_reception()                       *
*                         and icmp_reception() with change of IP fragment  FY *
* 2012-11-13 Simplified function title                                     FY *
* 2012-11-13 Added parameter check for ICMP data length in icmp_snd_dat()  GS *
* 2019-06-19 Added deq_frag_list() calling in icmp_echo_req_reception()    FY *
* 2021-06-22 Changed 2nd parameter type of remove_???() ID -> T_ETH        FY *
* 2021-06-22 Removed initialization of pkt->ctl.arprty                     FY *
* 2023-05-08 Added missing too short ICMP packet discarding by LAN driver  FY *
* 2023-05-08 Added missing SNMP icmpInErrors counting when ICMP receiving  FY *
* 2023-05-25 Corrected icmp_checksum() not to do word access with odd         *
*              address even when get_reassembly_buffer() returns odd size  FY *
* 2023-05-25 Fixed icmp_reception() to discard header-fragmented packet    FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/*****************************************************************************
* ICMP internal error
*
******************************************************************************/

#ifndef DEBUG
ER icmp_internal_error(ER ercd)
{
    return tcpip_internal_error(ercd);
}
#endif

/*****************************************************************************
* ICMP check sum
*
******************************************************************************/

static UH icmp_checksum(T_IP4 *pkt, UH len)
{
    UH *p;
    UW sum, sumf;
    UH offset, len2;

    sum = 0;

    if (pkt->ctl.rcheck) {  /* reassembly packet */
        /* compute checksum for reassembly packet */
        offset = 0;
        while (offset < len) {
            if (!get_reassembly_buffer((T_IPF *)pkt, offset, (VP *)&p, &len2))
                return (UH)-1;
            if (offset & 1) {
                sumf = (UW)*(UB *)p;
              #ifdef LITTLE_ENDIAN
                sumf <<= 8;
              #endif
                sum += sumf;
                p = (UH *)((UB *)p + 1);
                offset++;
                len2--;
            }
            offset += len2;
            if (len2 & 1) {
                sumf = (UW)*(UB *)((UW)p + len2 - 1);
              #ifndef LITTLE_ENDIAN
                sumf <<= 8;
              #endif
                sum += sumf;
            }
            len2 >>= 1;
            while (len2-- > 0)
                sum += *p++;
        }
    } else {
        p = (UH *)pkt->data;
        if (len & 1) {
            sum = *(UB *)((UW)p + len - 1);
          #ifndef LITTLE_ENDIAN
            sum <<= 8;
          #endif
        }
        len >>= 1;
        while (len-- > 0)
            sum += *p++;
    }

    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);

    return (UH)~sum;
}

/*****************************************************************************
* ICMP echo req reception
*
******************************************************************************/

static BOOL icmp_echo_req_reception(T_IP4 *pkt, T_ICMP_MSG *icmp, UH len)
{
    T_NIF *nif;
    UW a;
    ER ercd;

    nif = pkt->ctl.nif;

    if (icmp->code != 0)
        return FALSE;

    icmp->type = TYPE_ECHO_REP;
    icmp->cs = 0;
    icmp->cs = icmp_checksum(pkt, len);

    /* accept broadcast address */

    if (!is_broadcast(nif, ntohl(pkt->ip.da))) {
        a = pkt->ip.da;
        pkt->ip.da = pkt->ip.sa;
        pkt->ip.sa = a;
    } else {
        a = byte4_to_long(nif->ipaddr);
        pkt->ip.da = pkt->ip.sa;
        pkt->ip.sa = htonl(a);
    }

    memset(pkt->eth.da, 0, 6);
    pkt->eth.etype = htons(ETYPE_IP4);

    pkt->ctl.hedflg = FALSE;
    pkt->ip.ttl = (UB)IP_DEF_TTL;
    ercd = snd_mbx(nif->smbxid, (T_MSG *)pkt);
    if (ercd != E_OK) {
        icmp_internal_error(ercd);
        return FALSE;
    }
    if (pkt->ctl.rcheck)
        deq_frag_list((T_IPF *)pkt);
    SNMP_BYPCNT(snmp_mibbyp.icmpOutMsgs, 1);        /* icmpOutMsgs */
    SNMP_BYPCNT(snmp_mibbyp.icmpOutEchosReps, 1);   /* icmpOutEchosReps */

    return TRUE;
}

/*****************************************************************************
* ICMP reception
*
******************************************************************************/

T_IP4 *icmp_reception(T_IP4 *pkt)
{
    T_ICMP_MSG *icmp;
    T_ICMP_CB *b;
    ICMP_CALLBACK func;
    T_NIF *nif;
    UH len, ilen;

    nif = pkt->ctl.nif;

    SNMP_BYPCNT(snmp_mibbyp.icmpInMsgs, 1);         /* icmpInMsgs */

    /* read ICMP Message */

    if (pkt->ctl.rcheck) {
        len = ((T_IPF *)pkt)->tl;
        if (!get_reassembly_buffer((T_IPF *)pkt, 0, (VP *)&icmp, &ilen))
            return pkt;
        if (ilen < 4) {
            SNMP_BYPCNT(snmp_mibbyp.icmpInErrors, 1);   /* icmpInErrors */
            return pkt;
        }
    } else {
        if (ntohs(pkt->ip.tl) < IP4_HEADER_SZ + 4) {
            (*nif->func)(nif, TFN_NET_IGN_PKT);
            SNMP_BYPCNT(snmp_mibbyp.icmpInErrors, 1);   /* icmpInErrors */
            return pkt;
        }
        len = ntohs(pkt->ip.tl) - IP4_HEADER_SZ;
        icmp = (T_ICMP_MSG *)(pkt->data);
        if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, icmp, len, nif->path_mtu)) {
            SNMP_BYPCNT(snmp_mibbyp.icmpInErrors, 1);   /* icmpInErrors */
            return pkt;
        }
    }

    /* checksum */

    if (icmp_checksum(pkt, len) != 0) {
        SNMP_BYPCNT(snmp_mibbyp.icmpInErrors, 1);   /* icmpInErrors */
        return pkt;
    }

    /* ICMP Callback */

    b = pICMP_CB;
    while (b != NULL) {
        func = (ICMP_CALLBACK)b->callback;
        if (func != (ICMP_CALLBACK)NULL) {
            pkt = (*func)(b, pkt, icmp, len);
            if (pkt == NULL)
                return pkt;
        }
        b = b->next;
    }

    /* process ICMP message */

    switch (icmp->type) {
    case TYPE_ECHO_REQ:
        SNMP_BYPCNT(snmp_mibbyp.icmpInEchos, 1);    /* icmpInEchos */
        if (icmp_echo_req_reception(pkt, icmp, len))
            pkt = NULL; /* packet area sent */
        break;

    case TYPE_ECHO_REP:
        SNMP_BYPCNT(snmp_mibbyp.icmpInEchoReps, 1); /* icmpInEchoReps */
    default:
        break;
    }

    return pkt;
}

/*****************************************************************************
* ICMP define callback
*
******************************************************************************/

ER icmp_def_cbk(T_ICMP_CB *b, ICMP_CALLBACK callback)
{
    T_ICMP_CB *bb, *bbb;
    PRI save_pri;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK; /* No Interface available */
    }

    bbb = (T_ICMP_CB *)&pICMP_CB;
    bb = bbb->next;

    /* remove ICMP control block if 'callback' is NULL */

    if (callback == (ICMP_CALLBACK)NULL) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;
                break;
            }
            bbb = bb;
            bb = bb->next;
        }
    } else {

    /* chain ICMP control block */

        b->callback = (FP)callback;
        for (;;) {
            if (bb == NULL) {
                b->next = NULL;
                bbb->next = b;
                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }

    return tcpip_critical(FALSE, &save_pri);
}

/*****************************************************************************
* ICMP send data
*
******************************************************************************/

ER icmp_snd_dat(UW ipaddr, UW dstaddr, T_ICMP_HEADER *icmp, VP data, INT len)
{
    PRI save_pri;
    ER ercd;

    if (len < 0 || len > (PATH_MTU4 - sizeof(T_ICMP_HEADER)))
        return E_PAR;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (is_nif_exists(NULL))
        ercd = icmp_snd_data(ipaddr, dstaddr, icmp, data, len);
    else
        ercd = E_LNK; /* No interface available */

    tcpip_critical(FALSE, &save_pri);

    return ercd;
}

ER icmp_snd_data(UW ipaddr, UW dstaddr, T_ICMP_HEADER *icmp, VP data, INT len)
{
    T_IP4 *pkt;
    T_NIF *nif;
    ER ercd;

    if (len < 0 || len > (PATH_MTU4 - sizeof(T_ICMP_HEADER)))
        return E_PAR;

    /* get interface */

    if (ipaddr != IPV4_ADDRANY) {
        if ((nif = getnif_addr(ipaddr)) == NULL)
            return E_OBJ;
    } else {
        nif = getnif_dstaddr(dstaddr);
        if (nif == NULL)
            return E_OBJ;
    }

    if (is_my_ipaddr(nif, dstaddr, 0)) {
        /* send to loopback interface */
        if ((nif = getnif_loop()) == NULL)
            return E_OBJ;
    }

    ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
    if (ercd != E_OK) {
        SNMP_BYPCNT(snmp_mibbyp.icmpOutErrors, 1);  /* icmpOutErrors */
        return ercd;
    }
    memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
    pkt->ctl.mpfid = (H)ID_ETH_MPF;
    pkt->ctl.cep = icmp;    /* for cancel */
    pkt->ctl.nif = nif;     /* 11Jan2005 TCP_EXT */

    memcpy(pkt->data, icmp, sizeof (T_ICMP_HEADER));
    if (len > 0)
        memcpy(pkt->data + sizeof (T_ICMP_HEADER), data, len);
    len += sizeof (T_ICMP_HEADER);
    icmp = (T_ICMP_HEADER *)pkt->data;
    icmp->cs = 0;
    icmp->cs = icmp_checksum(pkt, len);

    pkt->ip.da = htonl(dstaddr);
    if (ipaddr == IPV4_ADDRANY)
        ipaddr = byte4_to_long(nif->ipaddr);
    pkt->ip.sa = htonl(ipaddr);

    pkt->ip.ver = 0x45;
    pkt->ip.tos = 0;
    pkt->ip.tl = htons(IP4_HEADER_SZ + len);
    pkt->ip.id = htons(ip_ident++);
    pkt->ip.fo = 0;
    pkt->ip.ttl = (UB)IP_DEF_TTL;
    pkt->ip.prot = PROT_ICMP;

    memset(pkt->eth.da, 0, 6);
    pkt->eth.etype = htons(ETYPE_IP4);

    pkt->ctl.hedflg = FALSE;

    SNMP_BYPCNT(snmp_mibbyp.icmpOutMsgs, 1);  /* icmpOutMsgs */

    if (icmp->type == TYPE_ECHO_REQ) {
        SNMP_BYPCNT(snmp_mibbyp.icmpOutEchos, 1);  /* icmpOutEchos */
    }

    return snd_mbx(nif->smbxid, (T_MSG *)pkt);
}

/*****************************************************************************
* ICMP cancel send
*
******************************************************************************/

ER icmp_can_snd(T_ICMP_HEADER *icmp)
{
    ER ercd;
    T_NIF *nif;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    nif = getnif_default();

    if (nif)
        remove_queued_packet(nif->smbxid, (T_ETH *)&nif->arp_waiting, icmp);
    else
        ercd = E_LNK;

    tcpip_critical(FALSE, &save_pri);

    return ercd;
}

/* end */
