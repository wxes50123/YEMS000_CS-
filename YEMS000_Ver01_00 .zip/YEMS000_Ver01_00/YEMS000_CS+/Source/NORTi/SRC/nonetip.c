/******************************************************************************
* NORTi TCP/IP Stack - IP Module                                              *
*                                                                             *
*  Copyright (c) 1999-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05 Created                                                          *
* 2000-10-03 Released as Ver.4.02                                             *
* 2000-12-01 Released as Ver.4.03                                             *
* 2001-01-22 Added support for multihome and multi channel                    *
* 2002-06-26 Added support for IP fragmentation and reassembly                *
* 2002-11-19 Fixed memorypool for IP reassembly                               *
* 2003-02-14 Added timer function for ARP and IP reassembly, and              *
*              modularized ip_snd_tsk() as ip_set_hd4() and ip_frag_pkt()     *
* 2002-03-30 Modified for loopback interface                                  *
* 2004-02-20 Corrected reception of ICMP broadcast packet in ip_reception()   *
* 2004-07-01 Modified for IPv6 stack                                       PK *
* 2004-10-28 Fixed ip_reception()                                          PK *
* 2005-04-04 Modified IP timer process, and added support for PPPoE           *
* 2005-05-10 Modified ip_def_cbk() for interface check                     AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2005-07-08 Added MLD timer check for IPv6                                GS *
* 2005-10-24 Modified to support PPPoE interface                           MK *
* 2006-03-03 Added support for IGMPv2                                      GS *
* 2006-07-22 Unified IPv6 related periodic checks into ip6_tmr_func()      GS *
* 2006-07-28 Fixed IP checksum check to accept both of 0x0000 and 0xFFFF   AK *
* 2006-07-29 Added SNMP support for IPv6                                   MK *
* 2007-02-27 Added counting udpOutDatagrams for non-blocking mode          EM *
* 2007-03-06 Marged 4.09.05 (internal version) & 4.09.04e (spot release)   OK *
* 2007-05-10 Changed parameter of callback function                        IH *
* 2007-05-29 Modified for directed-broadcast from DHCP relay agent         OK *
* 2008-03-04 Replaced tcpip_cretical() by nested callable tcpip_critical() OK *
* 2008-05-13 Tuned loop of searching UDP/TCP end points & reception points OM *
* 2008-06-30 Added support for RAW communication end point                 OM *
* 2008-07-15 Modified check of RAW communication end point                 OM *
* 2008-07-18 Adjusted indent of switch-case sentence                       GS *
* 2008-07-31 Modified to support PPPoE multi-session                       FY *
* 2008-10-16 Set IPv4 to indefinite Ethernet type before ip_reception()       *
*            call in ip_rcv_tsk() as it had problem when PPP on dual stack FY *
* 2008-10-16 Added connecting process before sending data in ip_snd_tsk()     *
*                         when auto connection is enabled on PPP or PPPoE  FY *
* 2008-10-16 Deleted some unnecessary spaces at end of line                FY *
* 2008-10-26 Modified for IPv6 stack                                       IS *
* 2008-11-30 Added support for IGMPv3                                      GS *
* 2009-02-03 Modified ip_frag_pkt()                                        IS *
* 2009-09-14 Stopped bad ARP reply on multicast by fixing mismatched return   *
*                value check of updated search_igmp_ip() in is_my_ipaddr() GS *
* 2009-11-11 Added clear to len1/len2 auto variables assignment in            *
*                  ip_snd_tsk() to avoid exeGCC warning of uninitializing  GS *
* 2009-12-21 Added net_get/set_transmission_pkt() call in ip_snd_tsk()        *
*                for fixing sending order of UDP packet when ARP overlaps  KZ *
* 2010-01-13 Fixed ip_set_hdr4() not to overwrite destination MAC address     *
*             on send packet header meaninglessly when it is 000000-00XXXX KZ *
* 2010-07-14 Replaced wait() macro with MSEC2TICK() macro                  FY *
* 2011-04-08 Fixed memory leak problem at IP fragment reassembly on PPP    KZ *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2012-02-06 Improved ipaddr retrieval speed when not using multi-home     FY *
* 2012-07-27 Added code to assign TTL to multicast packets in ip_set_hdr4  GS *
* 2012-11-13 Modified ip_snd_tsk() and ip_rcv_tsk() according to              *
*                         updated IP fragmentation and reassembly process  FY *
* 2012-11-13 Modified ip_frag_pkt() to omit data field copy                   *
*             when generating ICMP reply packet to fragmented ICMP request    *
*                 and when sending large UDP packet with IP fragmentation  FY *
* 2012-11-23 Moved setup of address and size of send data from                *
*                      ip_snd_tsk() to ip_set_hdr4(), and simplified them  FY *
* 2012-11-23 Minimized memory pool for send UDP packet queueing               *
*                by swapping data and IP header member in T_IP4 structure  FY *
* 2012-12-05 Removed int cast of ETH_HEADER_SZ casted in nonets.h             *
*                and int cast of IP4_HEADER_SZ unneeded at (*nif->func)()  FY *
* 2013-01-24 Added bad packet discard with total length in ip_reception()  FY *
* 2013-06-18 Added missing TCP timer process for updated PPPoE Ver.2.00    FY *
* 2013-06-18 Modified ip_set_hdr4() not to remove Ethernet header             *
*                                            for adapting PPPoE to IPv6CP  FY *
* 2015-06-01 Added timeout time calculation in ip_snd_tsk()                   *
*                 to reduce burden of TCP timeout check of each end point  FY *
* 2016-07-13 Added missing UH cast to htons() parameter in ip_frag_pkt()   MT *
* 2019-06-19 Moved received fragmented packets dequeue of ip_frag_pkt() into  *
*               icmp_echo_req_reception() to avoid re-sent packet problem  FY *
* 2019-06-19 Added missing unsent fragmented packets release in ip_snd_tsk FY *
* 2020-07-27 Moved updating of tcp_iss from ip_snd_tsk() to ip_rcv_tsk(),     *
*                     and modified it to randomize ISS with tickck_read()  FY *
* 2021-06-08 Added wup_snd_tsk() called by plural functions, and moved        *
*                  IP send task waking code from tcpip_timer_func() to it  FY *
* 2021-06-08 Removed TFN_IP_WAKE_UP process in ip_snd_tsk()                   *
*                               by commonizing with TFN_IP_TIM_ON process  FY *
* 2021-06-08 Corrected TFN_NET_WAI_SND loop in ip_snd_tsk() from              *
*                      do~while(0) & mistaken continue to for(;;) & break  FY *
* 2021-06-22 Fixed ip_snd_tsk() to call tcp_recover_retrans if queue lack  FY *
* 2021-06-22 Replaced ARP req code in ip_set_hdr4() with ref_macaddr call  FY *
* 2021-06-22 Separated modified ARP retry over process to arp_retry_over() FY *
* 2021-06-22 Removed arp_request() 3rd param CEP unused in new retry way   FY *
* 2021-06-22 Moved ARP retry process in ip_set_hdr4() to nonearp.c         FY *
* 2021-06-22 Removed arp_req_retry() call in ip_snd_tsk()                     *
*                     since ARP retry check was merged to val_arp_table()  FY *
* 2021-09-05 Moved ring_sub() declaration to nonets.h                      FY *
* 2021-09-15 Tuned is_my_ipaddr() by separating loop of searching TCP &       *
*                UDP communication end points in case of multihome or not  FY *
* 2021-11-18 Moved nif->tim_pkt.ctl.fncd=TFN_IP_TIM_ON from wup_snd_tsk()     *
*                to tcp_nif_ini(), and removed clearing it in ip_snd_tsk() FY *
* 2021-11-18 Replaced TCPIP_TIMER_FLAG bit operation with tcpip_timer_flag FY *
* 2021-11-18 Added exclusive control to wup_snd_tsk() with wup_stsk_inuse  FY *
* 2022-02-24 Added "!= FALSE" to avoid armcc warning in wup_snd_tsk()      GS *
* 2022-07-21 Fixed ip_frag_pkt()/ip_snd_tsk() not to get 'next' pointer       *
*                      from fragment list already released with rel_mpf()  FY *
* 2023-07-11 In ip_reception(), added discarding malformed IP packets with    *
*              too short header/total length, and commonized code for IGMP    *
*              with others by modifying ip_checksum() to handle IP options MI *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/* External Variable */

extern T_NIF *netif;

/******************************************************************************
* Module Name   : tcpip_timer_func (Cyclic timer handler)                     *
* Purpose       : This cyclic timer periodically checks the ARP cache timeout *
*                 ARP retransmissions timeout and also the IP reassembly      *
*                 process timeout.                                            *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 24-Feb-2003                                                 *
*                 21-Sep-2004 Modified to invoke ip_snd_tsk periodically      *
*                 20-May-2005 Modified for NORTiV4                            *
******************************************************************************/

void tcpip_timer_func(void)
{
    ip_timer++;
    tcpip_timer_flag = TRUE;
    wup_snd_tsk(getnif_default());
}

void wup_snd_tsk(T_NIF *nif)
{
    T_RMBX rmbx;
    ER ercd;
    BOOL ctx; /* TRUE: cyclic handler, FALSE: task */

    if ((ctx = sns_ctx()) != FALSE) {
        if (wup_stsk_inuse)
            return;
    } else if (nif == getnif_default()) {
        wup_stsk_inuse = TRUE;
    }

    ercd = ref_mbx(nif->smbxid, &rmbx);
    if (ercd == E_OK && rmbx.pk_msg == NULL) {
        ercd = snd_mbx(nif->smbxid, &nif->tim_pkt);
        if (ercd != E_OK)
            ip_internal_error(ercd);
    }

    if (!ctx && nif == getnif_default())
        wup_stsk_inuse = FALSE;
}

/******************************************************************************
* Module Name   : ip_internal_error                                           *
* Purpose       : This function is called by IP layer whenever an internal    *
*                 error occurred. The DEBUG option must be enabled for this.  *
* Arguments     : ER ercd - Error code.                                       *
* Return value  : Returns a value after process the Error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
#ifndef DEBUG

ER ip_internal_error(ER ercd)
{
    return tcpip_internal_error(ercd);
}

#endif
/******************************************************************************
* Module Name   : is_broadcast                                                *
* Purpose       : This function checks whether a given address is a broadcast *
*                 address to the interface or not.                            *
* Arguments     : T_NIF *nif - Interface address.                             *
*                 UW addr    - Address to be checked.                         *
* Return value  : TRUE if address is broadcast else return FALSE.             *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

BOOL is_broadcast(T_NIF *nif, UW addr)
{
    UW myip, mask;

    mask = byte4_to_long(nif->mask);
    myip = byte4_to_long(nif->ipaddr);
    if (addr == 0xFFFFFFFF) {
        return TRUE;
    }
    else if ((addr & mask) == (myip & mask)) {
        if (((addr &~mask) | mask) == 0xFFFFFFFF)
            return TRUE;
        if ((addr | mask) == mask)
            return TRUE;
    }
    return FALSE;
}

/******************************************************************************
* Module Name   : is_my_ipaddr                                                *
* Purpose       : This function checks whether a given address is a valid     *
*                 address for the host and the source address is allowed.     *
* Arguments     : T_NIF *nif - Interface address.                             *
*                 UW addr    - Address to be checked.                         *
*                 UW srcaddr - Source Address of the packet.                  *
* Return value  : TRUE,                                                       *
*                 if the address is default address to the interface or       *
*                 if any UDP or TCP CEP using this address or                 *
*                 if broadcast address and any UDP CEP option is broadcast or *
*                 if multicast address and any UDP CEP option is multicast.   *
*                 FALSE otherwise.                                            *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
*   30/Nov/2008 : Updated for IGMPv3 Source filtering                     G.S *
******************************************************************************/

BOOL is_my_ipaddr(T_NIF *nif, UW addr, UW srcaddr)
{
    T_NIF *nifa;
    UW mask, myip;
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;

    /* invalid IP address? */
    if (addr == 0UL)
        return FALSE;

    /* default IP address of this network interface? */
    if (addr == byte4_to_long(nif->ipaddr))
        return TRUE;

    /* broadcast IP address? */
    if (is_broadcast(nif, addr))
        return TRUE;

    /* check for multicast IP address */
    if ((addr & 0xF0000000UL) == 0xE0000000UL) {
        if (!search_igmp_ip(nif, addr, srcaddr))
            return FALSE;
        for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next)
            if (ucep->options & UDP_MULTICAST)
                return TRUE;
        return FALSE;
    }

    /* check for loopback interface */
    if (nif->type == NI_LOOP) {
        mask = byte4_to_long(nif->mask);
        myip = byte4_to_long(nif->ipaddr);
        if ((addr & mask) == (myip & mask))
            return TRUE; /* IP address on this network interface */
        nifa = getnif_addr(addr);
        if (nifa != NULL && addr == byte4_to_long(nifa->ipaddr))
            return TRUE; /* default IP address of another network interface */
    }

    /* is any end point using this IP address when not multihoming? */
    if (nif->multihome == 0) {
        /* check for broadcasting UDP communication end points */
        for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next) {
            if ((ucep->options & (UDP_BROADCAST|UDP_BROADDHCP)) == (UDP_BROADCAST|UDP_BROADDHCP)) {
                mask = byte4_to_long(ucep->d_ipmask);
                myip = byte4_to_long(ucep->d_ipaddr);
                if (myip == 0UL)
                    myip = addr;
                if (((addr & mask) == (myip & mask)) && ((addr &~mask) | mask) == 0xFFFFFFFFUL)
                    return TRUE;
            }
        }

    /* is any end point using this IP address when multihoming? */
    } else {
        /* check for all TCP communication end points */
        for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next)
            if (addr == tcep->ipaddr && nif == tcep->nif)
                return TRUE;
        /* check for all UDP communication end points */
        for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next) {
            if (addr == ucep->ipaddr && nif == ucep->nif)
                return TRUE;
            /* check for broadcasting UDP communication end points */
            if ((ucep->options & (UDP_BROADCAST|UDP_BROADDHCP)) == (UDP_BROADCAST|UDP_BROADDHCP)) {
                mask = byte4_to_long(ucep->d_ipmask);
                myip = byte4_to_long(ucep->d_ipaddr);
                if (myip == 0UL)
                    myip = addr;
                if (((addr & mask) == (myip & mask)) && ((addr &~mask) | mask) == 0xFFFFFFFFUL)
                    return TRUE;
            }
        }
    }
    return FALSE;
}

/******************************************************************************
* Module Name   : ip_checksum                                                 *
* Purpose       : This function computes the checksum for IP header.          *
* Arguments     : T_IP4 *pkt - IP buffer pointer that contains the IP header. *
*               : int optlen - IP option length.                              *
* Return value  : Returns the computed checksum.                              *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static UH ip_checksum(T_IP4 *pkt, int optlen)
{
    UW sum;
    UH *p;

    p = (UH *)&pkt->ip;
    sum  = *p++;        /* ver, tos */
    sum += *p++;        /* tl */
    sum += *p++;        /* id */
    sum += *p++;        /* fo */
    sum += *p++;        /* ttl,prot */
    sum += *p++;        /* hc */
    sum += *p++;        /* sa(high) */
    sum += *p++;        /* sa(low) */
    sum += *p++;        /* da(high) */
    sum += *p++;        /* da(low) */
    while (optlen != 0) {
        sum += *p++;    /* IP option */
        sum += *p++;
        optlen -= 4;
    }
    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);
    return (UH)~sum;
}

/******************************************************************************
* Module Name   : read_ethernet_header                                        *
* Purpose       : This function reads the ethernet header information from    *
*                 the ethernet buffer by using the link layer API's.          *
* Arguments     : T_ETH *pkt - Pointer in which the header informations will  *
*                              be copied.                                     *
* Return value  : On success it returns the length of the ethernet buffer     *
*                 otherwise returns the error value.                          *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static BOOL read_ethernet_header(T_ETH *pkt)
{
    T_NIF *nif;
    int len;

    nif = pkt->ctl.nif;

    /* get packet length */
    len = pkt->eth.len = (*nif->func)(nif, TFN_NET_RCV_LEN);
    if (len == 0)
        return FALSE;

    /* read ethernet header */
    if (len < ETH_HEADER_SZ) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        return FALSE;
    }
    return (*nif->func)(nif, TFN_NET_RED_PKT, pkt->eth.da, ETH_HEADER_SZ);
}

/******************************************************************************
* Module Name   : chk_callback                                                *
* Purpose       : This function invokes if any callback function defined for  *
*                 IP layer whenever it receives an invalid packet.            *
* Arguments     : T_IP4 *pkt - Pointer to the invalid packet.                 *
* Return value  : TRUE if callback function is called otherwise returns FALSE.*
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static BOOL chk_callback(T_IP4 *pkt)
{
    T_IP_CB *b;
    IP_CALLBACK func;
    BOOL flg;

    flg=FALSE;

    b = pIP_CB;
    while (b != NULL) {
        func = (IP_CALLBACK)b->callback;
        if (func != (IP_CALLBACK)NULL) {
            if (!(*func)(pkt)){
                flg = TRUE;
                break;
            }
        }
        b = b->next;
    }
    return flg;
}

/*******************************************************************************
* Module Name   : ip_reception                                                 *
* Purpose       : This function is called by reception task whenever an IP pkt *
*                 received. It reads the IP header from link layer, checks for *
*                 valid packet and calls appropriate upper layer for furthur   *
*                 processing.                                                  *
* Arguments     : T_IP4 *pkt - IP packet received from the lower interface.    *
* Return value  : NULL if received a valid packet otherwise returns address of *
*                 the packet.                                                  *
* Author        : MiSPO                                                        *
* Date          : 2004                                                         *
*******************************************************************************/

VP ip_reception(T_IP4 *pkt)
{
    T_NIF *nif;
    T_IP4 *temp;
    UH tl, ihl, opl;

    nif = pkt->ctl.nif;

    SNMP_BYPCNT(snmp_mibbyp.ipInReceives, 1);     /* ipInReceives */

    /* read IP header informations */
    if (!(*nif->func)(nif, TFN_NET_RED_PKT, &(pkt->ip), IP4_HEADER_SZ)) {
        SNMP_BYPCNT(snmp_mibbyp.ipInDiscards, 1); /* ipInDiscards */
        return pkt;
    }

    /* discard if version unsupported or header/total length malformed */
    if (((pkt->ip.ver & 0xF0) != 0x40) || ((ihl = pkt->ip.ver & 0x0F) < 5) ||
        ((tl = ntohs(pkt->ip.tl)) < (ihl *= 4)) || (tl > nif->path_mtu + IP4_HEADER_SZ)) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        SNMP_BYPCNT(snmp_mibbyp.ipInDiscards, 1); /* ipInDiscards */
        return pkt;
    }

    /* read IP options */
    if ((opl = ihl - IP4_HEADER_SZ) > 0) {
        if (!(*nif->func)(nif, TFN_NET_RED_PKT, pkt->data, opl)) {
            SNMP_BYPCNT(snmp_mibbyp.ipInDiscards, 1); /* ipInDiscards */
            return pkt;
        }
    }

    /* discard if IP header checksum error */
    if (ip_checksum(pkt, opl) != 0) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        ip_internal_error(0);
        SNMP_BYPCNT(snmp_mibbyp.ipInHdrErrors, 1);/* ipInHdrErrors */
        return pkt;
    }

    /* move IP options to packet tail when them added */
    if (opl != 0) {
        memcpy(pkt->data + PATH_MTU4 - opl, pkt->data, opl);
        pkt->ip.tl = htons(tl - opl);
    }

    /* discard if source address does not matche with any local address */
    if (nif->type != NI_LOOP) {
        if (ntohl(pkt->ip.sa) == byte4_to_long(nif->ipaddr)) {
            (*nif->func)(nif, TFN_NET_IGN_PKT);
            SNMP_BYPCNT(snmp_mibbyp.ipInDiscards, 1);   /* ipInDiscards */
            return pkt;
        }
    }

    /* discard if this packet does not come for this host */
    if (pkt->ip.prot != PROT_IGMP) { /* ICMP, TCP, UDP */
        /* accept Broadcast ICMP packets - Corrected 20Feb2004 */
        if (!is_my_ipaddr(nif, ntohl(pkt->ip.da), ntohl(pkt->ip.sa))) {
            if (!(pkt->ip.prot == PROT_ICMP && (is_broadcast(nif, ntohl(pkt->ip.da))))) {
                if (!chk_callback(pkt)) {
                    (*nif->func)(nif, TFN_NET_IGN_PKT);
                    SNMP_BYPCNT(snmp_mibbyp.ipInAddrErrors, 1); /* ipInAddrErrors */
                    return pkt;
                } else {
                    return NULL;
                }
            }
        }
    }

    /* if a fragment packet received */
    if (ntohs(pkt->ip.fo) & (IP_MF|IP_OFFSET)) {
        /* process for reassembling the fragment packet */
        temp = ip_reassembling(pkt);
        if (temp == NULL)
            return pkt;     /* error during reassembly */
        else if (!temp->ctl.rcheck)
            return NULL;    /* waiting for remaining fragments */

        /* reassembly process successful and all the fragments are linked */
        /* in correct order. upper layer should copy the data from this */
        /* fragments. */
        pkt = temp;
    }

    /* deliver the packet to upper layer */
    switch (pkt->ip.prot) {
    case PROT_ICMP:
        SNMP_BYPCNT(snmp_mibbyp.ipInDelivers, 1);       /* ipInDelivers */
        return icmp_reception(pkt);
    case PROT_TCP:
        SNMP_BYPCNT(snmp_mibbyp.ipInDelivers, 1);       /* ipInDelivers */
        return tcp_reception((T_TCP_PKT *)pkt);
    case PROT_UDP:
        SNMP_BYPCNT(snmp_mibbyp.ipInDelivers, 1);       /* ipInDelivers */
        return udp_reception((T_UDP_PKT *)pkt);
    case PROT_IGMP:
        SNMP_BYPCNT(snmp_mibbyp.ipInDelivers, 1);       /* ipInDelivers */
        return igmp3_reception(pkt);
    default:
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        SNMP_BYPCNT(snmp_mibbyp.ipInUnknownProtos, 1);  /* ipInUnknownProtos */
        return pkt;
    }
}

/******************************************************************************
* Module Name   : ip_rcv_tsk                                                  *
* Purpose       : This task starts during TCP/IP stack initialization and it  *
*                 calls the IP or ARP reception process whenever a  packet is *
*                 from the link layer.                                        *
* Arguments     : int ch - Interface number.                                  *
* Return value  : It loops forever.                                           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

TASK ip_rcv_tsk(int ch)
{
    T_NIF *nif, *tnif;
    T_ETH *pkt;
    ER ercd;

    pkt = NULL;

    /* get interface for the channel number */
    nif = getnif_default();
    while (nif->next != NULL) {
        if (nif->ch == ch)
            break;
        nif = nif->next;
    }

    for (;;) {
        /* get buffer to store the incoming packet */
        if (pkt == NULL) {
            ercd = get_mpf(ID_ETH_MPF, (VP *)&pkt);
            if (ercd != E_OK){
                pkt = NULL;
                ip_internal_error(ercd);
                if (nif->type == NI_ETH || nif->type == NI_LOOP) {
                    ip_evictor();
                  #ifdef DUAL_STK
                    ip6_evictor();
                  #endif
                }

                dly_tsk(MSEC2TICK(1000));
                continue;
            }
        }
        memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
        pkt->ctl.mpfid = (H)ID_ETH_MPF;
        pkt->ctl.nif = nif;

        /* wait until a packet appears in the network */
        ercd = (*nif->func)(nif, TFN_NET_WAI_RCV, TMO_FEVR);
        if (ercd != E_OK) {
            ip_internal_error(ercd);
            dly_tsk(MSEC2TICK(1000));
            continue;
        }

        /* update initial send sequence number */
        if (!(tcp_iss & 0x80000000))
            tcp_iss = (tcp_iss + tickck_read()) | 0x80000000;

        /* process the packet */
        pkt->ctl.nif = nif;

        if (nif->type == NI_ETH || nif->type == NI_LOOP) {
            /* read ethernet header */
            if (!read_ethernet_header(pkt))
                continue;
            SNMP_UPD_IF(pkt, nif->ch);

            /* RAW communication packet */
            if (is_raw_pkt((T_RAW_PKT *)pkt, RAW_LAYER_ETHER)) {
                pkt = raw_reception((T_RAW_PKT *)pkt, RAW_LAYER_ETHER);
                continue;
            }

            switch (ntohs(pkt->eth.etype)) {
            case ETYPE_IP4:
                pkt = ip_reception((T_IP4 *)pkt);
                /* clear reassembly fragments if any exists */
                if (pkt != NULL && pkt->ctl.rcheck)
                    clr_frag_list((T_IPF *)pkt, FALSE);
                break;

            case ETYPE_ARP:
                pkt = arp_reception((T_ARP *)pkt);
                break;
          #ifdef DUAL_STK
            case ETYPE_IP6:
                pkt = ip6_reception((T_IP6*) pkt);
                if (pkt != NULL && pkt->ctl.rcheck)
                    clr_frag_list((T_IPF *)pkt, FALSE);
                break;
          #endif
            case ETYPE_DISCOVERY:
            case ETYPE_SESSION:
                if (!(*nif->func)(nif, TFN_NET_RED_PKT, &pkt->data, 8))
                    continue;
                for (tnif = netif; tnif!=NULL; tnif = tnif->next) {
                    if ((*tnif->func)(tnif, TFN_PPPOE_SESSION_MATCH, pkt) == E_OK) {
                        pkt->ctl.nif = tnif;
                        break;
                    }
                }
                if (!(tnif!=NULL && (*tnif->func)(tnif, TFN_PPPOE_RECEPTION, &pkt)))
                    (*nif->func)(nif, TFN_NET_IGN_PKT);
                break;

            default:
                SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifInUnknownProtos, 1); /* ifInUnknownProtos */
                (*nif->func)(nif, TFN_NET_IGN_PKT);
            }
        } else {
            if (nif->type == NI_PPP)
                pkt->eth.etype = htons(ETYPE_IP4);
            SNMP_BYPCNT(snmp_mibbyp_if[ch].ifInUcastPkts, 1);       /* ifInNUcastPkts */
            SNMP_BYPCNT64(snmp_mibbyp_ifX[ch].ifHCInUcastPkts, 1);  /* ifHCInNUcastPkts */
            pkt = ip_reception((T_IP4 *)pkt);
            if (pkt != NULL && pkt->ctl.rcheck)
                clr_frag_list((T_IPF *)pkt, FALSE);
        }
    }
}

/******************************************************************************
* Module Name   : set_icmp_ip_header                                          *
* Purpose       : This function is called by IP sending process whenever an   *
*                 ICMP or IGMP packet to be send. It fills the header values  *
*                 that are not filled by the upper layers.                    *
* Arguments     : T_IP4 *pkt - ICMP or IGMP packet.                           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void set_icmp_ip_header(T_IP4 *pkt)
{
    if (pkt->ctl.hedflg != TRUE){
        pkt->ip.hc = 0;
        pkt->ip.hc = ip_checksum(pkt, (pkt->ip.ver & 0x0F) * 4 - IP4_HEADER_SZ);
    }
}

/******************************************************************************
* Module Name   : set_udp_ip_header                                           *
* Purpose       : This function is called by IP sending process whenever an   *
*                 UDP packet to be send. It fills the header values that are  *
*                 not filled by the UDP layer.                                *
* Arguments     : T_UDP_PKT *pkt - UDP packet.                                *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void set_udp_ip_header(T_UDP_PKT *pkt)
{
    if (pkt->ctl.hedflg != TRUE) {
        pkt->ip.ver = 0x45;
        pkt->ip.tl = htons(IP4_HEADER_SZ + ntohs(pkt->udp.len));
        pkt->ip.id = htons(ip_ident++);
        pkt->ip.fo = 0;
        pkt->ip.hc = 0;
        pkt->ip.hc = ip_checksum((T_IP4 *)pkt, 0);
    }
}

/******************************************************************************
* Module Name   : set_tcp_ip_header                                           *
* Purpose       : This function is called by IP sending process whenever an   *
*                 TCP packet to be send. It fills the header values that are  *
*                 not filled by the TCP layer.                                *
* Arguments     : T_TCP_PKT *pkt - TCP packet.                                *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void set_tcp_ip_header(T_TCP_PKT *pkt)
{
    if (pkt->ctl.hedflg != TRUE) {
        pkt->ip.ver = 0x45;
        if (pkt->ip.ttl == 0)
            pkt->ip.ttl = pkt->ctl.nif->ip.ttl;
        pkt->ip.id = htons(ip_ident++);
        pkt->ip.fo = 0;
        pkt->ip.hc = 0;
        pkt->ip.hc = ip_checksum((T_IP4 *)pkt, 0);
    }
}

/******************************************************************************
* Module Name   : ip_set_hdr4                                                 *
* Purpose       : This function is called by IP sending process whenever an   *
*                 IP or ARP packet to be send. It fills the destination MAC   *
*                 address for the corresponding destination IP address. If    *
*                 a MAC address is not available then it sends ARP requests   *
*                 to the IP address and saves the packet in retry mailbox for *
*                 furthur processing.                                         *
* Arguments     : T_NIF *nif  - Network Interface of the processing packet.   *
*                 T_IP4 **tpkt - Pointer which has the packet address. This   *
                                value will become NULL if ARP query fails.    *
*                 T_DATA *p_data - data block.                                *
*                 int *n         - number of data block.                      *
* Return value  : For IP packet returns the offset of data.                   *
*                 For ARP packet returns zero.                                *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static BOOL ip_set_hdr4(T_NIF *nif, T_IP4 **tpkt, T_DATA *p_data, int *n)
{
    T_IP4 *pkt;
    T_CTL_PKT *pre;
    UB ipb4[4];
    ER ercd;

    pkt = *tpkt;
    *n = 0;

    if (nif->type == NI_PPP || ntohs(pkt->eth.etype) == ETYPE_IP4) {

        /* ethernet interface */
        if (nif->type == NI_ETH) {

            /* broadcast packet */
            if (is_broadcast(nif, ntohl(pkt->ip.da))) {
                SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutNUcastPkts, 1);         /* ifOutNUcastPkts */
                SNMP_BYPCNT(snmp_mibbyp_ifX[nif->ch].ifOutBroadcastPkts, 1);     /* ifOutBroadcastPkts */
                SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutBroadcastPkts, 1); /* ifHCOutBroadcastPkts */
                memset(pkt->eth.da, -1, 6);
            }

            /* multicast packet */
            else if ((ntohl(pkt->ip.da) & 0xE0000000UL) == 0xE0000000UL) {
                long_to_byte4(ipb4, ntohl(pkt->ip.da));
                pkt->eth.da[5] = ipb4[3];
                pkt->eth.da[4] = ipb4[2];
                pkt->eth.da[3] = (ipb4[1]&0x7F);
                pkt->eth.da[2] = 0x5E;
                pkt->eth.da[1] = 0;
                pkt->eth.da[0] = 1;
                pkt->ip.ttl = nif->ip.m_ttl;
                SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutNUcastPkts, 1);         /* ifOutNUcastPkts */
                SNMP_BYPCNT(snmp_mibbyp_ifX[nif->ch].ifOutMulticastPkts, 1);     /* ifOutMulticastPkts */
                SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutMulticastPkts, 1); /* ifHCOutMulticastPkts */
            }

            /* set target MAC address */
            else if (memcmp(pkt->eth.da, unknown_addr, 6) == 0) {
                ercd = ref_macaddr(nif, pkt->eth.da, ntohl(pkt->ip.da));
                if (ercd != E_OK) {
                    if (ercd == E_PAR) {
                        pre = (T_CTL_PKT *)&nif->arp_waiting;
                        while (pre->next != NULL)
                            pre = pre->next;
                        pre->next = (VP)pkt;
                        pkt->next = NULL;
                        *tpkt = NULL;
                    }
                    return FALSE;
                }

                SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutUcastPkts, 1);      /* ifOutUcastPkts */
                SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutUcastPkts, 1); /* ifHCOutUcastPkts */
            }
        }
        else if (nif->type == NI_PPP) {
            SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutUcastPkts, 1);      /* ifOutUcastPkts */
            SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutUcastPkts, 1); /* ifHCOutUcastPkts */
        }
        else if (nif->type == NI_LOOP) {
            SNMP_BYPCNT(snmp_mibbyp_if[nif->ch].ifOutUcastPkts, 1);      /* ifOutUcastPkts */
            SNMP_BYPCNT64(snmp_mibbyp_ifX[nif->ch].ifHCOutUcastPkts, 1); /* ifHCOutUcastPkts */
            memcpy(pkt->eth.da, nif->hwaddr, 6);
        }

        /* initialize IP header information */
        switch (pkt->ip.prot) {
        case PROT_IGMP:
            set_icmp_ip_header(pkt);
            break;
        default: /* PROT_ICMP or IGMP */
            pkt->ip.ttl = nif->ip.ttl;
            set_icmp_ip_header(pkt);
            break;
        case PROT_UDP:
            set_udp_ip_header((T_UDP_PKT *)pkt);
            break;
        case PROT_TCP:
            set_tcp_ip_header((T_TCP_PKT *)pkt);
            break;
        }

        p_data[*n].data = pkt->eth.da;
        if (pkt->ip.prot == PROT_UDP) {
            p_data[(*n)++].len = ETH_HEADER_SZ + IP4_HEADER_SZ + UDP_HEADER_SZ;
            p_data[*n].data = ((T_UDP_PKT *)pkt)->data;
            p_data[(*n)++].len = ntohs(((T_UDP_PKT *)pkt)->udp.len) - UDP_HEADER_SZ;
        } else {
            p_data[(*n)++].len = ETH_HEADER_SZ + ntohs(pkt->ip.tl);
        }
        SNMP_BYPCNT(snmp_mibbyp.ipOutRequests, 1);  /* ipOutRequests */
    } else {
        /* for ETYPE_ARP or ETYPE_DISCOVERY packet */
        p_data[*n].data = pkt->eth.da;
        p_data[(*n)++].len = pkt->eth.len;
    }

    if (nif->type == NI_PPP) {
        p_data[0].data = (void *)((UW)p_data[0].data + ETH_HEADER_SZ);
        p_data[0].len -= ETH_HEADER_SZ;
    }

    /* set MAC address */
    if (nif->type == NI_ETH || nif->type == NI_LOOP)
        memcpy(pkt->eth.sa, nif->hwaddr, 6);

    return TRUE;
}

/******************************************************************************
* Module Name   : arp_retry_over                                              *
* Purpose       : Discard packets that cannot be sent due to ARP retry over   *
* Arguments     : T_NIF *nif - Network Interface of the processing packet.    *
*                 UW ipaddr  - IP address of ARP retry over                   *
* Author        : FY                                                          *
* Date          : 2020                                                        *
******************************************************************************/

void arp_retry_over(T_NIF *nif, UW ipaddr)
{
    TCP_CALLBACK func;
    T_CTL_PKT *pre;
    T_IP4 *pkt;
    ID tskid;
    ER ercd;

    pre = (T_CTL_PKT *)&nif->arp_waiting;
    pkt = (T_IP4 *)pre->next;
    while (pkt != NULL) {
        if (ntohl(pkt->ip.da) == ipaddr) {

            /* release waiting task */
            tskid = pkt->ctl.tskid;
            if (tskid != FALSE) {
                ercd = rel_wai(tskid);
                if (ercd != E_OK)
                    ip_internal_error(ercd);
            }

            /* call the callback function if any */
            func = pkt->ctl.callback;
            if (func != (TCP_CALLBACK)NULL){
                /* check for ARP request retry timeout */
                pkt->ctl.parblk = E_RLWAI;
                if (pkt->ctl.fncd == TFN_UDP_SND_DAT && pkt->ctl.parblk > 0)
                    SNMP_BYPCNT(snmp_mibbyp.udpOutDatagrams, 1); /* udpOutDatagrams (Non-Blocking) */

                /* UDP callback routine can get the address of sent data from the 2nd parameter */
                pkt->ctl.callback = (TCP_CALLBACK)(((T_UDP_PKT *)pkt)->data);
                (func)(((T_UDP_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd, &pkt->ctl.parblk);
                /* recover 'callback' member used for the 2nd parameter temporarily */
                pkt->ctl.callback = func;
            }
            pre->next = (VP)pkt->next;

            /* release memory allocated for this packet */
            ercd = rel_mpf(pkt->ctl.mpfid, pkt);
            if (ercd != E_OK) {
                ip_internal_error(ercd);
                dly_tsk(MSEC2TICK(1000));
            }
        } else {
            pre = (T_CTL_PKT *)pkt;
        }
        pkt = (T_IP4 *)pre->next;
    }
}

/******************************************************************************
* Module Name   : ip_frag_pkt                                                 *
* Purpose       : This function is called by IP sending process whenever the  *
*                 total packet length exceeds the Path MTU size and requires  *
*                 fragmentation. This function fragments the packet and fills *
*                 correct header information and transmits it to the network. *
*                 It also releases the memory allocated by reassembly process *
*                 for this packet if any.                                     *
* Arguments     : T_NIF *nif - Network Interface of the processing packet.    *
*                 T_IP4 *pkt  - IP packet to be fragmented.                   *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

static T_IP4 *ip_frag_pkt(T_NIF *nif, T_IP4 *pkt)
{
    T_DATA p_data[4];
    T_IPF *fl, *prev, *next;        /* fragment list */
    W len, len1;                    /* variable used for IP fragmentation */
    int n;
    int num_frag, count;            /* fragment variables */
    int split_unit;
    ER ercd;

    /* if dont fragment flag is set then fragment should not be done */
    if (nif->type == NI_ETH || nif->type == NI_LOOP) {
        if (ntohs(pkt->eth.etype) != ETYPE_IP4)
            return pkt;
    } else if (nif->type != NI_PPP && nif->type != NI_PPPOE) {
        return pkt;
    }

    if (pkt->ip.prot == PROT_UDP) {
        len = ntohs(pkt->ip.tl) - IP4_HEADER_SZ;

        /* get the number of fragments */
        split_unit = (nif->path_mtu / 8) * 8;
        num_frag = (len + (split_unit - 1)) / split_unit;

        for (count = 0; count < num_frag; count++) {
            SNMP_BYPCNT(snmp_mibbyp.ipFragCreates, 1);  /* ipFragCreates */

            /* transmit the fragment packet to network */
            for (;;) {
                ercd = (*nif->func)(nif, TFN_NET_WAI_SND, TMO_FEVR);
                if (ercd != E_OK) {
                    ip_internal_error(ercd);
                    return pkt;
                }
                break;
            }

            /* set ethernet header */
            n = 0;
            if (nif->type == NI_ETH || nif->type == NI_LOOP) {
                p_data[n].data = pkt->eth.da;
                p_data[n++].len = ETH_HEADER_SZ;
            }

            /* set IP header */
            if (count == num_frag - 1) {                /* last fragment */
                len1 = len - (split_unit * count);
                pkt->ip.fo = 0;
            } else {
                len1 = split_unit;
                pkt->ip.fo = htons(IP_MF);              /* set MORE fragment flag */
            }
            pkt->ip.tl = htons(IP4_HEADER_SZ + (UH)len1);
            pkt->ip.fo |= htons((split_unit * count) >> 3);
            pkt->ip.hc = 0;
            pkt->ip.hc = ip_checksum(pkt, 0);

            p_data[n].data = &pkt->ip;
            p_data[n++].len = IP4_HEADER_SZ;

            /* set payload */
            if (count == 0) {
                p_data[n].data = &((T_UDP_PKT *)pkt)->udp;
                p_data[n++].len = UDP_HEADER_SZ;
                p_data[n].data = (UB *)((T_UDP_PKT *)pkt)->data;
                p_data[n++].len = len1 - UDP_HEADER_SZ;
            } else {
                p_data[n].data = (UB *)((T_UDP_PKT *)pkt)->data
                    + split_unit * count - UDP_HEADER_SZ;
                p_data[n++].len = len1;
            }

            /* send packet */
            ercd = (*nif->func)(nif, TFN_NET_WRI_M_PKT, p_data, n);
        }
    } else { /* pkt->ip.prot == PROT_ICMP */
        for (;;) {
            SNMP_BYPCNT(snmp_mibbyp.ipFragCreates, 1);  /* ipFragCreates */

            /* transmit the fragment packet to network */
            for (;;) {
                ercd = (*nif->func)(nif, TFN_NET_WAI_SND, TMO_FEVR);
                if (ercd != E_OK) {
                    ip_internal_error(ercd);
                    fl = (T_IPF *)pkt;
                    do {
                        next = fl->nextf;
                        rel_mpf(ID_ETH_MPF, fl);
                        fl = next;
                    } while (fl != NULL);
                    return NULL;
                }
                break;
            }

            /* search oldest packet */
            fl = (T_IPF *)pkt;
            prev = NULL;
            while (fl->nextf != NULL) {
                prev = fl;
                fl = fl->nextf;
            }

            /* set ethernet header */
            n = 0;
            if (nif->type == NI_ETH || nif->type == NI_LOOP) {
                p_data[n].data = pkt->eth.da;
                p_data[n++].len = ETH_HEADER_SZ;
            }

            /* set IP header */
            if (prev != NULL) {
                ((T_IP4 *)fl)->ip.sa = pkt->ip.sa;
                ((T_IP4 *)fl)->ip.da = pkt->ip.da;
                ((T_IP4 *)fl)->ip.hc = 0;
                ((T_IP4 *)fl)->ip.hc = ip_checksum((T_IP4 *)fl, 0);
            }
            p_data[n].data = &((T_IP4 *)fl)->ip;
            p_data[n++].len = IP4_HEADER_SZ;

            /* set payload */
            p_data[n].data = ((T_IP4 *)fl)->data;
            p_data[n++].len = ntohs(((T_IP4 *)fl)->ip.tl) - IP4_HEADER_SZ;

            /* send packet */
            ercd = (*nif->func)(nif, TFN_NET_WRI_M_PKT, p_data, n);

            /* release packet */
            rel_mpf(ID_ETH_MPF, fl);
            if (prev == NULL)
                return NULL;
            prev->nextf = NULL;
        }
    }
    SNMP_BYPCNT(snmp_mibbyp.ipFragOKs, 1);   /* ipFragOKs */
    return pkt;
}

/******************************************************************************
* Module Name   : ip_snd_tsk                                                  *
* Purpose       : This task starts during TCP/IP stack initialization and it  *
*                 waits in the IP send message box. Any packet appears in the *
*                 message box will be furthur processed by this task and send *
*                 out to the network. It releases the memory allocated for the*
*                 packet and invoke any function or task bind for the packet. *
*                 This task also acts like tcp timer for transmitting delay   *
*                 ack and retransmission packets.                             *
* Arguments     : int ch - Interface number.                                  *
* Return value  : It loops forever.                                           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

TASK ip_snd_tsk(int ch)
{
    TCP_CALLBACK func;
    T_DATA p_data[2];
    T_NIF *nif, *enif;
    T_IP4 *pkt, *next;
    UW tt;
    TMO t;
    ID tskid;
    UW ipaddr;
    int n;
    ER ercd;

    pkt = NULL;

    /* get interface for this channel number */
    enif = getnif_default();
    while (enif != NULL) {
        if (enif->ch == ch)
            break;
        enif = enif->next;
    }

    /* send ARP broadcast */
    if (enif->type == NI_ETH) {
        ipaddr = byte4_to_long(enif->ipaddr);
        if (ipaddr != 0)
            arp_request(enif, ipaddr);
    }

    for (;;) {
        if (pkt != NULL) {
            /* release reassembly packets if any */
            if (pkt->ctl.rcheck) {  /* reassembly packet */
                do {
                    next = (T_IP4 *)((T_IPF *)pkt)->nextf;
                    rel_mpf(ID_ETH_MPF, pkt);
                    pkt = next;
                } while (pkt != NULL);

            } else if (pkt->ctl.fncd == TFN_RAW_SND_DAT) {
                /* release waiting task */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = wup_tsk(tskid);
                    if (ercd != E_OK)
                        ip_internal_error(ercd);
                }

                /* call the callback function if any */
                func = pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL){
                    (func)(((T_RAW_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd, &pkt->ctl.parblk);
                }

                /* release memory allocated for this packet */
                ercd = rel_mpf(pkt->ctl.mpfid, pkt);
                if (ercd != E_OK) {
                    ip_internal_error(ercd);
                    dly_tsk(MSEC2TICK(1000));
                }

                pkt = NULL;

            } else {
                /* release waiting task */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = wup_tsk(tskid);
                    if (ercd != E_OK)
                        ip_internal_error(ercd);
                }

                /* call the callback function if any */
                func = pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL){
                    if (pkt->ctl.fncd == TFN_UDP_SND_DAT && pkt->ctl.parblk > 0)
                        SNMP_BYPCNT(snmp_mibbyp.udpOutDatagrams, 1); /* udpOutDatagrams (Non-Blocking) */

                    /* UDP callback routine can get the address of sent data from the 2nd parameter */
                  #ifdef DUAL_STK
                    if (ntohs(pkt->eth.etype) == ETYPE_IP6)
                        pkt->ctl.callback = (TCP_CALLBACK)(((T_UDP6_PKT *)pkt)->data);
                    else
                  #endif
                        pkt->ctl.callback = (TCP_CALLBACK)(((T_UDP_PKT *)pkt)->data);
                    (func)(((T_UDP_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd, &pkt->ctl.parblk);
                    /* recover 'callback' member used for the 2nd parameter temporarily */
                    pkt->ctl.callback = func;
                }

                /* release memory allocated for this packet */
                ercd = rel_mpf(pkt->ctl.mpfid, pkt);
                if (ercd != E_OK) {
                    ip_internal_error(ercd);
                    dly_tsk(MSEC2TICK(1000));
                }
                pkt = NULL;
            }
        }

        /* do timer function if any */
        if (tcpip_timer_flag) {
            tcpip_timer_flag = FALSE;
            /* check ARP retry and cache timeout */
            val_arp_table();
            /* check IP reassembly timeout */
            ip_frag_timeout();
            /* IGMPv3/IGMPv2/IGMPv1 timer check */
            igmp3_tmr_check();
        }

        /* recover retransmission after queue lacked */
        if (ip_miscflag & ETH_QLACK)
            tcp_recover_retrans();

        /* check for TCP timeout */
        if (enif->tcp_tmout != 0 && ring_sub(enif->tcp_tmout, SYSCK.ltime) <= 0)
            tcp_timeout_process(&TCP_CEP[enif->tcp_tmout_cepid - 1]);
        tt = enif->tcp_tmout;

        /* check for TCP timeout of PPPoE */
        nif = getnif_default();
        while (nif != NULL) {
            if (nif->type == NI_PPPOE &&
                *(T_NIF **)(nif->pppoe_sess_info) == enif &&
                nif->tcp_tmout != 0) {
                if (ring_sub(nif->tcp_tmout, SYSCK.ltime) <= 0)
                    tcp_timeout_process(&TCP_CEP[nif->tcp_tmout_cepid - 1]);
                if (tt == 0)
                    tt = nif->tcp_tmout;
                else if (ring_sub(nif->tcp_tmout, tt) < 0)
                    tt = nif->tcp_tmout;
            }
            nif = nif->next;
        }

        /* calculate timeout time */
        if (tt == 0) {
            t = MSEC2TICK(1000);
        } else {
            t = ring_sub(tt, SYSCK.ltime);
            if (t <= 0)
                t = TMO_POL;
            else if (t > MSEC2TICK(1000))
                t = MSEC2TICK(1000);
        }

        /* get a packet that retries transmission */
        pkt = (T_IP4 *)net_get_transmission_pkt(enif);
        if (pkt == NULL) {
            /* wait to receive packet from upper layer for transmission */
            ercd = trcv_mbx(enif->smbxid, (T_MSG **)&pkt, t);
            if (ercd != E_OK) {
                if ((ercd != E_RLWAI) && (ercd != E_TMOUT)) {
                    ip_internal_error(ercd);
                    dly_tsk(MSEC2TICK(1000));
                }
                continue;
            }
            if (pkt->ctl.fncd == TFN_IP_TIM_ON) {
                pkt = NULL;
                continue;
            }
            /* when a packet that retries transmission exists,
               it is processed by priority. */
            next = (T_IP4 *)net_get_transmission_pkt(enif);
            if (next != NULL) {
                net_set_transmission_pkt(enif, (T_CTL_PKT*)pkt);
                pkt = next;
            }
        }

        nif = (pkt->ctl.nif != NULL) ? pkt->ctl.nif : enif;

        if (pkt->ctl.fncd == TFN_RAW_SND_DAT) {
            /* check layer & protocol */
            if (!raw_check_protocol(RAW_LAYER_ETHER, ntohs(pkt->eth.etype)))
                continue;
            n = 0;
            p_data[n].data = pkt->eth.da;
            p_data[n++].len  = ETH_HEADER_SZ;
            if (((T_RAW_PKT *)pkt)->data != NULL && ((T_RAW_PKT *)pkt)->dlen > 0) {
                p_data[n].data = ((T_RAW_PKT *)pkt)->data;
                p_data[n++].len = ((T_RAW_PKT *)pkt)->dlen;
            }
        } else {
            if (nif->type == NI_PPP || nif->type == NI_PPPOE) {
                ercd = (*nif->func)(nif, TFN_CONNECT, &pkt);
                if (ercd != E_OK && ercd != E_NOSPT)
                    continue;
            }

          #ifdef DUAL_STK
            if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
                /* fill IP6 header informations and MAC address */
                if (!ip_set_hdr6(nif, (T_IP6 **)&pkt, p_data, &n))
                    continue;
            } else
          #endif
            {
                /* fill IP4 header informations and MAC address */
                if (!ip_set_hdr4(nif, &pkt, p_data, &n))
                    continue;
            }

          #ifdef DUAL_STK
            if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
                /* fragment packet if total length > PATH_MTU6 size */
                if ((ntohs(((T_IP6 *) pkt)->ip6.pl)  > PATH_MTU6) || pkt->ctl.rcheck) {
                    /* construct and send all fragments */
                    pkt = (T_IP4 *)ip6_frag_pkt(nif, (T_IP6 *)pkt);
                    continue;
                }
            } else
          #endif
            /* fragment packet if total length > PATH_MTU4 size */
            if ((nif->type != NI_ETH || ntohs(pkt->eth.etype) == ETYPE_IP4) && \
                (((ntohs(pkt->ip.tl) - IP4_HEADER_SZ) > nif->path_mtu) ||
                pkt->ctl.rcheck)) {
                /* construct and send all fragments */
                pkt = ip_frag_pkt(nif, pkt);
                continue;
            }
        }

        for (;;) {
            /* wait to send data to the network driver */
            if ((ercd = (*nif->func)(nif, TFN_NET_WAI_SND, TMO_FEVR)) == E_OK)
                break;
            ip_internal_error(ercd);
        }

      #ifdef DUAL_STK
        if ((nif->type == NI_ETH || nif->type == NI_LOOP) &&
            ntohs(pkt->eth.etype) == ETYPE_IP6) {
            SNMP_BYPCNT(snmp_mibbyp_ipv6[ch].ipv6IfStatsOutForwDatagrams, 1);
                /* ipv6IfStatsOutForwDatagrams */
            if (pkt->eth.da[0] == 0x33 && pkt->eth.da[1] == 0x33)
                SNMP_BYPCNT(snmp_mibbyp_ipv6[ch].ipv6IfStatsOutMcastPkts, 1);
                    /* ipv6IfStatsOutMcastPkts */
        }
      #endif
        /* write data to network driver */
        (*nif->func)(nif, TFN_NET_WRI_M_PKT, p_data, n);
    }
}

/******************************************************************************
* Module Name   : ip_def_cbk                                                  *
* Purpose       : This function is used to add or remove a callback function  *
                  for IP layer.                                               *
* Arguments     : T_IP_CB *b           - IP callback control block.           *
*                 IP_CALLBACK callback - Callback function.                   *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER ip_def_cbk(T_IP_CB *b, IP_CALLBACK callback)
{

    T_IP_CB *bb, *bbb;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK; /* No Interface available */
    }

    bbb = (T_IP_CB *)&pIP_CB;
    bb = bbb->next;

    /* remove IP control block if 'callback' is NULL */
    if (callback == (IP_CALLBACK)NULL) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;
                break;
            }
            bbb = bb;
            bb = bb->next;
        }

    /* chain IP control block */
    } else {
        b->callback = (FP)callback;
        for (;;) {
            if (bb == NULL)
            {   b->next = NULL;
                bbb->next = b;
                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }
    return tcpip_critical(FALSE, &save_pri);
}

/* End */
