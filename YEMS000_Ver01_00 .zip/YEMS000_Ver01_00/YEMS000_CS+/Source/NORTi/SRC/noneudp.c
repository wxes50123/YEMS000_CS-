/******************************************************************************
* NORTi TCP/IP Stack - UDP Module                                             *
*                                                                             *
*  Copyright (c) 1999-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05 Created                                                          *
* 2000-10-12 Released as Ver.4.02                                             *
* 2000-10-21 Modified udp_rcv_dat_now (LittleEndian)                          *
* 2000-10-21 Added udp_snd_dat,udp_rcv_dat parameter check (E_PAR)            *
* 2000-12-01 Released as Ver.4.03                                             *
* 2001-02-10 Changed tcp_con_cep() to get port number                         *
* 2001-09-05 Deleted (cep->pkt = pkt) in make_udp_pkt and udp_snd_dat         *
* 2001-09-25 Fixed igmp_snd_dat() parameter IGMP_UNUSED -> IGMP_REPORT        *
* 2002-02-27 udp_rcv_dat_que, SIZEOF_INT != 4,initialize variable m        HM *
* 2002-03-26 Modified udp_reception_sub1 pkt->data = (UB *)bp                 *
* 2002-06-26 Modified UDP reception, and added support for IP reassembling    *
* 2002-11-19 Fixed memorypool for IP reassembly                               *
* 2003-05-30 Modified udp_cre_cep, udp_vcre_cep for LoopBack interface        *
* 2004-07-01 Modified for IPv6 Stack                                       PK *
* 2004-10-27 Fixed udp_rcv_dat_now() and udp_reception_sub1()              PK *
* 2004-10-28 Fixed udp_set_opt() for IP_DROP_MEMBERSHIP                    PK *
* 2004-11-30 Send Unreachable Port Error Message                           PK *
* 2005-04-05 Configurable TTL, TOS for UDP packets                            *
*            Modified to bind with required interface                      AK *
* 2005-05-10 Modified UDP API's for Interface check                        AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2005-07-27 udp_cre_cep: IPv4/6 same port number checking fixed           GS *
* 2005-09-01 make_udp_pkt: IPv6 Hop Limit header field initialized         GS *
* 2005-10-24 Update for PPPOE interface                                       *
*            Modified udp_rcv_dat_now, udp_reception_sub1 functions       M.K *
* 2005-12-05 udp_cpy_dat: validation code for data length                 A.K *
* 2006-03-03 Modified for IGMPV2 support                                  A.K *
* 2006-03-08 tcpip_cretical fix for udp_snd_dat & udp_rcv_dat             A.K *
* 2006-03-13 Fix search cep for broadcast pkts when default ipaddr is 0   A.K *
* 2006-04-03 Added code to ignore received UDP pkt with dest port as 0    A.K *
* 2006-07-27 MLDv2 Support Added                                           GS *
* 2006-07-29 SNMP Support for IPv6 added                                   MK *
* 2007-03-20 update_cep_entry: GHS warning corrected: *tmp = NULL          GS *
* 2007-04-11 icmp6_internal_error() is replaced with udp_internal_error()  GS *
* 2007-05-29 Modified for directed-broadcast [from DHCP(relay agent)]      OK *
* 2007-07-03 Corrected return value (0->E_OBJ) for udp_rcv_dat_now()       OK *
*              if pkt was received with checksum error                        *
* 2007-12-07 exeGCC compiler warning: get_updted_info(): cep initialized      *
*             to NULL: prepare_list(): NULL check is added for cep:           *
*             prev, prev1 initialized to NULL                              GS *
* 2008-03-04 Replaced tcpip_critical() from tcpip_cretical() of old-style  OK *
* 2008-05-13 Improvement of TCP_REP/TCP_CEP/UDP_CEP loop                   OM *
* 2008-06-05 rmbxid2 is added for remove_sndque_udppkt & remove_mbx_pkt    GS *
* 2008-07-18 switch-case indent is corrected                               GS *
* 2008-09-09 The judgment of ETYPE_SESSION added                           FY *
* 2008-10-16 The blank at the end of line is deleted                       FY *
* 2008-12-17 IGMPv3 Support added                                          GS *
* 2009-10-16 Modified the restriction of UDP transmission length in        FY *
*            udp_snd_dat function                                             *
* 2009-10-29 Modified the restriction of UDP reception length in           FY *
*            udp_rcv_dat function                                             *
* 2010-01-13 Fixed the problem that udp_snd_dat() cannot transmit the UDP  KZ *
*            data to another interface                                        *
* 2010-01-14 Fixed the problem of memory corruption when udp_rcv_dat()     KZ *
*            returns E_BOVR on PPPoE interface                                *
* 2010-01-14 Corrected MIB value of udpInErrors in udp_rcv_dat()           KZ *
* 2010-01-14 Modified the value which was returned by udp_rcv_dat() when   KZ *
*            the received packet is checksum error                            *
* 2010-04-21 Added missing del_mbx() and assigned id_udp_mbx clearing         *
*             after error of acre_mpf/cre_mpf() in udp_cre/udp_vcre_cep()  FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2012-02-08 Improved ipaddr retrieval speed when not using multi-home     FY *
* 2012-02-09 Skipped processing of unused CEPs using pUDP_CEP list         FY *
* 2012-02-09 Fixed problem that cannot be re-set up,                          *
*                                                 when NIF was set to CEP  FY *
* 2012-03-28 Removed unnecessary check of cep!=NULL in udp_snd_dat         FY *
* 2012-03-29 Corrected udp_del_cep() and udp_can_cep() for exclusion          *
*             control, when called task priority is higher than PRI_TCPIP  FY *
* 2012-07-05 Modified udp_snd_dat() to get NIF with static route to remote FY *
* 2012-07-27 Added UDP_REUSEPORT option to allow duplicate address & port  GS *
* 2012-07-27 Added dup_mcast_pkt() to copy multicast data to multiple CEPs GS *
* 2012-10-04 Enabled creating two or more CEPs of IPV6_ADDRANY             FY *
* 2012-11-13 Modified udp(6)_cpy_dat(), udp_checksum(), udp_rcv_dat_now(),    *
*                           udp_reception_sub1() and udp_reception_sub2()     *
*                                              with change of IP fragment  FY *
* 2012-11-13 Accessed cep->type only when DUAL_STK is effective            FY *
* 2012-11-13 Fixed problem of memory corruption                               *
*                              when udp_rcv_dat() returns E_BOVR for IPv6  FY *
* 2012-11-13 Fixed problem that dup_mcast_pkt() is called,                    *
*                     also when an error occurred in udp_reception_sub1()  FY *
* 2012-11-23 As generation information on memory pool for UDP transmission    *
*                      for IPv6, changed so that c_udp6_mpf might be used  FY *
* 2012-11-23 Changed position of IP header in packet in order                 *
*                       to make size of packet for UDP transmission small  FY *
* 2012-11-23 Fixed problem that udp_rcv_dat_now() did not correspond          *
*                                                to fragmentation of IPv6  FY *
* 2012-11-23 Fixed omission of check of packet type in udp_rcv_dat_now()      *
*                       and udp_reception_sub1() and udp_reception_sub2()  FY *
* 2012-11-27 Changed so that domain which p_ercd points out might not be      *
*                      accessed, when the member tskid of T_UDP_RCV was 0  FY *
* 2012-12-05 Deleted cast for TFN_NET_RED_PKT function argument            FY *
* 2013-06-18 Simplified udp_cre/udp_vcre_cep() & udp_del_cep() to ignore      *
*                 improbable internal error of tcpip_critical(FALSE, ...)  FY *
* 2013-06-18 Added udp_cre_cep_sub(), and reduced                             *
*                udp_cre_cep()/udp_vcre_cep() code by calling it commonly  FY *
* 2013-06-18 Replaced NADR (uITRON3 compatible) by NULL (uITRON4 standard) FY *
* 2013-07-04 Removed prot argument from chk_ip6_nif()                      FY *
* 2013-12-24 Added vcan_wup() after also tslp_tsk() to clear excessive        *
*                        wake-up request in udp_snd_dat() & udp_rcv_dat()  FY *
* 2016-07-05 Added support for ICMP type 3 in udp_reception()              FY *
* 2016-07-13 Changed some UW to int, and casted strlen() to avoid warning  MT *
* 2017-08-23 Removed redundant ETYPE_IP4/ETYPE_SESSION check in               *
*             udp_rcv_dat_now(), udp_reception_sub1() and udp_reception()  GS *
* 2018-02-16 Canceled unnecessary ICMP type 3 reply to multicast/broadcast FY *
* 2018-04-24 Added missing payload copy to ICMP type 3 error message       FY *
* 2020-08-28 Excluded duplicated UDP source port number check in              *
*             udp_(v)cre_cep/udp_set_opt() on different network interface  FY *
* 2021-06-22 Changed 2nd parameter type of remove_???() ID -> T_ETH        FY *
* 2021-06-22 Removed initialization/setting of pkt->ctl.arprty             FY *
* 2021-06-22 Removed exception handling for PPPoE in udp_rcv_dat_now() &      *
*                                                    udp_reception_sub1()  FY *
* 2021-09-05 Added discard of UDP packet with length field < UDP_HEADER_SZ FY *
* 2021-09-05 Added block of ICMP destination unreachable reply by its rate FY *
* 2023-05-25 Fixed udp_reception() to discard header-fragmented packet     FY *
* 2023-07-11 Modified udp_reception() to be able to store IP options in ICMP  *
*            type 3 message, and fixed it to store not last but head packet   *
*            in ICMP type 3 message for unreachable fragmented UDP packets FY *
* 2024-06-14 Fixed udp_reception_sub1() to call back with 0 for bad packet,   *
*             renaming len & len2 to size & len also in udp_rcv_dat_now()  FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/* Symbol */

#define UDP_SEND_MAX_LEN_IPV4   (65535-20-8)    /* 65535 - IP header - UDP header */
#define UDP_SEND_MAX_LEN_IPV6   (65535-8)       /* 65535 - UDP header */

/* Function prototypes */
static ER igmp3_cep_jgrp(T_NIF *nif, T_UDP_CEP *cep, int n, T_IPV4EP *gaddr);
static ER igmp3_cep_lgrp(T_MGRP_CB *grp);
static ER igmp3_cep_srcchg(INT optname, T_MGRP_CB *grp, UW *slist, int numsrc);
static ER igmp3_util_adjsrc(T_MGRP_CB *grp, UW *addr_arr, int numsrc, UB mode);
static ER igmp3_util_arrlist(T_IGMP3_SRC **head, UW *addr_arr, int numsrc);
static ER igmp3_chk_sts(T_NIF *nif, UW maddr, UW *new_state, ID *fcepid, BOOL *eflg);
static ER igmp3_if_genslist(T_NIF *nif, UW maddr, UW new_stat, UW mcnt, BOOL is_empty, ID fcepid, T_IGMP3_SRC **if_slist);
static ER igmp3_util_addlist(T_IGMP3_SRC **head, T_IGMP3_SRC *list);
static ER igmp3_util_union(T_IGMP3_SRC **if_slist, T_IGMP3_SRC *igmp_slist);
static ER igmp3_util_exclude(T_NIF *nif, UW maddr, UW mcnt, BOOL is_empty, ID fcepid, T_IGMP3_SRC **if_slist);

/******************************************************************************
* Module Name   : udp_internal_error                                          *
* Purpose       : This function is called by UDP process whenever an internal *
*                 error occurred. DEBUG option must be enabled for this.      *
* Arguments     : ER ercd - Error code.                                       *
* Return value  : Returns a value after process the Error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
#ifndef DEBUG
ER udp_internal_error(ER ercd)
{
    return tcpip_internal_error(ercd);
}
#endif

/******************************************************************************
* Module Name   : udp_dummy_cbk                                               *
* Purpose       : This is an example function for UDP callback process. Any   *
*                 application can define the callback functions as shown in   *
*                 this sample.                                                *
* Arguments     : ID cepid  - UDP cepid for which a packet is received.       *
*                 FN fncd   - Function code return by UDP process.            *
*                 VP parblk - Length of received or transmitting data.        *
* Return value  : E_OK if application is not waiting to receive data or       *
*                 return value of udp_rcv_dat API.                            *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
ER udp_dummy_cbk(ID cepid, FN fncd, VP parblk)
{
    T_IPV4EP dstaddr;

    if (fncd == TEV_UDP_RCV_DAT)
        return udp_rcv_dat(cepid, &dstaddr, NULL, 0, TMO_FEVR);
    else
        return E_OK;
}

/******************************************************************************
* Module Name   : udp_def_cep                                                 *
* Purpose       : This function is used to chain or remove enable end point   *
*                 for UDP communication end point                             *
* Arguments     : T_UDP_CEP *b  - control block table                         *
*                 BOOL cr_flag  - TRUE:chain,  FALSE:remove                   *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER udp_def_cep(T_UDP_CEP *b, BOOL cr_flag)
{
    T_UDP_CEP *bb, *bbb;
    T_NIF *nif;

    bbb = (T_UDP_CEP *)&pUDP_CEP;
    bb = bbb->next;

    /* remove enable end point if cr_flag == FALSE */
    if (!cr_flag) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;

                /* Check multi home */
                nif = b->nif;
                if (nif != NULL && b->ipaddr != byte4_to_long(nif->ipaddr)
                  #ifdef DUAL_STK
                    && b->type == IPV4_ADDR
                  #endif
                    )
                    nif->multihome--;

                break;
            }
            bbb = bb;
            bb = bb->next;
        }
    }

    /* chain enable end point if cr_flag == TRUE */
    else {
        for (;;) {
            if (bb == NULL) {
                b->next = NULL;
                bbb->next = b;

                /* Check multi home */
                nif = b->nif;
                if (nif != NULL && b->ipaddr != byte4_to_long(nif->ipaddr)
                  #ifdef DUAL_STK
                    && b->type == IPV4_ADDR
                  #endif
                    )
                    nif->multihome++;

                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }

    return E_OK;
}

/******************************************************************************
* Module Name   : udp_cpy_dat                                                 *
* Purpose       : This function copies data from reassembly buffer to user    *
*                 buffer.                                                     *
* Arguments     : VP data   - User buffer space.                              *
*                 T_IP4 *pkt - Header informations.                           *
*                 int len   - Total length of the reassembled UDP packet.     *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 28-Aug-2002                                                 *
*                 22-Sep-2004 Modified for return value.                      *
*                 05-Dec-2005 Do not copy data in User buffer beyond the      *
                              requested length. It may cause bufer overflow.  *
******************************************************************************/

static BOOL udp_cpy_dat(VP data, T_IP4 *pkt, int len)
{
    return get_reassembly_data(data, (T_IPF *)pkt, UDP_HEADER_SZ, (UH)len);
}

#ifdef DUAL_STK
/************************************************/
/* Copy fragmented UDP data into User buffer    */
/************************************************/

static BOOL udp6_cpy_dat(VP data, T_IP6 *pkt, int len)
{
    return get_reassembly6_data(data, (T_IPF *)pkt, UDP_HEADER_SZ, (UH)len);
}
#endif

/*****************************************************************************
* Create UDP CEP Process
*
******************************************************************************/

static ER udp_cre_cep_sub(T_UDP_CEP *cep, const T_UDP_CCEP *pk_ccep)
{
    T_UDP_CEP *c;
    ER ercd;
    UW a;
    UH n;
    T_NIF *nif;

    if (!(is_nif_exists(NULL)))
        return E_LNK;   /* No Interface available */

    /* 06Jan2005 Validation for 'pk_ccep' */

    if (pk_ccep == NULL)
        return E_PAR;

    nif = NULL;

    /* Validate the user specified ipaddr */

  #ifdef DUAL_STK
    if (pk_ccep->myaddr.type == IPV6_ADDR) {
        cep->type = IPV6_ADDR;
        cep->ipaddr = IPV4_ADDRANY;
        if (!is_ip6_addr_any(pk_ccep->myaddr.ip6addr)){
            /* �w�肳�ꂽIPv6�A�h���X������nif�̗L�����`�F�b�N */
            if ((nif = getnif_ip6addr(pk_ccep->myaddr.ip6addr)) == NULL)
                return E_OBJ;
            /* ����IP�A�h���X���ʂ�I/F�ɂ��邩 */
            if (chk_ip6_nif(nif, pk_ccep->myaddr.ip6addr))
                return E_OBJ;
        }

        n = pk_ccep->myaddr.portno;
        if (n == UDP_PORTANY) {
            n = udp_portany();
        } else {
            for (c = pUDP_CEP; c != NULL; c = c->next) {
                if (c->portno == n && c->type == IPV6_ADDR &&
                    memcmp(pk_ccep->myaddr.ip6addr, c->ip6addr, IP6_ADDR_SZ) == 0 &&
                    (c->nif == NULL || !is_ip6_addr_any(c->ip6addr))) {
                    return E_OBJ;
                }
            }
        }
        set_ip6_addr(cep->ip6addr, pk_ccep->myaddr.ip6addr);
    } else
  #endif
    {
      #ifdef DUAL_STK
        cep->type = IPV4_ADDR;
      #endif

        a = pk_ccep->myaddr.ipaddr;
        if (a != IPV4_ADDRANY) {

            /* Get interface for this address */
            if ((nif = getnif_addr(a)) == NULL)
                return E_OBJ;

            /* Check any other interface using this address */
            if (chk_ip_nif(nif, a))
                return E_OBJ;
        }

        /* Error if Port Number Already Used */

        n = pk_ccep->myaddr.portno;

        /* 11/Jul/02 - Modified AK */
        if (n == UDP_PORTANY) {
            n = udp_portany();
        } else {
            for (c = pUDP_CEP; c != NULL; c = c->next) {
                if (c->portno == n && c->ipaddr == a
                  #ifdef DUAL_STK
                    && c->type == IPV4_ADDR
                  #endif
                    && c->nif == nif
                    && !(c->options & UDP_REUSEPORT)) {
                    return E_OBJ;
                }
            }
        }

        cep->ipaddr = a;
    }

    cep->nif = nif;

    /* Mailbox and Memorypool Creation */

    if (cep->id_udp_mbx == 0) {
        ercd = acre_mbx(&c_tcpip_mbx);
        if (ercd < 0)
            return ercd;
        cep->id_udp_mbx = (UH)ercd;
    } else {
        ercd = cre_mbx(cep->id_udp_mbx, &c_tcpip_mbx);
        if (ercd != E_OK)
            return ercd;
    }
    if (cep->id_udp_mpf == 0) {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            ercd = acre_mpf(&c_udp6_mpf);
        else
      #endif
            ercd = acre_mpf(&c_udp_mpf);
        if (ercd < 0) {
            del_mbx(cep->id_udp_mbx);
            if (TCP_MBXID_TOP == 0)
                cep->id_udp_mbx = 0;
            return ercd;
        }
        cep->id_udp_mpf = (UH)ercd;
    } else {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            ercd = cre_mpf(cep->id_udp_mpf, &c_udp6_mpf);
        else
      #endif
            ercd = cre_mpf(cep->id_udp_mpf, &c_udp_mpf);
        if (ercd != E_OK) {
            del_mbx(cep->id_udp_mbx);
            if (TCP_MBXID_TOP == 0)
                cep->id_udp_mbx = 0;
            return ercd;
        }
    }

    /* Setup UDP CEP Control Block */

    cep->portno = n;
    cep->ttl = 0;
    cep->tos = 0;
    cep->rmsg.nif = NULL;

    udp_def_cep(cep, TRUE);

    /* for tcp_ext() */
    cep->ercd = E_OK;

    cep->callback = (TCP_CALLBACK)pk_ccep->callback;
    cep->pkt = NULL;

    /* SNMP udpConnState */

  #ifdef DUAL_STK
    if (cep->type == IPV4_ADDR) {
        if (cep->ipaddr == 0)
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_UNKNOWN, NULL, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
        else
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV4, &cep->ipaddr, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
    } else if (cep->type == IPV6_ADDR) {
        if (cep->ip6addr[0] != 0)
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV6, cep->ip6addr, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
        else
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_UNKNOWN, NULL, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
    }
  #else
    SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED, cep->ipaddr, cep->portno);
  #endif

    return E_OK;
}

/******************************************************************************
* Module Name   : udp_cre_cep                                                 *
* Purpose       : It creates a UDP communication end point.                   *
* Arguments     : ID cepid                  - UDP communication end point ID. *
*                 const T_UDP_CCEP *pk_ccep - Parameter informations required *
*                                             create a UDP CEP.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER udp_cre_cep(ID cepid, const T_UDP_CCEP *pk_ccep)
{
    T_UDP_CEP *cep;
    PRI save_pri;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* Error if CEP Already Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno != 0) {
        ercd = E_OBJ;
        goto ERR;
    }

    ercd = udp_cre_cep_sub(cep, pk_ccep);

ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : udp_vcre_cep                                                *
* Purpose       : It creates a UDP communication end point and the CEP ID for *
*                 this will be assinged automatically.                        *
* Arguments     : const T_UDP_CCEP *pk_ccep - Parameter informations required *
*                                             to create the UDP CEP.          *
* Return value  : Auto assigned ID value on success otherwise returns the     *
*                 error code.                                                 *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER udp_vcre_cep(const T_UDP_CCEP *pk_ccep)
{
    T_UDP_CEP *cep;
    PRI save_pri;
    ER ercd;
    ID cepid;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Serch unused CEP */

    for (cepid = UDP_CEPID_MAX;;) {
        if (cepid == 0) {
            ercd = E_ID;
            goto ERR;
        }
        cep = &UDP_CEP[--cepid];
        if (!cep->portno)
            break;
    }

    ercd = udp_cre_cep_sub(cep, pk_ccep);

ERR:
    tcpip_critical(FALSE, &save_pri);
    return (ercd == E_OK) ? (ER)++cepid : ercd;
}

/******************************************************************************
* Module Name   : udp_del_cep                                                 *
* Purpose       : It deletes a UDP communication end point and cancels any    *
*                 process pending for this CEP.                               *
* Arguments     : ID cepid - ID of the UDP CEP to be deleted.                 *
* Return value  : Auto assigned ID value on success otherwise returns the     *
*                 error code.                                                 *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
ER udp_del_cep(ID cepid)
{
    T_UDP_CEP *cep;
    ER ercd;
    T_UDP_RCV *data;
    T_NIF *nif;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto ERR;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* Error if CEP Not Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0)
    {   ercd = E_NOEXS;
        goto ERR;
    }

    /* Queued Sending Packet Removal */

    if (cep->nif == NULL || cep->ercd == E_LNK) {
        for (nif = getnif_default(); nif != NULL; nif = nif->next){
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR)
                remove_sndque_udppkt(nif->smbxid, (T_ETH *)&nif->na_waiting, cep, E_DLT);
            else
          #endif
                remove_sndque_udppkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, cep, E_DLT);
        }
    } else {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            remove_sndque_udppkt(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep, E_DLT);
        else
      #endif
            remove_sndque_udppkt(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep, E_DLT);
    }

    /*  Release receive waiting Task */

    do {
        ercd = prcv_mbx(cep->id_udp_mbx, (T_MSG **)&data);
        if (ercd == E_OK) {
            if (data->tskid != FALSE) {
                *(data->p_ercd) = E_DLT; /* Delete */
                rel_wai(data->tskid);
            }
            if (cep->callback != (TCP_CALLBACK)NULL) {
                ercd = E_DLT;
                /* Modified TFN_UDP_DEL_CEP as TFN_UDP_RCV_DAT - 07Jan2005 */
                (cep->callback)(cep->cepid, TFN_UDP_RCV_DAT, &ercd);
                ercd = E_OK; /* 07Jan2005 Don't Break the loop */
            }
        }
    } while(ercd == E_OK);

    ercd = E_OK;


    /* Mailbox and Memorypool Deletion */

    cep = &UDP_CEP[cepid];
    del_mbx(cep->id_udp_mbx);
    del_mpf(cep->id_udp_mpf);
    if (!TCP_MBXID_TOP)
        cep->id_udp_mbx = 0;
    if (!TCP_MPFID_TOP)
        cep->id_udp_mpf = 0;

    /* udpConnState */

  #ifdef DUAL_STK
    if (cep->type == IPV4_ADDR) {
        if (cep->ipaddr == 0)
            SNMP_UPDUDP(SNMP_CSTS_DELETETCB,SNMP_INAT_UNKNOWN, NULL, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
        else
            SNMP_UPDUDP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &cep->ipaddr, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
    } else if (cep->type == IPV6_ADDR) {
        if (cep->ip6addr[0] != 0)
            SNMP_UPDUDP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV6, cep->ip6addr, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
        else
            SNMP_UPDUDP(SNMP_CSTS_DELETETCB,SNMP_INAT_UNKNOWN, NULL, cep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
    }
  #else
    SNMP_UPDUDP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno);
  #endif

    /* Clear TCP REP Control Block */

    udp_def_cep(cep, FALSE);

    cep->ipaddr  = 0;
  #ifdef DUAL_STK
    memset(cep->ip6addr, 0, IP6_ADDR_SZ);
  #endif
    cep->portno  = 0;
    cep->options = 0;

    /* Clear Multicast Information */

    clr_mgrp_cb(cep);

    /* Normal Completion */

    if (save_pri <= PRI_TCPIP)
        rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */

    ercd = E_OK;

    /* Abnormal Completion */
ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : search_udp_cep                                              *
* Purpose       : This function searches whether the ipaddr & port pair is    *
*                 referred by any UDP CEP or not.                             *
* Arguments     : T_NIF    *nif   - Interface in which the packet is received *
*                 UW ipaddr - destination IP address of a received packet.    *
*                 UH portno - UDP Port number.                                *
* Return value  : TRUE if any UDP CEP assigned with the given address.        *
*                 else returns FALSE.                                         *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static T_UDP_CEP *search_udp_cep(T_NIF *nif, UW ipaddr, UH portno, UW srcaddr)
{
    T_UDP_CEP *cep, *cep1;
    int i;
    T_IPV4EP gaddr;
    T_MGRP_CB *mgrp;

    /* 03APR2006 - Invalid port number */
    if (portno == 0)
        return NULL;

    cep1 = NULL;

    /* Check for Multicast ipaddr */

    if ((ipaddr & 0xF0000000) == 0xE0000000) {
        gaddr.ipaddr = ipaddr;
        gaddr.portno = portno;
        i = search_igmp_group(nif, &gaddr); /* 04Feb2005 - Added 'nif' */
        if (i != -1) {
            mgrp = &mgrp_cb[i];
            if (igmp3_util_chksrc(mgrp->igmp_slist, srcaddr) == TRUE) {
                if (mgrp->mode == MODE_IS_INCLUDE) {
                    return mgrp->cep;
                }
                return NULL;
            }
            else {
                if (mgrp->mode == MODE_IS_EXCLUDE) {
                    return mgrp->cep;
                }
                return NULL;
            }
        }
        return NULL;
    }

    for (cep = pUDP_CEP; cep != NULL; cep = cep->next) {
      #ifdef DUAL_STK
        if (cep->type != IPV4_ADDR)
            continue;
      #endif
        if (portno == cep->portno) {

            /* AK 13MAR06 Processing Broadcast packets when default_ipaddr is zero.  */
            /* In this case, if cep is bind with some interface, then allow only those */
            /* interface packets. */

            if ((cep->nif != NULL) && (cep->nif != nif))
                continue;

            if (ipaddr == cep->ipaddr)
                return cep;
            else if ((cep->options & UDP_BROADCAST)
                    && (cep->nif != NULL) && (is_broadcast(cep->nif, ipaddr)))
                return cep;
            else if ((cep1 == NULL) && (cep->ipaddr == IPV4_ADDRANY))
                cep1 = cep;
        }
    }

    return cep1;
}

#ifdef DUAL_STK

static T_UDP_CEP *search_udp_cep6(T_NIF *nif, UW ip6addr[], UH portno)
{
    T_UDP_CEP *cep, *cep2, *cep3;

    /* 03APR2006 - Invalid port number */
    if (portno == 0)
        return NULL;

    cep2 = cep3 = NULL;

    for (cep = pUDP_CEP; cep != NULL; cep = cep->next) {
        if (cep->type != IPV6_ADDR)
            continue;

        /* return cep  - if portno, ip6addr and nif matches */
        /* return cep2 - if portno, nif matches and ip6addr is zero */
        /* return cep3 - if portno match and nif, ip6addr are zero */

        if (portno == cep->portno) {

            if (cep->nif == nif) {
                if(addr_type(ip6addr) & ADDR_MULTICAST){
                    return cep;
                }
                if ((is_ip6_addr_any(cep->ip6addr))) {
                    if (cep2 == NULL) {
                            cep2 = cep;
                    }
                }
                else {
                    if (!memcmp(ip6addr, cep->ip6addr, IP6_ADDR_SZ))
                        return cep;
                }
            }
            else {
                if ((cep->nif == NULL) && cep3 == NULL)
                    cep3 = cep;
            }
        }
    }

    if (cep2 != NULL) return cep2;
    return cep3;
}
#endif

#ifdef DUAL_STK
/*****************************************/
/*Mld2 filter at udp level               */
/*****************************************/
static T_UDP_CEP *mld2_udp_filt(T_UDP_CEP *cep, UW *src, UW *dst)
{
    T_MLD2_SRC *src_list;
    if(memcmp(cep->m_ip6addr, dst, IP6_ADDR_SZ) == 0){
        src_list = cep->src_list;
        if(cep->mode == MCAST_EXCLUDE){
            if(src_list == NULL){
                return cep;
            }
            while(src_list){
                if(memcmp(src_list->ip6addr, src, IP6_ADDR_SZ) == 0){
                    return NULL;
                }
                src_list = src_list->nxt;
            }
            if(src_list == NULL){
               return cep;
            }
        }
        else {
            while(src_list){
                if(memcmp(src_list->ip6addr, src, IP6_ADDR_SZ) == 0){
                   return cep;
               }
               src_list = src_list->nxt;
            }
            if(src_list == NULL){
               return NULL;
            }
        }
    }
    return NULL;
}

#endif

/******************************************************************************
* Module Name   : udp_checksum                                                *
* Purpose       : This function computes the checksum for UDP packet.         *
* Arguments     : T_UDP_PKT *pkt - UDP packet.                                *
* Return value  : Returns the computed checksum value.                        *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static UH udp_checksum(T_UDP_PKT *pkt, T_UDP_HEADER *udp, const VP data)
{
    UW sum;
    UH *p;
    int i;

    /* UDP Pseudo-Header */

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        p = (UH *)&(((T_IP6 *)pkt)->ip6.sa);
        sum = *p++;
        for (i = 0; i < 15; i++)    /* Source and Destiation IPv6 Address*/
            sum += *p++;
        sum += htons(PROT_UDP);     /* UDP Protocol Number */
        sum += udp->len;            /* UDP Packet Length */
    }
    else
  #endif
    {
        p = (UH *)&(pkt->ip.sa);
        sum  = *p++;                /* Source IP Address (High) */
        sum += *p++;                /* Source IP Address (Low) */
        sum += *p++;                /* Destination IP Address (High) */
        sum += *p++;                /* Destination IP Address (Low) */
        sum += htons(PROT_UDP);     /* UDP Protocol Number */
        sum += udp->len;            /* UDP Packet Length */
    }

    /* UDP Header */

    p = (UH *)udp;
    sum += *p++;                    /* Source Port Number */
    sum += *p++;                    /* Destination Port Number */
    sum += *p++;                    /* UDP Packet Length */

    /* UDP Data */

    p = (UH *)data;
    i = (ntohs(udp->len) - UDP_HEADER_SZ) / 2;
    while (--i >= 0)
        sum += *p++;
    if (ntohs(udp->len) & 1) {  /* Last Byte and Pad Byte */
        sum += (UH)(htons((ntohs(*p) & 0xff00)));
    }

    /* Add Carry and Complement */

    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);
    if ((UH)sum == 0xffff)
        return 0xffff;
    else
        return (UH)~sum;
}

/******************************************************************************
* Module Name   : get_udp_blf                                                 *
* Purpose       : This function allocates memory for outgoing UDP packet.     *
* Arguments     : T_UDP_CEP *cep - Packet control informations.               *
* Return value  : NULL if memory allocation is not possible else returns the  *
*                 packet.                                                     *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
static T_UDP_PKT *get_udp_blf(T_UDP_CEP *cep)
{
    T_UDP_PKT *pkt;
    ER ercd;
    ID mpfid;

    mpfid = cep->id_udp_mpf;
    ercd = pget_mpf(mpfid, &pkt);
    if (ercd != E_OK)
    {   if (ercd != E_TMOUT)
            udp_internal_error(ercd);
        return NULL;
    }

    memset(&(pkt->ctl), 0, sizeof (T_CTL_HEADER));
    pkt->ctl.cep = cep;
    pkt->ctl.mpfid = mpfid;
    return pkt;
}

/******************************************************************************
* Module Name   : make_udp_pkt                                                *
* Purpose       : This function constructs a UDP packet for transmission.     *
* Arguments     : T_UDP_PKT *pkt    - Buffer pointer for UDP packet.          *
*                 T_UDP_CEP *cep    - Packet control informations.            *
*                 const T_IPV4EP *p - IP address & port number to be used.    *
*                 const VP data     - UDP data.                               *
*                 INT len           - Length of the data.                     *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void make_udp_pkt(T_UDP_PKT *pkt, T_UDP_CEP *cep, const T_IPV4EP *p, const VP data, INT len)
{
    T_UDP_HEADER *udp;

    memset(pkt->eth.da, 0, 6);

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        pkt->eth.etype = htons(ETYPE_IP6);
        ((T_IP6 *)pkt)->ip6.nxt = PROT_UDP;
        if (cep->nif != NULL) {
            if (is_ip6_addr_any(cep->ip6addr))
                htonl6((UW *) set_src_addr(cep->nif, p->ip6addr), ((T_IP6 *)pkt)->ip6.sa);
            else
                htonl6(cep->ip6addr, ((T_IP6 *)pkt)->ip6.sa);
        }
        htonl6(p->ip6addr, ((T_IP6 *)pkt)->ip6.da);

        /* Set Hop Limit to zero. `ip_set_hdr6` will initialize with default hop limit */
        ((T_IP6 *)pkt)->ip6.hlim = 0;
        udp = &((T_UDP6_PKT *)pkt)->udp;
        ((T_UDP6_PKT *)pkt)->data = (UB *)data;
    } else
  #endif
    {
        pkt->eth.etype = htons(ETYPE_IP4);

        pkt->ip.prot = PROT_UDP;
        if (cep->nif != NULL)
            pkt->ip.sa = htonl(cep->ipaddr);
        pkt->ip.da = htonl(p->ipaddr);

        pkt->ip.tos = cep->tos;
        pkt->ip.ttl = cep->ttl;
        udp = &pkt->udp;
        pkt->data = (UB *)data;
    }

    udp->sp = htons(cep->portno);
    udp->dp = htons(p->portno);
    udp->len = htons(UDP_HEADER_SZ + len);
    udp->cs = udp_checksum(pkt, udp, data);
}

/******************************************************************************
* Module Name   : udp_snd_dat                                                 *
* Purpose       : API used for transmitting UDP data.                         *
* Arguments     : ID cepid          - UDP CEP id.                             *
*                 const T_IPV4EP                                              *
*                         p_dstaddr - Remote ipaddress & port number.         *
*                 const VP data     - UDP data.                               *
*                 INT len           - Length of the data.                     *
*                 TMO tmout         - Maximum time allowed for transmission.  *
* Return value  : On success it returns the length of transmitted data,       *
*                 else  returns the error code.                               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
ER udp_snd_dat(ID cepid, const T_IPV4EP *p_dstaddr, const VP data, INT len, TMO tmout)
{
    T_UDP_CEP *cep;
    T_UDP_PKT *pkt;
    T_NIF *nif;
    ER ercd;
    B flg;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto ERR;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* 06Jan2005 Validation for 'p_dstaddr' && 'data'*/

    if (p_dstaddr == NULL || data == NULL) {
        ercd = E_PAR;
        goto ERR;
    }

  #ifdef DUAL_STK
    if (p_dstaddr->type == IPV6_ADDR) {
        if ((is_ip6_addr_any(p_dstaddr->ip6addr)) || (p_dstaddr->portno == 0)) {
            ercd = E_PAR;
            goto ERR;
        }
    } else
  #endif
    {
        if ((p_dstaddr->ipaddr == 0L) || (p_dstaddr->portno == 0)) {
            ercd = E_PAR;
            goto ERR;
        }
    }

  #if (SIZEOF_INT <= 2)       /* 16-bit CPU */
    if (len <= 0) {
  #else
   #ifdef DUAL_STK
    if ((len <= 0)
        || ((p_dstaddr->type == IPV6_ADDR) && (len > UDP_SEND_MAX_LEN_IPV6))
        || ((p_dstaddr->type == IPV4_ADDR) && (len > UDP_SEND_MAX_LEN_IPV4))) {
   #else
    if ((len <= 0) || (len > UDP_SEND_MAX_LEN_IPV4)) { /* Invalid len */
   #endif
  #endif
        ercd = E_PAR;
        goto ERR;
    }

    if ((UW)data & 1) { /* Odd Address ? */
        ercd = E_PAR;
        goto ERR;
    }

    /* Error if CEP Not Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0) {
        ercd = E_NOEXS;
        goto ERR;
    }

    /* Interface for this CEP is already deleted */
    if (cep->ercd == E_LNK) {
        ercd = E_LNK;
        goto ERR;
    }

    pkt = get_udp_blf(cep);
    if (pkt == NULL) {
        ercd = E_QOVR;
        goto ERR;
    }

    if (tmout == TMO_NBLK) {
        pkt->ctl.callback = cep->callback;
        pkt->ctl.fncd = TFN_UDP_SND_DAT;
        pkt->ctl.parblk = len;
    }
    else
        pkt->ctl.tskid = vget_tid();

    nif = cep->nif;

    flg = FALSE;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        /* Set 'flg' if dstaddr is Broadcast/Multicast address */
        flg = FALSE;
    } else
  #endif
    {
        /* 28Oct2004 - Corrected for Broadcast address check when */
        /*             'nif' value is unknown.                    */
        if (((p_dstaddr->ipaddr & 0xF0000000) == 0xE0000000) ||
            (p_dstaddr->ipaddr == 0xFFFFFFFF) ||
            ((nif != NULL) && (is_broadcast(nif, p_dstaddr->ipaddr))))
            flg = TRUE;    /* Check for Broadcast or Multicast */
    }

    if (cep->nif == NULL) {

        /* User may wants to send data using recv information
           so check that first */
        if ((cep->options & UDP_USE_RMSG) && (cep->rmsg.nif != NULL)) {
            nif = cep->rmsg.nif;
        } else if (flg) {   /* if Broadcast or Multicast dest ipaddr */
            nif =  getnif_default();
            if (nif == NULL) {
                rel_mpf(pkt->ctl.mpfid, pkt);
                ercd = E_OBJ;
                goto ERR;
            }
        } else {
            /* Get interface using remote ipaddr */
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR) {
                nif = getnif_dst6addr(p_dstaddr->ip6addr);
                if (nif == NULL) {
                    rel_mpf(pkt->ctl.mpfid, pkt);
                    ercd = E_OBJ;
                    goto ERR;
                }
            }
            else
          #endif
            {
                nif = getnif_dstaddr(p_dstaddr->ipaddr);
                if (nif == NULL) {
                    rel_mpf(pkt->ctl.mpfid, pkt);
                    ercd = E_OBJ;
                    goto ERR;
                }
            }
        }

      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            htonl6((UW *) set_src_addr(nif, p_dstaddr->ip6addr), ((T_IP6 *) pkt)->ip6.sa);

            /* Set 'flg' if dstaddr is Broadcast/Multicast address */
        } else
      #endif
        {
            ((T_IP4 *) pkt)->ip.sa = byte4_to_long(nif->ipaddr);
            ((T_IP4 *) pkt)->ip.sa = htonl(((T_IP4 *) pkt)->ip.sa);

            /* 28Oct2004 - Check for broadcast addr for this interface */
            if ((flg == FALSE) && (is_broadcast(nif, p_dstaddr->ipaddr)))
                flg = TRUE;
        }
    } else {
        nif = cep->nif;
    }

    if (flg == FALSE) {
      #ifdef DUAL_STK
        if (cep->type == IPV4_ADDR)
      #endif
        {
            /* dstipaddr should not be a ipaddress of local host */
            /* This cannot be allowed unless loopback interface is
               enabled. */
            if (nif->type != NI_LOOP) {
                if (is_nif_ipaddr(nif, p_dstaddr->ipaddr)) {
                    rel_mpf(pkt->ctl.mpfid, pkt);
                    ercd = E_PAR;
                    goto ERR;
                }
            }
        }
    }

    make_udp_pkt(pkt, cep, p_dstaddr, data, len);
    if (
      #ifdef DUAL_STK
        (cep->type == IPV4_ADDR) &&
      #endif
        (cep->ttl == 0)) {
        ((T_IP4 *) pkt)->ip.ttl = nif->ip.ttl;
    }

    vcan_wup();
    pkt->ctl.hedflg = FALSE;
    pkt->ctl.nif = nif; /* 11Jan2005 TCP_EXT */

    ercd = snd_mbx(nif->smbxid, (T_MSG *)pkt);
    if (ercd != E_OK) {
        rel_mpf(pkt->ctl.mpfid, pkt);
        goto ERR;
    }

    if (tmout == TMO_NBLK) {
        tcpip_critical(FALSE, &save_pri);
        return E_WBLK;
    }

    rot_rdq(TPRI_SELF);
    ercd = tslp_tsk(tmout);
    vcan_wup();

    if (ercd != E_OK) {
        /* To support tcp_ext() */
        if (ercd == E_RLWAI) {
            if (cep->ercd == E_LNK) {   /* Interface deleted */
                ercd = cep->ercd;
                goto ERR;
            }
        }

        if (ercd == E_RLWAI && cep->ipaddr == 0 && cep->portno == 0) {
            ercd = E_DLT;
            goto ERR;
        } else {
            /* 17May2005 - Release the pkt which was sent by this call */
            if (ercd == E_TMOUT) {
              #ifdef DUAL_STK
                if (cep->type == IPV6_ADDR)
                    flg = remove_mbx_pkt(nif->smbxid, (T_ETH *)&nif->na_waiting, cep, (T_ETH *)pkt);
                else
              #endif
                    flg = remove_mbx_pkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, cep, (T_ETH *)pkt);
                if (!flg) {
                    ercd = len;
                    goto ERR;
                }
            }
            goto ERR;
        }
    }
    SNMP_BYPCNT(snmp_mibbyp.udpOutDatagrams, 1);  /* udpOutDatagrams */
  #ifdef DUAL_STK
    SNMP_BYPCNT64(snmp_mibbyp.udpHCOutDatagrams, 1);  /* udpHCOutDatagrams */
  #endif
    tcpip_critical(FALSE, &save_pri);
    return len;

    /* Abnormal Completion */
ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Function Name : dup_mcast_pkt                                               *
* Purpose       : Searches for any other CEPs listening on the same multicast *
*                 address/port, and delivers data, remote address/port number *
*                 and data length to each matching CEP.                       *
* Arguments     : T_NIF *nif     - Pointer to interface                       *
*                 T_IPV4EP *p    - Pointer to remote address and port number  *
*                 UB *data       - Pointer to data received                   *
*                 INT len        - Length of data received                    *
*                 T_UDP_CEP *cep - Pointer to CEP to which data is delivered  *
*                 UW da          - Multicast group address                    *
*                 UH dp          - Listening port number                      *
* Return value  : None                                                        *
******************************************************************************/

static void dup_mcast_pkt(T_NIF *nif, T_IPV4EP *p, UB *data, INT len, T_UDP_CEP *cep, UW da, UH dp)
{
    T_UDP_RCV *q;
    ID tskid;
    ER ercd;
    UB *bp;
    int i;

    /* skip till CEP to which data is delivered */
    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        if (mgrp_cb[i].cep == cep && mgrp_cb[i].ipaddr == da &&
            mgrp_cb[i].portno == dp && mgrp_cb[i].nif == nif)
            break;
    }
    i++;

    /* for each CEP listening on this address and port, copy the data */
    for (; i < MULTICAST_GROUP_CNT; i++) {
        if (mgrp_cb[i].ipaddr == da && mgrp_cb[i].portno == dp &&
            mgrp_cb[i].nif == nif) {

            cep = mgrp_cb[i].cep;
            ercd = prcv_mbx(cep->id_udp_mbx, (T_MSG **)&q);
            if (ercd == E_OK) { /* if reception request is queued, */
                q->p_dstaddr->portno = p->portno;
                q->p_dstaddr->ipaddr = p->ipaddr;

                if (len > q->len)
                    len = q->len;
                bp = q->buf;
                tskid = q->tskid;
                memcpy(bp, data, len);  /* copy data */
                if (tskid != FALSE) {   /* wake-up waiting task */
                    *(q->p_ercd) = len;
                    ercd = wup_tsk(tskid);
                    if (ercd != E_OK)
                        udp_internal_error(ercd);
                } else if (cep->callback != (TCP_CALLBACK)NULL) {
                    /* if no waiting task (non-blocking mode), notify callback */
                    (cep->callback)(cep->cepid, TFN_UDP_RCV_DAT, &len);
                }
            } else if (ercd == E_TMOUT) { /* if no reception request queued, */
                T_UDP_RCV d;

                d.p_dstaddr = p;
                d.buf = data;
                d.len = len;            /* pass data to callback */
                if (cep->callback != (TCP_CALLBACK)NULL)
                    (cep->callback)(cep->cepid, TEV_UDP_RCV_MCAST, &d);
            }       /* copy data, remote addr to user buffer inside callback */
        }
    }
}

/******************************************************************************
* Module Name   : udp_rcv_dat_now                                             *
* Purpose       : This function is called by udp reception to process the UDP *
*                 packet that is already received in the network and not yet  *
*                 processed.                                                  *
* Arguments     : T_IPV4EP *p    - Pointer to fill remote address & port no.  *
*                 UB *data       - User data buffer.                          *
*                 INT len        - Length of the data to be received.         *
*                 T_UDP_PKT *pkt - Received UDP packet.                       *
* Return value  : On success it returns the length of the data readed from    *
*                 the network. Else returns the error code.                   *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static ER udp_rcv_dat_now(T_IPV4EP *p, UB *data, INT size, T_UDP_PKT *pkt, T_UDP_CEP *cep)
{
    ER ercd;
    ER len;
    T_NIF *nif = pkt->ctl.nif;
    T_UDP_HEADER* udp;
    UH ulen;

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        if (pkt->ctl.rcheck) {
            if (!get_reassembly6_buffer((T_IPF *)pkt, 0, (VP *)&udp, &ulen) || ulen < UDP_HEADER_SZ) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        } else {
            udp = &((T_UDP6_PKT *)pkt)->udp;
        }
    } else
  #endif
    if (pkt->ctl.rcheck) {
        if (!get_reassembly_buffer((T_IPF *)pkt, 0, (VP *)&udp, &ulen) || ulen < UDP_HEADER_SZ) {
            len = 0;
            SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
            goto END;
        }
    } else {
        udp = &pkt->udp;
    }

    p->portno = ntohs(udp->sp);
    len = ntohs(udp->len) - UDP_HEADER_SZ;

    if (len > size)
        len = E_BOVR;
    else
        size = len;

  #ifdef DUAL_STK
    p->type = IPV4_ADDR;
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        ntohl6(((T_IP6 *)pkt)->ip6.sa, p->ip6addr);
        p->type = IPV6_ADDR;
        if (!((T_IP *)pkt)->ctl.rcheck) {
            memcpy(data, &((T_UDP6_PKT *)pkt)->data, size);
        } else {
            /* Get data from reassembly buffer */
            if (!udp6_cpy_dat(data, (T_IP6 *)pkt, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        }
    } else
  #endif
    {
        p->ipaddr = ntohl(pkt->ip.sa);

        if (!pkt->ctl.rcheck) {
            if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, data, size, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        } else {
            /* Get data from reassembly buffer */
            if (!udp_cpy_dat(data, (T_IP4 *)pkt, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        }
    }

    if (udp->cs != 0 && len >= 0) {
        if (udp->cs != udp_checksum(pkt, udp, data)) {
            len = 0;
            SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
        }
    }

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP4)
  #endif
    if ((ntohl(pkt->ip.da) & 0xF0000000) == 0xE0000000)
        /* deliver data of this multicast packet to each matching CEP */
        dup_mcast_pkt(nif, p, data, size, cep, ntohl(pkt->ip.da), ntohs(udp->dp));

END:
    if (pkt->ctl.rcheck) {
        clr_frag_list((T_IPF *)pkt, TRUE);
        ercd = E_OK;
    } else {
        ercd = rel_mpf(pkt->ctl.mpfid, pkt);
        if (ercd != E_OK)
            udp_internal_error(ercd);
    }

    return len;
}

/******************************************************************************
* Module Name   : udp_rcv_dat_que                                             *
* Purpose       : This function queus the UDP reception request when no data  *
*                 is received in the network.                                 *
* Arguments     : T_IPV4EP *p    - Pointer to fill remote address & port no.  *
*                 VP buf         - User data buffer.                          *
*                 ER *len        - Length of the data to be received.         *
*                 TMO tmout      - Timeout for reception process.             *
* Return value  : E_OK if queued successfully else returns the error code.    *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
static ER udp_rcv_dat_que(T_UDP_CEP *cep, T_IPV4EP *p, VP buf, ER *len, TMO tmout)
{
    ER ercd;
    T_UDP_RCV *data;
    INT m;

  #if (SIZEOF_INT == 4)
    m = 4 - ((INT)buf & 3);
    if (m == 4)
        m = 0;
    data = (T_UDP_RCV *)((UW)buf + m);
  #else
    m = 0; /* 4.04.00a */
    data = buf;
  #endif
    if (*len - m < sizeof (T_UDP_RCV))  /* size for system use */
        return E_PAR;

    data->p_dstaddr = (T_IPV4EP *)p;
    data->p_ercd = len;
    data->buf = buf;
    data->len = *len;
    if (tmout == TMO_NBLK)
        data->tskid = FALSE;
    else
        data->tskid = (UH)vget_tid();

    ercd = snd_mbx(cep->id_udp_mbx, (T_MSG *)data);
    if (tmout == TMO_NBLK)
        return E_WBLK;

    return ercd;
}

/******************************************************************************
* Module Name   : udp_rcv_dat                                                 *
* Purpose       : API to receive UDP data.                                    *
* Arguments     : ID cepid       - UDP CEP id.                                *
*                 T_IPV4EP                                                    *
*                     *p_dstaddr - Pointer to fill remote address & port no.  *
*                 VP data        - User data buffer.                          *
*                 INT len        - Length of the data to be received.         *
*                 TMO tmout      - Timeout for reception process.             *
* Return value  : On success returns the length of received data else returns *
*                 the error code.                                             *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/
ER udp_rcv_dat(ID cepid, T_IPV4EP *p_dstaddr, VP data, INT len, TMO tmout)
{
    T_UDP_CEP *cep;
    T_UDP_PKT *pkt;
    ER ercd;
    ER len2;
    T_UDP_RCV *udp_rcv;
    T_NIF *nif;
    ID tskid;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto ERR;
    }

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* 06Jan2005 Validation for 'p_dstaddr', 'data' && 'len' */

    if (p_dstaddr == NULL || data == NULL) {
        ercd = E_PAR;
        goto ERR;
    }

    if ((UW)data & 1) { /* Odd Address ? */
        ercd = E_PAR;
        goto ERR;
    }

  #if (SIZEOF_INT <= 2)       /* 16-bit CPU */
    if (len <= 0) {
  #else
    if ((len <= 0) || (len > 0xffff)) {
  #endif
        ercd = E_PAR;
        goto ERR;
    }

    if (tmout == TMO_POL) {
        nif = getnif_default();
        tskid = vget_tid();
        for (; nif != NULL; nif=nif->next) {
            if (nif->rtskid == tskid)
                break;
        }
        if (nif == NULL) {
            ercd = E_PAR; /* Error except a callback */
            goto ERR;
        }
    }

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0) {
        ercd = E_NOEXS;
        goto ERR;
    }

    /* Interface for this CEP is already deleted */
    if (cep->ercd == E_LNK) {
        ercd = E_LNK;
        goto ERR;
    }

    pkt = cep->pkt;
    if (pkt != NULL) {
        len = udp_rcv_dat_now(p_dstaddr, data, len, pkt, cep);
        /* To be used in sending process when UDP_USE_RMSG is set */
        cep->rmsg.nif = pkt->ctl.nif;
        cep->pkt = NULL;
        tcpip_critical(FALSE, &save_pri);
        return len;
    } else {
        len2 = len;
        ercd = udp_rcv_dat_que(cep, p_dstaddr, data, &len2, tmout);
        if (ercd != E_OK)
            goto ERR;

        vcan_wup();
        ercd = tslp_tsk(tmout);
        vcan_wup();

        if (ercd < E_OK) {
            /* To support tcp_ext() */
            if (ercd == E_RLWAI) {
                if (cep->ercd == E_LNK) {   /* Interface deleted */
                    ercd = cep->ercd;
                    goto ERR;
                }
            }

            if (ercd == E_RLWAI && cep->ipaddr == 0 && cep->portno == 0) {
                udp_rcv = (T_UDP_RCV *)data;
                if (*udp_rcv->p_ercd == E_DLT) {
                    ercd = E_DLT;
                    goto ERR;
                }
            }
            remove_rcvque_udppkt(cep->id_udp_mbx, data);
            goto ERR;
        }
        tcpip_critical(FALSE, &save_pri);
        return len2;
    }

    /* Abnormal Completion */
ERR:
    tcpip_critical(FALSE, &save_pri);

    return ercd;
}

/******************************************************************************
* Module Name   : udp_reception_sub1                                          *
* Purpose       : This function called by UDP reception whenever a UDP packet *
*                 received and a reception request is already queued.         *
* Arguments     : T_UDP_RCV *data - Queud request for reception.              *
*                 T_UDP_PKT *pkt  - Received UDP packet.                      *
*                 T_UDP_CEP *cep  - UDP control informations.                 *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void udp_reception_sub1(T_UDP_RCV *data, T_UDP_PKT *pkt, T_UDP_CEP *cep, T_UDP_HEADER *udp)
{
    T_NIF *nif;
    ID tskid;
    ER ercd, len, size;
    ER *p_ercd;
    VP bp;

    len = ntohs(udp->len) - UDP_HEADER_SZ;
    size = data->len;
    if (len > size)
        len = E_BOVR;
    else
        size = len;

    nif = pkt->ctl.nif;
    tskid = data->tskid;
    p_ercd = data->p_ercd;
    bp = data->buf;
    data->p_dstaddr->portno = ntohs(udp->sp);

  #ifdef DUAL_STK
    data->p_dstaddr->type = IPV4_ADDR;
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        ntohl6(((T_IP6 *)pkt)->ip6.sa, data->p_dstaddr->ip6addr);
        data->p_dstaddr->type = IPV6_ADDR;
        if (!pkt->ctl.rcheck) {
            memcpy(bp, &((T_UDP6_PKT *)pkt)->data, ntohs(udp->len) - UDP_HEADER_SZ);
        } else {
            /* get data from reassembly buffer */
            if (!udp6_cpy_dat(bp, (T_IP6 *)pkt, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        }
    }
    else
  #endif
    {
        data->p_dstaddr->ipaddr = ntohl(pkt->ip.sa);

        if (!pkt->ctl.rcheck) {
            if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, bp, size, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        } else {
            /* get data from reassembly buffer */
            if (!udp_cpy_dat(bp, (T_IP4 *)pkt, size)) {
                len = 0;
                SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
                goto END;
            }
        }
    }

    if (udp->cs != 0 && len >= 0) {
        if (udp->cs != udp_checksum(pkt, udp, bp)) {
            len = 0;
            SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
        }
    }

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP4)
  #endif
    if ((ntohl(pkt->ip.da) & 0xF0000000) == 0xE0000000)
        /* deliver data of this multicast packet to each matching CEP */
        dup_mcast_pkt(nif, data->p_dstaddr, bp, size, cep, ntohl(pkt->ip.da), ntohs(udp->dp));

END:

    /* to be used in sending process when UDP_USE_RMSG is set */
    cep->rmsg.nif = nif;

    if (tskid != FALSE) {
        *p_ercd = (ER)len;
        ercd = wup_tsk(tskid);
        if (ercd != E_OK)
            udp_internal_error(ercd);
    } else if (cep->callback != (TCP_CALLBACK)NULL) {
        (cep->callback)(cep->cepid, TFN_UDP_RCV_DAT, &len);
    }
}

/******************************************************************************
* Module Name   : udp_reception_sub2                                          *
* Purpose       : This function is called by UDP reception to check whether   *
*                 any callback function has to be called during a packet      *
*                 reception.                                                  *
* Arguments     : T_UDP_PKT *pkt  - Received UDP packet.                      *
*                 T_UDP_CEP *cep  - UDP control informations.                 *
* Return value  : Return code of callback function.                           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static T_UDP_PKT *udp_reception_sub2(T_UDP_PKT *pkt, T_UDP_CEP *cep, T_UDP_HEADER *udp)
{
    INT len;
    T_NIF *nif = pkt->ctl.nif;
    T_IPV4EP maddr;
    int i;

    cep->pkt = pkt;
    len = ntohs(udp->len) - UDP_HEADER_SZ;
    if (cep->callback != (TCP_CALLBACK)NULL) {
        (cep->callback)(cep->cepid, TEV_UDP_RCV_DAT, &len);
        if (cep->pkt == NULL)
            return NULL;
    }

    cep->pkt = NULL;

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP4)
  #endif
    {
        maddr.ipaddr = ntohl(pkt->ip.da);
        /* if multicast packet, check any other CEP ready to receive packet */
        if ((maddr.ipaddr & 0xF0000000) == 0xE0000000) {
            maddr.portno =  ntohs(udp->dp);
            i = search_igmp_group(nif, &maddr); /* skip first CEP checked above */
            for (i++; i < MULTICAST_GROUP_CNT; i++) {
                if (mgrp_cb[i].ipaddr == maddr.ipaddr &&
                    mgrp_cb[i].portno == maddr.portno && mgrp_cb[i].nif == nif) {
                    cep = mgrp_cb[i].cep;
                    cep->pkt = pkt;
                    if (cep->callback != (TCP_CALLBACK)NULL) {
                        (cep->callback)(cep->cepid, TEV_UDP_RCV_DAT, &len);
                        if (cep->pkt == NULL)
                            return NULL; /* packet received and copied to others */
                    }
                    cep->pkt = NULL;
                }
            }
        }
    }

    if (!pkt->ctl.rcheck)
        (*nif->func)(nif, TFN_NET_IGN_PKT);

    return pkt;
}

/******************************************************************************
* Module Name   : udp_reception                                               *
* Purpose       : This function is called from IP layer whenever a UDP packet *
*                 is received. It reads the UDP header informations, checks   *
*                 matching CEP for the received packet and calls appropriate  *
*                 functions to handle the packet.                             *
* Arguments     : T_UDP_PKT *pkt  - Received UDP packet.                      *
* Return value  : Returns the packet.                                         *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

VP udp_reception(T_UDP_PKT *pkt)
{
    T_UDP_CEP *cep;
    T_UDP_RCV *data;
    ER ercd;
    T_NIF *nif = pkt->ctl.nif;
    T_UDP_HEADER *udp;
    T_ICMP_HEADER icmp;
    UH ulen;
    UW ipaddr, mask;
  #ifdef DUAL_STK
    UW ip6addr[4];
    T_ICMPV6_HEADER icmpv6;
    UW srcaddr[4];
  #endif
    UH opl;
    T_UDP_PKT *p;

    ipaddr = htonl(pkt->ip.da);

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        if (pkt->ctl.rcheck) {
            if (!get_reassembly6_buffer((T_IPF *)pkt, 0, (VP *)&udp, &ulen) || ulen < UDP_HEADER_SZ)
                return pkt;
        } else {
            udp = &((T_UDP6_PKT *)pkt)->udp;
        }

        ntohl6(((T_IP6 *)pkt)->ip6.da, ip6addr);
        cep = search_udp_cep6(nif, ip6addr, ntohs(udp->dp));
        if ((cep != NULL) && (addr_type(ip6addr) & ADDR_MULTICAST)) {
            ntohl6(((T_IP6 *)pkt)->ip6.sa, srcaddr);
            cep = mld2_udp_filt(cep, srcaddr, ip6addr);
        }
    } else
  #endif
    {
        if (pkt->ctl.rcheck) {
            if (!get_reassembly_buffer((T_IPF *)pkt, 0, (VP *)&udp, &ulen) || ulen < UDP_HEADER_SZ)
                return pkt;
        } else {
            udp = &pkt->udp;
            if (!(*nif->func)(nif, TFN_NET_RED_PKT, udp, UDP_HEADER_SZ))
                return pkt;
        }

        cep = search_udp_cep(nif, ipaddr, ntohs(udp->dp), ntohl(pkt->ip.sa));
    }

    if (cep == NULL) {
      #ifdef DUAL_STK
        if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
            if ( !(addr_type(ntohl6(((T_IP6 *)pkt)->ip6.sa, ip6addr)) & ADDR_UNICAST) ||
                (addr_type(ntohl6(((T_IP6 *)pkt)->ip6.da, ip6addr)) & ADDR_MULTICAST))
                return pkt;
            else {
                /* Make Error Message */
                SNMP_BYPCNT(snmp_mibbyp_icmpv6[nif->ch].ipv6IfIcmpOutDestUnreachs, 1);   /* ipv6IfIcmpInDestUnreachs */
                if (SYSCK.ltime - nif->icmpdu < MSEC2TICK(ICMP_DU_RATE))
                    return pkt;
                nif->icmpdu = SYSCK.ltime;
                icmpv6.type = ICMPV6_DST_UNREACHABLE;
                icmpv6.code = 4;
                icmpv6.rsrvd = 0;
                ntohl6(((T_IP6 *)pkt)->ip6.sa, ip6addr);

                /* Send Error Message */
                SNMP_BYPCNT(snmp_mibbyp_icmpv6[nif->ch].ipv6IfIcmpOutErrors, 1);
                icmpv6_snd_out(nif, set_src_addr(nif, ip6addr), ip6addr, &icmpv6,
                    &((T_UDP6_PKT *)pkt)->data, 1232);

                return pkt;
            }
        }
        else
      #endif
        {
            if ((ipaddr & 0xF0000000) != 0xE0000000 &&      /* not multicast */
                ipaddr != 0xFFFFFFFF) {                     /* not broadcast */
                mask = byte4_to_long(pkt->ctl.nif->mask);
                if ((ipaddr & ~mask) != ~mask ||            /* not directed-broadcast */
                    (ipaddr & mask) != (byte4_to_long(pkt->ctl.nif->ipaddr) & mask)) {
                    SNMP_BYPCNT(snmp_mibbyp.udpNoPorts, 1); /* udpNoPorts */
                    if (SYSCK.ltime - nif->icmpdu < MSEC2TICK(ICMP_DU_RATE)) {
                        if (!pkt->ctl.rcheck)
                            (*nif->func)(nif, TFN_NET_IGN_PKT);
                        return pkt;
                    }
                    nif->icmpdu = SYSCK.ltime;
                    icmp.type = TYPE_UNREACHABLE;           /* destination unreachable (ICMP type 3) */
                    icmp.code = 3;                          /* port unreachable */
                    icmp.cs = icmp.id = icmp.seq = 0;
                    p = pkt;
                    if (p->ctl.rcheck) {
                        while (((T_IPF *)p)->ofs != 0) { /* search fragment offset 0 */
                            p = (T_UDP_PKT *)(((T_IPF *)p)->nextf);
                            if (p == NULL)
                                return pkt;
                        }
                    }
                    opl = (p->ip.ver & 0x0F) * 4 - IP4_HEADER_SZ; /* IP options length */
                    if (opl != 0) {
                        memmove((UB *)udp + opl, udp, UDP_HEADER_SZ);
                        memcpy(udp, ((T_IP4 *)p)->data + PATH_MTU4 - opl, opl);
                    }
                    if (!pkt->ctl.rcheck) {
                        if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, (UB *)(&p->data) + opl,
                            ntohs(p->ip.tl) - IP4_HEADER_SZ - UDP_HEADER_SZ,
                            PATH_MTU4 - opl - UDP_HEADER_SZ)) /* read UDP data to store it in ICMP message */
                            return p;
                    }
                    p->ip.tl = htons(ntohs(p->ip.tl) + opl);
                    ulen = ntohs(p->ip.tl);
                    ulen = MIN(ulen, nif->path_mtu - sizeof (T_ICMP_HEADER));
                    icmp_snd_data(ipaddr, ntohl(p->ip.sa), &icmp, &p->ip, ulen);
                    return pkt;
                }
            }

            if (!pkt->ctl.rcheck)
                (*nif->func)(nif, TFN_NET_IGN_PKT);
            return pkt;
        }
    }

    /* discard packet with too short length field */
    if (ntohs(udp->len) < UDP_HEADER_SZ) {
        if (
          #ifdef DUAL_STK
            ntohs(pkt->eth.etype) != ETYPE_IP6 &&
          #endif
            !pkt->ctl.rcheck)
            (*nif->func)(nif, TFN_NET_IGN_PKT);
        SNMP_BYPCNT(snmp_mibbyp.udpInErrors, 1);  /* udpInErrors */
        return pkt;
    }

    SNMP_BYPCNT(snmp_mibbyp.udpInDatagrams, 1);  /* udpInDatagrams */
  #ifdef DUAL_STK
    SNMP_BYPCNT64(snmp_mibbyp.udpHCInDatagrams, 1);  /* udpHCInDatagrams */
  #endif
    ercd = prcv_mbx(cep->id_udp_mbx, (T_MSG **)&data);
    if (ercd == E_OK)
        udp_reception_sub1(data, pkt, cep, udp);
    else if (ercd == E_TMOUT)
        pkt = udp_reception_sub2(pkt, cep, udp);
    else
        udp_internal_error(ercd);

    return pkt;
}

/******************************************************************************
* Module Name   : udp_can_cep                                                 *
* Purpose       : API to cancel UDP processes.                                *
* Arguments     : ID cepid - UDP CEP id value to be cancelled.                *
*                 FN fncd  - Function code of the service to be cancelled.    *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER udp_can_cep(ID cepid, FN fncd)
{
    T_UDP_CEP *cep;
    ER ercd;
    T_UDP_RCV *data;
    BOOL sflg, rflg;
    T_NIF *nif;
    PRI save_pri;

    sflg = rflg = FALSE;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto ERR;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    if (fncd != TFN_UDP_SND_DAT && fncd != TFN_UDP_RCV_DAT && fncd != TFN_UDP_ALL) {
        ercd = E_PAR;
        goto ERR;
    }

    /* Error if CEP Not Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0) {
        ercd = E_NOEXS;
        goto ERR;
    }

    /* Interface for this CEP is already deleted */
    if (cep->ercd == E_LNK) {
        ercd = E_LNK;
        goto ERR;
    }

    if (fncd == TFN_UDP_RCV_DAT || fncd == TFN_UDP_ALL) {
        do {
            ercd = prcv_mbx(cep->id_udp_mbx, (T_MSG **)&data);
            if (ercd == E_OK) {
                rflg = TRUE;
                if (data->tskid != FALSE) {
                    *(data->p_ercd) = E_DLT; /* Delete */
                    rel_wai(data->tskid);
                }
                if (cep->callback != (TCP_CALLBACK)NULL) {
                    ercd = E_RLWAI;
                    (cep->callback)(cep->cepid, TFN_UDP_RCV_DAT, &ercd);
                    ercd = E_OK; /* 07Jan2005 Don't Break the loop */
                }
            }
        } while(ercd == E_OK);
    }
    if (fncd == TFN_UDP_SND_DAT || fncd == TFN_UDP_ALL) {
        if (cep->nif == NULL) {
            nif = getnif_default();
            while (nif != NULL) {
              #ifdef DUAL_STK
                if (cep->type == IPV6_ADDR)
                    sflg = remove_sndque_udppkt(nif->smbxid, (T_ETH *)&nif->na_waiting, cep, E_RLWAI);
                else
              #endif
                    sflg = remove_sndque_udppkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, cep, E_RLWAI);
                nif = nif->next;
            }
        } else {
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR)
                sflg = remove_sndque_udppkt(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep, E_RLWAI);
            else
          #endif
                sflg = remove_sndque_udppkt(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep, E_RLWAI);
        }
    }

    if (save_pri <= PRI_TCPIP && (sflg || rflg))
        rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */

    tcpip_critical(FALSE, &save_pri);

    if (sflg || rflg)
       return E_OK;
    else
       return E_OBJ;

ERR:
    tcpip_critical(FALSE, &save_pri);

    return ercd;

}

/******************************************************************************
* Module Name   : udp_set_opt                                                 *
* Purpose       : API to set various UDP CEP options.                         *
* Arguments     : ID cepid        - UDP CEP id.                               *
*                 INT optname     - UDP option to be configured.              *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER udp_set_opt(ID cepid, INT optname, const VP optval, INT optlen)
{
    UW ipaddr, mask;
    int n, mcnt;
    UW new_state;
    BOOL is_empty;
    ID fentry;
    T_IGMP3_SRC *if_slist = NULL;
    T_IGMP3_USL *usl;
    T_UDP_CEP *cep, *c;
    ER ercd = E_OK;
    T_NIF *nif;
    T_IPV4EP gaddr;
    T_IPV4EP *p_gaddr;
    PRI save_pri;
  #ifdef DUAL_STK
    T_MLD2_SRC *src_list;
    UH mode;
  #endif

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK; /* No Interface available */
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        tcpip_critical(FALSE, &save_pri);
        return E_ID;
    }

    /* Error if CEP Not Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0) {
       tcpip_critical(FALSE, &save_pri);
       return E_NOEXS;
    }

    /* Interface for this CEP is already deleted */
    if (cep->ercd == E_LNK) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK;
    }

    nif = cep->nif;

    switch (optname) {
    case IP_ADD_MEMBERSHIP:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }

        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        /* 04Feb2005 - CEP can register to more than one multicast group */

        if (cep->options & UDP_BROADCAST) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        if (optval == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }

        n = search_igmp_group(nif, (T_IPV4EP *)optval);
        if (n != -1 && !(cep->options & UDP_REUSEPORT)) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        /* Check entry space */
        gaddr.ipaddr = 0;
        gaddr.portno = 0;
        n = search_igmp_group(NULL, &gaddr);
        if (n == -1) {
            tcpip_critical(FALSE, &save_pri);
            return E_NOID;
        }

        p_gaddr = (T_IPV4EP *)optval; /* Pointer to Group Addr structure */

        /* Join the Multicast Address at CEP level */
        igmp3_cep_jgrp(nif, cep, n, p_gaddr);

        /* Check no of CEP with the given MCast addr, New state, first entry */
        /* ID with the MCAST address, Check for Empty list with Exclude mode */
        mcnt = igmp3_chk_sts(nif, p_gaddr->ipaddr, &new_state, &fentry, &is_empty);

        if (mcnt == 1) { /* First instance. So, Join */
            ercd = igmp3_if_jgrp(nif, &mgrp_cb[n]);
        } else {
            /* Generate the source list for the interface */
            ercd = igmp3_if_genslist(nif, p_gaddr->ipaddr, new_state, mcnt,
                     is_empty, fentry, &if_slist);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
            /* Update the Interface module with the new source list */
            ercd = igmp3_if_upgrp(nif, p_gaddr->ipaddr, new_state, if_slist);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        }
        break;
    case IP_DROP_MEMBERSHIP:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }

        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        if (optval == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }

        n = search_igmp_group(nif, (T_IPV4EP *)optval);
        if (n == -1) {
            tcpip_critical(FALSE, &save_pri);
            return E_NOEXS;
        }

        p_gaddr = (T_IPV4EP *)optval; /* Pointer to Group Addr strucute */

        /* Check no of CEP with the given MCast addr, New state, first entry */
        /* ID with the MCAST address, Check for Empty list with Exclude mode */
        mcnt = igmp3_chk_sts(nif, p_gaddr->ipaddr, &new_state, &fentry, &is_empty);
        if (mcnt == 1) {
            ercd = igmp3_if_lgrp(nif, &mgrp_cb[n]); /* Last group leaves */
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        } else {
            /* Generate the source list for the interface */
            ercd = igmp3_if_genslist(nif, p_gaddr->ipaddr, new_state, mcnt,
                     is_empty, fentry, &if_slist);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
            /* Update the Interface module with the new source list */
            ercd = igmp3_if_upgrp(nif, p_gaddr->ipaddr, new_state, if_slist);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        }

        /* Leave the Multicast Address at CEP level */
        igmp3_cep_lgrp(&mgrp_cb[n]);

        /* 04Feb2005 - Reset CEP options if the CEP does not bind to any
           Multicast group */
        for (n = 0; n < MULTICAST_GROUP_CNT; n++) {
            if ((mgrp_cb[n].portno != 0) && (mgrp_cb[n].cep == cep))
                break;
        }

        if (n >= MULTICAST_GROUP_CNT)
            cep->options &= ~UDP_MULTICAST;
        break;
    case IP_MCAST_INCLUDE:
    case IP_MCAST_EXCLUDE:
    case IP_ALLOW_SOURCES:
    case IP_BLOCK_SOURCES:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }
        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        if (cep->options & UDP_BROADCAST) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        if (optval == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }

        /* Group Address + Source List Structure */
        usl = (T_IGMP3_USL *)optval;
        p_gaddr = usl->mgrp_addr;

        n = search_igmp_group(nif, (T_IPV4EP *)p_gaddr);
        if (n == -1) {
            tcpip_critical(FALSE, &save_pri);
            return E_NOEXS;
        }
        /* At first, update the source list at CEP level */
        ercd = igmp3_cep_srcchg(optname, &mgrp_cb[n], usl->src_list, (int)usl->num_src);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        /* Check no of CEP with the given MCast addr, New state, first entry */
        /* ID with the MCAST address, Check for Empty list with Exclude mode */
        mcnt = igmp3_chk_sts(nif, p_gaddr->ipaddr, &new_state, &fentry, &is_empty);

        /* Generate the source list for the interface */
        ercd = igmp3_if_genslist(nif, p_gaddr->ipaddr, new_state, mcnt,
                 is_empty, fentry, &if_slist);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        /* Update the Interface module with the new source list */
        ercd = igmp3_if_upgrp(nif, p_gaddr->ipaddr, new_state, if_slist);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        break;
    case IP_BROADCAST:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }

        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        if ((BOOL)optval == TRUE) {
            if (cep->options & UDP_MULTICAST) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
            cep->options |= UDP_BROADCAST;
        } else {
            cep->options &= ~UDP_BROADCAST;
        }
        break;
    case IP_REUSEPORT:
        if ((BOOL)optval == FALSE)
            cep->options &= ~UDP_REUSEPORT;
        else
            cep->options |= UDP_REUSEPORT;
        break;
    case IP_IF_NAME:
        nif = getnif_from_name((const char *)optval);
        if (nif == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        break;
    case IP_IF_CH:
        nif = getnif_from_ch((int)optval);
        if (nif == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        break;
    case SET_IP_TTL:
        cep->ttl = *((UB *)optval);
        break;
    case SET_IP_TOS:
        cep->tos = *((UB *)optval);
        break;
    case SET_UDP_RPKT_OPT:
        if ((BOOL)optval == TRUE)
            cep->options |= UDP_USE_RMSG;
        else
            cep->options &= ~UDP_USE_RMSG;
        break;
    case SET_UDP_SND_IF:
        if (!(cep->options & UDP_USE_RMSG)) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        if (((T_NIF *)optval) == NULL) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        cep->rmsg.nif = (T_NIF *)optval;
        break;

  #ifdef DUAL_STK
    case IPV6_JOIN_GROUP :
        if (nif == NULL){
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }
        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        if (cep->options & UDP_BROADCAST) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        /*check for the address type */
        if (!(addr_type((UW *)optval) & ADDR_MULTICAST)) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        ercd = update_cep_entry(cepid, optname, (UW *)optval, optlen);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        n = check_cep_entry(cepid);
        if (n == 1) {/*if there is no entry in the UDP_CEP array for this multicast address, this is the first entry */
            ercd = mld2_join_group(nif, (UW *)optval);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        } else {
            get_updted_info(nif, (UW *)optval, &mode, &src_list);
            /* call the function from mld2 engine to trigger */
            ercd = mld2_set_filter(nif, UDP_CEP[cepid].m_ip6addr,  mode,  src_list);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        }
        break;
    case IPV6_LEAVE_GROUP:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }
        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        if (cep->options & UDP_BROADCAST) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        /* check for the address type */
        if (!(addr_type((UW *)optval) & ADDR_MULTICAST)) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }

        n = check_cep_entry(cepid);
        if (n == 1) {/*if there is no entry in the UDP_CEP array for this
                      multicast address, this is the first entry */
            ercd = update_cep_entry(cepid, optname, NULL, 0);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
            ercd = mld2_leave_group(nif, (UW *)optval);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        } else {
            ercd = update_cep_entry(cepid, optname, NULL, 0);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
            get_updted_info(nif, (UW *)optval, &mode, &src_list);
            ercd = mld2_set_filter( nif, (UW *)optval,  mode,  src_list);
            if (ercd != E_OK) {
                tcpip_critical(FALSE, &save_pri);
                return ercd;
            }
        }
        break;
    case MCAST_INCLUDE:
    case MCAST_EXCLUDE:
    case ALLOW_SOURCES:
    case BLOCK_SOURCES:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }
        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        if (cep->options & UDP_BROADCAST) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        n = check_cep_entry(cepid);
        if (n == 0) {/* he has not yet joined the group */
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }
        ercd = update_cep_entry(cepid, optname, (UW*)optval, optlen);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        get_updted_info(nif, UDP_CEP[cepid].m_ip6addr, &mode, &src_list);
        /* call the function from mld2 engine to trigger */
        ercd = mld2_set_filter(nif, UDP_CEP[cepid].m_ip6addr,  mode,  src_list);
        if (ercd != E_OK) {
            tcpip_critical(FALSE, &save_pri);
            return ercd;
        }
        break;
  #endif
    case IP_BROAD_FOR_DHCP:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }

        if (nif->type != NI_ETH) {
            tcpip_critical(FALSE, &save_pri);
            return E_OBJ;
        }

        if (optval) {
            cep->options |= UDP_BROADDHCP;
            memcpy(cep->d_ipaddr, ((T_NET_ADDR *)optval)->ipaddr, 4);
            memcpy(cep->d_ipmask, ((T_NET_ADDR *)optval)->ipmask, 4);
        } else {
            cep->options &= ~UDP_BROADDHCP;
        }
        break;
    default:
        tcpip_critical(FALSE, &save_pri);
        return E_PAR;
    }

    if ((optname == IP_IF_CH) || (optname == IP_IF_NAME)) {

      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            cep->nif = nif;
            tcpip_critical(FALSE, &save_pri);
            return E_OK;
        }
      #endif
        /* set ipaddr */
        if (cep->ipaddr == IPV4_ADDRANY) {
            ipaddr = byte4_to_long(nif->ipaddr);

            /* Validate port */
            for (c = pUDP_CEP; c != NULL; c = c->next) {
                if (c != cep) {
                    if (c->portno == cep->portno && c->ipaddr == ipaddr && c->nif == nif &&
                        !(c->options & UDP_REUSEPORT)) {
                        tcpip_critical(FALSE, &save_pri);
                        return E_OBJ;
                    }
                }
            }
        } else {
            /* Is 'nif' already set ? */
            if (cep->nif == nif) {
                tcpip_critical(FALSE, &save_pri);
                return E_OK;
            }

            /* validate ipaddr */
            ipaddr = cep->ipaddr;
            if (cep->nif != NULL && ipaddr == byte4_to_long(cep->nif->ipaddr)) {
                ipaddr = byte4_to_long(nif->ipaddr);
            } else {
                mask   = byte4_to_long(nif->mask);

                /* not in same network ? */
                if ((ipaddr & mask) != (byte4_to_long(nif->ipaddr) & mask)) {
                    tcpip_critical(FALSE, &save_pri);
                    return E_OBJ;
                }

                /* Check any other interface using this address */
                cep->ipaddr = IPV4_ADDRANY;
                if (chk_ip_nif(nif, ipaddr)) {
                    cep->ipaddr = ipaddr;
                    tcpip_critical(FALSE, &save_pri);
                    return E_OBJ;
                }
            }

            /* Validate port */
            for (c = pUDP_CEP; c != NULL; c = c->next) {
                if (c != cep) {
                    if (c->portno == cep->portno && c->ipaddr == ipaddr &&
                        !(c->options & UDP_REUSEPORT)) {
                        tcpip_critical(FALSE, &save_pri);
                        return E_OBJ;
                    }
                }
            }

            /* Check multi home */
            if (cep->nif != NULL && ipaddr != byte4_to_long(cep->nif->ipaddr))
                cep->nif->multihome--;
            if (ipaddr != byte4_to_long(nif->ipaddr))
                nif->multihome++;
        }

        cep->ipaddr = ipaddr;
        cep->nif = nif;

        /* 04Feb2005 - Rebind 'nif' in Multicast group */
        if (cep->options & UDP_MULTICAST) {
            for (n = 0; n < MULTICAST_GROUP_CNT; n++) {
                if ((mgrp_cb[n].portno != 0) &&
                    (mgrp_cb[n].cep == cep))
                        mgrp_cb[n].nif = nif;
            }
        }

        if (cep->ttl == 0)
            cep->ttl = nif->ip.ttl;
    }

    tcpip_critical(FALSE, &save_pri);

    return ercd;
}

/******************************************************************************
* Add the Multicast Address in the UDP Socket level layer of IGMPv3           *
******************************************************************************/
static ER igmp3_cep_jgrp(T_NIF *nif, T_UDP_CEP *cep, int n, T_IPV4EP *gaddr)
{
    mgrp_cb[n].ipaddr = gaddr->ipaddr;
    mgrp_cb[n].portno = gaddr->portno;
    mgrp_cb[n].cep = cep;
    mgrp_cb[n].nif = nif;
    mgrp_cb[n].igmp_slist = NULL;
    mgrp_cb[n].mode = MODE_IS_EXCLUDE;

    cep->options |= UDP_MULTICAST;
    return E_OK;
}

/******************************************************************************
* Remove the Multicast Address in the UDP Socket layer of IGMPv3              *
******************************************************************************/
static ER igmp3_cep_lgrp(T_MGRP_CB *grp)
{
    ER ercd;

    grp->ipaddr = 0L;
    grp->portno = 0;
    grp->cep = NULL;
    grp->nif = NULL;
    grp->tif = NULL;
    grp->rptime = 0;
    grp->mode = NOT_IN_USE;

    ercd = igmp3_free_src(grp->igmp_slist);
    grp->igmp_slist = NULL;

    return ercd;
}

/******************************************************************************
* Update the Source List at UDP CEP level first                               *
******************************************************************************/
static ER igmp3_cep_srcchg(INT optname, T_MGRP_CB *grp, UW *slist, int numsrc)
{
    ER ercd = E_OK;

    switch (optname) {
    case IP_MCAST_INCLUDE: /* Filter mode change */
        /* Just remove existing list and add the new list */
        ercd = igmp3_free_src(grp->igmp_slist);
        if (ercd != E_OK) {
            return ercd;
        }
        grp->igmp_slist = NULL;
        grp->mode = MODE_IS_INCLUDE;
        ercd = igmp3_util_arrlist(&grp->igmp_slist, slist, numsrc);
        break;
    case IP_MCAST_EXCLUDE: /* Filter mode change */
        /* Just remove existing list and add the new list */
        ercd = igmp3_free_src(grp->igmp_slist);
        if (ercd != E_OK) {
            return ercd;
        }
        grp->igmp_slist = NULL;
        grp->mode = MODE_IS_EXCLUDE;
        ercd = igmp3_util_arrlist(&grp->igmp_slist, slist, numsrc);
        break;
    case IP_ALLOW_SOURCES: /* Source list change */
        /* No chance of being empty, since it is INCLUDE mode */
        ercd = igmp3_util_adjsrc(grp, slist, numsrc, MODE_IS_INCLUDE);
        break;
    case IP_BLOCK_SOURCES:
        /* If it is empty, just add the new list. Else, update as per rfc */
        if ((grp->igmp_slist == NULL) && (grp->mode == MODE_IS_EXCLUDE)) {
            ercd = igmp3_util_arrlist(&grp->igmp_slist, slist, numsrc);
            if (ercd != E_OK) {
                return ercd;
            }
        }
        ercd = igmp3_util_adjsrc(grp, slist, numsrc, MODE_IS_EXCLUDE);
        break;
    }
    return ercd;
}

/******************************************************************************
* Update the Source List at UDP CEP level first                               *
* If the new source that has to be added, but does not exist in the list, it  *
* adds. If the new source that has to be deleted exists in the list, it       *
* removes. Otherwise, it does nothing.                                        *
******************************************************************************/
static ER igmp3_util_adjsrc(T_MGRP_CB *grp, UW *addr_arr, int numsrc, UB mode)
{
    T_IGMP3_SRC *cur, *temp, *prev = NULL;
    ER ercd;
    int i;

    for (i = 0; i < numsrc; i++) {
        cur = grp->igmp_slist;
        while (cur) {
            if (cur->ipaddr == addr_arr[i]) {
                if (grp->mode != mode) {
                    /* Delete the Source */
                    temp = cur;
                    if (grp->igmp_slist == cur) {
                        grp->igmp_slist = cur->nxt;
                    }
                    else {
                        prev->nxt = cur->nxt;
                    }
                    /*free(temp);*/
                    ercd = rel_mpf(ID_IGMP3_SRC_MPF, temp);
                    if (ercd != E_OK) {
                        udp_internal_error(ercd);
                        return ercd;
                    }
                }
                break;
            }
            prev = cur;
            cur = cur->nxt;
        }
        if ((cur == NULL) && (grp->mode == mode)) {
            ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&temp);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return ercd;
            }
            if (temp == NULL) {
                return E_NOMEM;
            }
            if (grp->igmp_slist == NULL) {
                grp->igmp_slist = temp;
            }
            else {
                prev ->nxt = temp;
            }
            temp->nxt = NULL;
            temp->ipaddr = addr_arr[i];
        }
    }
    return E_OK;
}

/******************************************************************************
* Converts array of sources into Linked list and joins it with head pointer   *
******************************************************************************/
static ER igmp3_util_arrlist(T_IGMP3_SRC **head, UW *addr_arr, int numsrc)
{
    T_IGMP3_SRC *prev, *temp;
    ER ercd;
    int i;

    prev = NULL;

    for (i = 0; i < numsrc; i++) {
        ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&temp);
        if (ercd != E_OK) {
            udp_internal_error(ercd);
            return ercd;
        }
        if (temp == NULL) {
            return E_NOMEM;
        }
        temp->ipaddr = addr_arr[i];
        if (prev == NULL) {
            temp->nxt = *head;
            *head = temp;
        }
        else {
            temp->nxt = prev->nxt;
            prev->nxt = temp;
        }
        prev = temp;
    }
    return E_OK;
}

/******************************************************************************
* Get Number of CEPs with same Group address, New state, First CEP entry      *
* which has the same Group address, Flag wheather empty list with Exclude     *
* mode exists                                                                 *
******************************************************************************/
static ER igmp3_chk_sts(T_NIF *nif, UW maddr, UW *new_state, ID *fentry, BOOL *eflg)
{
    int i;
    UW count = 0;
    T_MGRP_CB *pmgrp;

    *new_state = MODE_IS_INCLUDE;
    *eflg = FALSE;
    *fentry = 0;

    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        pmgrp = &mgrp_cb[i];
        if ((pmgrp->ipaddr == maddr) && (pmgrp->nif == nif)) {
            if (pmgrp->mode == MODE_IS_EXCLUDE) {
                *new_state = MODE_IS_EXCLUDE;
                if (pmgrp->igmp_slist == NULL) {
                    *eflg = TRUE;
                }
            }
            if (count == 0) {
                *fentry = i;
            }
            count++;
        }
    }
    return count;
}

/******************************************************************************
* Calculate the Interface source list                                         *
******************************************************************************/
static ER igmp3_if_genslist(T_NIF *nif, UW maddr, UW new_stat, UW mcnt,
                      BOOL is_empty, ID fentry, T_IGMP3_SRC **if_slist)
{
    UW cnt;
    T_MGRP_CB *pmgrp;
    ER ercd;
    int i;

    if (*if_slist != NULL) {
        return E_PAR;
    }

    /* If all sockets are of INCLUDE mode, then interface source list is
       union of all socket source lists and interface filter mode is INCLUDE */
    if (new_stat == MODE_IS_INCLUDE) {
        cnt = 0;
        for (i = fentry; i < MULTICAST_GROUP_CNT; i++) {
            pmgrp = &mgrp_cb[i];
            if ((pmgrp->ipaddr == maddr) && (pmgrp->nif == nif)) {
                ercd = igmp3_util_union(if_slist, pmgrp->igmp_slist);
                if (ercd != E_OK) {
                    return ercd;
                }
                cnt++;
                if (cnt == mcnt) {
                    break;
                }
            }
        }
    }
    else {
        /* New state is MODE_IS_EXCLUDE: */
        /* Calculate intersection all Exlclude - Union of all INCLUDE */
        return igmp3_util_exclude(nif, maddr, mcnt, is_empty, fentry,if_slist);
    }
    return E_OK;
}

/******************************************************************************
* Generates same list and joins with the head pointer                         *
******************************************************************************/
static ER igmp3_util_addlist(T_IGMP3_SRC **head, T_IGMP3_SRC *list)
{
    T_IGMP3_SRC *node, *prev = NULL;
    ER ercd;

    /* It adds the list only to the head of the list */
    if (*head != NULL) {
        return E_PAR;
    }
    while (list) {
        ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&node);
        if (ercd != E_OK) {
            udp_internal_error(ercd);
            return ercd;
        }
        node->ipaddr = list->ipaddr;
        node->nxt = NULL;
        if (*head == NULL) {
            *head = node;
        }
        else {
            prev->nxt = node;
        }
        prev = node;
        list = list->nxt;
    }
    return E_OK;
}

/******************************************************************************
* Generates Union Set of two linked lists. Adds the new node                  *
******************************************************************************/
static ER igmp3_util_union(T_IGMP3_SRC **if_slist, T_IGMP3_SRC *igmp_slist)
{
    T_IGMP3_SRC *cur, *tmp, *prev, *node;
    ER ercd;

    if (*if_slist == NULL) {
        ercd = igmp3_util_addlist(if_slist, igmp_slist);
        return ercd;
    }
    cur = igmp_slist;
    while (cur) {
        tmp = *if_slist;
        prev = NULL;
        while (tmp) {
            if (tmp->ipaddr == cur->ipaddr) {
                break;
            }
            prev = tmp;
            tmp = tmp->nxt;
        }
        if (tmp == NULL) {
            ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&node);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return ercd;
            }
            node->ipaddr = cur->ipaddr;
            node->nxt = NULL;
            prev->nxt = node;
        }
        cur = cur->nxt;
    }
    return E_OK;
}

/******************************************************************************
* Generates Intersection all EXCLUDE minus Union of all INCLUDE               *
******************************************************************************/
static ER igmp3_util_exclude(T_NIF *nif, UW maddr, UW mcnt, BOOL is_empty,
                                       ID fentry, T_IGMP3_SRC **if_slist)
{
    T_IGMP3_SRC *fcep_node = NULL, *node, *prev = NULL;
    T_MGRP_CB *pmgrp;
    BOOL can_add;
    ER ercd;
    UW cnt;
    int i;

    if (*if_slist != NULL) {
        return E_PAR;
    }

    /* Single CEP with EXCLUDE mode; So, it goes as it is */
    if (mcnt == 1) {
        ercd = igmp3_util_addlist(if_slist, mgrp_cb[fentry].igmp_slist);
        return ercd;
    }
    /* There is atleast one CEP with EXCLUDE mode empty list;
       So, result will be empty list */
    if (is_empty == TRUE) {
        *if_slist = NULL;
        return E_OK;
    }

    /* Find any one list with EXCLUDE mode */

    for (i = fentry; i < MULTICAST_GROUP_CNT; i++) {
        pmgrp = &mgrp_cb[i];
        if ((pmgrp->ipaddr == maddr) && (pmgrp->nif == nif)) {
            if (pmgrp->mode == MODE_IS_EXCLUDE) {
                fcep_node = pmgrp->igmp_slist;
                break;
            }
        }
    }

    if (fcep_node == NULL) {
        return E_OBJ;
    }

    /* For each source in an EXCLUDE List, */
    /* If it exists in an INCLUDE list, it is removed */
    /* If it doesn not exist in an EXCLUDE list, it is removed */
    /* It means source that exists in all EXCLUDE, but not in any INCLUDE is */
    /* added */
    while (fcep_node) {
        cnt = 0;
        can_add = TRUE;
        for (i = fentry; i < MULTICAST_GROUP_CNT; i++) {
            pmgrp = &mgrp_cb[i];
            if ((pmgrp->ipaddr == maddr) && (pmgrp->nif == nif)) {
                if (igmp3_util_chksrc(pmgrp->igmp_slist, fcep_node->ipaddr) == TRUE) {
                    if (pmgrp->mode == MODE_IS_INCLUDE) { /* MCAST_INCLUDE */
                        can_add = FALSE;
                        break; /* Check next src */
                    }
                }
                else { /* SRC does not exist */
                    if (pmgrp->mode == MODE_IS_EXCLUDE) {
                        can_add = FALSE;
                        break; /* Check next src */
                    }
                }
                cnt++;
                if (cnt == mcnt) {
                    break;
                }
            } /* Check next list */
        }
        if (can_add == TRUE) {
            /* It is in all CEPs with EXCLUDE mode, but in no INCLUDE mode */
            /* Add the node */
            ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&node);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return ercd;
            }
            node->ipaddr = fcep_node->ipaddr;
            node->nxt = NULL;
            if (*if_slist == NULL) {
                *if_slist = node;
            }
            else {
                prev->nxt = node;
            }
            prev = node;
        }
        fcep_node = fcep_node->nxt;
    }
    return E_OK;
}

/******************************************************************************
* It returns TRUE, if source exists in the list. Else, it returns FALSE       *
******************************************************************************/
ER igmp3_util_chksrc(T_IGMP3_SRC *list, UW saddr)
{
    while (list) {
        if (list->ipaddr == saddr) {
            return TRUE;
        }
        list = list->nxt;
    }
    return FALSE;
}

/******************************************************************************
* Module Name   : udp_get_opt                                                 *
* Purpose       : API to check the options used by UDP CEP.                   *
* Arguments     : ID cepid        - UDP CEP id.                               *
*                 INT optname     - UDP option to be configured.              *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/
ER udp_get_opt(ID cepid, INT optname, VP optval, INT optlen)
{
    ER ercd = E_OK;
    T_UDP_CEP *cep;
    T_NIF *nif;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK; /* No Interface available */
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)UDP_CEPID_MAX) {
        tcpip_critical(FALSE, &save_pri);
        return E_ID;
    }

    /* Error if CEP Not Created */

    cep = &UDP_CEP[cepid];
    if (cep->portno == 0) {
        tcpip_critical(FALSE, &save_pri);
       return E_NOEXS;
    }

    /* Interface for this CEP is already deleted */
    if (cep->ercd == E_LNK) {
        tcpip_critical(FALSE, &save_pri);
        return E_LNK;
    }

    nif = cep->nif;

    switch (optname) {
    case IP_IF_NAME:
        if (nif == NULL) {
            /* use default interface */
            nif = getnif_default();
            if (nif == NULL) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
        }
        if (optlen <= (INT)strlen(nif->name)) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        strcpy((char *)optval, nif->name);
        break;
    case SET_IP_TOS:
        if (optval == NULL || optlen < 1) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        (*(UB *)(optval)) = cep->tos;
        break;
    case SET_IP_TTL:
        if (optval == NULL || optlen < 1) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        (*(UB *)(optval)) = cep->ttl;
        break;
    case SET_UDP_SND_IF:
        if (!(cep->options & UDP_USE_RMSG)) {
            tcpip_critical(FALSE, &save_pri);
            return E_PAR;
        }
        (*(T_NIF **)(optval)) = (T_NIF *)cep->rmsg.nif;
        break;
    default:
        tcpip_critical(FALSE, &save_pri);
        return E_NOSPT;
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

#ifdef DUAL_STK

/********************************************************************************************************************/
/* Module to Get Updated Information after the Change in State for a give Multicast Address                        */
/*******************************************************************************************************************/
void get_updted_info(T_NIF *nif,UW *maddr,UH *mode, T_MLD2_SRC **src)
{
    T_UDP_CEP *cep = NULL, *c;
    UH flag = 0, count = 0;
    /* find out the mode for the corresponding list */
    *mode = get_final_mode(nif, maddr, &flag);
    /* get the 1st UDP_CEP with exclude mode if the resulting mode is MCAST_EXCLUDE*/
    if (*mode == MCAST_EXCLUDE) {
        for (c = pUDP_CEP; c != NULL; c = c->next) {
            if (nif == c->nif) {
                if (c->mode == MCAST_EXCLUDE) {
                    if (memcmp(c->m_ip6addr, maddr, IP6_ADDR_SZ) == 0) {
                        cep = c;
                        if (c->src_list == NULL) {
                            flag = 1;
                            break;
                        }
                    }
                }
            }
        }
        if (flag == 1) {/* indicates that there is one socket on the given multicast address in EXCLUDE mode and source list is empty */
            *src = NULL;
            return;
        }
    }
    else {/* get the 1st UDP_CEP with include mode if the resulting mode is MCAST_INCLUDE*/
        for (c = pUDP_CEP; c != NULL; c = c->next) {
            if (nif == c->nif) {
                if (c->mode == MCAST_INCLUDE) {
                    if (memcmp(c->m_ip6addr, maddr, IP6_ADDR_SZ) == 0) {
                        cep = c;
                        break;
                    }
                }
            }
        }
    }
    *src = prepare_list(nif, cep, *mode, &count);
    return;
}

/****************************************************************************************************************/
/* Module to Prepare a New Source List for a multicast when there is a State Change due to mode or source list  */
/****************************************************************************************************************/
/* algorithm according to RFC3810(4.2) to calculate the new state*/
T_MLD2_SRC  *prepare_list(T_NIF *nif,T_UDP_CEP *cep, UH mode,UH *numsrc)
{
    T_UDP_CEP *c;
    T_MLD2_SRC *sel_cep,*given_cep;
    T_MLD2_SRC *src, *curr, *prev = NULL,*curr1,*prev1 = NULL;
    UH flag, count = 0;
    ER ercd;
    src = NULL;

    if (cep == NULL) {
        return NULL;
    }
    given_cep = cep->src_list;/*get the source list of cep passed as argument*/
    if (mode == MCAST_EXCLUDE) {
       while (given_cep) {
            flag = 0;
            for (c = pUDP_CEP; c != NULL; c = c->next) {
                if (nif == c->nif) {
                    if (memcmp(cep->m_ip6addr, c->m_ip6addr, IP6_ADDR_SZ) == 0) {
                        sel_cep = c->src_list;/* get the source list of cep from the selected one*/
                        while (sel_cep) {/* take the first source in the seleted cep */
                            if (memcmp(given_cep->ip6addr, sel_cep->ip6addr, IP6_ADDR_SZ) != 0) {
                                sel_cep = sel_cep->nxt;
                                continue;
                            }
                            else {
                                if (c->mode == MCAST_EXCLUDE) {
                                    /*since entry of the given source is there in the selected list go to check the next list*/
                                    flag = 1;
                                    break;
                                }
                                else {
                                    /* since entry of the given source is present in the selected list but it is in include mode so dont consider this source further*/
                                    goto jmp1;
                                }
                            }
                        }
                        if (sel_cep == NULL) {
                            if (c->mode == MCAST_EXCLUDE) {
                                goto jmp1;
                            }
                            else {
                                flag = 1;
                            }
                        }
                    }
                }
            }
            if (c == NULL && flag) {/* indicates all cep entries with exclude mode contains the source and all cep entries with include mode doesnt contain the source entry*/
               /*prepare a list*/
                /*curr = (T_MLD2_SRC *)malloc(sizeof(T_MLD2_SRC ));*//*allocate memory*/
                ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&curr);
                if (ercd != E_OK) {
                    udp_internal_error(ercd);
                    return NULL;/*this has to be considered*/
                }
                memcpy(curr->ip6addr, given_cep->ip6addr, IP6_ADDR_SZ);
                if (src == NULL) {
                    src = curr;/* first address*/
                }
                else {
                    prev ->nxt = curr;
                }
                prev = curr;
                curr->nxt = NULL;
                count++;
            }
            jmp1:
            given_cep = given_cep->nxt;
        }
    }
    else {/*if the resutlting mode is include */
        /*prepare a list from the given cep*/
        while (given_cep) {    /* copy all the sources from the given cep */
            /*curr = (T_MLD2_SRC *)malloc(sizeof(T_MLD2_SRC ));*//*allocate memory*/
            ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&curr);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return NULL;/* this has to be considered because it should return ercd*/
            }
            memcpy(curr->ip6addr, given_cep->ip6addr, IP6_ADDR_SZ);
            if (src == NULL) {
                src = curr;/* first address*/
            }
            else {
                prev ->nxt = curr;
            }
            prev = curr;
            curr->nxt = NULL;
            given_cep = given_cep->nxt;
            count++;
        }
        for (c = pUDP_CEP; c != NULL; c = c->next) {
            if (nif == c->nif) {
                if (memcmp(cep->m_ip6addr, c->m_ip6addr, IP6_ADDR_SZ) !=0) {
                    continue;
                }
                sel_cep = c->src_list;/*take the list for the cep which is selected */
                while (sel_cep) { /* take the each entry of source list from the selected cep*/
                    flag = 0;
                    curr1 = src; /* take the source list */
                    while (curr1) { /*take the each entry of source from the formed list*/
                        if (memcmp(sel_cep->ip6addr,curr1->ip6addr, IP6_ADDR_SZ) !=0) {
                            prev1 = curr1;
                            curr1 = curr1->nxt;
                            continue;
                         }
                         else {
                            goto jmp2;/* entry is present in list*/
                         }
                    }
                    /* if the entry is not present in the source list make a new entry */
                    /*curr = (T_MLD2_SRC *)malloc(sizeof(T_MLD2_SRC ));*//*allocate memory*/
                    ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&curr);
                    if (ercd != E_OK) {
                        udp_internal_error(ercd);
                        return NULL;/*this has to be considered*/
                    }
                    memcpy(curr->ip6addr, sel_cep->ip6addr, IP6_ADDR_SZ);
                    prev1->nxt = curr;
                    curr->nxt = NULL;
                    count++;
                    jmp2:
                    sel_cep = sel_cep->nxt;
                }
            }
        }
    }
    *numsrc = count;
    return src;
}

/****************************************************************************************************/
/*Module to Get the New Mode for a given multicast address when there is a state change             */
/****************************************************************************************************/
UH get_final_mode(T_NIF *nif, UW *maddr, UH *flag)
{
    T_UDP_CEP *c;
    UH mode ;

    mode = MCAST_INCLUDE;/* keep the default as include mode */
    for (c = pUDP_CEP; c != NULL; c = c->next) {
        if (nif == c->nif) {
            if (!memcmp(c->m_ip6addr, maddr, IP6_ADDR_SZ)) {
                if (c->mode == MCAST_EXCLUDE) {/* indicates the mode of interface for a given multicast address is EXCLUDE*/
                    mode = MCAST_EXCLUDE;
                }
                if (c->src_list == NULL) {/* Check any cep with empty source */
                    *flag = 1;
                    return mode;
                }
            }
        }
    }
    *flag = 0;
    return mode;
}

/********************************************************************************************************************/
/* Module to find whether there is Already existing entry for a given multicast address  and Number of entries with */
/* respect to multicast address in T_UDP_CEP array                                                                  */
/********************************************************************************************************************/
UH check_cep_entry(ID cepid)
{
    UW *maddr;
    T_UDP_CEP *c;
    UH count = 0;

    if (UDP_CEP[cepid].mode != NOT_IN_USE) {/* considering that the entry will be in the condition NOT_IN_USE , if it is free */
        maddr = UDP_CEP[cepid].m_ip6addr;
        count = 1;
        for (c = pUDP_CEP; c != NULL; c = c->next) {
            if (cepid == c->cepid - 1)
                continue;
            if (UDP_CEP[cepid].nif == c->nif) {
                if (memcmp(&c->m_ip6addr, maddr, IP6_ADDR_SZ) == 0) {
                   count++;
                }
            }
        }
    }
    return count;
}

/****************************************************/
/*Module to update the CEP entry based on Options  */
/***************************************************/
ER update_cep_entry(ID cepid,UH optname, UW *optval,INT optlen)
{
    UW tempaddr[4] = { 0x0000, 0x0000, 0x0000, 0x0000};
    UH numsrc = 0,i,j;
    T_MLD2_SRC *curr, *temp = NULL, *prev = NULL;
    ER ercd;

    switch (optname) {
    case IPV6_JOIN_GROUP :
        UDP_CEP[cepid].mode = MCAST_EXCLUDE;
        memcpy(UDP_CEP[cepid].m_ip6addr, optval, IP6_ADDR_SZ);
        UDP_CEP[cepid].src_list = NULL;
        break;
    case IPV6_LEAVE_GROUP :
        UDP_CEP[cepid].mode = NOT_IN_USE;
        memcpy(UDP_CEP[cepid].m_ip6addr, tempaddr, IP6_ADDR_SZ);
        ercd = mld2_free_src(UDP_CEP[cepid].src_list);
        if(ercd != E_OK){
            return ercd;
        }
        UDP_CEP[cepid].src_list = NULL;
        break;
    case MCAST_INCLUDE :
        if (optlen == 0) {
            update_cep_entry(cepid, IPV6_LEAVE_GROUP, NULL, 0);
            return E_OK;
        }
        mld2_free_src(UDP_CEP[cepid].src_list);
        UDP_CEP[cepid].src_list = NULL;
        numsrc = optlen / IP6_ADDR_SZ;
        UDP_CEP[cepid].mode = MCAST_INCLUDE;
        for (i = 0, j = 0; i < numsrc; i++, j = j + 4) {
            prev = temp;
            /*temp = (T_MLD2_SRC *)malloc( sizeof(T_MLD2_SRC));*/
            ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&temp);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return ercd;
            }
            if (temp == NULL) {
                return E_NOMEM;
            }
            memcpy(temp->ip6addr, &optval[j], IP6_ADDR_SZ);
            temp->nxt = NULL;
            if (UDP_CEP[cepid].src_list == NULL) {
                UDP_CEP[cepid].src_list = temp;
            }
            else {
                prev->nxt = temp;
            }
        }
        break;
    case MCAST_EXCLUDE:
        ercd = mld2_free_src(UDP_CEP[cepid].src_list);
        if (ercd != E_OK) {
            return ercd;
        }
        UDP_CEP[cepid].src_list = NULL;
        numsrc = optlen / IP6_ADDR_SZ;
        UDP_CEP[cepid].mode = MCAST_EXCLUDE;
        for (i = 0, j = 0; i < numsrc; i++, j = j + 4) {
            prev = temp;
            /*temp = (T_MLD2_SRC *)malloc( sizeof(T_MLD2_SRC));*/
            ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&temp);
            if (ercd != E_OK) {
                udp_internal_error(ercd);
                return ercd;
            }
            if (temp == NULL) {
                return E_NOMEM;
            }
            memcpy(temp->ip6addr, &optval[j], IP6_ADDR_SZ);
            temp->nxt = NULL;
            if (UDP_CEP[cepid].src_list == NULL) {
                UDP_CEP[cepid].src_list = temp;
            }
            else {
                prev->nxt = temp;
            }
        }
        break;
    case ALLOW_SOURCES:
        numsrc = optlen / IP6_ADDR_SZ;
        for (i = 0, j = 0; i < numsrc; i++, j = j + 4) {
            curr = UDP_CEP[cepid].src_list;
            while (curr) {/* if the match is found in the middle */
                if (memcmp(curr->ip6addr, &optval[j], IP6_ADDR_SZ) == 0) {
                    if (UDP_CEP[cepid].mode == MCAST_EXCLUDE) {
                        temp = curr;
                        if (UDP_CEP[cepid].src_list == curr) {
                            UDP_CEP[cepid].src_list = curr->nxt;
                        }
                        else {
                            prev->nxt = curr->nxt;
                        }
                        /*free(temp);*/
                        ercd = rel_mpf(ID_MLDV2_MPF, temp);
                        if (ercd != E_OK) {
                            udp_internal_error(ercd);
                            return ercd;
                        }
                    }
                    goto allow;/* if match is found and the mode is include no need to free or enter */
                }
                prev = curr;
                curr = curr->nxt;
            }
            if (curr == NULL && UDP_CEP[cepid].mode == MCAST_INCLUDE) {
                /*temp = (T_MLD2_SRC *)malloc( sizeof(T_MLD2_SRC));*/
                ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&temp);
                if (ercd != E_OK) {
                    udp_internal_error(ercd);
                    return ercd;
                }
                if (temp == NULL) {
                    return E_NOMEM;
                }
                if (UDP_CEP[cepid].src_list == NULL) {
                    UDP_CEP[cepid].src_list = temp;
                }
                else {
                    prev ->nxt = temp;
                }
                temp->nxt = NULL;
                memcpy(temp->ip6addr, &optval[j], IP6_ADDR_SZ);
            }
            allow:
            continue;
        }
        break;
    case BLOCK_SOURCES:
        numsrc = optlen / IP6_ADDR_SZ;
        curr = UDP_CEP[cepid].src_list;
        if (curr == NULL) {
            if (UDP_CEP[cepid].mode == MCAST_EXCLUDE) {
                for (i = 0, j = 0; i < numsrc; i++, j = j + 4) {
                    ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&temp);
                    if (ercd != E_OK) {
                        udp_internal_error(ercd);
                        return ercd;
                    }
                    if (temp == NULL) {
                        return E_NOMEM;
                    }
                    if (UDP_CEP[cepid].src_list == NULL) {
                        UDP_CEP[cepid].src_list = temp;
                        prev = temp;
                    }
                    else {
                        prev ->nxt = temp;
                        prev = temp;
                    }
                    temp->nxt = NULL;
                    memcpy(temp->ip6addr, &optval[j], IP6_ADDR_SZ);
                }
            }
            return E_OK;
        }
        for (i = 0, j = 0; i < numsrc; i++, j = j + 4) {
            curr = UDP_CEP[cepid].src_list;
            while (curr) {/* if the match is found in the middle */
                if (memcmp(curr->ip6addr, &optval[j], IP6_ADDR_SZ) == 0) {
                    if (UDP_CEP[cepid].mode == MCAST_INCLUDE) {
                        temp = curr;
                        if (UDP_CEP[cepid].src_list == curr) {
                            UDP_CEP[cepid].src_list = curr->nxt;
                        }
                        else {
                            prev->nxt = curr->nxt;
                        }
                        /*free(temp);*/
                        ercd = rel_mpf(ID_MLDV2_MPF, temp);
                        if (ercd != E_OK) {
                           udp_internal_error(ercd);
                           return ercd;
                        }
                    }
                    goto block;/* if match is found and the mode is include no need to free or enter */
                }
                prev = curr;
                curr = curr->nxt;
            }
            if (curr == NULL && UDP_CEP[cepid].mode == MCAST_EXCLUDE) {
                /*temp = (T_MLD2_SRC *)malloc( sizeof(T_MLD2_SRC));*/
                ercd = pget_mpf(ID_MLDV2_MPF, (VP *)&temp);
                if (ercd != E_OK) {
                    udp_internal_error(ercd);
                    return ercd;
                }
                /*if (temp == NULL) {
                    return E_NOMEM;
                }*/
                if (UDP_CEP[cepid].src_list == NULL) {
                    UDP_CEP[cepid].src_list = temp;
                }
                else {
                    prev ->nxt = temp;
                }
                temp->nxt = NULL;
                memcpy(temp->ip6addr, &optval[j], IP6_ADDR_SZ);
            }
            block:
            continue;
        }
        break;
    }
    return E_OK;

}
#endif
/* End */
