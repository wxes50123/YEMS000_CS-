/******************************************************************************
* NORTi TCP/IP Stack - IP Reassembling Module                                 *
*                                                                             *
*  Copyright (c) 2002-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2002-01-31 Created                                                       AK *
* 2002-08-01 Corrected memory releasing problems                           AK *
* 2002-08-28 Modified for fixed-size memorypool                            AK *
* 2003-02-24 Modified for SNMP                                             AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2008-08-07 Removed declaration of ip_internal_error                      FY *
* 2008-10-16 Deleted blank at the end of line                              FY *
* 2012-11-13 Added reass_ini() to clear reass_root when initialization     FY *
* 2012-11-13 Deleted hash for fragmented packet search to reduce work area FY *
* 2012-11-13 Corrected handling of ICMP packet fragmented shorter than MTU FY *
* 2012-11-13 Fixed releasing oldest packet correctly when memorypool lacks FY *
* 2012-11-13 Removed needless ipf_timer_flag on improved ip_frag_timeout() FY *
* 2012-11-13 Changed fragmented packets list from offset to arrival order  FY *
* 2012-11-13 Fixed reassembly timeout to be changed by netif_get_opt()     FY *
* 2014-10-20 Renamed IP_VER to MASK_IP_HEADER_LEN                          FY *
* 2019-06-19 Moved clr_frag_list's dequeue process to added deq_frag_list  FY *
* 2020-08-28 Fixed ip_frag_timeout() to send time exceeded message            *
*                    with correct length and header/data of fragment zero  FY *
* 2020-08-28 Replaced MASK_IP_HEADER_LEN macro with 0x0F for readability   FY *
* 2020-09-14 Corrected make_ip_pkt()'s unsending fragmented                   *
*                        ICMP packets of total length <= MTU as malformed  FY *
* 2023-07-11 Changed ip_reassembling() to calculate flen with total           *
*             length excluded IP options length by updated ip_reception()  FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

T_IPF *reass_root;

/*****************************************************************************
* Initialize reassembly list
*
******************************************************************************/

void reass_ini(void)
{
    reass_root = NULL;
}

/*****************************************************************************
* Search fragment list
*
******************************************************************************/

static T_IPF *search_fragment_list(T_IP4_HEADER *iph)
{
    T_IPF *fl;
    UW saddr, daddr;
    UH id;
    UB prot;

    id = iph->id;           /* identification value of the IP packet */
    saddr = iph->sa;        /* source address of the IP packet */
    daddr = iph->da;        /* destination address of the IP packet */
    prot = iph->prot;       /* protocol value of the IP packet */

    for (fl = reass_root; fl != NULL; fl = fl->fl_next) {
        if (((T_IP4 *)fl)->ip.id == id &&
           ((T_IP4 *)fl)->ip.sa == saddr &&
           ((T_IP4 *)fl)->ip.da == daddr &&
           ((T_IP4 *)fl)->ip.prot == prot)
            break;          /* fragment list found */
    }

    return fl;              /* return fragment list */
}

/*****************************************************************************
* Judge whether all fragment packet were received
*
******************************************************************************/

BOOL receive_all_frag(T_IPF *fl)
{
    T_IPF *current;
    W curofs, dend, cend;

    dend = fl->tl;
    if (dend == 0)                          /* final fragment not received */
        return FALSE;

    do {
        for (current = fl; current != NULL; current = current->nextf) {
            curofs = current->ofs;
            if (curofs >= dend) {
                if (current == fl)
                    fl = fl->nextf;
                continue;
            }
            cend = curofs + current->len;
            if (cend < dend)
                continue;
            dend = curofs;
            break;
        }
        if (current == NULL)
            return FALSE;
    } while (dend > 0);

    return TRUE;
}

/*****************************************************************************
* Make IP packet
*
******************************************************************************/

static BOOL make_ip_pkt(T_IPF *fl)
{
    T_NIF *nif;
    UB proto;

    proto = ((T_IP4 *)fl)->ip.prot;
    if (proto != PROT_ICMP && proto != PROT_UDP)
        return FALSE;

    nif = fl->nif;
    if (nif == NULL)
        return FALSE;

    if (fl->nextf == NULL)
        return FALSE;

    ((T_IP4 *)fl)->ctl.rcheck = TRUE;       /* reassembly packet */
    ((T_IP4 *)fl)->ctl.hedflg = FALSE;

    /* seperate this pkt from reassembly pool */
    if (fl->fl_next)
        fl->fl_next->fl_prev = fl->fl_prev;
    fl->fl_prev->fl_next = fl->fl_next;

    fl->fl_next = NULL;
    fl->fl_prev = NULL;

    return TRUE;
}

/*****************************************************************************
* Get reassembly data
*
******************************************************************************/

BOOL get_reassembly_data(VP data, T_IPF *fl, UH offset, UH len)
{
    T_IPF *current;
    UH curofs, dend, cend, limit;

    dend = offset + len;
    if (dend > fl->tl)
        return FALSE;
    while (fl != NULL && dend > offset) {
        limit = offset;
        for (current = fl; current != NULL; current = current->nextf) {
            curofs = current->ofs;
            if (curofs >= dend) {
                if (current == fl)
                    fl = fl->nextf;
                continue;
            }
            cend = curofs + current->len;
            if (cend < dend) {
                if (limit < cend)
                    limit = cend;
                continue;
            }
            if (limit < curofs)
                limit = curofs;
            memcpy((UB *)data + (limit - offset),
                ((T_IP4 *)current)->data + (limit - curofs),
                dend - limit);
            dend = limit;
            break;
        }
        if (current == NULL)
            return FALSE;
    }

    return TRUE;
}

/*****************************************************************************
* Get reassembly buffer
*
******************************************************************************/

BOOL get_reassembly_buffer(T_IPF *fl, UH offset, VP *data, UH *len)
{
    UH curofs, cend, limit;

    limit = fl->tl;
    for (; fl != NULL; fl = fl->nextf) {
        curofs = fl->ofs;
        if (curofs > offset) {
            if (limit > curofs)
                limit = curofs;
            continue;
        }
        cend = curofs + fl->len;
        if (cend <= offset)
            continue;
        if (limit > cend)
            limit = cend;
        *data = ((T_IP4 *)fl)->data + offset - curofs;
        *len = limit - offset;
        break;
    }

    return fl != NULL;
}

/*****************************************************************************
* Dequeue fragment list
*
******************************************************************************/

void deq_frag_list(T_IPF *fl)
{
    /* dequeue specified fragment list from reassembly list */
    if (fl->fl_next)
        fl->fl_next->fl_prev = fl->fl_prev;
    if (fl->fl_prev)
        fl->fl_prev->fl_next = fl->fl_next;
}

/*****************************************************************************
* Clear fragment list
*
******************************************************************************/

void clr_frag_list(T_IPF *fl, BOOL wf)
{
    T_IPF *next;
    ER ercd;

    if (fl == NULL)
        return;

    deq_frag_list(fl);

    if (!wf)
        if (fl != NULL)
            fl = fl->nextf; /* skip first fragment packet */

    /* release the fragments */
    while (fl) {
        next = fl->nextf;
        ercd = rel_mpf(ID_ETH_MPF, (VP)fl);
        if (ercd != E_OK)
            ip_internal_error(ercd);
        fl = next;
    }
}

/*****************************************************************************
* Release old fragment list until required memory space become free
*
******************************************************************************/

void ip_evictor(void)
{
    T_IPF *frag, *prev;
    T_RMPF rmpf;                            /* memory pool reference */

    frag = reass_root;
    if (frag) {
        while (frag->fl_next)               /* find oldest fragment list */
            frag = frag->fl_next;

        while (frag) {
            prev = frag->fl_prev;
            clr_frag_list(frag, TRUE);      /* clear it */

            /* return if enough memory freed */
            ref_mpf(ID_ETH_MPF, &rmpf);
            if (rmpf.fblkcnt > IPF_UMEM_BLK)
                return;

            if (prev == (T_IPF *)&reass_root)
                break;

            frag = prev;
        }
    }
}

/*****************************************************************************
* Release fragments that bind with an interface
*
******************************************************************************/

void release_ipf_que(T_NIF *nif)
{
    T_IPF *fl, *next;

    fl = reass_root;
    while (fl) {
        next = fl->fl_next;
        if (fl->nif == nif)
            clr_frag_list(fl, TRUE);
        fl = next;
    }
}

/*****************************************************************************
* IP fragment packet time out
*
******************************************************************************/

void ip_frag_timeout(void)
{
    T_IPF *fl, *next, *p;
    T_ICMP_HEADER ficmp;
    UW srcaddr, dstaddr;

    fl = reass_root;                        /* get the exists reassembly list */
    while (fl) {
        next = fl->fl_next;
        if (fl->rtime-- == 0) {             /* if timeout occurs */
            p = fl;
            while (p != NULL && p->ofs != 0)/* search fragment zero */
                p = p->nextf;
            if (p != NULL) {
                /* construct and send ICMP timeout message to remote host */
                ficmp.type = 11;            /* ICMP type = timeout */
                ficmp.code = 1;             /* ICMP code = timeout during reassembling */
                ficmp.id = htons((((T_IP4 *)p)->ip.ver & 0x0F) + 8 / 4);
                ficmp.seq = 0;
                srcaddr = ntohl(((T_IP4 *)p)->ip.da);
                dstaddr = ntohl(((T_IP4 *)p)->ip.sa);
                if (p->len < 8)
                    memset((UB*)(&((T_IP4 *)p)->ip) + ntohs(ficmp.id) * 4 - (8 - p->len),
                        0, 8 - p->len);
                icmp_snd_dat(srcaddr, dstaddr, &ficmp, &((T_IP4 *)p)->ip, ntohs(ficmp.id) * 4);
            }
            clr_frag_list(fl, TRUE);        /* clear fragment list */
        }
        fl = next;
    }
}

/*****************************************************************************
* IP reassembling
*
******************************************************************************/

T_IP4 *ip_reassembling(T_IP4 *pkt)
{
    T_RMPF rmpf;                            /* memory pool reference */
    T_IP4_HEADER *iph;                      /* pointer to IP header of incoming fragment */
    T_IPF *fl;                              /* pointer to fragment list */
    T_NIF *nif;
    W offset;                               /* fragment offset of IP header */
    W flen, end;                            /* data processing variables */
    BOOL mf;                                /* more fragment flag */
    ER ercd;                                /* error code */

    nif = pkt->ctl.nif;
    SNMP_BYPCNT(snmp_mibbyp.ipReasmReqds, 1);       /* ipReasmReqds */

    /* release old incomplete fragments if memory is insufficient */
    ercd = ref_mpf(ID_ETH_MPF, &rmpf);
    if (ercd != E_OK || rmpf.fblkcnt <= IPF_MREQ_BLK) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        ip_evictor();
        ip_internal_error(ercd);
        return NULL;
    }

    /* process fragment IP header */
    iph = &pkt->ip;                         /* pointer to IP header of incoming fragment */

    offset = ntohs(iph->fo);                /* get the offset value of the fragment */
    mf = (offset & IP_MF) ? TRUE : FALSE;
    offset = (offset & IP_OFFSET) << 3;

    /* get last data byte for position check */
    flen = ntohs(iph->tl) - IP4_HEADER_SZ;
    end = offset + flen;

    /* find fragment list for this fragment */
    fl = search_fragment_list(iph);         /* searches reassembly list for the fragment */

    /* ignore any invalid length fragment */
    if (flen <= 0 || end > 65535 || (offset == 0 && !mf)) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        clr_frag_list(fl, TRUE);
        SNMP_BYPCNT(snmp_mibbyp.ipReasmFails, 1);   /* ipReasmFails */
        return NULL;
    }

    /* read data of IP fragment */
    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, pkt->data, (int)flen, (int)nif->path_mtu)) {
        clr_frag_list(fl, TRUE);
        SNMP_BYPCNT(snmp_mibbyp.ipReasmFails, 1);   /* ipReasmFails */
        return NULL;
    }

    if (fl) {                               /* fragment list exists */
        ((T_IPF *)pkt)->tl = fl->tl;
        ((T_IPF *)pkt)->fl_next = fl->fl_next;
        ((T_IPF *)pkt)->fl_prev = fl->fl_prev;
        if (fl->fl_next != NULL)
            fl->fl_next->fl_prev = (T_IPF *)pkt;
        fl->fl_prev->fl_next = (T_IPF *)pkt;
        ((T_IPF *)pkt)->nextf = fl;

        fl = (T_IPF *)pkt;
    } else {                                /* fragment list not exists */
        fl = (T_IPF *)pkt;

        /* fill header information in fragment list */
        fl->tl = 0;

        /* insert new fragment list in reassembly list */
        if ((fl->fl_next = reass_root) != NULL)
            fl->fl_next->fl_prev = fl;
        reass_root = fl;
        fl->fl_prev = (T_IPF *)&reass_root;
        fl->nextf = NULL;
    }

    /* get the total length from last fragment */
    if (!mf)
        fl->tl = (UH)end;

    /* Fill the header informations of this fragment */
    fl->ofs = (UH)offset;
    fl->len = (UH)flen;

    /* check all fragments are received or not */
    if (receive_all_frag(fl)) {
        if (!make_ip_pkt(fl)) {
            clr_frag_list(fl, FALSE);
            return NULL;
        }
        SNMP_BYPCNT(snmp_mibbyp.ipReasmOKs, 1);     /* ipReasmOKs */
        return pkt;
    }
    fl->rtime = nif->ip.reasm_tmo;          /* redefine the timeout value */

    return pkt;                             /* framents to be received */
}

/* end */
