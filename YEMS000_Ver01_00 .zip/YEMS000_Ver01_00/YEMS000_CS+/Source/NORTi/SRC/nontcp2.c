/******************************************************************************
* NORTi TCP/IP Stack - TCP Module 2/2                                         *
*                                                                             *
*  Copyright (c) 1999-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05 Created                                                          *
* 2000-10-03 Released as Ver.4.02                                             *
* 2000-10-26 Modified tcp_transmit2() timeout for PPP                         *
* 2000-10-27 Modified RST packet sending process                              *
* 2000-12-01 Changed delayed ACK process                                      *
* 2000-12-01 Released as Ver.4.03                                             *
* 2001-01-22 Added support for multihome and multi-channel                    *
* 2001-01-22 Modified transfer exceeding 4GB                                  *
* 2001-02-10 Released as Ver.4.04                                             *
* 2001-02-27 Fixed "if (len <= 0)" to "if (len < 0)" in tcp_rcv_data()        *
* 2001-03-06 Modified tcp_reception() for flow control                        *
* 2001-03-15 Modified tcp_rcv_data() for zero window                          *
* 2001-04-06 Modified illegal access to p_dstaddr                             *
* 2001-04-06 Modified tcp_rcv_rst() not to call unnecessary callback          *
* 2001-06-18 Fixed ETHERNET_MTU to TCP_MTU in tcp_reception()                 *
* 2001-09-12 Fixed TCP_MTU to (cep->win0 >> 2) in tcp_get_sdat()              *
* 2001-09-13 Added part of retransmission request process in tcp_rcv_data()   *
* 2001-09-14 Modified adjust_getp()                                           *
* 2001-09-14 Modified tcp_rcv_ack()/_data() for tcp_cls_cep(..., TMO_NBLK)    *
* 2001-11-07 Modified tcp_rcv_ack() for closing sequence no. of FIN+ACK       *
* 2001-11-14 Modified tcp_rcv_ack() for reply of zero window probe            *
* 2002-02-18 Changed RST packet transmitting mechanism                        *
* 2002-04-04 Renamed adjust_getp() to tcp_flw_ctl()                           *
* 2002-03-23 Updated TCP retransmission with improved Exponential Backoff,    *
*                             and implemented Jacobson & Karn's algorithm     *
* 2002-03-23 Avoided unnecessary loop of ACK retransmission                   *
* 2002-04-28 Corrected slow start, congestion avoidance and                   *
*                                  fast recovery algorithm implementation     *
* 2002-05-01 Added code for keep-alive timer                                  *
* 2002-06-21 Modified zero window probe timeout                               *
* 2002-06-24 Modified tcp_transmit()                                          *
* 2002-06-25 Modified tcp_flw_ctl()                                           *
* 2002-12-23 Added sequence number validation for TCP reception               *
* 2003-03-25 Modified TCP reception to get target MSS value                   *
* 2003-03-25 Modified for SNMP                                                *
* 2003-05-30 Modified for loopBack interface                                  *
* 2004-07-01 Modified for IPv6 stack                                       PK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2005-09-01 Added missing hop limit reset (ip6.hlim=0) in make_tcp_pkt()  GS *
* 2006-03-24 Corrected delayed ACK transmission in tcp_transmit_ack()      AK *
* 2006-03-24 Made TCP_DACK_TMO and TCP_DUP_ACK values configurable         AK *
* 2008-07-28 Fixed TCP checksum check to accept both of 0x0000 and 0xFFFF  AK *
* 2006-07-29 Added SNMP support for IPv6                                   MK *
* 2007-01-25 Fixed tcp_rcv_rst() not to reset cep->rfncd/sfncd after          *
*             callback, for post process of API isuued by callback routine GS *
* 2007-03-06 Marged 4.09.05(inter) & 4.09.04e(FIX)                         OK *
* 2008-03-04 Added missing NULL check of cep->nif                          OK *
* 2008-03-12 Added missing !IS_USED(cep->state) check in can_ack_delay()   OK *
* 2008-04-28 Fixed problem of sequence number when FIN conflicted          OK *
* 2008-05-13 Tuned loop of searching TCP end points & reception points     OM *
* 2008-06-05 Added rmbxid2 for remove_queued_packet()                      GS *
* 2008-06-06 Added configurable timeout/retry parameters for each TCP_CEP  OM *
* 2008-07-18 Adjusted indent of switch-case sentence                       GS *
* 2008-09-09 Added ETYPE_SESSION judgment for PPPoE                        FY *
* 2008-09-18 Enabled ACK of zero window probe if FIN already sent          OM *
* 2008-10-16 Deleted some unnecessary spaces at end of line                FY *
* 2009-12-09 Fixed tcp_transmit_sub() not to stop TCP retransmission          *
*                                            after keep-alive packet sent  KZ *
* 2009-12-09 Fixed incorrect round trip time measurement                      *
*                       after keep-alive or zero window probe packet sent  KZ *
* 2009-12-09 Fixed problem that retransmission timeout becomes too big     KZ *
* 2009-12-10 Fixed reception process of TCP zero window advertisement      KZ *
* 2010-07-14 Replaced wait() macro with MSEC2TICK() macro                  FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2011-08-20 Added missing callback of tcp_cls_cep timeout when TMO_NBLK   GS *
* 2011-10-18 Corrected CEP search to connect in order of tcp_acp_cep call  FY *
* 2012-02-09 Skipped processing of IS_USED() by using pTCP_CEP list        FY *
* 2012-03-28 Fixed miss receiving of ACK for sent data with cycled SEQ=0   FY *
* 2012-03-28 Fixed return of double ACK if Rx buffer is emptied from full  FY *
* 2012-03-28 Added cep->type check in search_tcp_cep not to pick IPv6 CEPs FY *
* 2012-04-13 Fixed problem that CEP is used after call tcp_cep_unused()    FY *
* 2012-04-13 Simplified tcp_put_rdat() coding to avoid CSS optimizer bug   HE *
* 2012-04-14 Renamed cep->ack to cep->rseq (remote sequence number),          *
*                and cep->seq to cep->risn (remote initial sequence number),  *
*                and cep->seq0 to cep->isn (local initial sequence number) FY *
* 2012-05-15 Fixed tcp_rcv_syn not to alter source address by set_src_addr GS *
* 2012-05-15 Restored nif check in search_tcp_cep6 to get CEP of fixed nif GS *
* 2012-06-07 Moved code that searches tasks waiting in select to nonsock.c GS *
* 2012-11-13 Abolished power-of-two restriction of TCP CEP's buffers          *
*              using added sgeti/sputi/rgeti/rputi for offset calculation  FY *
* 2012-11-13 Accessed cep->type only when DUAL_STK is effective            FY *
* 2012-11-19 Fixed search_tcp_cep() not to select same CEP by multiple SYN GS *
* 2012-11-23 Modified according to swapping data and IP header member in      *
*              T_IP4 to minimize memory pool for send UDP packet queueing  FY *
* 2012-12-05 Removed int cast of IP4_HEADER_SZ unneeded at (*nif->func)()  FY *
* 2013-01-24 Added support for TSopt (TCP time stamp option)               FY *
* 2013-01-24 Fixed htonl() to ntohl() at converting network byte order of     *
*             tcp->seq into host byte order in tcp_put_rdat/make_tcp_pkt() FY *
* 2013-01-24 Added missing ntohs() to tcp->flag read in can_ack_delay()    FY *
* 2013-01-24 Added error count processing for SNMP                            *
*                      at packet reading error or its length is erroneous  FY *
* 2013-02-07 Added UW cast to cep->sbufsz in % remainder calc to make sure FY *
* 2013-06-18 Changed tcp_transmit2() to use passed timeout instead of 2sec FY *
* 2013-06-18 Corrected FIN retry process not to increment sequence number  FY *
* 2013-06-18 Fixed problem that RST was sent when active close competes    FY *
* 2013-06-18 Added missing send of FIN when tcp_cls_cep() was called with     *
*                non-blocking and FIN and ACK were received as one packet  FY *
* 2013-06-18 Fixed send of RST when tcp_cls_cep() was called with             *
*               non-blocking and data and ACK were received as one packet  FY *
* 2013-06-18 Changed dcls_id type (UH->H) to avoid RXC misjadge with (-1)  FY *
* 2013-06-18 Added dcls_id = 0 when calling wup_tsk/rel_wai(dcls_id)       FY *
* 2013-06-18 Replaced seq_check calc. by ring_sub() to avoid old GCC bug   MI *
* 2013-06-18 Fixed long word access across 4-byte boundary for TSopt       FY *
* 2013-06-18 Added missing discard of packets,                                *
*                        when invalid header length's packet was received  FY *
* 2013-09-24 Added missing TSecr initialization in tcp_reception()         HE *
* 2014-01-30 Added updating entry of tcpConnectionTable & tcpListenerTable    *
*                    of MIB-2 in tcp_rcv_syn() in case of CEP_WAIT_P_OPEN  HE *
* 2014-06-04 Fixed tcp_rcv_ack() not to accept old ACK                     FY *
* 2014-10-20 Replaced magic number to TSOPT_REQUEST/TSOPT_ENABLE macro     FY *
* 2015-06-01 Changed parameter of tcp_transmit_ack()                       FY *
* 2015-06-01 Added calling of tcp_timeout_update() for TCP timeout         FY *
* 2015-06-01 Added static modifier to tcp_transmit_sub()                   FY *
* 2015-06-01 Renamed tcp_timeout() to tcp_retry_failure()                  FY *
* 2015-06-01 Modified TCP timeout process                                  FY *
* 2016-02-08 Added missing "|| cep->sflag != 0" in tcp_transmit_sub()      FY *
* 2016-02-23 Fixed cep->sgeti miscalculation when retrying in tcp_get_sdat FY *
* 2016-07-13 Added missing cast of (UH)_win, (UB)cep->retry.flag and so on MT *
* 2016-07-27 Ridded needless if-condition to update TSecr in tcp_reception FY *
* 2017-01-25 Replaced all UW subtractions by ring_sub() to avoid CCS bug   HE *
* 2017-03-30 Removed unnecessary "if (len ...) cep->sflag |= ACK_FLAG;"       *
*                   for zero window and keep-alive probe in tcp_rcv_ack()  FY *
* 2017-08-21 Added missing tcp_timeout_update() in validate_tcp_rpkt()     FY *
* 2017-08-23 Removed redundant ETYPE_IP4/ETYPE_SESSION check in               *
*                  make_tcp_ack_pkt(), make_rst_pkt() and tcp_reception()  GS *
* 2019-10-04 Added missing "if(cep->state!=CEP_CLOSED)" in tcp_reception() FY *
* 2021-06-08 Removed unnecessary IP send task waking code in tcp_reception FY *
* 2021-06-08 Replaced rel_wai() with wup_snd_tsk() in tcp_timeout_update() FY *
* 2021-06-22 Removed code to retransmit later in tcp_transmit_sub(), and      *
*             added tcp_recover_retrans() to do it ASAP after queue lacked FY *
* 2021-06-22 Changed remove_queued_packet() 2nd parameter type ID -> T_ETH FY *
* 2021-06-22 Deleted clearing of removed pkt->ctl.arprty                   FY *
* 2021-09-05 Added discard of packets with abnormal TCP option size           *
*                                                      in tcp_reception()  FY *
* 2021-09-05 Moved ring_sub() declaration to nonets.h                      FY *
* 2022-03-18 Stopped keep-alive & retransmission process after RST packet     *
*             received by adding missing cep->time clear in tcp_rcv_rst()     *
*             & CEP_DISCONNECTED check in tcp_timeout_update()/_process()  FY *
* 2022-03-18 Canceled unnecessary ACK sending after RST packet received       *
*                  by adding CEP_DISCONNECTED check in can_transmit_ack()     *
*                     and by removing queued delayed ACK in tcp_rcv_rst()  FY *
* 2022-03-18 Fixed RST packet seq no. within the range of TCP window using    *
*            cep->isn+cep->sgetp instead of cep->seq in tcp_transmit_sub() FY *
* 2022-07-08 Canceled delayed ACK when sending ACK for                        *
*                          received invalid packet in validate_tcp_rpkt()  FY *
* 2023-10-31 Fixed frequent retransmission bug introduced on 2016-07-13 by    *
*             removing 'else' before cep->win=(UH)_win in tcp_reception()  FY *
* 2024-09-29 Added RST send when keep-alive timeout in tcp_retry_failure() FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

#ifdef SOCK
#include "nonsock.h"
#endif

/************************************************/
/* Search TCP Communication End Point           */
/************************************************/
#ifdef DUAL_STK
static T_TCP_CEP *search_tcp_cep6(T_NIF *nif, UW dst[], UH dp, UW src[], UH sp)
{
    T_TCP_CEP *cep;
    UW sa[4], da[4];

    ntohl6(dst, da);
    ntohl6(src, sa);

    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->type == IPV6_ADDR
         && cep->dstpor == sp && cep->portno == dp
         && memcmp(cep->dst6ipa, sa, IP6_ADDR_SZ) == 0
         && memcmp(cep->ip6addr, da, IP6_ADDR_SZ) == 0)
            return cep;
    }
    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->type == IPV6_ADDR && cep->state == CEP_WAIT_P_OPEN
         && cep->portno == dp && cep->dstpor == 0
         && (memcmp(cep->ip6addr, da, IP6_ADDR_SZ) == 0
          || (is_ip6_addr_any(cep->ip6addr) && (cep->nif == NULL
           || cep->nif == nif))))
            return cep;
    }
    return NULL;
}
#endif

static T_TCP_CEP *search_tcp_cep(UW da, UH dp, UW sa, UH sp)
{
    T_TCP_CEP *cep;

    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->dstpor == sp && cep->portno == dp
         && cep->dstipa == sa && cep->ipaddr == da)
            return cep;
    }
    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->state == CEP_WAIT_P_OPEN && cep->portno == dp
            && cep->dstpor == 0
            && (cep->ipaddr == da || cep->ipaddr == IPV4_ADDRANY)
      #ifdef DUAL_STK
            && (cep->type == IPV4_ADDR)
      #endif
        )
            return cep;
    }
    return NULL;
}

/************************************************/
/* Calculate TCP Checksum                       */
/************************************************/

static UH tcp_checksum(T_TCP_PKT *pkt)
{
    UW sum;
    UH *p, *end;
    int i;

    /* TCP pseudo-header */
  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        p = (UH *)(((T_IP6 *)pkt)->ip6.sa);
            sum = *p++;
        for (i = 0; i < 15; i++)/* source and destination IPv6 address */
            sum += *p++;
        sum += ((T_IP6 *)pkt)->ip6.pl;

        sum += htons(PROT_TCP); /* TCP protocol number */
        i = ntohs(((T_IP6 *)pkt)->ip6.pl) - TCP_HEADER_SZ;
        p = (UH *)&((T_TCP6_PKT *)pkt)->tcp;
    } else
  #endif
    {
        p = (UH *)&(pkt->ip.sa);
        sum  = *p++;            /* source IP address (high) */
        sum += *p++;            /* source IP address (low) */
        sum += *p++;            /* destination IP address (High) */
        sum += *p++;            /* destination IP address (Low) */
        sum += htons(PROT_TCP); /* TCP protocol number */
        sum += htons(ntohs(pkt->ip.tl) - IP4_HEADER_SZ);
        i = ntohs(pkt->ip.tl) - IP4_HEADER_SZ - TCP_HEADER_SZ;
        p = (UH *)&pkt->tcp;
    }

    /* TCP Header */
    sum += *p++;                /* source port number */
    sum += *p++;                /* destination port number */
    sum += *p++;                /* sequence number (high) */
    sum += *p++;                /* sequence number (low) */
    sum += *p++;                /* acknowledgment number (high) */
    sum += *p++;                /* acknowledgment number (low) */
    sum += *p++;                /* header length (data offset), flags */
    sum += *p++;                /* window size */
    sum += *p++;                /* checksum */
    sum += *p++;                /* urgent pointer */

    /* TCP option & data */
    if (i > 0) {
      #ifdef DUAL_STK
        if (ntohs(pkt->eth.etype) == ETYPE_IP6)
            p = (UH *)((T_TCP6_PKT *)pkt)->data;
        else
      #endif
            p = (UH *)pkt->data;
        end = (UH *)((UB *)p + (i & ~1));
        while (p < end)
            sum += *p++;
        if (i & 1)
            sum += (UH)(htons((ntohs(*p) & 0xff00)));
    }

    /* add carry and complement */
    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);
    return (UH)~sum;
}

/************************************************/
/* Seq validation for incoming TCP segments     */
/************************************************/

static B tcp_seq_valid(T_TCP_CEP *cep, UW rxseq, int len, UH rxwin)
{
    UW seq_next;
    W seq_check;

    seq_next = cep->rseq;
    if (len == 0) {
        if (rxwin == 0) {
            if (rxseq == seq_next)
                return TRUE;
        } else {
            seq_check = ring_sub(seq_next, rxseq);
            if (seq_check <= 0) {
                seq_check = ring_sub(rxseq, seq_next + (UW)rxwin);
                if (seq_check < 0)
                    return TRUE;
            }
        }
    } else {
        if (rxwin > 0) {
            seq_check = ring_sub(rxseq, seq_next);
            if (seq_check >= 0) {
                seq_check = ring_sub(rxseq, seq_next + (UW)rxwin);
                if (seq_check < 0)
                    return TRUE;
            }

            seq_check = ring_sub(seq_next, rxseq + (UW)len - 1);
            if (seq_check <= 0) {
                seq_check = ring_sub(rxseq + (UW)len - 1, seq_next + (UW)rxwin);
                if (seq_check < 0)
                    return TRUE;
            }
        }
    }
    return FALSE;
}

/************************************************************************************
* Module Name   : tcp_rtt_cal                                                       *
* Purpose       : This funtion calulates RTO value for retransmission by using the  *
*                 calculated value of RTT.                                          *
*                 (Implemented as per RFC 2988-Computing TCP's Retransmission timer)*
* Arguments     : T_TCP_CEP *cep - TCP CEP structure                                *
*                 UW rtime       - Round trip time of a TCP segment                 *
* Return value  : None.                                                             *
* Author        : AK                                                                *
* Date          : 23-Mar-2002                                                       *
* Modified UW rtime as W rtime and added else cond for rtime - A.K 18/jul/2002      *
************************************************************************************/

static void tcp_rtt_cal(T_NIF *nif, T_TCP_CEP *cep, W rtime)
{
    if (IS_USED(cep->state)) {          /* check for valid CEP state */
        if (rtime == 0)
            rtime = 1;

        /* for first measurment of RTO use the equation */
        /*  srtt = r                                    */
        /*  rttvar = r / 2                              */
        /* else use                                     */
        /*  rttvar = (1-B) * rttvar + B * |srtt - r|    */
        /*  srtt = (1-A) * srtt + (A * r)               */
        /* calculate RTO using the equation             */
        /* RTO = srtt + max(g, k * rttvar)              */
        if (cep->retry.srtt != 0) {
            rtime = rtime - (cep->retry.srtt >> 3);

            if (((W)(cep->retry.srtt + rtime)) <= 0)
                cep->retry.srtt = 1;
            else
                cep->retry.srtt += rtime;

            if (rtime < 0)
                rtime = -rtime;
            rtime -= (cep->retry.rttvar >> 2);
            cep->retry.rttvar += rtime;
        } else {
            cep->retry.srtt = rtime << 3;
            cep->retry.rttvar = MAX(((UW)rtime << 1), cep->tmo.rto_min);
        }

        cep->retry.rto = (cep->retry.srtt >> 3) + cep->retry.rttvar;

        /* RTO value should not less than lower bound and */
        /* should not greater than upper bound            */
        if (cep->retry.rto > cep->tmo.rto_max)
            cep->retry.rto = cep->tmo.rto_max;
        if (cep->retry.rto < cep->tmo.rto_min)
            cep->retry.rto = cep->tmo.rto_min;
    }
}

/************************************************/
/* Put Sending Data to Window Buffer            */
/************************************************/

INT tcp_put_sdat(T_TCP_CEP *cep, const UB *buf, INT len)
{
    W size;
    W i, len2;

    size = (W)cep->sbufsz - (W)(cep->sputp - (cep->seq - cep->isn));
    if (size <= 0)
        return 0;
    if ((W)len > size)
        len = (INT)size;

    i = (W)(cep->sputi);
    if (i + len <= cep->sbufsz) {
        memcpy(cep->sbuf + i, buf, len);
    } else {
        len2 = cep->sbufsz - i;
        memcpy(cep->sbuf + i, buf, len2);
        buf += len2;
        len2 = len - len2;
        memcpy(cep->sbuf, buf, len2);
    }

    cep->sputp += len;
    if ((W)cep->sputi + len >= cep->sbufsz)
        cep->sputi += (UH)len - cep->sbufsz;
    else
        cep->sputi += len;
    return len;
}

/************************************************/
/* Get Sending Buffer from Window Buffer        */
/************************************************/

INT tcp_get_sbuf(UB **p_buf, T_TCP_CEP *cep)
{
    W size;
    W i, len;

    size = (W)cep->sbufsz - (W)(cep->sputp - (cep->seq - cep->isn));
    if (size <= 0)
        return 0;
    if (size > 0x7fffL)
        len = 0x7fff;
    else
        len = size;

    i = cep->sputi;
    if (i + len > cep->sbufsz)
        len = cep->sbufsz - i;
    *p_buf = cep->sbuf + i;
    return (INT)len;
}

/*******************************************************/
/* Put Buffer Containing Sending Data to Window Buffer */
/*******************************************************/

ER tcp_put_sbuf(T_TCP_CEP *cep, INT len)
{
    W size;

    size = (W)cep->sbufsz - (W)(cep->sputp - cep->sgetp);
    if ((W)len > size)
        return E_OBJ;

    cep->sputp += len;
    if ((W)cep->sputi + len >= cep->sbufsz)
        cep->sputi += (UH)len - cep->sbufsz;
    else
        cep->sputi += len;
    return E_OK;
}

/************************************************/
/* Get optimized receive window size            */
/************************************************/

UH rwin_size(T_TCP_CEP *cep)
{
    UW rmtu;
    UH win;

    if (cep->umtu == 0) {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            rmtu =  cep->nif->path_mtu6 - TCP_HEADER_SZ;
        else
      #endif
            rmtu =  cep->nif->path_mtu - TCP_HEADER_SZ;
    } else {
        rmtu = cep->umtu;
    }

    win = (UH)(cep->rbufsz - (cep->rputp - cep->rgetp));

    if (cep->rbufsz > rmtu * 4) {
        if (win < (cep->rbufsz / 4))
            return 0;
    } else if (cep->rbufsz > rmtu) {
        if (win < rmtu)
            return 0;
    } else {
        if (win < cep->rbufsz) {
            /* 26 Jan2003 AK - send actual win size */
            return win;
        }
    }
    return win;
}

/************************************************/
/* Can ACK be transmitted ?                     */
/************************************************/

static BOOL can_transmit_ack(UH win1, UH win2, T_TCP_CEP *cep)
{
    UW rmtu;

    if (cep->state == CEP_DISCONNECTED)
        return FALSE;

    if (cep->umtu == 0) {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            rmtu =  cep->nif->path_mtu6 - TCP_HEADER_SZ;
        else
      #endif
            rmtu =  cep->nif->path_mtu - TCP_HEADER_SZ;
    } else {
        rmtu = cep->umtu;
    }

    /* 10Feb2003 - ACK for every second segment */
    if (cep->rgetp == cep->rputp) {
        cep->dackflag = 0;
        return TRUE;
    }

    if (win1 == 0 && win2 > 0)
        return TRUE;

    if (rmtu * 4 < cep->rbufsz) {
        if (win1 < (cep->rbufsz / 4) && (cep->rbufsz / 4) <= win2)
            return TRUE;
    } else if (cep->rbufsz > rmtu) {
        if (win1 < rmtu && rmtu <= win2)
            return TRUE;
    } else {
        if (win1 < cep->rbufsz && cep->rbufsz <= win2)
            return TRUE;
    }
    return FALSE;
}

/************************************************/
/* Get Received Data from Window Buffer         */
/************************************************/

INT tcp_get_rdat(UB *buf, T_TCP_CEP *cep, INT len)
{
    W i, len2;
    W size;
    UH win1, win2;

    size = ring_sub(cep->rputp, cep->rgetp);
    if (size <= 0)
        return 0;

    win1 = (UH)(cep->rbufsz - size);
    if ((W)len > size)
        len = (INT)size;

    i = cep->rgeti;
    if (i + len <= cep->rbufsz) {
        memcpy(buf, cep->rbuf + i, len);
    } else {
        len2 = cep->rbufsz - i;
        memcpy(buf, cep->rbuf + i, len2);
        buf += len2;
        len2 = len - len2;
        memcpy(buf, cep->rbuf, len2);
    }
    cep->rgetp += len;
    if ((W)cep->rgeti + len >= cep->rbufsz)
        cep->rgeti += (UH)len - cep->rbufsz;
    else
        cep->rgeti += len;
    win2 = (UH)(cep->rbufsz - (cep->rputp - cep->rgetp));

    if (can_transmit_ack(win1, win2, cep)) {
        if (cep->ackpkt != NULL) {
            tcp_transmit_ack(cep);
        } else {
            cep->sflag |= ACK_FLAG;
            tcp_transmit(cep);
        }
    }
    return len;
}

/**********************************************************/
/* Get Buffer Containing Received Data from Window Buffer */
/**********************************************************/

INT tcp_get_rbuf(UB **p_buf, T_TCP_CEP *cep)
{
    W i, size;
    INT len;

    size = ring_sub(cep->rputp, cep->rgetp);
    if (size == 0)
        return 0;
    if (size > 0x7fffL)
        len = 0x7fff;
    else
        len = (INT)size;

    i = cep->rgeti;
    *p_buf = cep->rbuf + i;

    if (i + len >= cep->rbufsz)
        len = cep->rbufsz - i;
    return len;
}

/************************************************/
/* Release Receiving Buffer to Window Buffer    */
/************************************************/

ER tcp_rel_rbuf(T_TCP_CEP *cep, INT len)
{
    W size;
    UH win1, win2;

    size = ring_sub(cep->rputp, cep->rgetp);
    if ((W)len > size)
        return E_OBJ;
    win1 = (UH)(cep->rbufsz - size);
    cep->rgetp += len;
    if ((W)cep->rgeti + len >= cep->rbufsz)
        cep->rgeti += (UH)len - cep->rbufsz;
    else
        cep->rgeti += len;
    win2 = (UH)(cep->rbufsz - (cep->rputp - cep->rgetp));

    if (can_transmit_ack(win1, win2, cep)) {
        if (cep->ackpkt != NULL) {
            tcp_transmit_ack(cep);
        } else {
            cep->sflag |= ACK_FLAG;
            tcp_transmit(cep);
        }
    }
    return E_OK;
}

/************************************************/
/* Get Sending Data from Window Buffer          */
/************************************************/

static INT tcp_get_sdat(UB *buf, T_TCP_CEP *cep, W *p_size, BOOL retry, int optlen)
{
    UW pos;
    W size, seq_check;
    W i, len, len2;
    UH posi;

    if (retry) {
        cep->sgetp = cep->seq - cep->isn;
        cep->sgeti = cep->seqi;
    }
    pos = cep->sgetp;
    posi = cep->sgeti;
    /* dont transmit new data during retransmission */
    if (cep->hseq && !(cep->dackmd)) {
        seq_check = ring_sub(cep->hsqn - cep->isn, pos);
        if (seq_check < 0)
            return 0;
    }

    size = ring_sub(cep->sputp, pos);
    if (size <= 0)
        return 0;

    *p_size = size;

    if (size > (W)cep->mss - optlen)
        size = cep->mss - optlen;

    if (retry) {
        /* do not send until get enough space */
        /* 25Oct2004 - corrected cep->win as cep->win1 */
        if (cep->win1 == 0) {
            buf[0] = 0;
            return -1; /* to send zero window probe */
        }
        if (size > (W)cep->win1)
            len = cep->win1;
        else
            len = size;
    } else {
        /* do not send until get enough space */
        if (cep->smax == 0 || (cep->win == 0 && cep->dackmd == FALSE)) {
            if (cep->time == 0) { /* refresh time value only if already not set */
                if ((cep->time = SYSCK.ltime) == 0)
                    cep->time = 1;
            }
            return 0;
        }

        if (size > (W)cep->smax)
            len = cep->smax;
        else
            len = size;

        if (cep->smax != 0)
            cep->smax -= len;
    }

    i = posi;

    if (i + len <= cep->sbufsz) {
        memcpy(buf, cep->sbuf + i, len);
    } else {
        len2 = cep->sbufsz - i;
        memcpy(buf, cep->sbuf + i, len2);
        buf += len2;
        len2 = len - len2;
        memcpy(buf, cep->sbuf, len2);
    }
    cep->sgeti = (UH)(((UW)cep->sgeti + len) % cep->sbufsz);
    cep->sgetp = pos + len;
    return (INT)len;
}

/************************************************/
/* Put Received Data to Window Buffer           */
/************************************************/

static INT tcp_put_rdat(T_TCP_PKT *pkt, T_TCP_CEP *cep, UB *buf, INT len)
{
    UW pos;
    W i, len2;
    T_TCP_HEADER *tcp;

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

    pos = ntohl(tcp->seq) - (cep->risn + 1);
    i = (W)(cep->rputp - pos);
    if (i < 0)
        return (INT)i;

    if (i >= len)
        return len;
    buf += i;
    len -= i;

    i = (W)cep->rbufsz - (W)(cep->rputp - cep->rgetp);
    if (i == 0)
        return 0;
    if ((W)len > i)
        len = (INT)i;

    i = cep->rputi;
    if (i + len <= cep->rbufsz) {
        memcpy(cep->rbuf + i, buf, len);
    } else {
        len2 = cep->rbufsz - i;
        memcpy(cep->rbuf + i, buf, len2);
        buf += len2;
        len2 = len - len2;
        memcpy(cep->rbuf, buf, len2);
    }
    cep->rputp += len;
    if ((W)cep->rputi + len >= cep->rbufsz)
        cep->rputi += (UH)len - cep->rbufsz;
    else
        cep->rputi += len;

  #ifdef SOCK /* ready to read data */
    wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif
    return (INT)(cep->rputp - pos);
}

/************************************************/
/* Make ACK Packet                              */
/************************************************/
/* Added 29/08/2002 - AK - process invalid TCP packets */
static void make_tcp_ack_pkt(T_TCP_PKT *pkt, T_TCP_CEP *cep)
{
    UW tmp1[4];
    UH tmp2;
    T_TCP_HEADER *tcp;

    memset(pkt->eth.da, 0, 6);
  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        pkt->eth.etype = htons(ETYPE_IP6);
        ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
        ntohl6(((T_IP6 *)pkt)->ip6.sa, tmp1);
        memcpy(((T_IP6 *)pkt)->ip6.sa, ((T_IP6 *)pkt)->ip6.da, IP6_ADDR_SZ);
        htonl6(tmp1, ((T_IP6 *)pkt)->ip6.da);
        ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ));

        /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
        ((T_IP6 *) pkt)->ip6.hlim = 0;
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    } else
  #endif
    {
        pkt->eth.etype = htons(ETYPE_IP4);
        pkt->ip.prot = PROT_TCP;
        tmp1[3] = ntohl(pkt->ip.sa);
        pkt->ip.sa = pkt->ip.da;
        pkt->ip.da = htonl(tmp1[3]);
        pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ));
        pkt->ip.tos = cep->tos;
        pkt->ip.ttl = cep->ttl;
        tcp = &pkt->tcp;
    }

    tmp2 = ntohs(tcp->sp);
    tcp->sp = tcp->dp;
    tcp->dp = htons(tmp2);

    /* send SND.NXT sequence number, not SND.UNA */
    tcp->seq = htonl(cep->mseq);
    tcp->ack = htonl(cep->rseq);
    tcp->flag = htons((UH)(((sizeof (T_TCP_HEADER) / 4) << 12) | ACK_FLAG));
    tcp->win = rwin_size(cep);
    tcp->win = htons(tcp->win);
    tcp->urgp = 0;
    tcp->cs = 0;
    tcp->cs = tcp_checksum(pkt);
}

/************************************************/
/* Make RST Packet                              */
/************************************************/

static void make_tcp_rst_pkt(T_TCP_PKT *pkt, T_TCP_CEP *cep)
{
    UW tmp1[4];
    UH tmp2;
    T_TCP_HEADER *tcp;

    memset(pkt->eth.da, 0, 6);

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        pkt->eth.etype = htons(ETYPE_IP6);
        ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
        ntohl6(((T_IP6 *)pkt)->ip6.sa, tmp1);
        memcpy(((T_IP6 *)pkt)->ip6.sa, ((T_IP6 *)pkt)->ip6.da, IP6_ADDR_SZ);
        htonl6(tmp1, ((T_IP6 *)pkt)->ip6.da);
        ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ));

        /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
        ((T_IP6 *) pkt)->ip6.hlim = 0;
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    } else
  #endif
    {
        pkt->ip.prot = PROT_TCP;
        pkt->eth.etype = htons(ETYPE_IP4);
        tmp1[3] = ntohl(pkt->ip.sa);
        pkt->ip.sa = pkt->ip.da;
        pkt->ip.da = htonl(tmp1[3]);
        pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ));
        if (cep != NULL) {
            pkt->ip.tos = cep->tos;
            pkt->ip.ttl = cep->ttl;
        } else {
            pkt->ip.tos = 0; /* default TOS */
            pkt->ip.ttl = (pkt->ctl.nif)->ip.ttl;
        }
        tcp = &pkt->tcp;
    }

    tmp2 = ntohs(tcp->sp);
    tcp->sp = tcp->dp;
    tcp->dp = htons(tmp2);
    tmp1[3] = ntohl(tcp->seq);
    tcp->seq = tcp->ack;
    if (ntohs(tcp->flag) & (FIN_FLAG|SYN_FLAG))
        tmp1[3]+=1;
    tcp->ack = htonl(tmp1[3]);

    tcp->flag = htons((UH)(((sizeof (T_TCP_HEADER) / 4) << 12) | (ACK_FLAG|RST_FLAG)));
    tcp->win = 0;
    tcp->urgp = 0;
    tcp->cs = 0;
    tcp->cs = tcp_checksum(pkt);

    SNMP_BYPCNT(snmp_mibbyp.tcpOutRsts, 1);  /* tcpOutRsts */
}

static void make_tcp_rst_pkt1(T_TCP_PKT *pkt, T_TCP_CEP *cep)
{
    int flag, len;
    UW tmp1[4];
    UH tmp2;
    T_TCP_HEADER *tcp;

    memset(pkt->eth.da, 0, 6);

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        pkt->eth.etype = htons(ETYPE_IP6);
        ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
        ntohl6(((T_IP6 *)pkt)->ip6.sa, tmp1);
        memcpy(((T_IP6 *)pkt)->ip6.sa, ((T_IP6 *)pkt)->ip6.da, IP6_ADDR_SZ);
        htonl6(tmp1, ((T_IP6 *)pkt)->ip6.da);
        len = ntohs(((T_IP6 *)pkt)->ip6.pl) - TCP_HEADER_SZ;
        ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ));

        /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
        ((T_IP6 *) pkt)->ip6.hlim = 0;
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    } else
  #endif
    {
        pkt->ip.prot = PROT_TCP;
        pkt->eth.etype = htons(ETYPE_IP4);
        tmp1[3] = ntohl(pkt->ip.sa);
        pkt->ip.sa = pkt->ip.da;
        pkt->ip.da = htonl(tmp1[3]);
        len = ntohs(pkt->ip.tl) - (IP4_HEADER_SZ + TCP_HEADER_SZ);
        pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ));
        if (cep != NULL) {
            pkt->ip.tos = cep->tos;
            pkt->ip.ttl = cep->ttl;
        } else {
            pkt->ip.tos = 0; /* Default TOS */
            pkt->ip.ttl = (pkt->ctl.nif)->ip.ttl;
        }
        tcp = &pkt->tcp;
    }

    tmp2 = ntohs(tcp->sp);
    tcp->sp = tcp->dp;
    tcp->dp = htons(tmp2);

    flag = ntohs(tcp->flag) & 0x3f;

    /* if ACK is set then */
    if (flag & ACK_FLAG) {
        tcp->seq = tcp->ack;
        tcp->ack = 0;
        flag = RST_FLAG;
    } else {
        tmp1[3] = ntohl(tcp->seq);      /* UH->UW 24MAR2006 AK */

        if (ntohs(tcp->flag) & SYN_FLAG)
            tmp1[3] += 1;

        if (ntohs(tcp->flag) & FIN_FLAG)
            tmp1[3] += 1;

        if ((ntohs(tcp->flag) & 0xf000) != 0x5000) { /* option */
            len = len - (((ntohs(tcp->flag) >> 12) * 4) - TCP_HEADER_SZ);
        }

        tmp1[3] += len;

        tcp->seq = 0;
        tcp->ack = htonl(tmp1[3]);

        flag = RST_FLAG|ACK_FLAG;
    }

    tcp->flag = htons((UH)(((sizeof (T_TCP_HEADER) / 4) << 12) | (flag)));
    tcp->win = 0;
    tcp->urgp = 0;
    tcp->cs = 0;
    tcp->cs = tcp_checksum(pkt);

    SNMP_BYPCNT(snmp_mibbyp.tcpOutRsts, 1);  /* tcpOutRsts */
}

/************************************************/
/* Make TCP Packet                              */
/************************************************/

static W make_tcp_pkt(T_TCP_PKT *pkt, T_TCP_CEP *cep, BOOL retry)
{
    W seq_check;
    W size = 0;
    UW rmtu;
    UW maxseq;
    UH flag;
    INT len;
    BOOL zerow = FALSE;
    T_TCP_HEADER *tcp;
    UB *data;
    int optlen = 0;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
        data = ((T_TCP6_PKT *)pkt)->data;
    } else
  #endif
    {
        tcp = &pkt->tcp;
        data = pkt->data;
    }

    cep->retry.ref = 0;

    flag = cep->sflag;

    if (flag & SYN_FLAG) {
        if (cep->umtu == 0) {
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR)
                rmtu =  cep->nif->path_mtu6 - TCP_HEADER_SZ;
            else
          #endif
                rmtu =  cep->nif->path_mtu - TCP_HEADER_SZ;
        } else {
            rmtu = cep->umtu;
        }

        data[optlen++] = 2;
        data[optlen++] = 4;
        data[optlen++] = (UB)((rmtu) >> 8);
        data[optlen++] = (UB)(rmtu);
    }

    if (cep->tsopt & TSOPT_ENABLE) {
        data[optlen++] = 8;
        data[optlen++] = 10;
        ((UH *)(data + optlen))[0] = htons((UH)(((UW)SYSCK.ltime * mSEC) >> 16));
        ((UH *)(data + optlen))[1] = htons((UH)(SYSCK.ltime * mSEC));
        optlen += 4;
        ((UH *)(data + optlen))[0] = htons((UH)(cep->tsecr >> 16));
        ((UH *)(data + optlen))[1] = htons((UH)(cep->tsecr));
        optlen += 4;
    }

    while (optlen % 4)
        data[optlen++] = 0;

    cep->sflag &= ~(ACK_FLAG|RST_FLAG);
    if (flag & (RST_FLAG|SYN_FLAG)) {
        len = 0;
        if (flag & RST_FLAG) { /* send RST */
            make_tcp_rst_pkt(pkt, cep);
            return size;
        }
        cep->retry.ref = 1; /* need set ret timer SYN retransmissions */
    } else {
        if (cep->state == CEP_CLOSED || cep->state == CEP_DISCONNECTED)
            len = 0;
        else
            len = tcp_get_sdat(data + optlen, cep, &size, retry, optlen);
    }

    /* Mod 21-Sep-2004 transmit FIN immediatly after data transmission */

    /* check whether FIN need to transmit or not */
    if (flag & FIN_FLAG) {

        if (cep->state == CEP_TERMINATED) {
            /* still data transmission is pending */
            if (cep->sputp != cep->sgetp)
                flag &= ~FIN_FLAG;
        } else {
            seq_check = ring_sub(cep->sputp, cep->seq - cep->isn);
            if (seq_check > 0)   /* Window Buffer not empty */
                flag &= ~FIN_FLAG;
        }

        if (flag & FIN_FLAG) {
            /* already sent FIN ? */
            if ((retry == FALSE) && (cep->mseq == cep->isn + cep->sputp + 1))
                flag &= ~FIN_FLAG;
        }
    }

    if (len == 0) {
        if (flag == 0)
            return -1;
        size = 0;   /* set this to avoid looping with ACK segment */
    }

    if (cep->dackflag & TCP_ZERO_PROBE) {
        cep->dackflag &= ~TCP_ZERO_PROBE;
        len = -1;
        cep->retry.ref = 1; /* need set ret timer - zero win probe retries */
    }

    if (len != 0 || !(flag & (RST_FLAG|SYN_FLAG)))
        flag |= ACK_FLAG;
    if (len == -1) { /* to send zero window probe */
        len = 0;
        zerow = TRUE;
        cep->retry.ref = 1; /* need set ret timer - zero window probing */
    } else if (len != 0) {
        if (retry)
            flag |= PSH_FLAG;
        else if (cep->smax <= 0 || ((cep->sputp - cep->sgetp) == 0))
            flag |= PSH_FLAG;
        cep->retry.ref = 1; /* need set ret timer - data retransmissions */
    }

    if (flag & FIN_FLAG)
        cep->retry.ref = 1; /* need set ret timer - data retransmissions */

    memset(pkt->eth.da, 0, 6);

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        pkt->eth.etype = htons(ETYPE_IP6);
        htonl6(cep->dst6ipa, ((T_IP6 *)pkt)->ip6.da);
        ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
        htonl6(cep->ip6addr, ((T_IP6 *)pkt)->ip6.sa);
    } else
  #endif
    {
        pkt->eth.etype = htons(ETYPE_IP4);
        pkt->ip.da   = htonl(cep->dstipa);
        pkt->ip.prot = PROT_TCP;
        pkt->ip.sa   = htonl(cep->ipaddr);
    }

    tcp->sp  = htons(cep->portno);
    tcp->dp  = htons(cep->dstpor);

    if (zerow) {    /* zero window probe */
        tcp->seq = htonl(cep->isn + cep->sgetp - 1);
    } else if (len == 0 && (cep->rflag & FIN_FLAG)) {   /* ACK of FIN */
        if ((cep->sflag & FIN_FLAG) && !(flag & FIN_FLAG))
            tcp->seq = htonl(cep->seq + 1);
        else
            tcp->seq = htonl(cep->seq);
    } else {
        if ((cep->state == CEP_TERMINATED || cep->state == CEP_CLOSING) &&
            !(cep->sflag & FIN_FLAG))
            tcp->seq = htonl(cep->isn + cep->sgetp - len + 1);
        else
            tcp->seq = htonl(cep->isn + cep->sgetp - len);
    }

    tcp->ack = htonl(cep->rseq);
    tcp->win = rwin_size(cep);

    pkt->ctl.cep = cep;
    tcp->win = htons(tcp->win);
    tcp->urgp = 0;

    /* used to avoid retransmission of ACK segments */
    if (len != 0)
        cep->retry.flag |= PSH_FLAG;
    else
        cep->retry.flag = flag;

    maxseq = ntohl(tcp->seq) + len;
    if (flag & (FIN_FLAG|SYN_FLAG))
        maxseq ++;

    seq_check = ring_sub(maxseq, cep->mseq);
    if (seq_check > 0)
        cep->mseq = maxseq;

    len += optlen;

    tcp->flag = htons((UH)((((sizeof (T_TCP_HEADER) + optlen) / 4) << 12) | flag));

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ + len));

        /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
        ((T_IP6 *) pkt)->ip6.hlim = 0;
    } else
  #endif
    {
        pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ + len));
        pkt->ip.tos = cep->tos;
        pkt->ip.ttl = cep->ttl;
    }

    tcp->cs = 0;
    tcp->cs = tcp_checksum(pkt);

    seq_check = ring_sub(maxseq, cep->mseq);
    if (len != 0 && (retry || (seq_check < 0))) {   /* �đ��� */
        SNMP_BYPCNT(snmp_mibbyp.tcpRetransSegs, 1); /* tcpRetransSegs */
    }

    if (retry && !cep->hseq) {
        if (cep->retry.retries == 1) {
            if (cep->retry.flag & PSH_FLAG) {
                cep->hseq = TRUE;
                cep->hsqn = cep->mseq;
            }
        }
    }
    return size;
}

/************************************************/
/* Set Sequence No                              */
/************************************************/

static void set_seq(T_TCP_CEP *cep, UW seq)
{
    cep->seqi = (UH)(((UW)cep->seqi + (seq - cep->seq)) % (UW)cep->sbufsz);
    cep->seq = seq;
}

/************************************************/
/* ACK Reception                                */
/************************************************/

void tcp_rcv_ack(T_TCP_PKT *pkt, T_TCP_CEP *cep, int len)
{
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    INT parblk, slen;
    W seq_check, ack_check;
    T_TCP_HEADER *tcp;
  #ifdef SOCK
    W size;
  #endif

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

    ack_check = (W)ntohl(tcp->ack) - (W)cep->seq;
    if (ack_check < 0)
        return;

    switch (cep->state) {
    case CEP_WAIT_P_OPEN:
        if (cep->dstpor == 0)
            break;
        if (ntohl(tcp->ack) != cep->seq + 1)
            break;
        cep->isn = ++cep->seq;
        cep->win1 = cep->win0 = ntohs(tcp->win);
        cep->sflag &= ~SYN_FLAG;
        cep->state = CEP_CONNECTING;
        cep->rflag &= ~SYN_FLAG;
      #ifdef DUAL_STK
        if (cep->type == IPV4_ADDR) {
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_UNKNOWN,NULL,0, 0);
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_IPV4, &cep->dstipa,cep->dstpor, 0);
        }
      #else
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno, 0, 0);
        SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
      #endif
        SNMP_BYPCNT(snmp_mibbyp.tcpPassiveOpens, 1);  /* tcpPassiveOpens */

        fncd = cep->rfncd;
        if (fncd != TFN_TCP_ACP_CEP || (ntohs(tcp->flag) & RST_FLAG))
            break;

        /* Do this here instead of in tcp_rcv_syn so that  */
        /* the values will be filled only after connection */
        /* establishment. 12Aug2004 - A.K                  */
      #ifdef DUAL_STK
        if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
            ntohl6(((T_IP6 *)pkt)->ip6.sa, ((T_IPEP *)(cep->rpar))->ip6addr);
            ((T_IPEP *)(cep->rpar))->type = IPV6_ADDR;
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_UNKNOWN,NULL,0, 0);
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_IPV6, cep->dst6ipa,cep->dstpor, 0);
        }
        else
      #endif
        {
            ((T_IPEP *)(cep->rpar))->ipaddr = ntohl(pkt->ip.sa);
        }

        ((T_IPEP *)(cep->rpar))->portno = ntohs(tcp->sp);

        goto L1;

    case CEP_WAIT_A_OPEN:

        /* dont do this process if valid ACK received already */
        if (!(cep->sflag & SYN_FLAG))
            break;

        if (ntohl(tcp->ack) != cep->seq + 1) {
            cep->sflag = ACK_FLAG|RST_FLAG;
            cep->seq = ntohl(tcp->ack);
            break;
        }

        cep->isn = ++cep->seq;
        cep->win1 = cep->win0 = ntohs(tcp->win);
        cep->sflag &= ~SYN_FLAG;
        if (!(ntohs(tcp->flag) & ACK_FLAG))
            cep->sflag |= RST_FLAG;
        break;

    case CEP_CONNECTING:
        set_seq(cep, ntohl(tcp->ack));

  #ifdef SOCK /* ready to write data */
    size = (W)cep->sbufsz - (W)(cep->sputp - (cep->seq - cep->isn));
    if (size > 0)
        wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif

        fncd = cep->sfncd;
        if (fncd == TFN_TCP_SND_DAT)
            slen = tcp_put_sdat(cep, cep->spar, cep->slen);
        else if (fncd == TFN_TCP_GET_BUF)
            slen = tcp_get_sbuf(cep->spar, cep);
        else
            break;
        if (slen <= 0) /* not enough space in the buffer yet */
            break;

        if (fncd != TFN_TCP_SND_DAT && fncd != TFN_TCP_RCV_DAT  &&
            fncd != TFN_TCP_RCV_BUF && fncd != TFN_TCP_GET_BUF)
            break;

        cep->sfncd = 0;
        if ((id = cep->stskid) != FALSE) {
            cep->stskid = FALSE;
            cep->slen = slen;
            wup_tsk(id);
        } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = slen;
            (func)(cep->cepid, fncd, &parblk);
        }
        break;

    case CEP_TERMINATED:
        set_seq(cep, ntohl(tcp->ack));

        seq_check = ring_sub(cep->sputp, cep->seq - 1 - cep->isn);
        if (seq_check > 0)      /* window buffer not empty */
            break;

        if (cep->sputp - (cep->seq - 1 - cep->isn) == 0) { /* ACK of FIN */
            cep->sflag &= ~FIN_FLAG;
            cep->time = 0;      /* Mod 13Mar2003 */
        }
        break;

    case CEP_CLOSING:
        set_seq(cep, ntohl(tcp->ack));
        fncd = cep->rfncd;
        if (len != 0) {         /* already closed */
            cep->state = CEP_CLOSED;
            goto L1;
        }

        seq_check = ring_sub(cep->sputp, cep->seq - 1 - cep->isn);
        if (seq_check > 0)      /* window buffer not empty */
            break;

        if (cep->sputp - (cep->seq - 1 - cep->isn) == 0) {   /* ACK of FIN */
            cep->sflag &= ~FIN_FLAG;
            cep->time = 0;      /* Mod 13Mar2003 */
        } else {
            break;
        }

        /* modified On Nov 7, 2001 PK */
        if (!(cep->rflag & FIN_FLAG))
            break;

        cep->state = CEP_CLOSED;
        if (fncd != TFN_TCP_CLS_CEP)
            break;
    L1:
        cep->rfncd = 0;
        if ((id = cep->rtskid) != FALSE) {
            cep->rtskid = FALSE;
            wup_tsk(id);
        } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_OK;
            (func)(cep->cepid, fncd, &parblk);
        }
        break;
    }
}

/************************************************/
/* SYN Reception                                */
/************************************************/

void tcp_rcv_syn(T_TCP_PKT *pkt, T_TCP_CEP *cep)
{
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    INT parblk;
    T_TCP_HEADER *tcp;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

    switch (cep->state) {
    case CEP_WAIT_P_OPEN:
        cep->sflag |= SYN_FLAG|ACK_FLAG;
        cep->rflag |= SYN_FLAG;
        cep->risn = ntohl(tcp->seq);
        cep->rseq = ntohl(tcp->seq) + 1;

      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr, cep->portno);
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr, cep->portno, SNMP_INAT_IPV6, cep->dst6ipa, cep->dstpor, 0);
        } else {
            SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno);
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno, SNMP_INAT_IPV4, &cep->dstipa, cep->dstpor, 0);
        }
      #else
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
      #endif
      #ifdef DUAL_STK
        if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
            ntohl6(((T_IP6 *)pkt)->ip6.sa, cep->dst6ipa);
            if (is_ip6_addr_any(cep->ip6addr))
                ntohl6(((T_IP6 *)pkt)->ip6.da, cep->ip6addr);
        } else
      #endif
        {
            cep->dstipa = ntohl(pkt->ip.sa);
        }

        if (cep->nif == NULL) {
            cep->nif = pkt->ctl.nif;
          #ifdef DUAL_STK
            if (cep->type == IPV4_ADDR)
          #endif
                cep->ipaddr = byte4_to_long(cep->nif->ipaddr);

            tcp_cep_set_default_opt(cep, cep->nif);
            cep->retry.rto = cep->tmo.rto_ini;
            cep->ktime     = cep->tmo.ktime_tmo;

            /* check for a bigger mss value */
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR) {
                if (cep->mss > (cep->nif->path_mtu6 - TCP_HEADER_SZ)) {
                    cep->mss = cep->nif->path_mtu6 - TCP_HEADER_SZ;
                    cep->cwnd = cep->mss * 2;
                    cep->smax = cep->cwnd;
                }
            } else
          #endif
            {
                if (cep->mss > (cep->nif->path_mtu - TCP_HEADER_SZ)) {
                    cep->mss = cep->nif->path_mtu - TCP_HEADER_SZ;
                    cep->cwnd = cep->mss * 2;
                    cep->smax = cep->cwnd;
                }
            }

        }
        cep->dstpor = ntohs(tcp->sp);
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, SNMP_INAT_IPV6, cep->ip6addr, cep->portno, SNMP_INAT_IPV6, cep->dst6ipa, cep->dstpor, 0);
        } else {
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno, SNMP_INAT_IPV4, &cep->dstipa, cep->dstpor, 0);
        }
      #else
        SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
      #endif
        break;

    case CEP_WAIT_A_OPEN:
        cep->sflag |= ACK_FLAG;
        cep->rflag |= SYN_FLAG;
        cep->risn = ntohl(tcp->seq);
        cep->rseq = ntohl(tcp->seq) + 1;
        if (cep->sflag & SYN_FLAG)
            break;
        fncd = cep->rfncd;
        if (fncd != TFN_TCP_CON_CEP)
            break;

      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr, cep->portno, SNMP_INAT_UNKNOWN, NULL, 0, 0);
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, SNMP_INAT_IPV6, cep->ip6addr, cep->portno, SNMP_INAT_IPV6, cep->dst6ipa, cep->dstpor, 0);
        } else {
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno, SNMP_INAT_UNKNOWN, NULL, 0, 0);
            SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno, SNMP_INAT_IPV4, &cep->dstipa, cep->dstpor, 0);
        }
      #else
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno, 0, 0);
        SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
      #endif
        cep->state = CEP_CONNECTING;
        cep->rflag &= ~SYN_FLAG;
        cep->rfncd = 0;
        if ((id = cep->rtskid) != FALSE) {
            cep->rtskid = FALSE;
            wup_tsk(id);
        } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_OK;
            (func)(cep->cepid, fncd, &parblk);
        }
        break;

    default:
        cep->sflag |= ACK_FLAG;
        cep->risn = ntohl(tcp->seq);
        cep->rseq = ntohl(tcp->seq) + 1;
        break;
    }
}

/************************************************/
/* Data Reception                               */
/************************************************/

static void tcp_rcv_data(T_TCP_PKT *pkt, T_TCP_CEP *cep)
{
    INT i, len;
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    INT parblk;
    W seq_check;
    T_TCP_HEADER *tcp;
    UB *data;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
        data = ((T_TCP6_PKT *)pkt)->data;
    } else
  #endif
    {
        tcp = &pkt->tcp;
        data = pkt->data;
    }

    if (cep->state != CEP_CONNECTING && cep->state != CEP_TERMINATED) {
        cep->sflag = ACK_FLAG|RST_FLAG;
        return;
    }

    if ((
      #ifdef DUAL_STK
        cep->type == IPV4_ADDR &&
      #endif
        cep->dstipa == 0)
      #ifdef DUAL_STK
        || (cep->type == IPV6_ADDR && is_ip6_addr_any(cep->dst6ipa))
      #endif
        )
        return;

    i = (ntohs(tcp->flag) >> 12) * 4;
  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6)
        len = ntohs(((T_IP6 *)pkt)->ip6.pl) - i;
    else
  #endif
        len = ntohs(pkt->ip.tl) - (IP4_HEADER_SZ + i);

    i -= TCP_HEADER_SZ;

    len = tcp_put_rdat(pkt, cep, data + i, len);
    if (len < 0) {
        /* add  YS-010914-003 */
        cep->rseq = (cep->rputp + (cep->risn + 1));
        cep->sflag |= ACK_FLAG;
        cep->dackflag |= TCP_ACK_OUTD;
        return;
    }

    /* 10Feb2003 - ACK for every second segment */
    if (cep->dackflag & TCP_ACK_DELAY)
        cep->dackflag |= TCP_ACK_NOW;
    else
        cep->dackflag |= TCP_ACK_DELAY;

    cep->rseq = ntohl(tcp->seq) + len;
    cep->sflag |= ACK_FLAG;

    fncd = cep->rfncd;

    seq_check = ring_sub(cep->rputp, cep->rgetp);
    if (seq_check <= 0)
        return;

    if ((id = cep->rtskid) != FALSE) {
        cep->rfncd = 0;
        cep->rtskid = FALSE;
        cep->rlen = len;
        wup_tsk(id);
    } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
        /* When using callback, data copy to user buffer here. */
        if (fncd == TFN_TCP_RCV_DAT)
            len = tcp_get_rdat((UB *)cep->rpar, cep, cep->rlen);
        else if (fncd == TFN_TCP_RCV_BUF)
            len = tcp_get_rbuf((UB **)cep->rpar, cep);
        else
            return;
        if (len != 0) {
            cep->rfncd = 0;
            parblk = len;
            (func)(cep->cepid, fncd, &parblk);
            /* add  YS-010914-001 */
            if (cep->sflag & (FIN_FLAG)) {
                cep->state = CEP_CLOSING;
                cep->rfncd = TFN_TCP_CLS_CEP;
            }
        }
    }
}

/************************************************/
/* FIN Reception                                */
/************************************************/

void tcp_rcv_fin(T_TCP_PKT *pkt, T_TCP_CEP *cep, INT len)
{
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    INT parblk;
    W pos;
    W seq_check;
    T_TCP_HEADER *tcp;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

  #ifdef SOCK   /* check for read or write half close */
    wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif

    /* 26Jan2003 AK - ignore invalid FIN */
    if (cep->state == CEP_WAIT_A_OPEN)
        return;

    /* modified on Nov 7, 2001 PK */
    if ((cep->rflag & FIN_FLAG) == FIN_FLAG)
        return;

    if ((
      #ifdef DUAL_STK
        cep->type == IPV4_ADDR &&
      #endif
        cep->dstipa == 0)
      #ifdef DUAL_STK
        || (cep->type == IPV6_ADDR && is_ip6_addr_any(cep->dst6ipa))
      #endif
        ) {
        cep->sflag = ACK_FLAG|RST_FLAG;
        return;
    }

    pos = ntohl(tcp->seq) - (cep->risn + 1) + len;
    if ((UW)pos != cep->rputp) {
        /* send ack for FIN with invalid seq (data miss) */
        cep->sflag |= ACK_FLAG;
        return;
    }

    switch (cep->state) {
    case CEP_CONNECTING:
    case CEP_TERMINATED:
        cep->rflag |= FIN_FLAG;
        cep->sflag |= ACK_FLAG;
        cep->rseq = pos + cep->risn + 2;

        seq_check = ring_sub(cep->rputp, cep->rgetp);
        if (seq_check > 0)   /* window buffer not empty */
            break;
        fncd = cep->rfncd;
        if (fncd == TFN_TCP_RCV_DAT || fncd == TFN_TCP_RCV_BUF)
            goto L1;
        break;

    case CEP_CLOSING:
        cep->rflag |= FIN_FLAG;
        cep->sflag |= ACK_FLAG;
        cep->rseq = pos + cep->risn + 2;
        if (cep->sflag & FIN_FLAG)  /* not received ACK of FIN yet */
            break;
        cep->state = CEP_CLOSED;
        fncd = cep->rfncd;
        if (fncd != TFN_TCP_CLS_CEP)
            break;
    L1:
        cep->rfncd = 0;
        if ((id = cep->rtskid) != FALSE) {
            cep->rtskid = FALSE;
            cep->rlen = 0;
            wup_tsk(id);
        } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = 0;
            (func)(cep->cepid, fncd, &parblk);
        }
        break;

    default:
        cep->sflag = ACK_FLAG|RST_FLAG;
        break;
    }
}

/************************************************/
/* RST Reception                                */
/************************************************/

void tcp_rcv_rst(T_TCP_CEP *cep)
{
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    FN rfncd;
    FN sfncd;
    INT parblk;

    if ((
      #ifdef DUAL_STK
        cep->type == IPV4_ADDR &&
      #endif
        cep->dstipa == 0)
      #ifdef DUAL_STK
        || (cep->type == IPV6_ADDR && is_ip6_addr_any(cep->dst6ipa))
      #endif
        )
        return;

  #ifdef SOCK /* check for read or write half close */
    wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif

    switch (cep->state) {
    case CEP_WAIT_P_OPEN:
        cep->state = CEP_CLOSED;
        cep->rflag = RST_FLAG; /* 04Jan2005 Added */
        cep->sflag = 0;
        fncd = cep->rfncd;
        if (fncd != TFN_TCP_ACP_CEP)
            break;
        goto L1;

    case CEP_WAIT_A_OPEN:
        cep->state = CEP_CLOSED;
        cep->rflag = RST_FLAG; /* 04Jan2005 Added */
        cep->sflag = 0;
        fncd = cep->rfncd;
        if (fncd != TFN_TCP_CON_CEP)
            break;
    L1:
        if ((id = cep->dcls_id) > 0) {       /* if pending send of FIN */
            cep->dcls_id = 0;
            wup_tsk(id);
        }

        /* 24Dec2004 modified to wakeup all waiting processes */

        if ((cep->rfncd != 0) && ((id = cep->rtskid) != FALSE)) {
            cep->rtskid = FALSE;
            wup_tsk(id);
        }

        if ((cep->sfncd != 0) && ((id = cep->stskid) != FALSE)) {
            cep->stskid = FALSE;
            wup_tsk(id);
        }

        rfncd = cep->rfncd;
        sfncd = cep->sfncd;
        cep->rfncd = cep->sfncd = 0;

        while (((fncd = rfncd) != 0) || ((fncd = sfncd) != 0)) {
            if (fncd != TFN_TCP_SND_DAT && fncd != TFN_TCP_RCV_DAT  &&
                fncd != TFN_TCP_RCV_BUF && fncd != TFN_TCP_GET_BUF  &&
                fncd != TFN_TCP_CLS_CEP && fncd != TFN_TCP_CON_CEP  &&
                fncd != TFN_TCP_ACP_CEP)
                break;

            else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
                parblk = E_CLS;
                (func)(cep->cepid, fncd, &parblk);
            }
            if (fncd == rfncd) rfncd = 0;
            if (fncd == sfncd) sfncd = 0;
        }

        break;

    case CEP_CLOSING:
        cep->sflag = 0;
        cep->rlen = E_CLS; /* 04Jan2005 ERR valud for tcp_cls_cep */
        /* 03/09/2002 A.K. - change State */
        cep->state = CEP_CLOSED;
        SNMP_BYPCNT(snmp_mibbyp.tcpEstabResets, 1);  /* tcpEstabResets */
        goto L1;

    default:
        cep->state = CEP_DISCONNECTED;

        /* 04Jan2005 invoke callback function */
        if (cep->dcls_id == -1 && cep->rfncd == 0) {
            cep->rfncd = TFN_TCP_CLS_CEP;
            cep->state = CEP_CLOSED;
        }

        cep->rflag = RST_FLAG;
        cep->sflag = 0;
        cep->rlen = E_CLS;
        cep->slen = E_CLS; /* 04Jan2005 ERR valud for tcp_snd_dat */
        cep->time = 0;
        if (cep->ackpkt != NULL) {
            rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
            cep->ackpkt = NULL;
        }
        goto L1;
    }
}

/************************************************/
/* Flow Control Sub Routine                     */
/************************************************/

BOOL tcp_flw_ctl(T_TCP_CEP *cep)
{
    BOOL ret=FALSE;
    UW cwnd, oldsgetp;
    W seq_check;
    UB  dack_cnt;

    /* if cep->seq >= cep->retry.rseq */
    seq_check = ring_sub(cep->seq, cep->retry.rseq);
    if (seq_check >= 0) {
        cep->retry.on = 0;
    }

    /* mod YS-010914-002 */
    if ((cep->sflag & FIN_FLAG) || cep->state == CEP_TERMINATED
         || cep->state == CEP_CLOSING) {
        if (cep->sputp == (cep->seq - cep->isn - 1))  {
            cep->time = 0;
            cep->retry.retries = 0;
        }
    } else if ((cep->sgetp - (cep->seq - cep->isn)) == 0) {
        if ((!cep->hseq) && (!cep->dackmd)) {
            cep->time = 0;
            cep->retry.retries = 0;
        }
    }

    if (cep->state == CEP_CONNECTING) {
        /* window update ACK */
        if (cep->seq1 == cep->seq && cep->win != cep->win1 &&
            cep->sgetp != 0 && cep->win != 0) {
            cep->win1 = cep->win;
            return TRUE;
        }

        /* Mod 13Mar2003 - new reno implementation to process */
        /*                  duplicate ACK                     */
        if (cep->seq1 == cep->seq && cep->win == cep->win1 &&
            cep->sgetp != 0 && cep->win != 0 && cep->rputp == cep->rgetp) {

            if (cep->time != 0)
                cep->dackcnt++;

            /* AK 24MAR2006 - configurable duplicate ACK count */
            if (cep->nif != NULL)
                dack_cnt = (UB)cep->nif->tcp.dup_ack;
            else
                dack_cnt = (UB)TCP_DUP_ACK;

            if (cep->dackcnt < dack_cnt) {
                return TRUE;
            } else if (cep->dackcnt == dack_cnt) {

                 /* dont fast retransmit if already retransmitted */

                seq_check = ring_sub(cep->seq, cep->hsqn);
                if (cep->hseq && seq_check <= 0)
                    return -1;

                cep->hseq = TRUE;
                cep->hsqn = cep->mseq;
                cep->sgetpf = cep->sgetp;
                cep->dackmd = TRUE;
                /* ssth = MAX(FlightSize/2, 2*MSS) */
                cwnd = (UW)((cep->isn + cep->sgetp) - cep->seq1);
                cwnd = cwnd >> 1;
                cwnd = (cwnd / cep->mss) * cep->mss;
                cep->ssth = MAX(cwnd, cep->mss + cep->mss);
                cep->cwnd = cep->ssth + 3 * cep->mss;
                cep->sgetp = cep->seq - cep->isn;
                cep->sgeti = cep->seqi;

                /* restart retransmission timer */
                if ((cep->time = SYSCK.ltime) == 0)
                    cep->time = 1;
                return TRUE;

            } else {    /* fast recovery */
                cep->cwnd += cep->mss;
                return -1; /* ignore other duplicate ACK */
            }
        } else if (cep->dackmd) {
            /* receive ACK of retransmit packet */

            cep->sgetp = cep->seq - cep->isn;
            cep->sgeti = cep->seqi;

            seq_check = ring_sub(cep->sgetp, cep->sgetpf);
            if (seq_check >= 0) {
                cep->dackmd = FALSE; /* ends fast recovery */
                cep->hseq = FALSE;
                if (cep->dackcnt > 3 && (cep->cwnd > cep->ssth))
                    cep->cwnd = cep->ssth;
                cep->dackcnt = 0;
            } else {
                cep->hseq = FALSE;
                cwnd = (UW)((cep->isn + cep->sgetpf) - cep->seq);
                cwnd = (cwnd / cep->mss) * cep->mss;
                if (cwnd != 0)
                    cep->cwnd = MIN(cwnd, cep->mss + cep->mss);
                ret = TRUE;
            }
        } else {  /* Normal ACK */

            cep->dackcnt = 0;
            /* reset sgetp after retransmission */
            if (cep->hseq) {
                oldsgetp = cep->seq - cep->isn;
                if (oldsgetp > cep->sgetp) {
                    cep->sgetp = oldsgetp;
                    cep->sgeti = cep->seqi;
                }
                ret = TRUE;
            }

            /* 4Mar2003 - Change updation of cwnd */
            if (cep->cwnd < cep->ssth) {
                /* slow start */
                seq_check = ring_sub(cep->seq, cep->seq1);
                if (cep->seq != cep->seq1 && seq_check > 0)
                    cep->cwnd += (UW)(cep->seq - cep->seq1);
            } else {
                /* avoid congestion cwnd += 2*MSS/cwnd */
                cwnd = cep->mss * cep->mss;
                if (cep->cwnd > cwnd)
                    cep->cwnd += (cwnd / cep->cwnd);
                cwnd = cep->mss * cep->mss;
                cep->cwnd += (cwnd / cep->cwnd);
            }
        }
    }
    if (cep->cwnd > 0xFFFF)
        cep->cwnd = 0xFFFF;
    cep->seq1 = cep->seq;
    cep->win1 = cep->win;
    return ret;
}

/************************************************/
/* Confirms it can be delay ACK                 */
/************************************************/

BOOL can_ack_delay(W size, T_TCP_CEP *cep, T_TCP_PKT *pkt)
{
    T_TCP_HEADER *tcp;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

    if (!IS_USED(cep->state))  /* added this by 2008/03/12 [OK] */
        return FALSE;

    if (size != 0)
        return FALSE;
    if ((ntohs(tcp->flag) & 0x3F) != ACK_FLAG)
        return FALSE;
    if ((cep->rflag & (FIN_FLAG|SYN_FLAG)) != 0)
        return FALSE;
    if ((cep->sflag & (FIN_FLAG|SYN_FLAG)) != 0)
        return FALSE;
    if (cep->sgetp == 0 && cep->sputp == 0 && cep->rgetp == 0 && cep->rputp == 0)
        return FALSE;
    if (cep->win == 0)
        return FALSE;
    if (cep->dackflag & TCP_ACK_OUTD) {
        cep->dackflag &= ~TCP_ACK_OUTD;
        return FALSE;
    }
    return TRUE;
}

/************************************************/
/* Validation of incoming TCP packets           */
/************************************************/

static ER validate_tcp_rpkt(T_TCP_CEP *cep, T_TCP_PKT *pkt, int len, int *flag1)
{
    UW ack, seq;
    int flag;
    ER ercd;
    UH win;
    B check;
    W seq_check;
    T_NIF *nif;
    T_TCP_HEADER *tcp;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
    else
  #endif
        tcp = &pkt->tcp;

    ack = seq = 0;
    check = 0;
    flag = ntohs(tcp->flag) & 0x3f;
    nif = cep->nif;

    switch (cep->state) {
    case CEP_WAIT_P_OPEN:
        /* if SYN already received */
        if (cep->risn != 0 || (cep->rflag & SYN_FLAG))
            goto TCPSEQVALID;

        /* waiting for SYN */
        if (flag & RST_FLAG)
            return -1;

        /* if ACK is set then send a RST */
        if (flag & ACK_FLAG) {
            check = 1;
            if (nif == NULL)
                nif = pkt->ctl.nif;
            goto TCPSEQERR;
        }

        /* SYN received ? */
        if (flag & SYN_FLAG) {

            /* dont process other Flags */

            *flag1 = SYN_FLAG;

            /* first SYN, so ack value should be zero */

            tcp->ack = 0;

            break;
        }

        /* ignore all other segments */
        return -1;

    case CEP_WAIT_A_OPEN:

        /* SYN received ? */
        if ((cep->rflag & SYN_FLAG))
            goto TCPSEQVALID;

        /* waiting for SYN/ACK */
        if (flag & ACK_FLAG) {

            /* ignore and send RST if ack value is invalid */
            if (ntohl(tcp->ack) != cep->seq + 1) {
                check = 1;
                goto TCPSEQERR;
            }

            /* accept RST */
            if (flag & RST_FLAG)
                return 1;

            /* ignore packets other than SYN */
            if (!(flag & SYN_FLAG))
                return -1;
        }

        /* ignore any RST without ACK flag set */
        if (flag & RST_FLAG)
            return -1;

        /* accept SYN segment */
        if (flag & SYN_FLAG)
            return 1;

        /* ignore all other segments */
        return -1;

    default:
TCPSEQVALID:
        /* check for sequence validation */
        win  = (UH)(cep->rbufsz - (cep->rputp - cep->rgetp));
        seq = ntohl(tcp->seq);

        if (cep->rseq == seq + 1) {
            tcp_cep_ktime_init(cep);
            tcp_timeout_update(cep);
        }

        if (tcp_seq_valid(cep, seq, len, win) == FALSE) {
            if (flag & RST_FLAG) {
                if (cep->rflag & FIN_FLAG && seq == cep->rseq - 1)
                    break;
            }
            goto TCPSEQERR;
        }

        /* accept RST segments */
        if (flag & RST_FLAG)
            break;

        if (flag & SYN_FLAG) {
            /* If in SYN_RECEIVED state then close connection and
            move to LISTEN state or to CLOSED state */

            /* receiving SYN is invalid so send RST */
            check = 1;
            goto TCPSEQERR;
        }

        /* if ACK is not set then ignore the segment */
        if (!(flag & ACK_FLAG))
            return -1;

        ack = ntohl(tcp->ack);

        seq_check = ring_sub(ack, cep->seq);
        if (seq_check > 0) {
            seq_check = ring_sub(ack, cep->mseq);
            if (seq_check <= 0)
                break;
        }

        seq_check = ring_sub(ack, cep->seq);
        if (cep->state == CEP_WAIT_A_OPEN || cep->state == CEP_WAIT_P_OPEN)
            check = 1;
        else if (seq_check <= 0)    /* duplicate ACK */
            break;
        else
            return -1;              /* ignore pkt */

TCPSEQERR:
        /* Invalid pkt received */
        if (flag & RST_FLAG)
            return -1;              /* Ignore invalid RST pkt */

        if (check == 0)
            make_tcp_ack_pkt(pkt, cep);
        else
            make_tcp_rst_pkt1(pkt, cep);

        pkt->ctl.hedflg = FALSE;
        SNMP_BYPCNT(snmp_mibbyp.tcpOutSegs, 1);      /* tcpOutSegs */
      #ifdef DUAL_STK
        SNMP_BYPCNT64(snmp_mibbyp.tcpHCOutSegs, 1);  /* tcpHCOutSegs */
      #endif
        ercd = snd_mbx(nif->smbxid, pkt);
        if (ercd != E_OK) {
            tcp_internal_error(ercd);
            return -1;
        }
        if (cep->ackpkt != NULL) {
            ercd = rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
            cep->ackpkt = NULL;
            tcp_timeout_update(cep);
        }
        return 0;
    }

    return 1;
}

/************************************************/
/* TCP Reception Process                        */
/************************************************/

VP tcp_reception(T_TCP_PKT *pkt)
{
    T_TCP_CEP *cep;
    int flag, len, i;
    BOOL n=FALSE;
    ER ercd=E_OK;
    T_NIF *nif = pkt->ctl.nif;
    UW rtime, _ack, _seq;
    W size;
    W seq_check;
    UW _win;
    T_TCP_HEADER *tcp;
    UB *data;
    UW tsecr;
    UW rmtu;
    ID id;

    _ack = _seq = 0;

    SNMP_BYPCNT(snmp_mibbyp.tcpInSegs, 1);  /* tcpInSegs */

  #ifdef DUAL_STK
    SNMP_BYPCNT64(snmp_mibbyp.tcpHCInSegs, 1); /* tcpHCInSegs */
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        tcp = &((T_TCP6_PKT *)pkt)->tcp;
        data = ((T_TCP6_PKT *)pkt)->data;
        cep = search_tcp_cep6(nif, ((T_IP6 *)pkt)->ip6.da, ntohs(tcp->dp),
                ((T_IP6 *)pkt)->ip6.sa, ntohs(tcp->sp));
        len = ntohs(((T_IP6 *)pkt)->ip6.pl) - TCP_HEADER_SZ;
    } else
  #endif
    {
        tcp = &pkt->tcp;
        data = pkt->data;
        if (!(*nif->func)(nif, TFN_NET_RED_PKT, tcp, TCP_HEADER_SZ)) {
            SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
            return pkt;
        }

        len = (int)ntohs(pkt->ip.tl) - (IP4_HEADER_SZ + TCP_HEADER_SZ);

        cep = search_tcp_cep(ntohl(pkt->ip.da), ntohs(tcp->dp),
              ntohl(pkt->ip.sa), ntohs(tcp->sp));
    }

    if (cep == NULL || cep->state == CEP_DISCONNECTED) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        if (ntohs(tcp->flag) & RST_FLAG)
            return pkt;
        make_tcp_rst_pkt1(pkt, cep);
        pkt->ctl.hedflg = FALSE;
        ercd = snd_mbx(nif->smbxid, pkt);
        if (ercd != E_OK) {
            tcp_internal_error(ercd);
            return pkt;
        }
        return NULL;
    }

    flag = ntohs(tcp->flag) & 0x3f;

    i = (ntohs(tcp->flag) >> 12) * 4 - TCP_HEADER_SZ;

  #ifdef DUAL_STK
    if (ntohs(pkt->eth.etype) == ETYPE_IP6) {
        if (i < 0) {
            SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
            return pkt;
        }

        rmtu = nif->path_mtu6 - TCP_HEADER_SZ;
        if (cep->umtu != 0 && cep->umtu < rmtu)
            rmtu = cep->umtu;
        if (len < i || len > rmtu) {
            SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
            return pkt;
        }
    } else
  #endif
    {
        if (i < 0) {
            (*nif->func)(nif, TFN_NET_IGN_PKT);
            SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
            return pkt;
        }

        rmtu = nif->path_mtu - TCP_HEADER_SZ;
        if (cep->umtu != 0 && cep->umtu < rmtu)
            rmtu = cep->umtu;
        if (len  < i || len > (int)rmtu) {
            (*nif->func)(nif, TFN_NET_IGN_PKT);
            SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
            return pkt;
        }

        if (nif->type == NI_ETH || nif->type == NI_LOOP || nif->type == NI_PPPOE ||
            (nif->type == NI_PPP && len != 0)) {
            if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, data, len, (int)(nif->path_mtu - TCP_HEADER_SZ))) {
                SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
                return pkt;
            }
        }
    }

    if (tcp_checksum(pkt) != 0) {
        SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
        tcp_internal_error(ercd);
        return pkt;
    }

    tsecr = cep->tsecr;
    len -= i;
    while (i > 0) {
        switch (data[0]) {
        case 0:     /* finish */
            i = 0;
            break;
        case 1:     /* no operation */
            i--;
            data++;
            break;
        case 2:     /* MSS option */
            if (data[1] < 2 || data[1] > i) {
                SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
                return pkt;
            }
            i -= data[1];
            if ((flag & SYN_FLAG) && data[1] == 4) {    /* check for MSS option */
                cep->mss = ((data[2] << 8) | data[3]);
                if (cep->mss > rmtu)
                    cep->mss = rmtu;
              #ifdef DUAL_STK
                if (ntohs(pkt->eth.etype) == ETYPE_IP6)
                    cep->cwnd = NIF_MTU_MIN - IP6_HEADER_SZ - TCP_HEADER_SZ;
                else
              #endif
                    cep->cwnd = NIF_MTU_MIN - IP4_HEADER_SZ - TCP_HEADER_SZ;
                if (cep->mss < cep->cwnd)
                    cep->mss = cep->cwnd;   /* min MSS */
                cep->cwnd = cep->mss * 2;   /* init cwnd, ssth value */
                cep->smax = cep->cwnd;
            }
            data += data[1];
            break;
        case 8:     /* time stamp */
            if (data[1] < 2 || data[1] > i) {
                SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
                return pkt;
            }
            i -= data[1];
            if (data[1] == 10) {        /* check for time stamp option */
                cep->tsopt |= TSOPT_ENABLE;
                tsecr = ((UW)ntohs(*(UH *)(data + 2)) << 16) | ((UW)ntohs(*(UH *)(data + 4)));
            }
            data += data[1];
            break;
        default:    /* no support option */
            if (data[1] < 2 || data[1] > i) {
                SNMP_BYPCNT(snmp_mibbyp.tcpInErrs, 1);  /* tcpInErrs */
                return pkt;
            }
            i -= data[1];
            data += data[1];
            break;
        }
    }

    if (flag & SYN_FLAG)
        len = 0;    /* ignore data of SYN segment */

    /* discard if not a valid pkt */
    ercd = validate_tcp_rpkt(cep, pkt, len, &flag);
    if (ercd == -1)
        return pkt;
    if (ercd == 0)
        return NULL;

    _seq = ntohl(tcp->ack);

    /* Measure the RTT value and calculate new RTO for */
    /* an ACK of non retransmitted TCP segment         */
    if (cep->retry.retries == 0L && cep->dackmd == FALSE && !cep->hseq) {
        if (cep->retry.stat & TCP_RET_SEQ_VALID) {
            seq_check = ring_sub(_seq, cep->retry.seq);
            if (seq_check > 0 && (cep->retry.stat & TCP_RET_ON)) {
                rtime = (UW)(SYSCK.ltime - cep->retry.rtime);
                tcp_rtt_cal(nif, cep, rtime);
                if (cep->state == CEP_WAIT_P_OPEN || cep->state == CEP_WAIT_A_OPEN) {
                    if (cep->retry.rto < cep->tmo.rto_ini)
                        cep->retry.rto = cep->tmo.rto_ini;
                }
                cep->retry.stat &= ~(TCP_RET_ON|TCP_RET_SEQ_VALID);
            }
        }
    } else {
        /* ACK after retransmission */
        cep->retry.stat &= ~(TCP_RET_ON|TCP_RET_SEQ_VALID);
    }

    /* 26Jan2003- Ignore data if FIN already recv */
    if (cep->rflag & FIN_FLAG)
        len = 0;

    tcp_cep_ktime_init(cep);
    cep->win = ntohs(tcp->win);

    /* discard ACK of zero window probe */
    if (cep->win == 0 && flag == ACK_FLAG && len == 0) {
        /* ACK of zero window probe is enable if FIN already sent */
        if (cep->sflag & FIN_FLAG) {
            cep->retry.flag = 0;
        } else {
            /* Don't send a packet to probe a zero window until the window
               size is updated. */
            if ((cep->win1 != 0) && (cep->sputp != cep->sgetp)) {
                cep->dackflag |= TCP_ZERO_PROBE;
                cep->sflag |= ACK_FLAG;
            }
       }
    }
    else {
        cep->retry.flag = 0;
    }

    if (flag & ACK_FLAG)
        tcp_rcv_ack(pkt, cep, len);
    if (flag & SYN_FLAG)
        tcp_rcv_syn(pkt, cep);
    if (len != 0)
        tcp_rcv_data(pkt, cep);
    if (flag & FIN_FLAG)
        tcp_rcv_fin(pkt, cep, len);
    if (flag & RST_FLAG)
        tcp_rcv_rst(cep);

    if (cep->sputp == (cep->seq - cep->isn)) {
        if ((id = cep->dcls_id) > 0) {          /* not TMO_NBLK */
            cep->dcls_id = 0;
            wup_tsk(id);
        } else if (id == -1) {                  /* Modified on Nov 27, 2001 */
            if (cep->state != CEP_CLOSED)
                cep->state = CEP_CLOSING;
            cep->rfncd = TFN_TCP_CLS_CEP;
        }
    }

    if ((cep->tsopt & TSOPT_ENABLE) && cep->ackpkt == NULL &&
        !(cep->dackflag & TCP_ACK_OUTD))
        cep->tsecr = tsecr;

    if (flag & ACK_FLAG) {
        n = tcp_flw_ctl(cep);
        seq_check = ring_sub(cep->seq1, cep->hsqn);
        if (cep->hseq && seq_check >= 0) {
            cep->hseq = FALSE;
            cep->time = 0;
            cep->retry.retries = 0;
            cep->retry.stat &= ~TCP_RET_ON;
        }
        if (n == -1)
            goto END;
    }

    if ((
      #ifdef DUAL_STK
        cep->type == IPV4_ADDR &&
      #endif
        cep->dstipa == 0)
      #ifdef DUAL_STK
        || (cep->type == IPV6_ADDR && is_ip6_addr_any(cep->dst6ipa))
      #endif
        )
        if (!(cep->sflag & RST_FLAG))
            goto END;

    _win = ntohs(tcp->win);
    _ack = ntohl(tcp->ack);
    _seq = (cep->isn + cep->sgetp);
    if (_ack != 0 && _win != 0 && _seq != 0)
        _win = _win - (UH)(_seq - _ack);
    cep->win = (UH)_win;

    /* dont send new segments during fast recovery */
    if (cep->hseq || cep->dackmd == TRUE) {
        /* It allows to send only one segment during FR phase */
        /* That segment size will be the min of MSS size and remaining data */
        /* This code also prevents transmission of data from other place like
           tcp_transmit_sub etc., Until FR ends data should be tx from this
           function only */
        _win = MIN(_win,  (cep->sputp -  cep->sgetp));
        cep->smax = MIN(_win, cep->mss); /* Set to 1 packet */
        if (cep->smax == 0) {
            cep->smax = cep->mss;
        }
    } else {
        _win = cep->cwnd;
        _win = (cep->cwnd / cep->mss) * cep->mss;
        cep->smax = MIN(_win, cep->win);
    }

    for (;;) {
        if ((size = make_tcp_pkt(pkt, cep, FALSE)) <= -1)
            break;
        if (can_ack_delay(size, cep, pkt)) {
            /* release if any pending ACK packet */
            if (cep->ackpkt != NULL)
                ercd = rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
            cep->ackpkt = pkt; /* store this pkt to send after TCP_DACK_TMO */
            cep->dtime = SYSCK.ltime + nif->tcp.dack_tmo;
            pkt = NULL;
            break;
        }
        /* set timer only if it already not set because prev
           transmission may be using this value */
        if (cep->retry.on == 0 && cep->retry.ref == 1) {
            if ((cep->time = SYSCK.ltime) == 0)
                cep->time = 1;
            cep->retry.on  = 1;
            cep->retry.rseq = cep->seq + 1; /* will be used when rx ACK */
        }
        cep->retry.ref = 0;

        if (cep->ackpkt != NULL) {
            ercd = rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
            cep->ackpkt = NULL;
        }

        /* initialize the retransmission variables */
        /* retry count for SYN should be 3         */
        /* retry count for DATA should be 12       */
        cep->retry.retries = 0;
        if (cep->state == CEP_WAIT_P_OPEN || cep->state == CEP_WAIT_A_OPEN)
            cep->retry.retry_cnt = cep->tmo.syn_rcnt;
        else
            cep->retry.retry_cnt = cep->tmo.dat_rcnt;

        /* dont try retransmit ACK segments */
        if ((cep->retry.flag == ACK_FLAG)
         && ((cep->sgetp - (cep->seq - cep->isn)) == 0)) {
            if (cep->sputp == cep->sgetp) {
                cep->time = 0;
                cep->retry.retries = 0;
            }
            cep->retry.stat &= ~TCP_RET_ON;
            cep->retry.on = 0;
        } else {    /* set rtt timer */
            if (((cep->retry.flag & PSH_FLAG) || (cep->retry.flag & SYN_FLAG)) &&
                (cep->retry.stat & TCP_RET_ON) == 0 && !cep->hseq) {
                cep->retry.seq = ntohl(tcp->seq);
                cep->retry.stat |= (TCP_RET_ON|TCP_RET_SEQ_VALID);
                cep->retry.rtime = cep->time;
            }
        }

        SNMP_BYPCNT(snmp_mibbyp.tcpOutSegs, 1);         /* tcpOutSegs */
      #ifdef DUAL_STK
        SNMP_BYPCNT64(snmp_mibbyp.tcpHCOutSegs, 1);     /* tcpHCOutSegs */
      #endif
        ercd = snd_mbx(nif->smbxid, pkt);
        if (ercd != E_OK) {
            tcp_internal_error(ercd);
            break;
        }

        /* Added AK - Initialize keep-alive timer whenever */
        /*             a packet to be transmitted.         */
        tcp_cep_ktime_init(cep);

        pkt = NULL;
        if (size <= 0 || n == TRUE)
            break;
        ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
        if (ercd != E_OK)
            break;
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            tcp = &((T_TCP6_PKT *)pkt)->tcp;
        else
      #endif
            tcp = &pkt->tcp;
        memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
        pkt->ctl.mpfid = (ID)ID_ETH_MPF;
        pkt->ctl.cep = cep;
        pkt->ctl.nif = cep->nif; /* 11Jan2005 TCP_EXT */
        tcp->flag = 0;
    }

END:
    if (cep->state == CEP_CLOSED)
        tcp_cep_unused(cep);
    else
        tcp_timeout_update(cep);
    return pkt;
}

/************************************************/
/* TCP Transmition Process                      */
/************************************************/

static void tcp_transmit_sub(T_TCP_CEP *cep, BOOL retry)
{
    T_TCP_PKT *pkt;
    ER ercd;
    W size;
    T_TCP_HEADER *tcp;

    for (;;) {
        ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
        if (ercd != E_OK) {
            cep->qlack = TRUE;
            ip_miscflag |= ETH_QLACK;
            return;
        }

      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            tcp = &((T_TCP6_PKT *)pkt)->tcp;
        else
      #endif
            tcp = &pkt->tcp;

        memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
        pkt->ctl.mpfid = (ID)ID_ETH_MPF;
        pkt->ctl.cep = cep;
        tcp->flag = 0;
        pkt->ctl.nif = cep->nif;
        cep->retry.ref = 0;

        /* Added AK - send keep-alive probe whenever */
        /*            Keep-alive timeout occurs.     */
        if (cep->ktime > cep->tmo.ktime_tmo) {
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR) {
                pkt->eth.etype = htons(ETYPE_IP6);
                ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
                htonl6(cep->dst6ipa, ((T_IP6 *)pkt)->ip6.da);
                htonl6(cep->ip6addr, ((T_IP6 *)pkt)->ip6.sa);
                ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ));

                /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
                ((T_IP6 *) pkt)->ip6.hlim = 0;
            } else
          #endif
            {
                pkt->eth.etype = htons(ETYPE_IP4);
                pkt->ip.prot = PROT_TCP;
                pkt->ip.da = htonl(cep->dstipa);
                pkt->ip.sa = htonl(cep->ipaddr);
                pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ));
                pkt->ip.tos = cep->tos;
                pkt->ip.ttl = cep->ttl;
            }

            tcp->sp = htons(cep->portno);
            tcp->dp = htons(cep->dstpor);
            tcp->seq = htonl(cep->isn + cep->sgetp - 1); /* seq for keep-alive probe */
            tcp->ack = htonl(cep->rseq);
            tcp->flag = htons((UH)(((sizeof (T_TCP_HEADER) / 4) << 12) | (ACK_FLAG)));
            tcp->win = rwin_size(cep);
            tcp->win = htons(tcp->win);
            tcp->urgp = 0;
            tcp->cs = 0;
            tcp->cs = tcp_checksum(pkt);
            size = 0;
            cep->retry.ref = 1;
            cep->retry.flag = ACK_FLAG;
            memset(pkt->eth.da, 0, 6);
        } else if (cep->sflag & RST_FLAG) { /* Add 2002/02/18 */
            /* send RST */
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR) {
                pkt->eth.etype = htons(ETYPE_IP6);
                ((T_IP6 *)pkt)->ip6.nxt = PROT_TCP;
                htonl6(cep->dst6ipa, ((T_IP6 *)pkt)->ip6.da);
                htonl6(cep->ip6addr, ((T_IP6 *)pkt)->ip6.sa);
                ((T_IP6 *)pkt)->ip6.pl = htons((UH)(TCP_HEADER_SZ));
                /* set hop limit to zero. `ip_set_hdr6` will initialize with default hop limit */
                ((T_IP6 *) pkt)->ip6.hlim = 0;
            } else
          #endif
            {
                pkt->eth.etype = htons(ETYPE_IP4);
                pkt->ip.prot = PROT_TCP;
                pkt->ip.da = htonl(cep->dstipa);
                pkt->ip.sa = htonl(cep->ipaddr);
                pkt->ip.tl = htons((UH)(IP4_HEADER_SZ + TCP_HEADER_SZ));
                pkt->ip.tos = cep->tos;
                pkt->ip.ttl = cep->ttl;
            }

            tcp->sp = htons(cep->portno);
            tcp->dp = htons(cep->dstpor);
            tcp->seq = htonl(cep->isn + cep->sgetp);
            tcp->ack = htonl(cep->rseq);
            tcp->flag = htons((UH)(((sizeof (T_TCP_HEADER) / 4) << 12) | (ACK_FLAG|RST_FLAG)));
            tcp->win = 0;
            tcp->urgp = 0;
            tcp->cs = 0;
            tcp->cs = tcp_checksum(pkt);
            memset(pkt->eth.da, 0, 6);
            cep->sflag &= ~(ACK_FLAG|RST_FLAG);
            size = 0;
            SNMP_BYPCNT(snmp_mibbyp.tcpOutRsts, 1);  /* tcpOutRsts */
        } else {
            if ((size = make_tcp_pkt(pkt, cep, retry)) <= -1) {
                rel_mpf(ID_ETH_MPF, pkt);
                if ((cep->seq - cep->isn) == cep->sgetp) {
                    if ((!cep->hseq) && (!cep->dackmd)) {
                        if (cep->win1 > (cep->mss))
                            cep->time = 0;
                    }
                }
                tcp_timeout_update(cep);
                return;
            }
        }
        /* Initialize the retransmission variables */
        /* retry count for SYN should be 3         */
        /* retry count for DATA should be 12       */
        if (!retry) {
            cep->retry.retries = 0;
            if (cep->state == CEP_WAIT_P_OPEN || cep->state == CEP_WAIT_A_OPEN)
                cep->retry.retry_cnt = cep->tmo.syn_rcnt;
            else
                cep->retry.retry_cnt = cep->tmo.dat_rcnt;
        }

        /* set RET timer */
        if (retry || (cep->retry.on == 0 && cep->retry.ref == 1)) {
            if ((cep->time = SYSCK.ltime) == 0)
                cep->time = 1;
            cep->retry.on  = 1;
            cep->retry.rseq = cep->seq + 1; /* will be used when rx ACK */
        }

        /* dont try retransmit ACK segments */
        if ((cep->retry.flag == ACK_FLAG)
         && ((cep->sgetp - (cep->seq - cep->isn)) == 0)) {
            if (cep->sputp == cep->sgetp) {
                cep->time = 0;
                cep->retry.retries = 0;
            }
            cep->retry.stat &= ~TCP_RET_ON;
            cep->retry.on = 0;
        } else {    /* set rtt timer */
            if (((cep->retry.flag & PSH_FLAG) || (cep->retry.flag & SYN_FLAG)) &&
                (cep->retry.stat & TCP_RET_ON) == 0 && !cep->hseq) {
                cep->retry.seq = ntohl(tcp->seq);
                cep->retry.stat |= (TCP_RET_ON|TCP_RET_SEQ_VALID);
                cep->retry.rtime = cep->time;
            }
        }

        /* 5Mar2003 - Clear existing delayed pkt */
        if (cep->ackpkt != NULL) {
            ercd = rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
            cep->ackpkt = NULL;
        }

        SNMP_BYPCNT(snmp_mibbyp.tcpOutSegs, 1);     /* tcpOutSegs */
      #ifdef DUAL_STK
        SNMP_BYPCNT64(snmp_mibbyp.tcpHCOutSegs, 1); /* tcpHCOutSegs */
      #endif
        pkt->ctl.hedflg = FALSE;

        ercd = snd_mbx(cep->nif->smbxid, pkt);
        if (ercd != E_OK) {
            tcp_internal_error(ercd);
            rel_mpf(ID_ETH_MPF, pkt);
        }
        /* Added AK - Initialize keep-alive timer whenever */
        /*             a packet to be transmitted.         */
        if (cep->ktime <= cep->tmo.ktime_tmo) {
            tcp_cep_ktime_init(cep);
        }

        /* modified AK - break if buffer is empty */
        if (size <= 0 || retry)
            break;
    }
    tcp_timeout_update(cep);
}

/************************************************/
/* TCP Transmition Process (tcp_transmit)       */
/************************************************/

void tcp_transmit(T_TCP_CEP *cep)
{
    tcp_transmit_sub(cep, FALSE);
}

/************************************************/
/* ACK Transmit                                 */
/************************************************/

void tcp_transmit_ack(T_TCP_CEP *cep)
{
    T_TCP_HEADER *acktcp;
    ER ercd;

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        acktcp = &((T_TCP6_PKT *)cep->ackpkt)->tcp;
    else
  #endif
        acktcp = &cep->ackpkt->tcp;
    acktcp->win = htons(rwin_size(cep));
    acktcp->ack = htonl(cep->rseq);
    acktcp->cs = 0;
    acktcp->cs = tcp_checksum(cep->ackpkt);
    cep->dackflag = 0;

    SNMP_BYPCNT(snmp_mibbyp.tcpOutSegs, 1);     /* tcpOutSegs */
  #ifdef DUAL_STK
    SNMP_BYPCNT64(snmp_mibbyp.tcpHCOutSegs, 1); /* tcpHCOutSegs */
  #endif
    ercd = snd_mbx(cep->nif->smbxid, cep->ackpkt);
    if (ercd != E_OK) {
        tcp_internal_error(ercd);
        rel_mpf(ID_ETH_MPF, cep->ackpkt);
    }
    cep->ackpkt = NULL;
    tcp_timeout_update(cep);
}

/************************************************************************************
* Module Name   : tcp_retry_failure                                                 *
* Purpose       : This funtion is called whenever retransmission fails after a      *
*                 particular number of retries. This function wakes up the tasks    *
*                 waiting for transmission and change the state of CEP to CLOSED.   *
* Arguments     : T_TCP_CEP *cep - TCP CEP structure                                *
*                 FN evcd - event code of timeout (0:no event code)                 *
* Return value  : None.                                                             *
* Author        : AK                                                                *
* Date          : 23-Mar-2002                                                       *
************************************************************************************/

static void tcp_retry_failure(T_TCP_CEP *cep, FN evcd)
{
    TCP_CALLBACK func;
    ID id;
    FN fncd;
    INT parblk;

    if (cep->state == CEP_CONNECTING ||  cep->rflag & FIN_FLAG)
        SNMP_BYPCNT(snmp_mibbyp.tcpEstabResets, 1);  /* tcpEstabResets */

    /* clear any remaining packet from mailbox */
  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
    else
  #endif
        remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);

    cep->rflag = 0;                  /* reset receive and send flag */
    cep->sflag = 0;
    if (evcd == TEV_TCP_TMO_KTIME && cep->state == CEP_CONNECTING) {
        cep->ktime = 0;
        cep->sflag = ACK_FLAG|RST_FLAG;
        tcp_transmit(cep);
    }

    /* 04Jan2005 Modified return value of tcp_snd_dat, tcp_rcv_dat */
    cep->slen = E_TMOUT;
    cep->rlen = E_TMOUT;

    /* 04Jan2005 Invoke callback function */
    if (((cep->state == CEP_CONNECTING) || (cep->state == CEP_TERMINATED))
        && (cep->dcls_id == -1) && (cep->rfncd == 0)) {
        cep->rfncd = TFN_TCP_CLS_CEP;
    }

    if ((id = cep->dcls_id) > 0) {   /* release task waiting for FIN */
        cep->dcls_id = 0;
        wup_tsk(id);
    }

    /* TCP keep-alive timer timeout */
    if (evcd == TEV_TCP_TMO_KTIME) {
        if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_TMOUT;
            (func)(cep->cepid, evcd, &parblk);
        }
    }

    /* 24Dec2004 modified to wakeup all waiting processes */
    if ((fncd = cep->sfncd) != 0) {
        if (((id = cep->stskid) != FALSE)) {
            cep->stskid = FALSE;
            wup_tsk(id);
        }

        if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_TMOUT;
            (func)(cep->cepid, fncd, &parblk);
        }
    }

    if ((fncd = cep->rfncd) != 0) {
        if (((id = cep->rtskid) != FALSE)) {
            cep->rtskid = FALSE;
            wup_tsk(id);
        }

        if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_TMOUT;
            (func)(cep->cepid, fncd, &parblk);
        }
    }

    tcp_cep_unused(cep);
}

/************************************************/
/* Recover Retransmission after Lack of Queue   */
/************************************************/

void tcp_recover_retrans(void)
{
    T_TCP_CEP *cep;

    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->qlack) {
            cep->qlack = FALSE;
            tcp_transmit_sub(cep, FALSE);
            if (cep->qlack)
                return;         /* lack is occurred again */
        }
    }
    ip_miscflag &= ~ETH_QLACK;  /* lack is solved */
}

/************************************************/
/* TCP Timeout Process                          */
/************************************************/

void tcp_timeout_process(T_TCP_CEP *cep)
{
    T_NIF *nif;
    UW tt;

    if (cep->state == CEP_DISCONNECTED)
        return;

    /* check keep-alive timeout */

    if (cep->tmo.ktime_tmo > 0 && cep->state > CEP_WAIT_P_OPEN) {
        tt = cep->itime + cep->ktime * KTIME_PRES;
        if (ring_sub(tt, SYSCK.ltime) <= 0) {               /* keep-alive time out */
            if (cep->state < CEP_CONNECTING)                /* yet connection not established */
                tcp_retry_failure(cep, TEV_TCP_TMO_KTIME);  /* close the socket */
            else {
                cep->ktime += cep->tmo.ktime_suc;           /* increase keep-alive time value */
                if (cep->ktime > (cep->tmo.ktime_tmo + cep->tmo.ktime_pro))
                    tcp_retry_failure(cep, TEV_TCP_TMO_KTIME);  /* close the socket */
                else
                    tcp_transmit_sub(cep, TRUE);            /* send probe */
            }
        }
    }

    if (!IS_USED(cep->state))
        return;

    if (cep->time != 0) {
        tt = cep->time + cep->retry.rto;
        if (ring_sub(tt, SYSCK.ltime) <= 0) {

            /* Added AK - Congestion avoidance algorithm       */
            /* congestion avoidance algorithm implemented here */
            if (cep->retry.retries == 0L && cep->win != 0) {
                if (!(cep->retry.flag & SYN_FLAG)) {
                    cep->cwnd = (UW)((cep->isn + cep->sgetp) - cep->seq1);
                    cep->cwnd = cep->cwnd >> 1;
                    cep->cwnd = (cep->cwnd / cep->mss) * cep->mss;
                    cep->ssth = MAX(cep->cwnd, cep->mss + cep->mss);
                    cep->cwnd = cep->mss;
                }
                cep->dackmd = FALSE;
                cep->dackcnt = 0;
                if (cep->retry.flag & PSH_FLAG) {
                    cep->hseq = TRUE;
                    cep->hsqn = cep->mseq;
                }
            }
            /* check if retransmission count exceeds total number */
            /* of retry counts. Then stop the retransmission and  */
            /* close the socket.                                  */
            if (++cep->retry.retries > cep->retry.retry_cnt) {
                cep->retry.srtt = 0;
                tcp_retry_failure(cep, 0);
            } else {
                /* Retransmit the segment and double the RTO value for  */
                /* next retransmission. (Exponential backoff algorithm) */
                /* 12/Jul/02 AK - remove any pending TCP seg            */
                nif = cep->nif;
                if (nif->type == NI_ETH || nif->type == NI_LOOP) {
                  #ifdef DUAL_STK
                    if (cep->type == IPV6_ADDR)
                        remove_queued_packet(0, (T_ETH *)&cep->nif->na_waiting, cep);
                    else
                  #endif
                        remove_queued_packet(0, (T_ETH *)&cep->nif->arp_waiting, cep);
                }
                if (cep->retry.flag & SYN_FLAG)
                    cep->sflag = (UB)cep->retry.flag;
                if (cep->win == 0 && !(cep->retry.flag & SYN_FLAG))
                    cep->retry.retries = 0;

                cep->retry.rto = cep->retry.rto << 1;
                if (cep->retry.rto > cep->tmo.rto_max)
                    cep->retry.rto = cep->tmo.rto_max;
                tcp_transmit_sub(cep, TRUE);
            }
        }
    }

    if (!IS_USED(cep->state))
        return;

    if (cep->ackpkt != NULL &&                      /* delayed ACK pending */
        ring_sub(cep->dtime, SYSCK.ltime) <= 0) {   /* delay time expired */
        tcp_transmit_ack(cep);
    }
}

/************************************************/
/* Update Timeout                               */
/************************************************/

static void update_nif_tcp_timeout(T_NIF *nif)
{
    T_TCP_CEP *cep;

    nif->tcp_tmout = 0;
    nif->tcp_tmout_cepid = 0;
    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->nif == nif && cep->tmout != 0) {
            if (nif->tcp_tmout == 0 || ring_sub(cep->tmout, nif->tcp_tmout) < 0) {
                nif->tcp_tmout = cep->tmout;
                nif->tcp_tmout_cepid = cep->cepid;
            }
        }
    }
}

void tcp_timeout_update(T_TCP_CEP *cep)
{
    T_NIF *nif;
    UW tmout, tt;

    nif = cep->nif;
    tmout = 0;
    if (IS_USED(cep->state) && cep->state != CEP_DISCONNECTED && nif != NULL) {
        if (cep->tmo.ktime_tmo > 0 && cep->state > CEP_WAIT_P_OPEN) {
            tmout = cep->itime + cep->ktime * KTIME_PRES;
            if (tmout == 0)
                tmout = 1;
        }

        if (cep->time != 0) {
            tt = cep->time + cep->retry.rto;
            if (tt == 0)
                tt = 1;
            if (tmout == 0)
                tmout = tt;
            else if (ring_sub(tt, tmout) < 0)
                tmout = tt;
        }

        if (cep->ackpkt != NULL) {                  /* delayed ACK pending */
            tt = cep->dtime;
            if (tt == 0)
                tt = 1;
            if (tmout == 0)
                tmout = tt;
            else if (ring_sub(tt, tmout) < 0)
                tmout = tt;
        }
    }

    if (cep->tmout == tmout)
        return;

    cep->tmout = tmout;
    if (tmout == 0) {
        if (nif != NULL && nif->tcp_tmout_cepid == cep->cepid)
            update_nif_tcp_timeout(nif);
    } else {
        if (nif->tcp_tmout == 0 || ring_sub(tmout, nif->tcp_tmout) < 0) {
            nif->tcp_tmout = tmout;
            nif->tcp_tmout_cepid = cep->cepid;
            if (ring_sub(tmout, SYSCK.ltime) < MSEC2TICK(1000))
                wup_snd_tsk(nif);
        } else if (nif->tcp_tmout_cepid == cep->cepid) {
            update_nif_tcp_timeout(nif);
        }
    }
}

/************************************************/
/* TCP Cancel CEP Subroutine                    */
/************************************************/

ER tcp_can_cep2(T_TCP_CEP *cep, FN fncd)
{
    TCP_CALLBACK func;
    ER ercd;
    ID id;
    INT parblk;

    ercd = E_OBJ;

    /* 24Dec2004 Modified to wakeup all waiting processes */
    if ((id = cep->dcls_id) > 0) {
        cep->dcls_id = 0;
        ercd = rel_wai(id);
    }

    if ((fncd == cep->sfncd) && ((id = cep->stskid) != FALSE)) {
        cep->stskid = FALSE;
        ercd = rel_wai(id);
        return ercd;
    }

    if ((fncd == cep->rfncd) && ((id = cep->rtskid) != FALSE)) {
        cep->rtskid = FALSE;
        ercd = rel_wai(id);
        return ercd;
    }

    if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
        if (cep->nif != NULL) {
          #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR)
                remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
            else
          #endif
                remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
        }
        if (fncd == TFN_TCP_ACP_CEP || fncd == TFN_TCP_CON_CEP || fncd == TFN_TCP_CLS_CEP ||
           (fncd == TFN_TCP_ALL && (cep->rfncd == TFN_TCP_ACP_CEP ||
           cep->rfncd == TFN_TCP_CON_CEP || cep->rfncd == TFN_TCP_CLS_CEP)))
            tcp_cep_unused(cep);
        parblk = E_RLWAI;
        ercd = E_OK;
        (func)(cep->cepid, fncd, &parblk);
    }
    return ercd;
}

/* end */
