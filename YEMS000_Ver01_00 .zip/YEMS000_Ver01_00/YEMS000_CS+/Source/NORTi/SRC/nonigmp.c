/******************************************************************************
* NORTi TCP/IP Stack - IGMP Module                                            *
*                                                                             *
*  Copyright (c) 2000-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-11-19 Created                                                          *
* 2000-06-07 Added support for little endian                                  *
* 2000-07-25 Modified igmp_reception()                                        *
* 2005-02-04 Modified for multi-channel                                    AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based ones     AK *
* 2006-03-03 Added support for IGMPv2                                      AK *
* 2006-05-08 Corrected ARM compiler warnings                               AK *
* 2006-07-28 Fixed igmp_checksum() to accept both of 0x0000 and 0xFFFF     AK *
* 2007-02-16 Fixed igmp_reception() to subtract options size from data_len GS *
* 2008-07-18 Adjusted indent of switch-case statement                      GS *
* 2008-10-16 Deleted some unnecessary spaces at end of line                FY *
* 2008-12-17 Removed check of (mgrp_cb[i].nif == NULL) meaning any interface, *
*             in igmp_reception()/search_igmp_group()/_ip() to strictly check *
*             receivable dest/source IP address on this network interface  GS *
* 2012-12-05 Added (int) cast to TFN_NET_RED_PKT_END function 5th argument FY *
* 2021-06-22 Deleted clearing of removed pkt->ctl.arprty                   FY *
* 2023-07-11 Changed igmp_reception() to calculate data_len with total        *
*             length excluded IP options length by updated ip_reception()  FY *
* 2023-07-11 Removed ip_opt_checksum() due to modifying ip_checksum()      MI *
* 2023-07-11 Randomized report delay time using SYSCK in igmp_reception()  GS *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/******************************************************************************
* Module Name   : search_igmp_group                                           *
* Purpose       : This function searches whether a group address is present   *
*                 mulitcast group or not.                                     *
* Arguments     : T_IPV4EP *gaddr - Address & port pair to be searched.       *
*                 T_NIF    *nif   - Interface address.                        *
* Return value  : On success it returns the offset of the group address in    *
*                 the Multicast group block otherwise returns -1.             *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

int search_igmp_group(T_NIF *nif, T_IPV4EP *gaddr)
{
    int i;

    /* 04Feb2005 - Modified for Multichannel */

    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        if (mgrp_cb[i].ipaddr == gaddr->ipaddr &&
            mgrp_cb[i].portno == gaddr->portno &&
            mgrp_cb[i].nif == nif)
                return i;
    }
    return -1;
}

/******************************************************************************
* Module Name   : search_igmp_ip                                              *
* Purpose       : This function checks whether the packet with the specific   *
*                 destination & source addresses are allowed in the interface *
*                 level or not.                                               *
* Arguments     : T_NIF *nif - Interface address.                             *
*                 UW ipaddr  - Packet`s Destination IP address.               *
*                 UW srcaddr - Packet`s Source IP address.                    *
* Return value  : On success, it returns TRUE.                                *
*                 On failure, it returns FALSE.                               *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
*                 11/Nov/2008 : Updated for IGMPv3                        G.S *
******************************************************************************/

BOOL search_igmp_ip(T_NIF *nif, UW ipaddr, UW srcaddr)
{
    T_GADDR *gaddr;

    /* Check the Destination IP with Group Address List & Check whether the
        Source Address is accepted or not */
    gaddr = nif->gaddr_list;
    while (gaddr != NULL) {
        if (ipaddr == gaddr->ipaddr) {
            if (igmp3_util_chksrc(gaddr->src_list, srcaddr) == TRUE) {
                if (gaddr->filt_mode == MODE_IS_INCLUDE)
                    return TRUE;
            } else {
                if (gaddr->filt_mode == MODE_IS_EXCLUDE)
                    return TRUE;
            }
            break;
        }
        gaddr = gaddr->nxt;
    }
    return FALSE;
}

/******************************************************************************
* Module Name   : clr_mgrp_cb                                                 *
* Purpose       : This function removes the entry of UDP CEP from multicast   *
*                 group control block.                                        *
* Arguments     : T_UDP_CEP *cep - UDP cep to be removed from mgrp_cb.        *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

void clr_mgrp_cb(T_UDP_CEP *cep)
{
    int i;

    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        if (mgrp_cb[i].cep == cep) {
            mgrp_cb[i].ipaddr = 0L;
            mgrp_cb[i].portno = 0;  /* Added 05Aug2004 A.K */
            mgrp_cb[i].cep = NULL;
            mgrp_cb[i].nif = NULL;
            mgrp_cb[i].tif = NULL;
            mgrp_cb[i].rptime = 0;
            cep->options = 0;
            break;
        }
    }
}

/******************************************************************************
* Module Name   : igmp_checksum                                               *
* Purpose       : This function computes the checksum for IGMP packet.        *
* Arguments     : T_IGMP_MSG *icmp - IGMP packet.                             *
* Return value  : Returns the computed checksum.                              *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static UH igmp_checksum(T_IGMP_MSG *igmp)
{
    UW sum;
    UH *p;

    p = (UH *)igmp;
    sum = *p++;         /* type, code */
    sum += *p++;        /* checksum */
    sum += *p++;        /* group address (high) */
    sum += *p++;        /* group address (low) */
    sum = (sum & 0xffff) + (sum >> 16);
    sum += (sum >> 16);
    return (UH)~sum;
}

/******************************************************************************
* Module Name   : leave_igmp_group                                            *
* Purpose       : It sends the IGMP leave report and drops the group from list*
* Arguments     : T_MGRP_CB *grp - Group address to be dropped.               *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 10/Aug/2005                                                 *
******************************************************************************/

void leave_igmp_group(T_MGRP_CB *grp)
{
    const UB all_router[] = { 224, 0, 0, 2 };
    T_NIF *nif=NULL;

    if (grp->nif != NULL)
        nif = grp->nif;
    else if (grp->tif != NULL) {
        nif = grp->tif;
    }
    else {
        nif = getnif_default();
        if (nif == NULL) goto END;
    }

    /* Don't send if IGMPv1 router is present */

    if (!(nif->ip.igmp_flag & IGMPV1_ROUTER_EXISTS))
        igmp_snd_dat(IGMPV2_LEAVE, nif->smbxid, byte4_to_long(nif->ipaddr), byte4_to_long(all_router), grp->ipaddr);

END:
    grp->ipaddr = 0L;
    grp->portno = 0;
    grp->cep = NULL;
    grp->nif = NULL;
    grp->tif = NULL;
    grp->rptime = 0;
}

/******************************************************************************
* Module Name   : send_igmp_report                                            *
* Purpose       : It sends the IGMP Report with proper version.               *
* Arguments     : T_MGRP_CB *grp - Group address to be reported.              *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 10/Aug/2005                                                 *
******************************************************************************/

void send_igmp_report(T_MGRP_CB *grp)
{
    T_NIF *nif=NULL;

    if (grp->nif != NULL)
        nif = grp->nif;
    else if (grp->tif != NULL) {
        nif = grp->tif;
    }
    else {
        nif = getnif_default();
        if (nif == NULL) return;
    }

    if (!(ip_miscflag & IGMP_MEMBER_EXISTS))
        ip_miscflag |= IGMP_MEMBER_EXISTS;

    /* If IGMP Router V1 present */

    if (nif->ip.igmp_flag & IGMPV1_ROUTER_EXISTS)
        igmp_snd_dat(IGMP_REPORT, nif->smbxid, byte4_to_long(nif->ipaddr), grp->ipaddr, grp->ipaddr);
    else
        igmp_snd_dat(IGMPV2_REPORT, nif->smbxid, byte4_to_long(nif->ipaddr), grp->ipaddr, grp->ipaddr);
}

/******************************************************************************
* Module Name   : check_igmp_tmo                                              *
* Purpose       : This Periodic function,                                     *
*                   1) Checks for any pending IGMP report to be send.         *
*                   2) Checks IGMPv1 Router Present timeout.                  *
*                   3) Stop calling this function if no member exists.        *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 10/Aug/2005                                                 *
******************************************************************************/

void check_igmp_tmo(void)
{
    T_NIF *nif;
    int i;
    UB member_exists=0;

    /* First, check for IGMPv1 Router Present Timeout */

    nif = getnif_default();
    while (nif) {

        if (nif->ip.igmpv1_tmo > 0) {
            if (--nif->ip.igmpv1_tmo == 0)
                nif->ip.igmp_flag = 0; /* Clear IGMPv1 Router Present flag */
        }
        nif = nif->next;
    }

    /* Check & Send if any Report timeout is expired */

    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        if (mgrp_cb[i].ipaddr != 0) {
            member_exists = 1;
            if (mgrp_cb[i].rptime > 0) {
                if (--mgrp_cb[i].rptime == 0) {
                    send_igmp_report(&mgrp_cb[i]);
                }
            }
        }
    }

    /* If a group is not exists then stop polling */

    if (member_exists == 0)
        ip_miscflag &= ~IGMP_MEMBER_EXISTS;

}

/******************************************************************************
* Module Name   : igmp_reception                                              *
* Purpose       : This function is called from IP layer whenever an IGMP pkt  *
*                 is received. This function validates the IGMP header and    *
*                 process the IGMP message. If a request message is received  *
*                 then a IGMP report will be send as response.                *
* Arguments     : T_IP4 *pkt       - IP header.                               *
* Return value  : Returns the packet.                                         *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
*                 10/Aug/2005 - Updated for IGMPv2                        A.K *
*                 11/Nov/2008 : Updated for IGMPv3                        G.S *
******************************************************************************/

T_IP4 *igmp_reception(T_IP4 *pkt)
{
    T_IGMP_MSG igmp;
    T_NIF *nif;
    int data_len,i;
    UB dly;

    nif = pkt->ctl.nif;

    data_len = ntohs(pkt->ip.tl) - IP4_HEADER_SZ;

    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, &igmp, data_len, (int)sizeof (T_IGMP_MSG)))
        return pkt;

    /* Checksum */

    if (igmp_checksum(&igmp) != 0)
        return pkt;

    switch(igmp.type) {
    case IGMP_INQUERY:
        if (data_len == 8) { /* Validate IGMPv1/v2 messages */
            /* IGMPv2/v1 Query recieved; Set system in v2/1 compatible mode */
            igmp3_setv2_mod(nif);

            if (igmp.rpt == 0) {
                igmp.rpt = 10;  /* IGMPv1 maximum report delay is 10 sec */

                /* IGMPv1 Router Exists, use this info for future transmission */
                nif->ip.igmp_flag  = IGMPV1_ROUTER_EXISTS;
                nif->ip.igmpv1_tmo = IGMPV1_PRESENT_TMO;
            } else { /* IGMPv2: Get Max Response Time in seconds */
                igmp.rpt = igmp.rpt / 10;
            }
            /* Calculate random delay */
            dly = SYSCK.ltime % igmp.rpt;
            if (dly == 0)
                dly = 1;

            /* If General Query then report all Member address */

            if (igmp.group == 0) {
                for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
                    if ((mgrp_cb[i].ipaddr != 0) && (mgrp_cb[i].nif == nif)) {
                        if ((mgrp_cb[i].rptime == 0) || (mgrp_cb[i].rptime >= igmp.rpt))
                            mgrp_cb[i].rptime = dly;
                        mgrp_cb[i].tif    = nif;
                    }
                }
            }
            else {
                for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
                    if ((mgrp_cb[i].ipaddr == ntohl(igmp.group)) && (mgrp_cb[i].nif == nif)) {
                        if ((mgrp_cb[i].rptime == 0) || (mgrp_cb[i].rptime >= igmp.rpt))
                            mgrp_cb[i].rptime = dly;
                        mgrp_cb[i].tif    = nif;
                    }
                }
            }
        }

        break;

    case IGMPV2_REPORT:
    case IGMP_REPORT:

        /* We can stop sending a Report if we found that another host in */
        /* the network transmitted the report for the Group. */

        for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
            if ((mgrp_cb[i].ipaddr == ntohl(igmp.group)) && (mgrp_cb[i].nif == nif)) {
                mgrp_cb[i].rptime = 0;
                mgrp_cb[i].tif    = NULL;
            }
        }
        break;
    default:
        break;
    }

    return pkt;

}

/******************************************************************************
* Module Name   : igmp_snd_dat                                                *
* Purpose       : This function is used to construct and send an IGMP message *
* Arguments     : UB type    - IGMP message type.                             *
*                 ID mbxid   - Interface to be used for transmission.         *
*                 UW srcaddr - Source IP address.                             *
*                 UW dstaddr - Destination IP address.                        *
*                 UW grpaddr - Group address.                                 *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER igmp_snd_dat(UB type, ID mbxid, UW srcaddr, UW dstaddr, UW grpaddr)
{
    T_IGMP_MSG igmp;
    T_IP4 *pkt;
    ER ercd;
    const UB opt[] = { 0x94, 0x04, 0x00, 0x00 }; /* router alert option */

    ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
    if (ercd != E_OK)
        return ercd;
    memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
    pkt->ctl.mpfid = (H)ID_ETH_MPF;

    pkt->ip.da = htonl(dstaddr);
    pkt->ip.sa = htonl(srcaddr);

    if(type == IGMP_REPORT){
        pkt->ip.ver = 0x45;
        pkt->ip.tl = htons(IP4_HEADER_SZ + sizeof igmp);
    }
    else{
        pkt->ip.ver = 0x46;
        pkt->ip.tl = htons(IP4_HEADER_SZ + 4 + sizeof igmp);
    }

    pkt->ip.tos = 0;
    pkt->ip.id = htons(ip_ident++);
    pkt->ip.fo = 0;
    pkt->ip.ttl = 1;
    pkt->ip.prot = PROT_IGMP;

    memset(pkt->eth.da, 0, 6);
    pkt->eth.etype = htons(ETYPE_IP4);

    pkt->ctl.hedflg = FALSE;

    igmp.type = type;
    igmp.rpt = 0;
    igmp.cs = 0;
    igmp.group = htonl(grpaddr);
    igmp.cs = igmp_checksum(&igmp);

    if (type == IGMP_REPORT) {
        memcpy(pkt->data, &igmp, sizeof igmp);
    } else {
        memcpy(pkt->data, opt, 4);
        memcpy(pkt->data + 4, &igmp, sizeof igmp);
    }
    return snd_mbx(mbxid, (T_MSG *)pkt);
}

/* End */
