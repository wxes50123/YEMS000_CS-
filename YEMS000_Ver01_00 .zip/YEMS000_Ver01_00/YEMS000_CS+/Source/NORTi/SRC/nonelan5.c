/******************************************************************************
* NORTi TCP/IP Stack - LAN Driver Bridge                                      *
*                                                                             *
*  Copyright (c) 2022, MiSPO Co., Ltd.                                        *
*  All rights reserved.                                                       *
*                                                                             *
* 2022-02-04 Copied nonelan.c 21/09/27, and changed NIF_NUM to 5           GS *
******************************************************************************/

#include <stddef.h>
#include <stdarg.h>
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"

#define NIF_NUM     5
#define INCLUDED_FROM_NONET
#include "nonetc.h"
#include "nonelan.h"

/* Packet Dump Routine for Debug */

#ifdef DUMP
typedef struct t_dump_msg T_DUMP_MSG;
void landump_len(T_DUMP_MSG **, int);
void landump_dat(T_DUMP_MSG *, const void *, int);
void landump_end(T_DUMP_MSG *);
static T_DUMP_MSG *rcv_dump;
static T_DUMP_MSG *snd_dump;
#else
#define landump_len(b,l)
#define landump_dat(b,d,l)
#define landump_end(b)
#endif

/* Internal Variable */

static UH received_len;

/*****************************************************************************
* LAN Driver Error Handling
*
******************************************************************************/

ER lan_error(ER ercd)
{
    /* This function is called when LAN driver returns an error.
       Does nothing by default. */

    return ercd;
}

/*****************************************************************************
* Get Received Packet Length
*
******************************************************************************/

UH lan_received_len(void)
{
    /* Returns number of bytes in the received Ethernet frame.
       Calls lan_get_len() of LAN driver. */

    ER ercd;

    ercd = lan_get_len(&received_len);
    if (ercd != E_OK) {
        lan_error(ercd);
        received_len = 0;
    }
    if (received_len == 0)
        lan_get_end();
    else
        landump_len(&rcv_dump, received_len);

    SNMP_BYPCNT(snmp_mibbyp_if[NIF_NUM].ifInOctets, received_len);      /* ifInOctets */
    SNMP_BYPCNT64(snmp_mibbyp_ifX[NIF_NUM].ifHCInOctets, received_len); /* ifHCInOctets */

    return received_len;
}

/*****************************************************************************
* Read Received Packet
*
******************************************************************************/

BOOL lan_read_pkt(void *buf, int len)
{
    /* Reads out specified number of bytes from the received Ethernet frame.
       Calls lan_get_pkt() of LAN driver. */

    ER ercd;

    /* when required size is within received size */
    if (len <= (int)received_len) {
        if (len != 0) {
            ercd = lan_get_pkt(buf, len);
            if (ercd != E_OK) {
                lan_error(ercd);
                received_len = 0;
                landump_end(rcv_dump);
                return FALSE;
            }
            landump_dat(rcv_dump, buf, len);
            if ((received_len -= len) == 0) {
                lan_get_end();
                landump_end(rcv_dump);
            }
        }
        return TRUE;
    }

    /* when required size is over received size */
    if (received_len != 0) {
        ercd = lan_get_pkt(buf, received_len);
        if (ercd != E_OK)
            lan_error(ercd);
        landump_dat(rcv_dump, buf, received_len);
        received_len = 0;
        lan_get_end();
        landump_end(rcv_dump);
    }
    return FALSE;
}

/*****************************************************************************
* Discard Received Packet
*
******************************************************************************/

void lan_ignore_pkt(void)
{
    ER ercd;

    if (received_len != 0) {
        ercd = lan_skp_pkt(received_len);
        if (ercd != E_OK)
            lan_error(ercd);
        received_len = 0;
        landump_end(rcv_dump);
    }
}

/*****************************************************************************
* Read Received Packet until End
*
******************************************************************************/

BOOL lan_read_pkt_end(void *buf, int len, int bufsz)
{
    /* error, if received data length is less than len */
    if ((int)received_len < len) {
        SNMP_BYPCNT(snmp_mibbyp_if[NIF_NUM].ifInErrors, 1); /* ifInErrors */
        if ((int)received_len > bufsz) {
            lan_read_pkt(buf, bufsz);
            lan_ignore_pkt();
        } else {
            lan_read_pkt(buf, received_len);
        }
        return FALSE;
    }

    /* discard any excess data more than bufsz */
    if ((int)received_len > bufsz) {
        if (!lan_read_pkt(buf, bufsz))
            return FALSE;
        lan_ignore_pkt();
        return TRUE;
    }

    /* normal reading */
    return lan_read_pkt(buf, received_len);
}

/*****************************************************************************
* Write Transmit Packet with Multiple Data
*
******************************************************************************/

BOOL lan_write_m_pkt(T_DATA *p_data, int num)
{
    /* p_data points structure of data to write in.
       num is number of data pointers in this structure. */

    int i, n, len;

    /* set transmit length (header length + data length) */
    for (len = n = 0; n < num; n++)
        len += p_data[n].len;
    i = 60 - len;
    if (i > 0)
        len = 60;
    lan_set_len(len);
    landump_len(&snd_dump, len);
    SNMP_BYPCNT(snmp_mibbyp_if[0].ifOutOctets, len); /* ifOutOctets */

    /* write data to transmit buffer */
    for (n = 0; n < num; n++) {
        if (p_data[n].len > 0) {
            lan_put_pkt(p_data[n].data, p_data[n].len);
            landump_dat(snd_dump, p_data[n].data, p_data[n].len);
        }
    }

    /* write dummy data when less than 60 bytes */
    if (i > 0) {
        lan_put_dmy(i);
        landump_dat(snd_dump, NULL, i);
    }

    /* terminate writing and start sending */
    lan_put_end();
    landump_end(snd_dump);
    return TRUE;
}

/*****************************************************************************
* LAN Driver Bridge Function
*
******************************************************************************/

ER lan_nif_dev(T_NIF *nif,  FN fncd, ...)
{
    va_list plist;
    ER ercd;
    UB *macaddr;
    VP buf;
    int len, bufsz, num;
    TMO tmo;
    T_DATA *p;

    va_start(plist, fncd);

    switch (fncd){
    /* initialize LAN driver */
    case TFN_NET_INI:
        nif->type = NI_ETH;
        macaddr = va_arg(plist, UB *);
        ercd = lan_ini(macaddr);
        if (nif_loop_back == NI_LOOP) {
            nif->type = NI_LOOP;
            nif_loop_back = 0;
        }
        break;

    /* wait for receive interrupt */
    case TFN_NET_WAI_RCV:
        tmo = va_arg(plist, TMO);
        ercd = lan_wai_rcv(tmo);
        break;

    /* wait for transmit interrupt */
    case TFN_NET_WAI_SND:
        tmo = va_arg(plist, TMO);
        ercd = lan_wai_snd(tmo);
        break;

    /* read received packet */
    case TFN_NET_RED_PKT:
        buf = va_arg(plist, VP);
        len = va_arg(plist, int);
        ercd = lan_read_pkt(buf, len);
        break;

    /* read received packet until end */
    case TFN_NET_RED_PKT_END:
        buf = va_arg(plist, VP);
        len = va_arg(plist, int);
        bufsz = va_arg(plist, int);
        ercd = lan_read_pkt_end(buf, len, bufsz);
        break;

    /* write transmit packet with multiple data */
    case TFN_NET_WRI_M_PKT:
        p = va_arg(plist, VP);
        num = va_arg(plist, int);
        ercd = lan_write_m_pkt(p, num);
        break;

    /* get received packet length */
    case TFN_NET_RCV_LEN:
        ercd = lan_received_len();
        break;

    /* discard received packet */
    case TFN_NET_IGN_PKT:
        lan_ignore_pkt();
        ercd = E_OK;
        break;

    /* LAN driver error handling */
    case TFN_NET_ERR:
        ercd = va_arg(plist, ER);
        ercd = lan_error(ercd);
        break;

    /* get network interface number */
    case TFN_GET_NIF_NUM:
        ercd = NIF_NUM;
        break;

    case TFN_NET_EXT:
        ercd = lan_ext_dev();
        break;

    default:
        ercd = E_NOSPT;
    }
    return ercd;
}

/* end */
