/******************************************************************************
* NORTi TCP/IP Stack - RAW Communication Module                               *
*                                                                             *
*  Copyright (c) 2008-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2008-06-30 Created for RAW communication                                 OM *
* 2008-07-08 Fixed GHS compiler warning, & added function parameter check  OM *
* 2008-07-15 Modified check of RAW communication endpoint                  OM *
* 2008-10-16 Deleted some unnecessary spaces at end of line                FY *
* 2009-01-26 Replaced tcpip_critical() from tcpip_cretical() of old-style  IS *
* 2009-11-02 Changed the commenting out characters in raw_rcv_dat()        FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2012-03-29 Corrected insufficient exclusion control of raw_del_cep()     FY *
* 2012-03-29 Removed unnecessary check of cep->nif!=NADR in raw_del_cep()  FY *
* 2012-11-13 Reduced ID variables size to UH (ex. cep->id_raw_rcv_mbx)     FY *
* 2012-11-27 Changed so that pkt->eth.len might be used without using         *
*               TFN_NET_RCV_LEN function call to obtain the received size  FY *
* 2012-11-27 Changed so that domain which p_ercd points out might not be      *
*                      accessed, when the member tskid of T_RAW_RCV was 0  FY *
* 2013-06-18 Simplified raw_cre_cep() & raw_del_cep() to ignore               *
*                 improbable internal error of tcpip_critical(FALSE, ...)  FY *
* 2013-06-18 Modified raw_(v)cre_cep and raw_cre_cep_sub                   FY *
* 2013-06-18 Replaced NADR (uITRON3 compatible) by NULL (uITRON4 standard) FY *
* 2013-12-24 Modified raw_snd_dat() not to return task priority               *
*                                                       during processing  FY *
* 2013-12-24 Added vcan_wup() after also tslp_tsk() to clear excessive        *
*                        wake-up request in raw_snd_dat() & raw_rcv_dat()  FY *
* 2014-10-20 Fixed RAW receiving's incorrect memory access bugged in v4.41 FY *
* 2021-06-22 Changed remove_sndque_rawpkt() and remove_mbx_pkt()              *
*                       2nd parameter's member from rmbxid to arp_waiting  FY *
* 2021-09-05 Adjusted coding style                                         MI *
* 2024-06-19 Modified raw_check_protocol() to allow all protocols             *
*                  except IPv4/ARP/IPv6, not just PPPoE Discovery/Session  FY *
* 2024-07-18 Removed unused layer check, and tuned code & comments totally MI *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/******************************************************************************
* RAW Communication Internal Error
*
* Parameter
*  ercd - error code
*
* Return value:
*  a value after processing the error code
******************************************************************************/
#ifndef DEBUG

ER raw_internal_error(ER ercd)
{
    /* This function is called by RAW communication process when an internal
       error occurred, and calls TCP/IP stack internal error function.
       This is replaced with trouble_shooter() if DEBUG macro is defined. */

    return tcpip_internal_error(ercd);
}

#endif
/********************************************************************************
* Check for RAW Packet
*
* Parameters:
*  layer - layer of network (unused)
*  etype - Ethernet type
*
* Return value:
*  TRUE if pass to RAW communication endpoint, FALSE otherwise
********************************************************************************/

BOOL raw_check_protocol(UH layer, UH etype)
{
    /* This function is also called by ip_rcv_tsk(), and checks whether
       the packet should be passed to RAW communication. */

    switch (etype) {
    case ETYPE_IP4:
    case ETYPE_ARP:
    case ETYPE_IP6:
        return FALSE;   /* pass to TCP/IP stack */
    default:
        return TRUE;    /* pass to RAW communication */
    }
}

/*****************************************************************************
* Chain/Delete RAW Communication Endpoint
*
* Parameters:
*  cep  - pointer to RAW communication endpoint control block
*  flag - TRUE: chain, FALSE: delete
*
* Return value:
*  allways E_OK
******************************************************************************/

static ER raw_def_cep(T_RAW_CEP *cep, BOOL flag)
{
    T_RAW_CEP *p, *q;

    p = (T_RAW_CEP *)&pRAW_CEP;
    q = p->next;

    /* chain endpoint if flag is TRUE */
    if (flag) {
        for (;;) {
            if (q == NULL) {
                cep->next = NULL;
                p->next = cep;
                break;
            }
            if (q == cep)
                break;
            p = q;
            q = q->next;
        }
    }

    /* delete endpoint if flag is FALSE */
    else {
        for (;;) {
            if (q == NULL)
                break;
            if (q == cep) {
                p->next = q->next;
                break;
            }
            p = q;
            q = q->next;
        }
    }
    return E_OK;
}

/*******************************************************************************
* Search RAW Communication Endpoint
*
* Parameters:
*  nif   - pointer to network interface control block received the packet
*  etype - Ethernet type
*
* Return value:
*  pointer to found RAW communication endpoint control block, NULL otherwise
********************************************************************************/

static T_RAW_CEP *search_raw_cep(T_NIF *nif, UH etype)
{
    /* This function searches for a RAW communication endpoint matching
       specified Ethernet type. */

    T_RAW_CEP *cep;

    for (cep = pRAW_CEP; cep != NULL; cep = cep->next) {
        if (cep->nif == nif && cep->prot == etype)
            break;
    }
    return cep;
}

/*****************************************************************************
* Common Subroutine to Create RAW Communication Endpoint
*
* Parameters:
*  cep     - pointer to RAW communication endpoint control block
*  pk_ccep - RAW communication endpoint creation information
*
* Return value:
*  E_OK on success, negative error code otherwise
******************************************************************************/

static ER raw_cre_cep_sub(T_RAW_CEP *cep, const T_RAW_CCEP *pk_ccep)
{
    /* This function is called from raw_cre_cep()/raw_vcre_cep() commonly to
       create a mailbox and a memorypool used by RAW communication endpoint. */

    T_NIF *nif;
    ER ercd;

    /* validate parameter */
    if (pk_ccep == NULL)
        return E_PAR;

    /* check specified Ethernet type */
    if (!raw_check_protocol(0, pk_ccep->prot))
        return E_PAR;

    /* get pointer to network interface control block */
    if (pk_ccep->nif_name == NULL) {
        nif = getnif_default();
    } else {
        if ((UINT)(strlen(pk_ccep->nif_name) - 1) >= RAW_NIF_NAME - 1)
            return E_PAR;
        nif = getnif_from_name(pk_ccep->nif_name);
    }
    if (nif == NULL)
        return E_LNK; /* interface unavailable */

    /* check duplicate creation for same Ethernet type */
    if (search_raw_cep(nif, pk_ccep->prot) != NULL)
        return E_OBJ;

    /* create mailbox and memorypool */
    if (cep->id_raw_rcv_mbx == 0) {
        ercd = acre_mbx(&c_raw_rcv_mbx);
        if (ercd < 0)
            return ercd;
        cep->id_raw_rcv_mbx = (UH)ercd;
    } else {
        ercd = cre_mbx(cep->id_raw_rcv_mbx, &c_raw_rcv_mbx);
        if (ercd != E_OK)
            return ercd;
    }
    if (cep->id_raw_snd_mpf == 0) {
        ercd = acre_mpf(&c_raw_snd_mpf);
        if (ercd < 0) {
            del_mbx(cep->id_raw_rcv_mbx);
            return ercd;
        }
        cep->id_raw_snd_mpf = (UH)ercd;
    } else {
        ercd = cre_mpf(cep->id_raw_snd_mpf, &c_raw_snd_mpf);
        if (ercd != E_OK) {
            del_mbx(cep->id_raw_rcv_mbx);
            return ercd;
        }
    }

    /* setup RAW communication endpoint control block */
    cep->nif   = nif;            /* network interface */
    cep->prot  = pk_ccep->prot;  /* Ethernet type */
    cep->callback = (TCP_CALLBACK)pk_ccep->callback;
    cep->ercd  = E_OK;
    cep->pkt   = NULL;

    return raw_def_cep(cep, TRUE);
}

/*****************************************************************************
* Service Call to Create RAW Communication Endpoint

* Parameters:
*  cepid   - RAW communication endpoint ID
*  pk_ccep - RAW communication endpoint creation information
*
* Return value:
*  E_OK on success, negative error code otherwise
******************************************************************************/

ER raw_cre_cep(ID cepid, const T_RAW_CCEP *pk_ccep)
{
    /* This service call creates a RAW communication endpoint for
       specified ID. */

    T_RAW_CEP *cep;
    PRI save_pri;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* parameter check */
    cepid--;
    if ((UINT)cepid >= RAW_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* error if this ID's endpoint already created */
    cep = &RAW_CEP[cepid];
    if (cep->nif != NULL) {
        ercd = E_OBJ;
        goto ERR;
    }

    /* create RAW communication endpoint */
    ercd = raw_cre_cep_sub(cep, pk_ccep);
ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Service Call to Create RAW Communication Endpoint (Auto ID)
*
* Parameter:
*  pk_ccep - RAW communication endpoint creation information
*
* Return value:
*  auto assigned ID value on success, negative error code otherwise
******************************************************************************/

ER raw_vcre_cep(const T_RAW_CCEP *pk_ccep)
{
    /* This service call creates a RAW communication endpoint with auto
       assignment ID. */

    T_RAW_CEP *cep;
    PRI save_pri;
    ID cepid;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* create RAW communication endpoint by searching its unused control
       block from tail to avoid conflict with raw_cre_cep() specified ID */
    cepid = RAW_CEPID_MAX;
    ercd = E_ID;
    while (--cepid >= 0) {
        cep = &RAW_CEP[cepid];
        if (cep->nif == NULL) {
            ercd = raw_cre_cep_sub(cep, pk_ccep);
            if (ercd == E_OK)
                ercd = (ER)cepid + 1;
            break;
        }
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Service Call to Delete RAW Communication Endpoint
*
* Parameter:
*  cepid - RAW communication endpoint ID
*
* Return value:
*  E_OK on success, negative error code otherwise
******************************************************************************/

ER raw_del_cep(ID cepid)
{
    /* This service call deletes specified RAW communication endpoint and
       cancels any pending process for it. */

    T_RAW_CEP *cep;
    ER ercd;
    T_RAW_RCV *data;
    PRI save_pri;
    ID mbxid;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* parameter check */
    cepid--;
    if ((UINT)cepid >= RAW_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* error if endpoint not created */
    cep = &RAW_CEP[cepid];
    if (cep->nif == NULL) {
        ercd = E_NOEXS;
        goto END;
    }

    /* remove queued sending packet */
    if (cep->nif != NULL)
        remove_sndque_rawpkt(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep, E_DLT);

    /* release receive task waiting */
    mbxid = cep->id_raw_rcv_mbx;
    while (prcv_mbx(mbxid, (T_MSG **)&data) == E_OK) {
        if (data->tskid != FALSE) {
            *(data->p_ercd) = E_DLT;
            rel_wai(data->tskid);
        }
        if (cep->callback != (TCP_CALLBACK)NULL) {
            ercd = E_DLT;
            (cep->callback)(cep->cepid, TFN_RAW_RCV_DAT, &ercd);
        }
    }

    /* delete mailbox and memorypool */
    del_mbx(mbxid);
    cep->id_raw_rcv_mbx = 0;
    del_mpf(cep->id_raw_snd_mpf);
    cep->id_raw_snd_mpf = 0;

    /* delete RAW communication endpoint */
    cep->nif = NULL;
    ercd = raw_def_cep(cep, FALSE);
    if (save_pri <= PRI_TCPIP)
        rot_rdq(TPRI_SELF); /* execute continuation of canceled API */
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Get Memory Block for sending RAW Packet
*
* Parameter:
*  cep - pointer to RAW communication endpoint control block
*
* Return value:
*  allocated memory block on success, NULL otherwise
******************************************************************************/

static T_RAW_PKT *get_raw_snd_blf(T_RAW_CEP *cep)
{
    /* This function allocates memory for queueing packet to send. */

    T_RAW_PKT *pkt;
    ID mpfid;
    ER ercd;

    mpfid = cep->id_raw_snd_mpf;
    ercd  = pget_mpf(mpfid, &pkt);
    if (ercd != E_OK) {
        if (ercd != E_TMOUT)
            raw_internal_error(ercd);
        return NULL;
    }

    memset(&(pkt->ctl), 0, sizeof (T_CTL_HEADER));
    pkt->ctl.cep   = cep;
    pkt->ctl.mpfid = mpfid;
    return pkt;
}

/*****************************************************************************
* Make RAW Packet to Send
*
* Parameters:
*  pkt   - pointer to sending RAW packet structure
*  cep   - pointer to RAW communication endpoint control block
*  ethdr - pointer to Ethernet header information
*  data  - pointer to data to send as Ethernet payload
*  len   - Ethernet payload length
******************************************************************************/

static void raw_snd_pkt_make(T_RAW_PKT *pkt, T_RAW_CEP *cep, const T_RAWEP *ethdr, const VP data, INT len)
{
    /* This function constructs a RAW packet to queue and send. */

    memcpy(pkt->eth.da, ethdr->da, RAW_ETHADDR_LEN);
    memcpy(pkt->eth.sa, cep->nif->hwaddr, RAW_ETHADDR_LEN);
    pkt->eth.etype = htons(cep->prot);
    pkt->dlen = len;
    pkt->data = (UB *)data;
}

/*****************************************************************************
* Service Call to Send RAW Packet
*
* Parameters:
*  cepid - RAW communication endpoint ID
*  ethdr - pointer to Ethernet header information
*  data  - pointer to data to send as Ethernet payload
*  len   - Ethernet payload length
*  tmout - timeout
*
* Return value:
*  length of transmitted data on success, negative error code otherwize
******************************************************************************/

ER raw_snd_dat(ID cepid, const T_RAWEP *ethdr, const VP data, INT len, TMO tmout)
{
    T_RAW_CEP *cep;
    T_RAW_PKT *pkt;
    T_NIF *nif;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* validate parameters */
    cepid--;
    if ((UINT)cepid >= RAW_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }
    if (ethdr == NULL || data == NULL ||
        len < ETHERNET_PAYLOAD_MIN || len > ETHERNET_PAYLOAD_MAX ||
        ((UW)data & 1) != 0) { /* odd address? */
        ercd = E_PAR;
        goto ERR;
    }

    /* error if RAW communication endpoint not created */
    cep = &RAW_CEP[cepid];
    if (cep->nif == NULL) {
        ercd = E_NOEXS;
        goto ERR;
    }

    /* error if endpoint or network interface not available */
    if (cep->ercd == E_LNK || (nif = cep->nif) == NULL) {
        ercd = E_LNK;
        goto ERR;
    }

    /* allocate memory block */
    pkt = get_raw_snd_blf(cep);
    if (pkt == NULL) {
        ercd = E_QOVR;
        goto ERR;
    }

    /* construct packet to queue raw_snd_dat */
    pkt->ctl.nif    = nif;
    pkt->ctl.fncd   = TFN_RAW_SND_DAT;
    pkt->ctl.parblk = len;
    if (tmout == TMO_NBLK) {
        pkt->ctl.tskid    = FALSE;
        pkt->ctl.callback = cep->callback;
    } else {
        pkt->ctl.tskid    = vget_tid();
        pkt->ctl.callback = (TCP_CALLBACK)NULL;
    }
    raw_snd_pkt_make(pkt, cep, ethdr, data, len);

    /* queue raw_snd_dat */
    ercd = snd_mbx(nif->smbxid, (T_MSG *)pkt);
    if (ercd != E_OK) {
        rel_mpf(pkt->ctl.mpfid, pkt);
        goto ERR;
    }
    if (tmout == TMO_NBLK) {
        tcpip_critical(FALSE, &save_pri);
        return E_WBLK;
    }

    /* wait for sending completion */
    rot_rdq(TPRI_SELF);
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();
    if (ercd == E_OK)
        return len;

    /* to support tcp_ext() */
    if (ercd == E_RLWAI) {
        if (cep->ercd == E_LNK) { /* network interface deleted */
            ercd = cep->ercd;
            goto ERR;
        }
        if (cep->nif == NULL) {
            ercd = E_DLT;
            goto ERR;
        }
    }

    /* abnormal end */
    remove_mbx_pkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, cep, (T_ETH *)pkt);
ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Set RAW Packet Ethernet Header
*
* Parameters:
*  ethdr - pointer to Ethernet header information
*  pkt   - pointer to receiving RAW packet structure
******************************************************************************/

static void raw_rcv_pkt_hdr(T_RAWEP *ethdr, T_RAW_PKT *pkt)
{
    /* This function copies the received Ethernet header into the specified
       receiving RAW packet structure. */

    static const UB broad_addr[] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    static const UB multi_addr[] = { 0x01, 0x00, 0x5E, 0x00, 0x00, 0x00 };
    static const UB multi_mask[] = { 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00 };
    UB dam[RAW_ETHADDR_LEN];
    int i;

    /* copy MAC address and Ethernet type */
    memcpy(ethdr->da, pkt->eth.da, RAW_ETHADDR_LEN);
    memcpy(ethdr->sa, pkt->eth.sa, RAW_ETHADDR_LEN);
    ethdr->prot = ntohs(pkt->eth.etype);

    /* set MAC address type */
    for (i = 0; i < RAW_ETHADDR_LEN; i++)
        dam[i] = ethdr->da[i] & multi_mask[i];
    if (memcmp(ethdr->da, broad_addr, RAW_ETHADDR_LEN) == 0)
        ethdr->pkttype = RAW_PACKET_BORADCAST;
    else if (memcmp(dam, multi_addr, RAW_ETHADDR_LEN) == 0)
        ethdr->pkttype = RAW_PACKET_MULTICAST;
    else
        ethdr->pkttype = RAW_PACKET_HOST;
}

/*****************************************************************************
* Read RAW Packet
*
* Parameters:
*  ethdr - pointer to Ethernet header information
*  data  - buffer to store Ethernet payload
*  size  - buffer size
*  pkt   - pointer to receiving RAW packet structure
*
* Return value:
*  length of read payload on success, negative error code otherwise
******************************************************************************/

static ER raw_rcv_dat_now(T_RAWEP *ethdr, UB *data, INT size, T_RAW_PKT *pkt)
{
    /* This function is called by raw_rcv_dat service call when it is issued
       after receiving RAW packet, and processes reading packet. */

    T_NIF *nif;
    int len;

    nif = pkt->ctl.nif;
    if (nif == NULL)
        return E_LNK; /* network interface not available */
    if (data == NULL || size <= 0) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        return E_OBJ;
    }

    /* limit read length of Ethernet payload */
    len = pkt->eth.len - ETH_HEADER_SZ;
    if (len > size)
        len = size;

    /* copy received Ethernet header */
    raw_rcv_pkt_hdr(ethdr, pkt);

    /* read Ethernet payload to receive buffer */
    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, data, len, (int)size)) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        return E_OBJ;
    }
    return (ER)len;
}

/****************************************************************************
* Queue raw_rcv_dat
*
* Parameters:
*  ethdr - pointer to Ethernet header information
*  data  - buffer to store Ethernet payload
*  len   - buffer size and length of stored payload
*  tmout - timeout
*
* Return value:
*  E_OK on queuing successfully, error code otherwise
******************************************************************************/

static ER raw_rcv_dat_que(T_RAW_CEP *cep, T_RAWEP *ethdr, VP data, ER *len, TMO tmout)
{
    /* This function is called by raw_rcv_dat service call when it is issued
       before receiving RAW packet, and queues raw_rcv_dat using mailbox. */

    T_RAW_RCV *msg;
    ER ercd;
    int m;

  #if (SIZEOF_INT == 4)
    if ((m = 4 - ((UW)data & 3)) == 4)
        m = 0;
    msg = (T_RAW_RCV *)((UW)data + m); /* 4-byte alignment */
  #else
    m = 0;
    msg = data;
  #endif
    if (*len - m < sizeof (T_RAW_RCV)) /* size for snd_mbx() */
        return E_PAR;

    msg->p_dstaddr = ethdr;
    msg->p_ercd    = len;
    msg->buf       = data;
    msg->size      = *len;
    if (tmout == TMO_NBLK)
        msg->tskid = FALSE;
    else
        msg->tskid = (UH)vget_tid();

    ercd = snd_mbx(cep->id_raw_rcv_mbx, (T_MSG *)msg);
    if (ercd == E_OK && tmout == TMO_NBLK)
        return E_WBLK;
    return ercd;
}

/*****************************************************************************
* Service Call to Receive RAW Packet
*
* Parameters:
*  cepid - RAW communication endpoint ID
*  ethdr - pointer to Ethernet header information
*  data  - buffer to store Ethernet payload
*  size  - buffer size
*  tmout - timeout
*
* Return value:
*  received data length on success, negative error code otherwise
******************************************************************************/

ER raw_rcv_dat(ID cepid, T_RAWEP *ethdr, VP data, INT size, TMO tmout)
{
    T_RAW_CEP *cep;
    T_NIF *nif;
    ER len, ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* validate parameters */
    cepid--;
    if ((UINT)cepid >= RAW_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }
    if (ethdr == NULL || data == NULL || size <= 0 ||
        ((UW)data & 1) != 0) { /* odd address? */
        ercd = E_PAR;
        goto END;
    }

    /* error if RAW communication endpoint not created */
    cep = &RAW_CEP[cepid];
    if (cep->nif == NULL) {
        ercd = E_NOEXS;
        goto END;
    }

    /* error if endpoint or network interface not available */
    if (cep->ercd == E_LNK) {
        ercd = E_LNK;
        goto END;
    }
    nif = cep->nif;
    if (nif == NULL) {
        ercd = E_LNK;
        goto END;
    }

    /* error if called by polling in except callback routine */
    if (tmout == TMO_POL) {
        if (vget_tid() != nif->rtskid) { /* IP receive task ID? */
            ercd = E_PAR;
            goto END;
        }
    }

    /* read RAW packet immediately when already received */
    if (cep->pkt != NULL) {
        len = raw_rcv_dat_now(ethdr, data, size, cep->pkt);
        cep->pkt = NULL;
        ercd = (ER)len;
        goto END;
    }

    /* read RAW packet later by queuing this raw_rcv_dat */
    len = size;
    ercd = raw_rcv_dat_que(cep, ethdr, data, &len, tmout);
    if (ercd != E_OK) /* E_WBLK or snd_mbx error */
        goto END;

    /* wait for receiving completion */
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();
    if (ercd >= E_OK) {
        ercd = (ER)len;
        goto END;
    }

    /* to support tcp_ext() */
    if (ercd == E_RLWAI) {
        if (cep->ercd == E_LNK) /* network interface deleted */
            ercd = E_LNK;
        else if (cep->nif == NULL &&
                 *((T_RAW_RCV *)data)->p_ercd == E_DLT)
            ercd = E_DLT;
        goto END;
    }

    /* when tslp_tsk() timeout */
    remove_rcvque_rawpkt(cep->id_raw_rcv_mbx, data);
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/****************************************************************************
* Receive RAW Packet when raw_rcv_dat Queued

* Parameters:
*  msg - queud raw_rcv_dat information
*  pkt - pointer to receiving RAW packet structure
*  cep - pointer to RAW communication endpoint control block
******************************************************************************/

static void raw_reception_sub1(T_RAW_RCV *msg, T_RAW_PKT *pkt, T_RAW_CEP *cep)
{
    /* This function is called by raw_reception() when raw_rcv_dat is queued,
       and executes its process. */

    T_NIF *nif;
    INT len;
    ER ercd;

    /* copy received Ethernet header */
    raw_rcv_pkt_hdr(msg->p_dstaddr, pkt);

    /* limit read length of Ethernet payload */
    len = pkt->eth.len - ETH_HEADER_SZ;
    if (len > msg->size)
        len = msg->size;

    /* read Ethernet payload to receive buffer */
    nif = pkt->ctl.nif;
    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, msg->buf, len, (int)(msg->size))) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        len = E_OBJ;
        raw_internal_error(len);
        goto END;
    }

END:/* wake up task waiting for completion of raw_rcv_dat */
    if (msg->tskid != FALSE) {
        *msg->p_ercd = (ER)len;
        ercd = wup_tsk(msg->tskid);
        if (ercd != E_OK)
            raw_internal_error(ercd);
    /* notify completion of raw_rcv_dat called non-blocking */
    } else if (cep->callback != (TCP_CALLBACK)NULL) {
        (cep->callback)(cep->cepid, TFN_RAW_RCV_DAT, &len);
    }
}

/*****************************************************************************
* Receive RAW Packet when raw_rcv_dat not Queued
*
* Parameters:
*  pkt - pointer to receiving RAW packet structure
*  cep - pointer to RAW communication endpoint control block
******************************************************************************/

static void raw_reception_sub2(T_RAW_PKT *pkt, T_RAW_CEP *cep)
{
    /* This function is called by raw_reception() when raw_rcv_dat is not
       queued, and executes callback. */

    T_NIF *nif;
    INT len;

    /* call back user specified routine to let raw_rcv_dat executed in it */
    cep->pkt = pkt;
    if (cep->callback != (TCP_CALLBACK)NULL) {
        len = pkt->eth.len - ETH_HEADER_SZ;
        (cep->callback)(cep->cepid, TEV_RAW_RCV_DAT, &len);
    }

    /* discard packet if not read out */
    if (cep->pkt != NULL) {
        nif = pkt->ctl.nif;
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        cep->pkt = NULL;
    }
}

/*****************************************************************************
* Check Whether RAW Packet to be Processed
*
* Parameters:
*  pkt   - pointer to receiving RAW packet structure
*  layer - layer of network (unused)
*
* Return value:
*  TRUE if a valid RAW packet, FALSE otherwise
******************************************************************************/

BOOL is_raw_pkt(T_RAW_PKT *pkt, UH layer)
{
    /* This function checks whether a given packet is a valid RAW packet, and
       select a RAW communication endpoint to be passed it. */

    T_RAW_CEP *cep;
    T_NIF *nif;
    UH etype;

    /* check if Ethernet type can be passed to RAW communication endpoint */
    etype = ntohs(pkt->eth.etype);
    if (!raw_check_protocol(0, etype))
        return FALSE;

    /* set RAW communication endpoint into control field of packet */
    if ((nif = pkt->ctl.nif) == NULL)
        return FALSE;
    cep = search_raw_cep(nif, etype);
    if (cep == NULL)
        return FALSE;
    pkt->ctl.cep = cep;
    return TRUE;
}

/*****************************************************************************
* RAW Packet Reception Process
*
* Parameters:
*  pkt   - pointer to receiving RAW packet structure
*  layer - layer of network (unused)
*
* Return value:
*  pointer to processed RAW packet structure
******************************************************************************/

VP raw_reception(T_RAW_PKT *pkt, UH layer)
{
    /* This function is called by ip_rcv_tsk() when a valid RAW packet is
       received. */

    T_RAW_CEP *cep;
    T_RAW_RCV *msg;
    ER ercd;

    /* get queued raw_rcv_dat */
    cep = pkt->ctl.cep;
    ercd = prcv_mbx(cep->id_raw_rcv_mbx, (T_MSG **)&msg);

    /* process received RAW packet */
    if (ercd == E_OK)
        raw_reception_sub1(msg, pkt, cep);
    else if (ercd == E_TMOUT)
        raw_reception_sub2(pkt, cep);
    else
        raw_internal_error(ercd);
    pkt->ctl.cep = NULL;
    return pkt;
}

/* end */
