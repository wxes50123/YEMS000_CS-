/******************************************************************************
* NORTi TCP/IP Stack - TCP Module 1/2                                         *
*                                                                             *
*  Copyright (c) 1999-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05 Created.                                                         *
* 2000-10-03 Released as Ver.4.02                                             *
* 2001-01-22 Supported multi home and multi channel                           *
* 2001-01-22 Modified for the transfer of exceeding 4GB                       *
* 2001-02-10 Change tcp_con_cep (get port number)                             *
* 2001-04-06 Deleted cep->rpar = p_dstaddr in tcp_con_cep                     *
* 2001-09-14 Modified tcp_cls_cep for TMO_NBLK                                *
* 2002-04-04 Added initialization of cwnd and ssth                            *
* 2002-03-23 Modified tcp_acp_cep and tcp_con_cep for retransmission          *
* 2002-05-13 Added code for Keep alive timer                                  *
* 2002-06-24 Modified tcp_snd_dat                                             *
* 2002-06-24 Modified tcp_acp_cep and tcp_con_cep for flow control            *
* 2003-03-25 Modified for SNMP                                                *
* 2003-05-30 Modified for LoopBack interface                                  *
* 2004-07-01 Modified for IPv6 Stack                                       PK *
* 2004-10-27 tcp_del_cep and tcp_cls_cep fixed                             PK *
* 2004-11-11 Modified tcp_acp_cep and tcp_con_cep to validate tcp_iss      PK *
* 2005-04-08 Configurable MTU, TTL, TOS for TCP packets                       *
             Modified to bind with required interface                      AK *
* 2005-03-10 Modified TCP API's for Interface check                        AK *
* 2005-03-13 Modified V3 -> V4                                             AK *
* 2005-07-27 tcp_cre_rep: IPv4/6 same port number checking fixed           GS *
* 2006-07-29 SNMP Support for IPv6 added                                   MK *
* 2007-02-20 Modified tcp_rcv_buf for E_TMOUT, if it hit tcp_timeout       OK *
* 2007-03-06 Marged 4.09.05(inter) & 4.09.04e(FIX)                         OK *
* 2007-10-04 Modified incorrect 3rd parameter of SNMP_UPD_TCPLISTEN        EM *
* 2008-03-04 Fixed cep->nif no-check                                       OK *
* 2008-03-04 Replaced tcpip_critical() from tcpip_cretical() of old-style  OK *
* 2008-05-13 Improvement of TCP_REP/TCP_CEP/UDP_CEP loop                   OM *
* 2008-06-05 rmbxid2 is added for  remove_queued_packet                    GS *
* 2008-06-06 Added configurable timeout/retry parameters for each TCP_CEP  OM *
* 2008-07-18 switch-case indent is corrected                               GS *
* 2010-01-13 Fixed the problem that tcp_con_cep() doesn't return E_PAR     KZ *
*            when IP address of remote TCP is its interface                   *
* 2010-07-14 Replaced wait macro by MSEC2TICK macro                        FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2011-10-18 Corrected CEP search to connect in order of tcp_acp_cep call  FY *
* 2012-02-08 Improved ipaddr retrieval speed when not using multi-home     FY *
* 2012-02-09 Replaced is_ip_uniq by chk_ip_nif                             FY *
* 2012-02-09 Skipped processing of unused CEP/REPs using pTCP_xEP list     FY *
* 2012-03-01 Corrected insufficient exclusion control of tcp_cls_cep()     FY *
* 2012-03-02 Improved speed by excluding check of IP address type          FY *
* 2012-03-02 Modified tcp_cep_unused                                       FY *
* 2012-03-28 Fixed miss receiving of ACK for sent data with cycled SEQ=0   FY *
* 2012-03-28 Removed code which forbids ISN to be initialized to zero      FY *
* 2012-03-28 Fixed return of double ACK if Rx buffer is emptied from full  FY *
* 2012-03-29 Corrected tcp_del_rep() and tcp_can_cep() for exclusion          *
*             control, when called task priority is higher than PRI_TCPIP  FY *
* 2012-04-13 Fixed problem that CEP is used after call tcp_cep_unused()    FY *
* 2012-04-14 Renamed cep->ack to cep->rseq (remote sequence number),          *
*              and cep->seq to cep->risn (remote initial sequence number),    *
*              and cep->seq0 to cep->isn (local initial sequence number)   FY *
* 2012-05-15 Fixed to set cep->ip6addr when rep->ip6addr,nif are specified GS *
* 2012-05-26 Corrected setting of cep->ip6addr and cep->nif in tcp_con_cep GS *
* 2012-07-05 Modified tcp_con_cep() to get NIF with static route to remote FY *
* 2012-11-13 Accessed rep->type and cep->type                                 *
*                               only when DUAL_STK is effective            FY *
* 2012-11-13 Made maximum size of window buffer 65536 bytes,                  *
*                                                         and added check  FY *
* 2012-11-13 Abolished power-of-two restriction of TCP CEP's buffers          *
*              using added sgeti/sputi/rgeti/rputi for offset calculation  FY *
* 2012-11-13 Reduced ID variables size to UH (ex. cep->rtskid, stskid)     FY *
* 2013-01-24 Added support for TSopt (TCP time stamp option)               FY *
* 2013-06-18 Changed dcls_id type (UH->H) to avoid RXC misjadge with (-1)  FY *
* 2013-06-18 Fixed tcp_del_rep() to cancel all of related tcp_acp_cep()    FY *
* 2013-06-18 Added tcp_cre_cep_sub(), and reduced                             *
*                tcp_cre_cep()/tcp_vcre_cep() code by calling it commonly  FY *
* 2013-06-18 Replaced NADR (uITRON3 compatible) by NULL (uITRON4 standard) FY *
* 2013-07-04 Removed prot argument from chk_ip6_nif()                      FY *
* 2013-07-04 Added tcp_cre_rep_sub(), and reduced                             *
*                tcp_cre_rep()/tcp_vcre_rep() code by calling it commonly  FY *
* 2013-07-06 Fixed tcp_cls_cep with TMO_POL to send only RST without FIN   FY *
* 2013-08-30 Added ring_sub() for nontcp2.c in here to prevent inlining    MI *
* 2013-09-24 Reversed tcp_set_opt's TSecr=0 condition, re-enabling or not  FY *
* 2013-12-24 Added vcan_wup() after also tslp_tsk() to clear excessive        *
*                wake-up request in tcp_???_cep/tcp_???_dat/tcp_???_buf()  FY *
* 2013-12-24 Renamed SET_TCP_MTU to SET_TCP_MSS                            FY *
* 2014-01-30 Corrected failure in deleting entry from tcpConnTablete          *
*                       & tcpConnectionTable of MIB-2 in tcp_cep_unused()  HE *
* 2014-10-20 Replaced magic number to TSOPT_REQUEST/TSOPT_ENABLE macro     FY *
* 2015-04-22 Added missing wake-up for select() in tcp_cls_/tcp_sht_cep    FY *
* 2015-06-01 Added calling of tcp_timeout_update() for TCP timeout         FY *
* 2015-11-04 Fixed tcp_cls_cep() to cancel pending processed                  *
*                                                  first than state check  FY *
* 2016-07-13 Casted strlen() with (INT) to avoid warning                   MT *
* 2020-07-27 Modified tcp_iss setup in tcp_acp/con_cep() to randomize ISS  FY *
* 2021-06-22 Changed remove_queued_packet() 2nd parameter type ID -> T_ETH FY *
* 2022-03-26 Added missing include of nonsock.h when SOCK macro is defined GS *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"
#ifdef SOCK
#include "nonsock.h"
#endif

UH rwin_size(T_TCP_CEP *cep);
W ring_sub(UW a, UW b) { return (W)(a - b); }

/************************************************/
/* TCP Internal Error                           */
/************************************************/

#ifndef DEBUG
ER tcp_internal_error(ER ercd)
{
    return tcpip_internal_error(ercd);
}
#endif

/************************************************/
/* TCP Dummy Callback                           */
/************************************************/

ER tcp_dummy_cbk(ID cepid, FN fncd, VP parblk)
{
    return E_OK;
}

/******************************************************************************
* Module Name   : tcp_def_rep                                                 *
* Purpose       : This function is used to chain or remove enable reception   *
*                 point for TCP reception point                               *
* Arguments     : T_TCP_REP *b  - control block table                         *
*                 BOOL cr_flag  - TRUE:chain,  FALSE:remove                   *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
*******************************************************************************/

ER tcp_def_rep(T_TCP_REP *b, BOOL cr_flag)
{
    T_TCP_REP *bb, *bbb;

    bbb = (T_TCP_REP *)&pTCP_REP;
    bb = bbb->next;

    /* remove enable reception point if cr_flag == FALSE */
    if (!cr_flag) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;
                break;
            }
            bbb = bb;
            bb = bb->next;
        }
    }

    /* chain enable reception point if cr_flag == TRUE */
    else {
        for (;;) {
            if (bb == NULL)
            {   b->next = NULL;
                bbb->next = b;
                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }

    return E_OK;
}

/******************************************************************************
* Module Name   : tcp_def_cep                                                 *
* Purpose       : This function is used to chain or remove enable end point   *
*                 for TCP communication end point                             *
* Arguments     : T_TCP_CEP *b  - control block table                         *
*                 BOOL cr_flag  - TRUE:chain,  FALSE:remove                   *
* Return value  : E_OK on success otherwise returns error code.               *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

ER tcp_def_cep(T_TCP_CEP *b, BOOL cr_flag)
{
    T_TCP_CEP *bb, *bbb;
    T_NIF *nif;

    bbb = (T_TCP_CEP *)&pTCP_CEP;
    bb = bbb->next;

    /* remove enable end point if cr_flag == FALSE */
    if (!cr_flag) {
        for (;;) {
            if (bb == NULL)
                break;
            if (bb == b) {
                bbb->next = bb->next;

                /* Check multi home */
                nif = b->nif;
                if (nif != NULL && b->ipaddr != byte4_to_long(nif->ipaddr))
                    nif->multihome--;

                break;
            }
            bbb = bb;
            bb = bb->next;
        }
    }

    /* chain enable end point if cr_flag == TRUE */
    else {
        for (;;) {
            if (bb == NULL) {
                b->next = NULL;
                bbb->next = b;

                /* Check multi home */
                nif = b->nif;
                if (nif != NULL && b->ipaddr != byte4_to_long(nif->ipaddr))
                    nif->multihome++;

                break;
            }
            if (bb == b)
                break;
            bbb = bb;
            bb = bb->next;
        }
    }

    return E_OK;
}

/************************************************/
/* TCP Closing Common Process                   */
/************************************************/

void tcp_cep_unused(T_TCP_CEP *cep)
{
    if (!IS_USED(cep->state))
        return;

    /* Delete list of used cep */

    tcp_def_cep(cep, FALSE);

  #ifdef DUAL_STK
    if(cep->type == IPV6_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr,cep->portno, SNMP_INAT_IPV6, cep->dst6ipa, cep->dstpor, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr, cep->portno);
    } else {
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno, SNMP_INAT_IPV4, &cep->dstipa, cep->dstpor, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno);
    }
  #else
    SNMP_UPDTCP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
  #endif

  #ifdef DUAL_STK
    if (cep->type == IPV6_ADDR)
        memset(cep->ip6addr, 0, IP6_ADDR_SZ);
    else
  #endif
        cep->ipaddr = 0;

    cep->state = CEP_UNUSED;
    tcp_timeout_update(cep);
    cep->nif = cep->unif;

    if (cep->ackpkt != NULL) {
        rel_mpf(cep->ackpkt->ctl.mpfid, cep->ackpkt);
        cep->ackpkt = NULL;
    }
    cep->dcls_id = 0;
}

/******************************************************************************
* Module Name   : tcp_cep_ktime_init()                                        *
* Purpose       : Initial keep alive timer                                    *
* Arguments     : T_TCP_CEP *cep - TCP CEP structure address.                 *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

void tcp_cep_ktime_init(T_TCP_CEP *cep)
{
    if ((cep->itime = SYSCK.ltime) == 0)
        cep->itime = (UW)-1;

    cep->ktime = cep->tmo.ktime_tmo; /* Initial keep alive timeout */
}

/******************************************************************************
* Module Name   : tcp_cep_retry_init()                                        *
* Purpose       : Initial retry timer and count                               *
* Arguments     : T_TCP_CEP *cep - TCP CEP structure address.                 *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

void tcp_cep_retry_init(T_TCP_CEP *cep)
{
    if(cep->state == CEP_WAIT_P_OPEN || cep->state == CEP_WAIT_A_OPEN)
        cep->retry.retry_cnt = cep->tmo.syn_rcnt;
    else
        cep->retry.retry_cnt = cep->tmo.dat_rcnt;

    cep->retry.rto = cep->tmo.rto_ini;
    if (cep->retry.rto > cep->tmo.rto_max)
        cep->retry.rto = cep->tmo.rto_max;
    if (cep->retry.rto < cep->tmo.rto_min)
        cep->retry.rto = cep->tmo.rto_min;
}

/******************************************************************************
* Module Name   : tcp_cep_set_default_opt()                                   *
* Purpose       : set default timeout/retry parameters to TCP_CEP table       *
* Arguments     : T_TCP_CEP *cep - TCP CEP structure address.                 *
*                 T_NIF *nif - Network Interface address.                     *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

void tcp_cep_set_default_opt(T_TCP_CEP *cep, T_NIF *nif)
{
    if (cep == NULL)
        return;

    if (nif != NULL) {
        cep->tmo.rto_ini  = nif->tcp.rto_ini;
        cep->tmo.rto_min  = nif->tcp.rto_min;
        cep->tmo.rto_max  = nif->tcp.rto_max;

        cep->tmo.syn_rcnt = nif->tcp.syn_rcnt;
        cep->tmo.dat_rcnt = nif->tcp.dat_rcnt;

        cep->tmo.ktime_tmo = nif->tcp.ktime_tmo;
        cep->tmo.ktime_pro = nif->tcp.ktime_pro;
        cep->tmo.ktime_suc = nif->tcp.ktime_suc;

    } else {
        cep->tmo.rto_ini  = MSEC2TICK(TCP_RTO_INI);
        cep->tmo.rto_min  = MSEC2TICK(TCP_RTO_LBOUND);
        cep->tmo.rto_max  = MSEC2TICK(TCP_RTO_UBOUND);

        cep->tmo.syn_rcnt = (UH)TCP_SYN_RETRY;
        cep->tmo.dat_rcnt = (UH)TCP_DATA_RETRY;

        cep->tmo.ktime_tmo = (UW)TCP_KTIME_INI;
        cep->tmo.ktime_pro = (UW)TCP_KTIME_PRO;
        cep->tmo.ktime_suc = (UW)TCP_KTIME_SUC;
    }
}

/*****************************************************************************
* Create TCP REP Process
*
******************************************************************************/

static ER tcp_cre_rep_sub(T_TCP_REP *rep, const T_TCP_CREP *pk_crep)
{
    T_TCP_REP *r;
    UW a;
    UH n;
  #ifdef DUAL_STK
    T_NIF *nif;
  #endif

    if (!(is_nif_exists(NULL)))
        return E_LNK;   /* No Interface available */

    /* Parameter Check */

    if (pk_crep->myaddr.portno == TCP_PORTANY)
        return E_PAR;

    /* Error if Port Number Already Used */
    n = pk_crep->myaddr.portno;
  #ifdef DUAL_STK
    if (pk_crep->myaddr.type == IPV6_ADDR) {
        rep->type = IPV6_ADDR;
        rep->ipaddr = IPV4_ADDRANY;
        if (!is_ip6_addr_any(pk_crep->myaddr.ip6addr)) {
            /* �w�肳�ꂽIPv6�A�h���X������nif�̗L�����`�F�b�N */
            if ((nif = getnif_ip6addr(pk_crep->myaddr.ip6addr)) == NULL)
                return E_OBJ;

            /* ����IP�A�h���X���ʂ�I/F�ɂ��邩 */
            if (chk_ip6_nif(nif, pk_crep->myaddr.ip6addr))
                return E_OBJ;
        }
        for (r = pTCP_REP; r != NULL; r = r->next) {
            if (r->portno == n && r->type == IPV6_ADDR &&
                memcmp(r->ip6addr, pk_crep->myaddr.ip6addr, IP6_ADDR_SZ) == 0)
                return E_OBJ;
        }
        set_ip6_addr(rep->ip6addr, pk_crep->myaddr.ip6addr);
    }
    else
  #endif
    {
        a = pk_crep->myaddr.ipaddr;
      #ifdef DUAL_STK
        rep->type = IPV4_ADDR;
      #endif

        for (r = pTCP_REP; r != NULL; r = r->next) {
            if (r->portno == n && r->ipaddr == a
              #ifdef DUAL_STK
                && r->type == IPV4_ADDR
              #endif
                )
                return E_OBJ;
        }

        rep->ipaddr = a;
    }

    /* Setup TCP REP Control Block */

    rep->portno = n;
    tcp_def_rep(rep, TRUE);

    return E_OK;
}

/************************************************/
/* Create TCP Reception Point                   */
/************************************************/

ER tcp_cre_rep(ID repid, const T_TCP_CREP *pk_crep)
{
    T_TCP_REP *rep;
    PRI save_pri;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Parameter Check */

    repid--;
    if ((UINT)repid >= (UINT)TCP_REPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* Error if REP Already Created */

    rep = &TCP_REP[repid];
    if (rep->portno != 0) {
        ercd = E_OBJ;
        goto END;
    }

    ercd = tcp_cre_rep_sub(rep, pk_crep);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************/
/* Create TCP Reception Point (Auto ID Assigned)     */
/*****************************************************/

ER tcp_vcre_rep(const T_TCP_CREP *pk_crep)
{
    T_TCP_REP *rep;
    PRI save_pri;
    ER ercd;
    ID repid;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Search unused REP */

    for (repid = TCP_REPID_MAX;;) {
        if (repid == 0) {
            ercd = E_ID;
            goto END;
        }
        rep = &TCP_REP[--repid];
        if (rep->portno == 0)
            break;
    }

    ercd = tcp_cre_rep_sub(rep, pk_crep);

END:
    tcpip_critical(FALSE, &save_pri);
    return (ercd == E_OK) ? (ER)++repid : ercd;
}

/************************************************/
/* Delete TCP Reception Point                   */
/************************************************/

ER tcp_del_rep(ID repid)
{
    T_TCP_REP *rep;
    ER ercd=E_OK;
    T_TCP_CEP *cep;
    TCP_CALLBACK func;
    INT parblk;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    repid--;
    if ((UINT)repid >= (UINT)TCP_REPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* Error if REP Not Created */

    rep = &TCP_REP[repid];
    if (rep->portno == 0){
        ercd = E_NOEXS;
        goto END;
    }

    /* Clear TCP REP Control Block */
    rep->ipaddr = 0;
    rep->portno = 0;

    tcp_def_rep(rep, FALSE);

#ifdef DUAL_STK
    memset(rep->ip6addr, 0, IP6_ADDR_SZ);
#endif

    /* Search repid */
    for (cep = pTCP_CEP; cep != NULL; cep = cep->next) {
        if (cep->repid == repid) {
            /* cancel accept */
            if (cep->rfncd == TFN_TCP_ACP_CEP) {
                if (cep->rtskid != FALSE) {
                    ercd = rel_wai(cep->rtskid);
                    if (save_pri <= PRI_TCPIP)
                        rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */
                } else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
                    parblk = E_DLT;
                    cep->rfncd = 0;
                    (func)(cep->cepid, TFN_TCP_ACP_CEP, &parblk);
                    tcp_cep_unused(cep);
                }
            }
        }
    }

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*****************************************************************************
* Create TCP CEP Process
*
******************************************************************************/

static ER tcp_cre_cep_sub(T_TCP_CEP *cep, const T_TCP_CCEP *pk_ccep)
{
    ID cepid;
    if (!(is_nif_exists(NULL)))
        return E_LNK;   /* No Interface available */

    /* Parameter Check */

    if ((pk_ccep->sbuf == (VP)NULL) || (pk_ccep->sbufsz <= 0) || (pk_ccep->sbufsz > 65535) ||
        (pk_ccep->rbuf == (VP)NULL) || (pk_ccep->rbufsz <= 0) || (pk_ccep->rbufsz > 65535))
        return E_PAR;

    cepid = cep->cepid;
    memset(cep, 0, sizeof (T_TCP_CEP));
    cep->cepid = cepid;

    /* Setup TCP CEP Control Block */

    cep->state = CEP_UNUSED;
    cep->sbuf = (UB *)pk_ccep->sbuf;
    cep->sbufsz = (UH)pk_ccep->sbufsz;
    cep->rbuf = (UB *)pk_ccep->rbuf;
    cep->rbufsz = (UH)pk_ccep->rbufsz;

    tcp_cep_set_default_opt(cep, NULL);

    cep->callback = (TCP_CALLBACK)pk_ccep->callback;

    return E_OK;
}

/************************************************/
/* Create TCP Communication End Point           */
/************************************************/

ER tcp_cre_cep(ID cepid, const T_TCP_CCEP *pk_ccep)
{
    T_TCP_CEP *cep;
    PRI save_pri;
    ER ercd;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto ERR;
    }

    /* Error if CEP Already Created */

    cep = &TCP_CEP[cepid];
    if (IS_CREATED(cep->state)) {
        ercd = E_OBJ;
        goto ERR;
    }

    ercd = tcp_cre_cep_sub(cep, pk_ccep);

ERR:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/*********************************************************/
/* Create TCP Communication End Point (Auto ID Assigned) */
/*********************************************************/

ER tcp_vcre_cep(const T_TCP_CCEP *pk_ccep)
{
    T_TCP_CEP *cep;
    PRI save_pri;
    ER ercd;
    ID cepid;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Serch unused CEP */

    for (cepid = TCP_CEPID_MAX;;) {
        if (cepid == 0) {
            ercd = E_ID;
            goto ERR;
        }
        cep = &TCP_CEP[--cepid];
        if (!IS_CREATED(cep->state))
            break;
    }

    ercd = tcp_cre_cep_sub(cep, pk_ccep);

ERR:
    tcpip_critical(FALSE, &save_pri);
    return (ercd == E_OK) ? (ER)++cepid : ercd;
}

/************************************************/
/* Delete TCP Communication End Point           */
/************************************************/

ER tcp_del_cep(ID cepid)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)){
        ercd = E_NOEXS;
        goto END;
    }

    /* To support tcp_ext() */
    if (cep->ercd == E_LNK) {
        cep->state = 0;
        goto END;
    }

    if (IS_USED(cep->state)) {
        ercd = E_OBJ;
        goto END;
    }

    /* Clear TCP CEP Control Block */

    cep->state = 0;

    if (cep->nif != NULL){
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
        else
      #endif
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
    }

  #ifdef DUAL_STK
    if(cep->type == IPV6_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_IPV6,cep->dst6ipa,cep->dstpor, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV6, cep->ip6addr, cep->portno);
    }
    else{
        SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_IPV4,&cep->dstipa,cep->dstpor, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno);
    }
  #else
    SNMP_UPDTCP(SNMP_CSTS_DELETETCB, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
  #endif
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Wait for Connection Request                  */
/************************************************/

ER tcp_acp_cep(ID cepid, ID repid, T_IPV4EP *p_dstaddr, TMO tmout)
{
    T_TCP_CEP *cep;
    T_TCP_REP *rep;
    ER ercd=E_OK;
    T_NIF *nif;
    UW a=0;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    repid--;
    if ((UINT)repid >= (UINT)TCP_REPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* 04Jan2005 Validation for 'p_dstaddr' */
    if (p_dstaddr == NULL) {
        ercd = E_PAR;
        goto END;
    }

    /* State Check */

    rep = &TCP_REP[repid];
    if (rep->portno == 0) {
        ercd = E_NOEXS;
        goto END;
    }
    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }
    if (IS_USED(cep->state)) {
        ercd = E_OBJ;
        goto END;
    }

    cep->ipaddr = 0;    /* Need initialization */

    nif = cep->nif = cep->unif; /* Assign User Defined Interface */

    if (nif) {
        if (!(is_nif_exists(nif))) {
            ercd = E_LNK; /* Specified Interface not available */
            goto END;
        }
    }

#ifdef DUAL_STK
    if (rep->type == IPV6_ADDR) {
        memset(cep->dst6ipa, 0, IP6_ADDR_SZ);
        if (!is_ip6_addr_any(rep->ip6addr)) {
            if (cep->nif == NULL) {
                if ((cep->nif = getnif_ip6addr(rep->ip6addr)) == NULL) {
                    ercd = E_OBJ;
                    goto END;
                }
                nif = cep->nif;
            }
            else { /* Validate user assigned cep->nif */
                if (cep->nif != (getnif_ip6addr(rep->ip6addr))) {
                    ercd = E_OBJ;
                    goto END;
                }
            }
            set_ip6_addr(cep->ip6addr, rep->ip6addr);
        }
    }
    else
#endif
    {
        a = rep->ipaddr;
        if (a == IPV4_ADDRANY) {
            if (nif != NULL) {
                a = byte4_to_long(nif->ipaddr);
            }
        }
        else {
            if (nif == NULL) {
                nif = getnif_addr(a);
                if (nif == NULL) {
                    ercd = E_PAR;
                    goto END;
                }
                cep->nif = nif;
            }
            else {
                if (!(is_same_network(nif, a))) {
                    ercd = E_PAR;
                    goto END;
                }
            }

            /* check whether some other interface using this 'addr' */

            if (chk_ip_nif(nif, a)) {
                ercd = E_PAR;
                goto END;
            }
        }
    }

    /* Setup TCP CEP Control Block */
    cep->sflag = 0;
    cep->rflag = 0;
    cep->risn = 0;
    tcp_iss += tickck_read();
    cep->isn = cep->seq = cep->seq1 = cep->mseq = tcp_iss;
    tcp_iss &= 0x7FFFFFFF;
    cep->rseq = 0;
    cep->win = 0;
    cep->sgetp = 0;
    cep->sputp = 0;
    cep->rgetp = 0;
    cep->rputp = 0;
    cep->sgeti = 0;
    cep->sputi = 0;
    cep->rgeti = 0;
    cep->rputi = 0;
    cep->seqi = 0;
    cep->repid = (UH)repid;
    cep->ipaddr = a;
    cep->portno = rep->portno;
    cep->dstipa = 0;
    cep->dstpor = 0;
    cep->state = CEP_WAIT_P_OPEN;
  #ifdef DUAL_STK
    cep->type = rep->type;
  #endif

    /* Add AK-29-09-2002 */
    cep->sfncd = 0;
    cep->rfncd = 0;
    cep->stskid = FALSE;
    cep->rtskid = FALSE;

    /* Initializes the retransmission variables     */
    cep->time = 0;                  /* Retransmission timeout   */
    cep->retry.srtt = 0;            /* Initial srtt value       */
    cep->retry.rttvar = 3;          /* Initial rttvar */
    cep->retry.retries = 0;         /* Reset number of retries  */
    cep->retry.stat = 0;
    cep->retry.ref = 0;
    cep->retry.on  = 0;

    cep->dackcnt = 0;               /* Number of Delay ACK received */
    cep->dackmd = FALSE;            /* Receive ACK of retransmit packet */
    cep->sgetpf = 0 ;               /* Sequence of first delay ACK */
    cep->dackflag = 0;
    cep->hseq = FALSE;

    cep->ercd = E_OK;
    cep->rlen = 0;    /* Added 07Jul2005 - tcp_cls_cep using this for error check */

    if (cep->tsopt & TSOPT_REQUEST)
        cep->tsopt |= TSOPT_ENABLE;
    else
        cep->tsopt &= ~TSOPT_ENABLE;
    cep->tsecr = 0;

    tcp_cep_set_default_opt(cep, nif);

    if (nif != NULL) {
        cep->retry.rto = cep->tmo.rto_ini;
        cep->ktime     = cep->tmo.ktime_tmo;

#ifdef DUAL_STK
        if (cep->type == IPV6_ADDR) {
            cep->mss = nif->path_mtu6 - TCP_HEADER_SZ;

            if (cep->umtu != 0) {
                if (cep->umtu <= (nif->path_mtu6 - TCP_HEADER_SZ))
                    cep->mss = cep->umtu;
            }
        }
        else
#endif
        {
            cep->mss = nif->path_mtu - TCP_HEADER_SZ;

            if (cep->umtu != 0) {
                if (cep->umtu <= (nif->path_mtu - TCP_HEADER_SZ))
                    cep->mss = cep->umtu;
            }
        }
    }
    else {
        cep->retry.rto = 0;         /* Will be filled after receive SYN */
        cep->ktime     = 0;
#ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            cep->mss = ETHERNET_MTU - IP6_HEADER_SZ - TCP_HEADER_SZ;
        else
#endif
            cep->mss = ETHERNET_MTU - IP4_HEADER_SZ - TCP_HEADER_SZ;
    }

    /*  Added AK - Initialize keep alive timeout */
    if ((cep->itime = SYSCK.ltime) == 0)
        cep->itime = (UW)-1;

    /* Add YS-020404-002 */
    cep->cwnd = cep->mss * 2;
    cep->smax = cep->cwnd;
    cep->ssth = 0xFFFF;

#ifdef DUAL_STK
    if(cep->ip6addr[0] == 0 && cep->ipaddr == 0){
        SNMP_UPDTCP(SNMP_CSTS_LISTEN,SNMP_INAT_UNKNOWN, &cep->ipaddr, cep->portno, SNMP_INAT_UNKNOWN,NULL, 0, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_LISTEN, SNMP_INAT_UNKNOWN, &cep->ipaddr, cep->portno);
    }
    else if(cep->type == IPV6_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_LISTEN,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_UNKNOWN,NULL,0, 0);/*because here we dont know the remote address and port number of the client*/
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_LISTEN, SNMP_INAT_IPV6, cep->ip6addr, cep->portno);
    }
    else if(cep->type == IPV4_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_LISTEN,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_UNKNOWN,NULL,0, 0);
        SNMP_UPD_TCPLISTEN(SNMP_CSTS_LISTEN, SNMP_INAT_IPV4, &cep->ipaddr, cep->portno);
    }
#else
    SNMP_UPDTCP(SNMP_CSTS_LISTEN, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
#endif

    /* Entry list of used cep */

    tcp_def_cep(cep, TRUE);

    /* Return if Non-Blocking Call */

    cep->rpar = p_dstaddr;
    cep->rfncd = TFN_TCP_ACP_CEP;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Connection Request */

    cep->rtskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) { /* Interface deleted */
            ercd = cep->rlen;
            goto END;
        }
    }

    /* 04Jan2005 Return E_CLS only when receive RST */
    if (ercd == E_OK && cep->state != CEP_CONNECTING) {
        if (cep->rflag & RST_FLAG)
            ercd = E_CLS;
        else
            ercd = E_TMOUT;
    }

    if ((ercd == E_RLWAI) && (rep->portno == 0))
        ercd = E_DLT;

    cep->rfncd = 0;
    cep->rtskid = FALSE;
    if (ercd != E_OK) {
        SNMP_BYPCNT(snmp_mibbyp.tcpAttemptFails, 1);  /* tcpAttemptFails */
        tcp_cep_unused(cep);
    }

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Request Connection                           */
/************************************************/

ER tcp_con_cep(ID cepid, const T_IPV4EP *p_myaddr, T_IPV4EP *p_dstaddr, TMO tmout)
{
    T_TCP_REP *r;
    T_TCP_CEP *cep, *c;
    ER ercd=E_OK;
    UW a;
    UH n;
    T_NIF *nif;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* 04Jan2005 Validation for 'p_myaddr' and 'p_dstaddr' */

    if (p_myaddr == NULL || p_dstaddr == NULL) {
        ercd = E_PAR;
        goto END;
    }

#ifdef DUAL_STK
    if (p_myaddr->type == IPV6_ADDR) {

        if ((is_ip6_addr_any(p_dstaddr->ip6addr)) || (p_dstaddr->portno == 0)) {
            ercd = E_PAR;
            goto END;
        }
    }
    else
#endif
    {
        if ((p_dstaddr->ipaddr == 0) || (p_dstaddr->portno == 0)) {
            ercd = E_PAR;
            goto END;
        }
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (IS_USED(cep->state)) {
        ercd = E_OBJ;
        goto END;
    }

    nif = cep->nif = cep->unif; /* Assign User Defined Interface */

    if (nif) {
        if (!(is_nif_exists(nif))) {
            ercd = E_LNK; /* Specified Interface not available */
            goto END;
        }
    }

#ifdef DUAL_STK
    if (p_myaddr->type == IPV6_ADDR) {
        cep->type = IPV6_ADDR;
        cep->ipaddr = IPV4_ADDRANY;

        if (is_ip6_addr_any(p_myaddr->ip6addr)) {
            if (nif == NULL) {
                nif = getnif_dst6addr(p_dstaddr->ip6addr);
                if (nif == NULL) {
                    ercd = E_PAR;
                    goto END;
                }
            }
            set_ip6_addr((UW *)p_myaddr->ip6addr, set_src_addr(nif, p_dstaddr->ip6addr));
        } else {
            if (nif == NULL) {
                nif = getnif_ip6addr(p_myaddr->ip6addr);
                if (nif == NULL) {
                    ercd = E_PAR;
                    goto END;
                }
            }

            if (!is_myip6addr(nif, (UW *)p_myaddr->ip6addr)) {
                ercd = E_OBJ;
                goto END;
            }

            /* ����IP�A�h���X���ʂ�I/F�ɂ��邩 */
            if (chk_ip6_nif(nif, p_myaddr->ip6addr)) {
                ercd = E_OBJ;
                goto END;
            }
        }

        if (nif->type != NI_LOOP && is_myip6addr(nif, p_dstaddr->ip6addr)) {
            ercd = E_PAR;
            goto END;
        }

        n = p_myaddr->portno;
        /* 11/Jul/02 - Modified AK */
        if (n == TCP_PORTANY) {
            n = tcp_portany();
        } else {
            for (r = pTCP_REP; r != NULL; r = r->next) {
                if (r->portno == n && memcmp(r->ip6addr, p_myaddr->ip6addr, IP6_ADDR_SZ) == 0) {
                    ercd = E_OBJ;
                    goto END;
                }
            }
            for (c = pTCP_CEP; c != NULL; c = c->next) {
                if (c->portno == n
                    && memcmp(c->ip6addr, p_myaddr->ip6addr, IP6_ADDR_SZ) == 0) {
                    ercd = E_OBJ;
                    goto END;
                }
            }
        }

        set_ip6_addr(cep->ip6addr, p_myaddr->ip6addr);
        set_ip6_addr(cep->dst6ipa, p_dstaddr->ip6addr);
        /* Add 20Apr2003 */
        cep->mss = TCP_MTU6;

        /* Add YS-020404-002 */
        cep->cwnd = TCP_MTU6 * 2;
    }
    else
#endif
    {
      #ifdef DUAL_STK
        cep->type = IPV4_ADDR;
      #endif
        a = p_myaddr->ipaddr;
        if (a == IPV4_ADDRANY) {
            if (nif == NULL) {
                nif = getnif_dstaddr(p_dstaddr->ipaddr);
                if (nif == NULL) {
                    ercd = E_PAR;
                    goto END;
                }
            }
            a = byte4_to_long(nif->ipaddr);
        }
        else {
            if (nif == NULL) {
                /* if addr not matches with local network of all interface */
                nif = getnif_addr(a);
                if (nif == NULL) {
                    ercd = E_PAR;
                    goto END;
                }
            }
            else {
                if (!(is_same_network(nif, a))) {
                    ercd = E_PAR;
                    goto END;
                }
            }

            /* check whether some other interface using this 'addr' */

            if (chk_ip_nif(nif, a)) {
                ercd = E_PAR;
                goto END;
            }
        }

        /* dstipaddr should not be a ipaddress of local host.
           This cannot be allowed unless loopback interface is enabled. */
        if (nif->type != NI_LOOP) {
            if (is_nif_ipaddr(nif, p_dstaddr->ipaddr)) {
                ercd = E_PAR;
                goto END;
            }
        }

        /* Now, nif, address are valid, check for Port */

        n = p_myaddr->portno;
        if (n == TCP_PORTANY) {
            n = tcp_portany();
        } else {
            for (r = pTCP_REP; r != NULL; r = r->next) {
                if (r->portno == n && r->ipaddr == a) {
                    ercd = E_OBJ;
                    goto END;
                }
            }
            for (c = pTCP_CEP; c != NULL; c = c->next) {
                if (c->portno == n && c->ipaddr == a) {
                    ercd = E_OBJ;
                    goto END;
                }
            }
        }

        cep->ipaddr = a;
        cep->dstipa = p_dstaddr->ipaddr;
    }

    /* Now, nif, ipaddr, port all are valid */

    cep->nif = nif;

    cep->ercd = E_OK;
    cep->rlen = 0;    /* Added 07Jul2005 - tcp_cls_cep using this for error check */

    /* Setup TCP CEP Control Block */
    cep->sflag = SYN_FLAG;
    cep->rflag = 0;
    cep->risn = 0;
    tcp_iss += tickck_read();
    cep->isn = cep->seq = cep->seq1 = cep->mseq = tcp_iss;
    tcp_iss &= 0x7FFFFFFF;
    cep->rseq = 0;
    cep->win = 0;
    cep->sgetp = 0;
    cep->sputp = 0;
    cep->rgetp = 0;
    cep->rputp = 0;
    cep->sgeti = 0;
    cep->sputi = 0;
    cep->rgeti = 0;
    cep->rputi = 0;
    cep->seqi = 0;
    cep->repid = 0;
    cep->portno = n;
    cep->dstpor = p_dstaddr->portno;
    cep->state = CEP_WAIT_A_OPEN;

    /* Add 02Jun2004 */
#ifdef DUAL_STK
    if (cep->type == IPV6_ADDR) {
        cep->mss = nif->path_mtu6 - TCP_HEADER_SZ;

        if (cep->umtu != 0) {
            if (cep->umtu <= (nif->path_mtu6 - TCP_HEADER_SZ))
                cep->mss = cep->umtu;
        }
    }
    else
#endif
    {
        cep->mss = nif->path_mtu - TCP_HEADER_SZ;

        if (cep->umtu != 0) {
            if (cep->umtu <= (nif->path_mtu - TCP_HEADER_SZ))
                cep->mss = cep->umtu;
        }
    }
    /* Add YS-020404-002 */
    cep->cwnd = cep->mss * 2;
    cep->smax = cep->cwnd;
    cep->ssth = 0xFFFF;

    /* Add AK-29-09-2002 */
    cep->sfncd = 0;
    cep->rfncd = 0;
    cep->stskid = FALSE;
    cep->rtskid = FALSE;

    /* Initializes the retransmission variables     */
    cep->time = 0;                      /* Retransmission timeout   */
    tcp_cep_set_default_opt(cep, nif);
    cep->retry.rto = cep->tmo.rto_ini;  /* Initial RTO */
    cep->retry.srtt = 0;                /* Initial srtt value       */
    cep->retry.rttvar = 3;              /* Initial rttvar */
    cep->retry.retries = 0;             /* Reset number of retries  */
    cep->retry.stat = 0;
    cep->retry.ref = 0;
    cep->retry.on  = 0;

    cep->dackcnt = 0;               /* Number of Delay ACK received */
    cep->dackmd = FALSE;            /* Receive ACK of retransmit packet */
    cep->sgetpf = 0 ;               /* Sequence of first delay ACK */
    cep->dackflag = 0;
    cep->hseq = FALSE;

    if (cep->tsopt & TSOPT_REQUEST)
        cep->tsopt |= TSOPT_ENABLE;
    else
        cep->tsopt &= ~TSOPT_ENABLE;
    cep->tsecr = 0;

    /*  Added AK - Initialize keep alive timeout */
    tcp_cep_ktime_init(cep);

    /* Entry list of used cep */

    tcp_def_cep(cep, TRUE);

    /* Send SYN */

    tcp_transmit(cep);

    SNMP_BYPCNT(snmp_mibbyp.tcpActiveOpens, 1);  /* tcpActiveOpens */
#ifdef DUAL_STK
    if(cep->type == IPV6_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_SYNSENT,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_IPV6,cep->dst6ipa,cep->dstpor, 0);
    }
    else {
        SNMP_UPDTCP(SNMP_CSTS_SYNSENT,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_IPV4, &cep->dstipa,cep->dstpor, 0);
    }
#else
    SNMP_UPDTCP(SNMP_CSTS_SYNSENT, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
#endif

    /* Return if Non-Blocking Call */

    cep->rfncd = TFN_TCP_CON_CEP;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Connection */

    cep->rtskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();
    cep->rfncd = 0;
    cep->rtskid = FALSE;

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) { /* Interface deleted */
            ercd = cep->rlen;
            goto END;
        }
    }

    if (ercd != E_OK) {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
        else
      #endif
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
        tcp_cep_unused(cep);
    } else if (cep->state != CEP_CONNECTING) {
        /* 04Jan2005 Return E_CLS only when receive RST */
        if (cep->rflag & RST_FLAG)
            ercd = E_CLS;
        else
            ercd = E_TMOUT;

        if (IS_USED(cep->state)) {
      #ifdef DUAL_STK
            if (cep->type == IPV6_ADDR)
                remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
            else
      #endif
                remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
            tcp_cep_unused(cep);
        }
      #ifdef DUAL_STK
        cep->type = 0;
      #endif
        SNMP_BYPCNT(snmp_mibbyp.tcpAttemptFails, 1);  /* tcpAttemptFails */
    }
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Terminate Data Transmission                  */
/************************************************/

ER tcp_sht_cep(ID cepid)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

  #ifdef SOCK /* check for read or write half close */
    wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if (cep->state != CEP_CONNECTING) {
        ercd = E_OBJ;
        goto END;
    }

    /* Mod 21-Sep-2004 Send FIN immediatly after data transmission */

    cep->sflag |= FIN_FLAG;
    cep->state = CEP_TERMINATED;

    /* Send FIN now if no data pending for transmission */
    if (cep->sputp == cep->sgetp)
        tcp_transmit(cep);
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Close TCP Communication End Point            */
/************************************************/

ER tcp_cls_cep(ID cepid, TMO tmout)
{
    TCP_CALLBACK func;
    T_TCP_CEP *cep;
    ER ercd, ercdt;
    INT parblk;
    PRI save_pri;

    ercd  = E_OK;
    ercdt = E_RLWAI;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (cep->state == 0) {
        ercd = E_NOEXS;
        goto END;
    }

  #ifdef SOCK /* check for read or write half close */
    wup_sel_tsk(cep->cepid, SOCK_STREAM);
  #endif

    /* The interface already deleted ? */
    if (cep->ercd == E_LNK) {
        if (cep->state == CEP_WAIT_P_OPEN)
            cep->repid = 0;
        if (cep->unif == NULL)
            ercd = E_RLWAI;
        else
            ercd = cep->ercd;
        goto END;
    }

    /* Cancel any pending processes */

    if (cep->rfncd != 0) {
        /* 04Jan2005 Error if closing process is already pending */
        if ((cep->dcls_id == -1) || (cep->rfncd == TFN_TCP_CLS_CEP)) {
            ercd = E_OBJ;
            goto END;
        }
        if (cep->rtskid != 0) {
            rel_wai(cep->rtskid);
            rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */
        }
        /* 19Oct2004 Corrected 'func' initialization */
        else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_RLWAI;
            (func)(cep->cepid, cep->rfncd, &parblk);
        }
    }

    if (cep->sfncd != 0) {
        if (cep->stskid != 0) {
            rel_wai(cep->stskid);
            rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */
        }
        /* 19Oct2004 Corrected 'func' initialization */
        else if ((func = cep->callback) != (TCP_CALLBACK)NULL) {
            parblk = E_RLWAI;
            (func)(cep->cepid, cep->sfncd, &parblk);
        }
    }

    /* State Check */

    if (cep->state == CEP_DISCONNECTED) {
        tcp_cep_unused(cep);
        goto END;
    }
    if (cep->state == CEP_WAIT_P_OPEN) {
        cep->repid = 0;
        tcp_cep_unused(cep);
        goto END;
    }
    if ((cep->state != CEP_CONNECTING) && (cep->state != CEP_TERMINATED)) {
        ercd = E_OBJ;
        goto END;
    }

    /* Send FIN if Connecting */

    if ((cep->state == CEP_CONNECTING || cep->state == CEP_TERMINATED) &&
        tmout != TMO_POL) {

        /* Send RST recv window is zero - AK */
        if (rwin_size(cep) == 0) {
            ercd = E_RLWAI;
            ercdt = E_OK;
            goto ERR;
        }

        /* If in CEP_TERMINATED state,
           # If FIN is not yet transmitted then wait until tx buffer become empty.
           # Close the connection if our FIN is acked and also received FIN from remote.
           # Move to CEP_CLOSING state if FIN is already transmitted and waiting for
             ACK (or FIN) from remote host.
        */
        if ((cep->sputp == (cep->seq - cep->isn)) ||
            (cep->state == CEP_TERMINATED && (cep->sputp == (cep->seq - 1 - cep->isn)))) {

            if (cep->state == CEP_TERMINATED) {
                /* Here, FIN might have been transmitted */

                /* Check FIN has acked */

                if ((!(cep->sflag & FIN_FLAG)) && (cep->rflag & FIN_FLAG)) {
                    /* FIN has been acked and also received FIN from remote host */
                    /* and close process is over */
                    tcp_cep_unused(cep);
                    goto END;
                }
            }
            else {
                /* Window Buffer Empty */
                cep->sflag |= FIN_FLAG;
                tcp_transmit(cep);
            }
        }
        else if (tmout == TMO_NBLK) {
            if (cep->state != CEP_TERMINATED)
                cep->sflag |= FIN_FLAG;
            cep->dcls_id = -1;
            ercd = E_WBLK;
            goto END;
        }
        else {
            cep->rfncd = TFN_TCP_CLS_CEP;
            vcan_wup();
            cep->dcls_id = (H)vget_tid();
            ercd = tslp_tsk(tmout);
            vcan_wup();
            cep->dcls_id = 0;
            if (ercd == E_TMOUT) {
                SNMP_BYPCNT(snmp_mibbyp.tcpEstabResets, 1);  /* tcpEstabResets */
            }
            if (ercd != E_OK)
                 goto ERR;
            else {  /* 04Jan2005 Return appropriate error value */
                if ((cep->rlen == E_CLS) || (cep->rlen == E_TMOUT))
                    goto ERR;
            }

            if (ercd == E_OK && cep->state != CEP_DISCONNECTED) {
                if (cep->state != CEP_TERMINATED) {
                    cep->sflag |= FIN_FLAG;
                    tcp_transmit(cep);
                }
                /* Mod 21-Sep-2004 - Is closing process finish? */
                else if (cep->rflag & FIN_FLAG) {
                    tcp_cep_unused(cep);
                    goto END;
                }
            }
            else {
                ercd = E_OBJ;
                goto ERR;
            }
        }
    }

    cep->state = CEP_CLOSING;
#ifdef DUAL_STK
    if(cep->type == IPV6_ADDR){
        SNMP_UPDTCP(SNMP_CSTS_CLOSING,SNMP_INAT_IPV6, cep->ip6addr,cep->portno ,SNMP_INAT_IPV6,cep->dst6ipa,cep->dstpor, 0);
    }
    else {
        SNMP_UPDTCP(SNMP_CSTS_CLOSING,SNMP_INAT_IPV4, &cep->ipaddr,cep->portno ,SNMP_INAT_IPV4,&cep->dstipa,cep->dstpor, 0);
    }
#else
    SNMP_UPDTCP(SNMP_CSTS_CLOSING, cep->ipaddr, cep->portno, cep->dstipa, cep->dstpor);
#endif
    /* Return if Non-Blocking Call */

    cep->rfncd = TFN_TCP_CLS_CEP;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for FIN Receiving */

    cep->rtskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();

    /* Return E_OK if timeout and reception of FIN or ACK */
    /* occurs at the same time                            */
    if (ercd == E_TMOUT && cep->rtskid == FALSE) {
        /* Response has received and closed successfully */
        ercd = E_OK;
    }

ERR:

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) { /* Interface deleted */
            ercd = cep->rlen;
            goto END;
        }
    }

    if((ercd == E_TMOUT) || (ercd == E_RLWAI)) {
        cep->sflag = (ACK_FLAG|RST_FLAG);
        tcp_transmit(cep);
        cep->sflag = 0;
    }

    cep->rfncd = 0;
    cep->rtskid = FALSE;
    if (ercd != E_OK){
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
        else
      #endif
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
    } else {
        /* RST received or retransmission time out */
        if (cep->rlen == E_CLS)
            ercd = E_CLS;
        else if (cep->rlen == E_TMOUT)
            ercd = E_TMOUT;
    }

    tcp_cep_unused(cep);

    if (ercdt == E_OK) ercd = E_OK;

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Send TCP Packet                              */
/************************************************/

ER tcp_snd_dat(ID cepid, const VP data, INT len, TMO tmout)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    UW sputp;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* 04Jan2004 Validation for 'data' */
    if (data == NULL) {
        ercd = E_PAR;
        goto END;
    }

    if (len <= 0) {
        ercd = E_PAR;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if (cep->state == CEP_DISCONNECTED) {
        ercd = E_CLS;
        goto END;
    }
    if (cep->state != CEP_CONNECTING || cep->sfncd != 0) {
        ercd = E_OBJ;
        goto END;
    }

    /* 04Jan2005 Closing connection. Cannot send any more data */
    if (cep->rfncd == TFN_TCP_CLS_CEP) {
        ercd = E_OBJ;
        goto END;
    }

    /* Free Size Check and Data Copy */

    ercd = tcp_put_sdat(cep, data, len);
    if (ercd > 0){
        tcp_transmit(cep);
        goto END;
    }
    if (ercd != E_OK)
        goto END;
    cep->spar = (VP)data;
    cep->slen = len;
    sputp = cep->sputp;

    /* Return if Non-Blocking Call */

    cep->sfncd = TFN_TCP_SND_DAT;
    if (tmout == TMO_NBLK){
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Buffer Empty */

    cep->stskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();
    cep->sfncd = 0;

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) /* Interface deleted */
            goto END;
    }

    cep->stskid = FALSE;
    if (ercd == E_OK || sputp != cep->sputp)
        ercd = cep->slen;
    else {
      #ifdef DUAL_STK
        if (cep->type == IPV6_ADDR)
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->na_waiting, cep);
        else
      #endif
            remove_queued_packet(cep->nif->smbxid, (T_ETH *)&cep->nif->arp_waiting, cep);
    }
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Receive TCP Packet                           */
/************************************************/

ER tcp_rcv_dat(ID cepid, VP data, INT len, TMO tmout)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* 04Jan2004 Validation for 'data' */
    if (data == NULL) {
        ercd = E_PAR;
        goto END;
    }

    if (len <= 0) {
        ercd = E_PAR;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    /* 04Jan2004 Return E_CLS if state is in CEP_DISCONNECTED */
    if (((cep->state != CEP_CONNECTING) && (cep->state != CEP_TERMINATED)
        && (cep->state != CEP_DISCONNECTED)) || (cep->rfncd != 0)) {
        ercd = E_OBJ;
        goto END;
    }

    /* Data Copy */

    ercd = tcp_get_rdat((UB *)data, cep, len);
    if (ercd > 0)
        goto END;

    /* End of Data ? */

    if (cep->state == CEP_DISCONNECTED) {
        ercd = E_CLS;
        goto END;
    }
    if (cep->rflag & FIN_FLAG)
        goto END;

    /* Return if Non-Blocking Call */

    cep->rpar = data;
    cep->rlen = len;
    cep->rfncd = TFN_TCP_RCV_DAT;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Data */

    cep->rtskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) /* Interface deleted */
            goto END;
    }

    cep->rfncd = 0;
    cep->rtskid = FALSE;

    /* Data Copy */

    len = tcp_get_rdat((UB *)data, cep, len);
    if (len > 0) {
        ercd = len;
    }
    else {
        if (ercd == E_OK && cep->rlen < 0)
            ercd = cep->rlen;
    }

    if (ercd == E_OK || (ercd == E_TMOUT && len != 0))
        ercd = len;
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Get Sending Buffer                           */
/************************************************/

ER tcp_get_buf(ID cepid, VP *p_buf, TMO tmout)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if (cep->state == CEP_DISCONNECTED) {
        ercd = E_CLS;
        goto END;
    }
    if (cep->state != CEP_CONNECTING || cep->sfncd != 0) {
        ercd = E_OBJ;
        goto END;
    }

    /* Get Buffer */

    ercd = tcp_get_sbuf((UB **)p_buf, cep);
    if (ercd > 0)
        goto END;
    if (ercd != E_OK)
        goto END;
    cep->spar = p_buf;
    cep->slen = 0;

    /* Return if Non-Blocking Call */

    cep->sfncd = TFN_TCP_GET_BUF;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Buffer Empty */

    cep->stskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) /* Interface deleted */
            goto END;
    }

    cep->sfncd = 0;
    cep->stskid = FALSE;
    if (ercd == E_OK)
        ercd = cep->slen;
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Send Data in Buffer                          */
/************************************************/

ER tcp_snd_buf(ID cepid, INT len)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    if (len <= 0) {
        ercd = E_PAR;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if (cep->state != CEP_CONNECTING || cep->sfncd != 0) {
        ercd = E_OBJ;
        goto END;
    }
    if (cep->state == CEP_DISCONNECTED || (cep->rflag & FIN_FLAG)) {
        ercd = E_CLS;
        goto END;
    }

    /* Update Buffer Pointers */

    ercd = tcp_put_sbuf(cep, len);
    if (ercd == E_OK)
        tcp_transmit(cep);
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Get Buffer Containing Received Data          */
/************************************************/

ER tcp_rcv_buf(ID cepid, VP *p_buf, TMO tmout)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    INT len;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if (((cep->state != CEP_CONNECTING) && (cep->state != CEP_TERMINATED))
     || (cep->rfncd != 0)) {
        ercd = E_OBJ;
        goto END;
    }

    /* Get Buffer */

    ercd = tcp_get_rbuf((UB **)p_buf, cep);
    if (ercd > 0)
        goto END;

    /* End of Data ? */

    if (cep->state == CEP_DISCONNECTED) {
        ercd = E_CLS;
        goto END;
    }
    if (cep->rflag & FIN_FLAG)
        goto END;

    /* Return if Non-Blocking Call */

    cep->rpar = p_buf;
    cep->rfncd = TFN_TCP_RCV_BUF;
    if (tmout == TMO_NBLK) {
        ercd = E_WBLK;
        goto END;
    }

    /* Wait for Data */

    cep->rtskid = (UH)vget_tid();
    vcan_wup();
    ercd = tslp_tsk(tmout);
    vcan_wup();

    /* To support tcp_ext() */
    if ((ercd == E_RLWAI) && cep->ercd != E_OK) {
        ercd = cep->ercd;
        if (ercd == E_LNK) /* Interface deleted */
            goto END;
    }

    cep->rfncd = 0;
    cep->rtskid = FALSE;

    /* Data Copy */

    len = tcp_get_rbuf((UB **)p_buf, cep);
    if (len > 0) {
        ercd = len;
    }
    else {
        if (ercd == E_OK && cep->rlen < 0)
            ercd = cep->rlen;
    }

    if (ercd == E_OK || (ercd == E_TMOUT && len != 0))
       ercd = len;
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Release Receiving Buffer                     */
/************************************************/

ER tcp_rel_buf(ID cepid, INT len)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    if (len <= 0) {
        ercd = E_PAR;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    if ((cep->state != CEP_CONNECTING) && (cep->state != CEP_TERMINATED)) {
        ercd = E_OBJ;
        goto END;
    }

    /* Release Buffer */

    ercd = tcp_rel_rbuf(cep, len);

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Send Urgent Data                             */
/************************************************/

ER tcp_snd_oob(ID cepid, const VP data, INT len, TMO tmout)
{
    if (!(is_nif_exists(NULL)))
        return E_LNK; /* No Interface available */

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX)
        return E_ID;
    if (len <= 0)
        return E_PAR;

    return E_NOSPT;
}

/************************************************/
/* Receive Urgent Data                          */
/************************************************/

ER tcp_rcv_oob(ID cepid, VP data, INT len)
{
    if (!(is_nif_exists(NULL)))
        return E_LNK; /* No Interface available */

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX)
        return E_ID;
    if (len <= 0)
        return E_PAR;

    return E_NOSPT;
}

/************************************************/
/* Cancel Pending TCP Process                   */
/************************************************/

ER tcp_can_cep(ID cepid, FN fncd)
{
    T_TCP_CEP *cep;
    ER ercd=E_OK;
    BOOL flg=FALSE;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (cep->ercd == E_LNK) {
        ercd = E_LNK; /* Interface not exists */
        goto END;
    }

    switch (fncd) {
    case TFN_TCP_ALL:
    case TFN_TCP_ACP_CEP:
        if (cep->rfncd != TFN_TCP_ACP_CEP)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->rfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->rfncd = 0;
        }
        if(fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_CON_CEP:
        if (cep->rfncd != TFN_TCP_CON_CEP)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->rfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->rfncd = 0;
        }
        if (fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_CLS_CEP:

        /* 04Jan2005 Invoke callback function */
        if ((cep->state == CEP_CONNECTING) && (cep->dcls_id == -1)
            && (cep->rfncd == 0)) {
            cep->rfncd = TFN_TCP_CLS_CEP;
        }

        if (cep->rfncd != TFN_TCP_CLS_CEP)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->rfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->rfncd = 0;
        }
        if (fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_SND_DAT:
        if (cep->sfncd != TFN_TCP_SND_DAT)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->sfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->sfncd = 0;
        }
        if (fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_RCV_DAT:
        if (cep->rfncd != TFN_TCP_RCV_DAT)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->rfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->rfncd = 0;
        }
        if (fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_GET_BUF:
        if (cep->sfncd != TFN_TCP_GET_BUF)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->sfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->sfncd = 0;
        }
        if (fncd != TFN_TCP_ALL)
            break;

    case TFN_TCP_RCV_BUF:
        if (cep->rfncd != TFN_TCP_RCV_BUF)
            ercd = E_OBJ;
        else {
            if ((ercd = tcp_can_cep2(cep, cep->rfncd)) != E_OK)
                goto END;
            flg = TRUE;
            cep->rfncd = 0;
        }
        break;

    case TFN_TCP_SND_OOB:
        ercd = E_NOSPT;
        break;

    default:
        ercd = E_PAR;
        break;
    }

    if (flg == TRUE)
       ercd = E_OK;

END:
    if (save_pri <= PRI_TCPIP)
        rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************************/
/* Set TCP Communication End Point timeout/retry parameters */
/************************************************************/

static ER tcp_cep_set_opt(ID cepid, INT optname, const VP optval, INT optlen)
{
    ER ercd = E_OK;
    T_TCP_CEP *cep;
    UW tval;
    UH val;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    if (optval == NULL) {
        ercd = E_PAR;
        goto END;
     }

    /* Error if CEP Not Created */

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    /* state is CEP_CONNECTING only */
    if (cep->state != CEP_CONNECTING) {
        ercd = E_OBJ;
        goto END;
    }

    switch (optname) {
    case SET_TCP_DAT_RCNT:
        if (optlen != sizeof(UH)) {
            ercd = E_PAR;
            goto END;
        }
        val = *((UH *)(optval));
        cep->tmo.dat_rcnt = val;
        tcp_cep_retry_init(cep);
        break;
    case SET_TCP_RTO_INI:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.rto_ini = tval;
        tcp_cep_retry_init(cep);
        break;
    case SET_TCP_RTO_MIN:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.rto_min = tval;
        tcp_cep_retry_init(cep);
        break;
    case SET_TCP_RTO_MAX:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.rto_max = tval;
        tcp_cep_retry_init(cep);
        break;
    case SET_TCP_KEEPALIVE_TMO:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.ktime_tmo = tval;
        tcp_cep_ktime_init(cep);
        tcp_timeout_update(cep);
        break;
    case SET_TCP_KEEPALIVE_PRO:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.ktime_pro = tval;
        tcp_cep_ktime_init(cep);
        tcp_timeout_update(cep);
        break;
    case SET_TCP_KEEPALIVE_SUC:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval = *((UW *)(optval));
        cep->tmo.ktime_suc = tval;
        tcp_cep_ktime_init(cep);
        tcp_timeout_update(cep);
        break;
    default:
        optlen = 0;
        ercd = E_NOSPT;
    }

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************************/
/* Get TCP Communication End Point timeout/retry parameters */
/************************************************************/

static ER tcp_cep_get_opt(ID cepid, INT optname, VP optval, INT optlen)
{
    ER ercd = E_OK;
    T_TCP_CEP *cep;
    UW *tval;
    UH *val;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    if (optval == NULL) {
        ercd = E_PAR;
        goto END;
     }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    switch (optname) {
    case SET_TCP_DAT_RCNT:
        if (optlen != sizeof(UH)) {
            ercd = E_PAR;
            goto END;
        }
        val  = (UH *)optval;
        *val = cep->tmo.dat_rcnt;
        break;
    case SET_TCP_RTO_INI:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.rto_ini;
        break;
    case SET_TCP_RTO_MIN:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.rto_min;
        break;
    case SET_TCP_RTO_MAX:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.rto_max;
        break;
    case SET_TCP_KEEPALIVE_TMO:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.ktime_tmo;
        break;
    case SET_TCP_KEEPALIVE_PRO:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.ktime_pro;
        break;
    case SET_TCP_KEEPALIVE_SUC:
        if (optlen != sizeof(UW)) {
            ercd = E_PAR;
            goto END;
        }
        tval  = (UW *)optval;
        *tval = cep->tmo.ktime_suc;
        break;
    default:
        ercd = E_NOSPT;
        break;
    }

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Set TCP Communication End Point Options      */
/************************************************/

ER tcp_set_opt(ID cepid, INT optname, const VP optval, INT optlen)
{
    ER ercd = E_OK;
    T_TCP_CEP *cep;
    T_NIF *nif;
    PRI save_pri;

    /* Set TCP Communication End Point timeout/retry parameters */
    switch (optname) {
    case SET_TCP_DAT_RCNT:
    case SET_TCP_RTO_INI:
    case SET_TCP_RTO_MIN:
    case SET_TCP_RTO_MAX:
    case SET_TCP_KEEPALIVE_TMO:
    case SET_TCP_KEEPALIVE_PRO:
    case SET_TCP_KEEPALIVE_SUC:
        return tcp_cep_set_opt(cepid, optname, optval, optlen);
    }

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* Error if CEP Not Created */

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }
    if (IS_USED(cep->state)) {
        ercd = E_OBJ;
        goto END;
    }

    nif = cep->unif;

    switch (optname) {
    case IP_IF_NAME:
        nif = getnif_from_name((const char *)optval);
        if (nif == NULL) {
            ercd = E_PAR;
            goto END;
        }
        cep->nif = cep->unif = nif;
        break;
    case IP_IF_CH:
        nif = getnif_from_ch((int)optval);
        if (nif == NULL) {
            ercd = E_PAR;
            goto END;
        }
        cep->nif = cep->unif = nif;
        break;
    case SET_IP_TTL:
        if (optlen != sizeof(UB))
            return E_OBJ;
        cep->ttl = *((UB *)optval);
        break;
    case SET_IP_TOS:
        if (optlen != sizeof(UB))
            return E_OBJ;
        cep->tos = *((UB *)optval);
        break;
    case SET_TCP_MSS:
        if (nif == NULL) {
            if (((*(UW *)optval) < 48) ||
                ((*(UW *)optval) > ((ETHERNET_MTU - IP4_HEADER_SZ - TCP_HEADER_SZ)))) {
                ercd = E_PAR;
                goto END;
            }
        }
        else {
            if (((*(UW *)optval) < 48) ||
                ((*(UW *)optval) > (nif->path_mtu - TCP_HEADER_SZ))) {
                ercd = E_PAR;
                goto END;
            }
        }
        cep->mss = *(UW *)optval;
        cep->umtu = cep->mss;
        break;
    case SET_TCP_TSOPT:
        if (optlen != sizeof(BOOL))
            return E_OBJ;
        if (*((BOOL *)optval)) {
            if (!(cep->tsopt & TSOPT_ENABLE))
                cep->tsecr = 0;
            cep->tsopt |= (TSOPT_REQUEST | TSOPT_ENABLE);
        } else {
            cep->tsopt &= ~(TSOPT_REQUEST | TSOPT_ENABLE);
        }
        break;
    default:
        optlen = 0;
        ercd = E_PAR;
    }
END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;

}

/************************************************/
/* Get TCP Communication End Point Options      */
/************************************************/

ER tcp_get_opt(ID cepid, INT optname, VP optval, INT optlen)
{
    ER ercd = E_OK;
    T_TCP_CEP *cep;
    T_NIF *nif;
    UB *opt;
    UW *optw;
    PRI save_pri;

    /* Get TCP Communication End Point timeout/retry parameters */
    switch (optname) {
    case SET_TCP_DAT_RCNT:
    case SET_TCP_RTO_INI:
    case SET_TCP_RTO_MIN:
    case SET_TCP_RTO_MAX:
    case SET_TCP_KEEPALIVE_TMO:
    case SET_TCP_KEEPALIVE_PRO:
    case SET_TCP_KEEPALIVE_SUC:
        return tcp_cep_get_opt(cepid, optname, optval, optlen);
    }

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    /* State Check */

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (IS_USED(cep->state)) {
        ercd = E_OBJ;
        goto END;
    }

    nif = cep->unif;

    switch (optname) {
    case IP_IF_NAME:
        if (nif == NULL) {
            ercd = E_OBJ;
            goto END;
        }
        if (optlen <= (INT)strlen(nif->name)) {
            ercd = E_PAR;
            goto END;
        }
        strcpy((char *)optval, nif->name);
        break;
    case SET_IP_TOS:
        if ((optval == NULL) || (optlen != sizeof(UB))) {
            ercd = E_PAR;
            goto END;
        }
        opt = (UB *)optval;
        *opt = cep->tos;
        break;
    case SET_IP_TTL:
        if ((optval == NULL) || (optlen != sizeof(UB))) {
            ercd = E_PAR;
            goto END;
        }
        opt = (UB *)optval;
        *opt = cep->ttl;
        break;
    case SET_TCP_MSS:
        if ((optval == NULL) || (optlen != sizeof(UW))) {
            ercd = E_PAR;
            goto END;
        }
        optw = (UW *)optval;
        *optw = cep->mss;
        break;
    case SET_TCP_TSOPT:
        if ((optval == NULL) || (optlen != sizeof(BOOL))) {
            ercd = E_PAR;
            goto END;
        }
        if (cep->tsopt & TSOPT_REQUEST)
            *(BOOL *)optval = TRUE;
        else
            *(BOOL *)optval = FALSE;
        break;
    default:
        ercd = E_NOSPT;
        break;
    }

END:
    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/************************************************/
/* Get TCP Communication End Point Informations */
/************************************************/

ER tcp_ref_cep(ID cepid, T_IPV4EP *myaddr)
{
    T_TCP_CEP *cep;
    ER ercd;
    PRI save_pri;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (!(is_nif_exists(NULL))) {
        ercd = E_LNK; /* No Interface available */
        goto END;
    }

    /* Parameter Check */

    cepid--;
    if ((UINT)cepid >= (UINT)TCP_CEPID_MAX) {
        ercd = E_ID;
        goto END;
    }

    cep = &TCP_CEP[cepid];
    if (!IS_CREATED(cep->state)) {
        ercd = E_NOEXS;
        goto END;
    }

    if (IS_USED(cep->state)) {
        if (cep->ercd == E_LNK) {
            ercd = E_LNK; /* Interface not exists */
            goto END;
        }
    }

#ifdef DUAL_STK
    myaddr->type = cep->type;
    if (cep->type == IPV6_ADDR) {
        set_ip6_addr(myaddr->ip6addr, cep->ip6addr);
    }
    else
#endif
    {
        myaddr->ipaddr = cep->ipaddr;
    }

    myaddr->portno = cep->portno;
    ercd = (ER)cep->state;

END:
    tcpip_critical(FALSE, &save_pri);

    return ercd;
}

/* End */
