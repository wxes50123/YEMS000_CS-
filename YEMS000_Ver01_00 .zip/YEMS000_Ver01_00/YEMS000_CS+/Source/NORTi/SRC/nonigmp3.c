/******************************************************************************
* NORTi TCP/IP Stack - IGMPv3 Module                                          *
*                                                                             *
*  Copyright (c) 2008-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2008-10-07 Created                                                       GS *
* 2009-10-07 Added missing TFN_NET_IGN_PKT function call when discarding      *
*             packet due to too short or no IP option in igmp3_reception() GS *
* 2009-11-11 Corrected exeGCC compiler warning                             GS *
* 2009-12-25 Corrected MCAST_EXCLUDE to MODE_IS_EXCLUDE in igmp3_if_jgrp() GS *
* 2012-11-13 Changed ID_IGMP3_ADR/SRC_MPF type ID to UH for size reduction FY *
* 2012-12-05 Added (int) cast to TFN_NET_RED_PKT_END function 5th argument FY *
* 2013-01-24 Corrected htonl()/htons() to ntohl()/ntohs()                     *
*                          in igmp3_reception() and igmp3_updt_response()  FY *
* 2016-07-13 Added missing UB cast to igmp3_updt_tmr() 3rd param and so on MI *
* 2021-06-22 Deleted clearing of removed pkt->ctl.arprty                   FY *
* 2023-07-11 Changed igmp3_reception() to calculate data_len with total       *
*             length excluded IP options length by updated ip_reception()  FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/* Maximum available data buffer length for IGMPv3 report message */
/* Alert option(4) */
#define MAX_DATA_SZ (PATH_MTU4 - 4)

/* Fixed Memory pool for IGMPv3 Address list */
UH ID_IGMP3_ADR_MPF;
/* Fixed Memory pool for IGMPv3 Source list */
UH ID_IGMP3_SRC_MPF;

/* All Systems Multicast Address */
const UB all_sys_maddr[] = {224,0,0,1};
/* All IGMPv3 Multicast Routers */
const UB all_rtr_maddr[] = {224,0,0,22};

/* Function Prototype Declarations */
static ER igmp3_if_setfilter(T_NIF *nif, T_GADDR *gaddr, UW new_state,
                                      T_IGMP3_SRC *if_slist);
static ER igmp3_build_src_chg(T_NIF *nif, T_GADDR *gaddr,
                                      T_IGMP3_SRC *new_list, BOOL *any_change);
static ER igmp3_build_mode_chg(T_GADDR *gaddr, UW new_stat,
                                      T_IGMP3_SRC *if_slist);
static ER igmp3_snd_state_change_report(T_NIF *nif, T_GADDR *gaddr);
static ER igmp3_add_retran_list(T_NIF *nif, T_GADDR *gaddr);
static ER igmp3_snd_fmod_chg(T_NIF *nif, T_GADDR *gaddr);
static ER igmp3_snd_slist_chg(T_NIF *nif, T_GADDR *gaddr);
static ER igmp3_snd_spec_report(T_NIF *nif, T_GADDR *gaddr);
static ER igmp3_snd_all_report(T_NIF *nif);
static void igmp3_updt_tmr(T_NIF *nif, T_GADDR *gaddr, UB max_resp_dly,
                                      BOOL flag, T_IP4 *pkt);
static ER igmp3_updt_response(T_GADDR *gaddr, T_IP4 *pkt);
static ER igmp3_add_resp_list(T_NIF *nif, T_GADDR *gaddr);
static void igmp3_tmr_nif(T_NIF *nif);
static void igmp3_rmv_retran_list(T_NIF *nif);
static void igmp3_rmv_response_list(T_NIF *nif);
static ER cancel_pending_ipret(T_NIF *nif);
static ER cancel_pending_ipres(T_GADDR *resp_list);
static ER igmp3_get_pkt(T_NIF *nif, T_IP4 **ppkt, T_IGMP3_REP **prep,
                              T_IGMP3_REC **prec, UW **psrcbuf);
ER igmp3_snd_rep(T_NIF *nif, T_IP4 *pkt, UH nrec, UB typ, UH nsrc, UW ipaddr,
                                                                       UW len);
static ER igmp3_snd_out(T_NIF *nif, T_IP4 *pkt, UW igmp3_len);
static ER igmp3_rmv_addr(T_NIF *nif, T_GADDR *gaddr);
static T_GADDR *igmp3_util_getgaddr(T_NIF *nif, UW maddr);
static UH igmp3_checksum(UH *msg, UW tot_len);

extern ER ip_internal_error(ER ercd);

/******************************************************************************
*                                    API Processing                           *
******************************************************************************/
/******************************************************************************
* When a group is newly added, this function is called from UDP layer.        *
******************************************************************************/
ER igmp3_if_jgrp(T_NIF *nif, T_MGRP_CB *grp)
{
    T_GADDR *gaddr, *prev = NULL;
    UW gipaddr;
    ER ercd;

    if (nif == NULL) {
        nif = getnif_default();
    }
    if (nif == NULL) {
        return E_OBJ;
    }

    if (grp == NULL) { /* Special case: All-system-multicast address */
        gipaddr = byte4_to_long(all_sys_maddr);
    }
    else {
        gipaddr = grp->ipaddr;
    }

    gaddr = nif->gaddr_list;
    /* First add the MAddr info in Interface table */
    /* And, decide about the resultant state change */
    while (gaddr) {
        if (gaddr->ipaddr == gipaddr) {
            /* The addr exists here already. This case occurs when a group */
            /* is added immediately after leaving the group */
            /* Reset the leave flag set by leave group */
            gaddr->leave_flag = FALSE;
            ercd = igmp3_if_setfilter(nif, gaddr, MODE_IS_EXCLUDE, NULL);
            return ercd;
        }
        prev = gaddr;
        gaddr = gaddr->nxt;
    }
    ercd = pget_mpf (ID_IGMP3_ADR_MPF, (VP *)&gaddr);
    if (ercd != E_OK) {
        ip_internal_error(ercd);
        return ercd;
    }
    if (nif->gaddr_list == NULL) {
        nif->gaddr_list = gaddr;
    }
    else {
        prev->nxt = gaddr;
    }
    /* Initialize New entry */
    gaddr->nxt = NULL;
    gaddr->ipaddr = gipaddr;
    gaddr->filt_mode = MODE_IS_EXCLUDE;
    gaddr->res_type = NOT_IN_USE;
    gaddr->nxt_ipres = NULL;
    gaddr->nxt_ipret = NULL;
    gaddr->src_list = NULL;
    gaddr->grp_tmr = 0;
    gaddr->leave_flag = FALSE;

    /* If all-system-multicast address, No need to send any report */
    if (gipaddr == byte4_to_long(all_sys_maddr)) {
        return E_OK;
    }
    if (nif->iprinfo.compt_mode == IGMP_VER_2) {
        /* The system is in IGMPv2 Compatible mode */
        send_igmp_report(grp);
        /* Send it once again after some interval, as specified in RFC */
        grp->rptime = IGMP_UNSOL_DLY; /* 2 Sec */
        return E_OK;
    }
    gaddr->ret_cnt = nif->iprinfo.qrv;/* robust variable -1 times */
    /* If the system is in IGMPv3 mode, send report & add for retransmission */
    ercd = igmp3_snd_state_change_report(nif, gaddr);
    if (ercd != E_OK) {
        return ercd;
    }
    return igmp3_add_retran_list(nif, gaddr);
}

/******************************************************************************
* When only one UDP socket used a group and it leaves, this function is       *
* called from UDP layer.                                                      *
******************************************************************************/
ER igmp3_if_lgrp(T_NIF *nif, T_MGRP_CB *grp)
{
    T_GADDR *gaddr;
    ER ercd;

    if (nif == NULL) {
        nif = getnif_default();
    }
    if (nif == NULL) {
        return E_OBJ;
    }

    /* Get the Multicast Address Entry at Interface Level */
    gaddr = igmp3_util_getgaddr(nif, grp->ipaddr);
    if (gaddr == NULL) {
        return E_NOEXS;
    }
    /* If already in INCLUDE mode, NULL is sent, just remove it */
    if ((gaddr->filt_mode == MODE_IS_INCLUDE) && (gaddr->src_list == NULL)
            && (gaddr->ret_cnt == 0)) {
        /* Destroy the entry */
        igmp3_rmv_addr(nif, gaddr);
        if (nif->iprinfo.compt_mode == IGMP_VER_2) {
            leave_igmp_group(grp);
        }
        return E_OK;
    }
    /* Set the leave flag to confirm removal of GADDR */
    gaddr->leave_flag = TRUE;
    ercd = igmp3_if_setfilter(nif, gaddr, MODE_IS_INCLUDE, NULL);
    if (ercd != E_OK) {
        return ercd;
    }
    if (nif->iprinfo.compt_mode == IGMP_VER_2) {
        /* Clear any pending retransmission due to APIs */
        if (nif->ipret_list != NULL) {
            ercd = cancel_pending_ipret(nif);
            if (ercd != E_OK) {
                return ercd;
            }
            nif->ipret_list = NULL;
        }
        if ((gaddr->filt_mode != MODE_IS_INCLUDE)
                                         || (gaddr->src_list != NULL)) {
            return E_OBJ;
        }
        /* Destroy the entry */
        igmp3_rmv_addr(nif, gaddr);
        leave_igmp_group(grp);
    }
    return E_OK;
}

/******************************************************************************
* This function is called from UDP layer to update the source list at the     *
* interface level when new list is added/removed.                             *
******************************************************************************/
ER igmp3_if_upgrp(T_NIF *nif, UW ipaddr, UW new_stat, T_IGMP3_SRC *if_slist)
{
    T_GADDR *gaddr;

    if (nif == NULL) {
        nif = getnif_default();
    }
    if (nif == NULL) {
        return E_OBJ;
    }

    /* Get the Multicast Address Entry at Interface Level */
    gaddr = igmp3_util_getgaddr(nif, ipaddr);
    if (gaddr == NULL) {
        return E_NOEXS;
    }
    return igmp3_if_setfilter(nif, gaddr, new_stat, if_slist);
}

/******************************************************************************
* This function is called from UDP layer to update the source list at the     *
* interface level when new list is added/removed.                             *
******************************************************************************/
static ER igmp3_if_setfilter(T_NIF *nif, T_GADDR *gaddr, UW new_stat,
                                                         T_IGMP3_SRC *if_slist)
{
    BOOL any_change;
    ER ercd;

    any_change = FALSE;

    if (gaddr->filt_mode == new_stat) {
        /* Same mode: So, just prepare the list for Source Change report */
        ercd = igmp3_build_src_chg(nif, gaddr, if_slist, &any_change);
        if (ercd != E_OK) {
            return ercd;
        }
    }
    else {
        /* This is filter mode change. So, release the Source list and */
        /* assign the new mode and send the report as filter mode change */
        ercd = igmp3_free_src(gaddr->src_list);
        if (ercd != E_OK) {
            return ercd;
        }
        gaddr->src_list = NULL;
        ercd = igmp3_build_mode_chg(gaddr, new_stat, if_slist);
        if (ercd != E_OK) {
            return ercd;
        }
        gaddr->ret_cnt = nif->iprinfo.qrv;
        any_change = TRUE;
    }
    if (any_change == TRUE) {
        /* igmp3_build_src_chg/igmp3_build_mode_chg & igmp3_add_retran_list */
        /* must be atomic.If they are marked to be transmitted, they have to */
        /* be added in the list */
        ercd = igmp3_add_retran_list(nif, gaddr);
        if (ercd != E_OK) {
            return ercd;
        }
        if (nif->iprinfo.compt_mode == IGMP_VER_3) {
            /* If IGMPv3 Send report and add for retransmission */
            return igmp3_snd_state_change_report(nif, gaddr);
        }
    }
    return E_OK;
}

/******************************************************************************
* This function adds the new source from the new list to the interface list   *
* and removes the sources from the interface list that does not exist in the  *
* new list.                                                                   *
******************************************************************************/
static ER igmp3_build_src_chg(T_NIF *nif, T_GADDR *gaddr,
                                       T_IGMP3_SRC *new_list, BOOL *any_change)
{
    T_IGMP3_SRC *gsrc, *gprev, *nsrc, *nprev, *temp;
    UB inc_mode, rem_mode;

    if (gaddr->filt_mode == MODE_IS_INCLUDE) {
        /* If the interface list is in INCLUDE, the source that has to be  */
        /* newly included must be marked as ALLOW. The sources that has to */
        /* removed must be marked as BLOCK */
        inc_mode = ALLOW;
        rem_mode = BLOCK;
    }
    else {
        /* If the interface list is in EXCLUDE, the source that has to be  */
        /* newly included must be marked as BLOCK. The sources that has to */
        /* removed must be marked as ALLOW */
        inc_mode = BLOCK;
        rem_mode = ALLOW;
    }

    /* If a source exists in Interface list and does not exist in the new */
    /* list, then mark it with rem_mode */
    gsrc = gaddr->src_list;
    while (gsrc) {
        /* If it is already in rem_mode, just leave it. */
        if (gsrc->src_mode != rem_mode) {
            nsrc = new_list;
            while (nsrc) {
                if (gsrc->ipaddr == nsrc->ipaddr) {
                    break;
                }
                nsrc = nsrc->nxt;
            }
            if (nsrc == NULL) {
                gsrc->src_mode = rem_mode;
                gsrc->ret_cnt = nif->iprinfo.qrv;
                *any_change = TRUE;
            }
        }
        gsrc = gsrc->nxt;
    }

    /* if the source exists in the new list, but not in the interface list */
    /* then, mark it with inc_mode */
    nprev = NULL;
    nsrc = new_list;
    while (nsrc) {
        gprev = NULL;
        gsrc = gaddr->src_list;
        while (gsrc) {
            if (gsrc->ipaddr == nsrc->ipaddr) {
                /* Source exists, but in opposite mode. So, change it */
                if (gsrc->src_mode == rem_mode) {
                    gsrc->src_mode = inc_mode;
                    gsrc->ret_cnt = nif->iprinfo.qrv;
                    *any_change = TRUE;
                }
                break;
            }
            gprev = gsrc;
            gsrc = gsrc->nxt;
        }
        if (gsrc == NULL) {
            /* The source has to be added newly */
            /* Move the node from the given new list to the interface list */
            temp = nsrc;
            if (nsrc == new_list) {
                new_list = nsrc->nxt;
            }
            else {
                nprev->nxt = nsrc->nxt;
            }
            nsrc = nsrc->nxt;

            temp->nxt = NULL;
            temp->src_mode = inc_mode;
            temp->ret_cnt = nif->iprinfo.qrv;
            temp->qry_flg = NOT_QUERIED;
            *any_change = TRUE;
            if (gprev == NULL) {
                gaddr->src_list = temp;
            }
            else {
                gprev->nxt = temp;
            }
            continue;
        }
        nprev = nsrc;
        nsrc = nsrc->nxt;
    }

    /* Now, release the remaining source nodes in the given list. */
    /* No more needed */
    return igmp3_free_src(new_list);
}

/******************************************************************************
* This mode change. New source list is assigned as it is. And, new mode is    *
* assigned.                                                                   *
******************************************************************************/
static ER igmp3_build_mode_chg(T_GADDR *gaddr, UW new_stat,
                                                         T_IGMP3_SRC *if_slist)
{
    T_IGMP3_SRC *cur;

    /* Assign New mode */
    gaddr->filt_mode = (UB)new_stat;

    /* Intialize and assign the new list */
    cur = if_slist;
    while (cur) {
        cur->src_mode = NOT_APPLICABLE;
        cur->ret_cnt = 0;
        cur->qry_flg = NOT_QUERIED;

        cur = cur->nxt;
    }
    gaddr->src_list = if_slist;
    return E_OK;
}

/******************************************************************************
* Sending state change report. The gaddr->ret_cnt is retransmission count for *
* filter mode change. The src->ret_cnt is for retransmission count for source *
* list change.                                                                *
******************************************************************************/
static ER igmp3_snd_state_change_report(T_NIF *nif, T_GADDR *gaddr)
{
    ER ercd;

    /* If all filter mode change is retransmitted, then retransmit */
    /* source list change */
    if (gaddr->ret_cnt != 0) {
        ercd = igmp3_snd_fmod_chg(nif, gaddr);
    }
    else {
        ercd = igmp3_snd_slist_chg(nif, gaddr);
    }

    return ercd;
}

/******************************************************************************
* Add the Multicast Group address to the Retransmission list. This is when    *
* the state change(Source list change & Filter mode change) occurs.           *
******************************************************************************/
static ER igmp3_add_retran_list(T_NIF *nif, T_GADDR *gaddr)
{
    T_GADDR *cur, *prev = NULL;

    if (nif->ipret_list == NULL) {
        nif->ipret_list = gaddr;
    }
    else {
        cur = nif->ipret_list;
        while (cur) {
            if (cur == gaddr) {
                return E_OK;
            }
            prev= cur;
            cur = cur->nxt_ipret;
        }
        prev->nxt_ipret = gaddr;
    }
    gaddr->nxt_ipret = NULL;
    return E_OK;
}

/******************************************************************************
* Sends Filter Mode Change record.                                            *
******************************************************************************/
static ER igmp3_snd_fmod_chg(T_NIF *nif, T_GADDR *gaddr)
{
    T_IP4 *ppkt;
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec;
    T_IGMP3_SRC *src;
    UW tot_len, *srcbuf;
    UH scnt;
    UB typ;
    ER ercd;

    /* Get the packet and the report, record & source pointers */
    ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
    if (ercd != E_OK) {
        return ercd;
    }
    tot_len = sizeof(T_IGMP3_REP) + sizeof(T_IGMP3_REC);
    scnt = 0;

    /* Decide the record type */
    if (gaddr->filt_mode == MODE_IS_INCLUDE) {
        typ = CHANGE_TO_INCLUDE_MODE;
    }
    else {
        typ = CHANGE_TO_EXCLUDE_MODE;
    }

    gaddr->ret_cnt--;

    src = gaddr->src_list;
    /* Prepare a record containing all sources related to corresponding */
    /* multicast address */
    while (src) {
        if (src->src_mode == NOT_APPLICABLE) {
            if ((tot_len + 4) > MAX_DATA_SZ) {
                /* Large number of sources. Send them as separate reports */
                ercd = igmp3_snd_rep(nif, ppkt, 1, typ, scnt, gaddr->ipaddr,
                                                                      tot_len);
                /* For exclude mode, all sources are not needed as per rfc */
                if ((typ == CHANGE_TO_EXCLUDE_MODE) || (ercd != E_OK)) {
                    return ercd;
                }
                /* Get the new packet and the pointers */
                ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
                if (ercd != E_OK) {
                    return ercd;
                }
                tot_len = sizeof(T_IGMP3_REP) + sizeof(T_IGMP3_REC);
                scnt = 0;
            }
            /* Get new packet for next report */
            srcbuf[scnt] = htonl(src->ipaddr);
            scnt++;
            tot_len += 4;
        }
        src = src->nxt;
    }

    /* Filter mode change report goes with only one record */
    return igmp3_snd_rep(nif, ppkt, 1, typ, scnt, gaddr->ipaddr, tot_len);
}

/******************************************************************************
* Sends Source List Change record.                                            *
******************************************************************************/
static ER igmp3_snd_slist_chg(T_NIF *nif, T_GADDR *gaddr)
{
    T_IP4 *ppkt;
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec;
    T_IGMP3_SRC *src, *temp, *prev = NULL;
    UW tot_len, *srcbuf;
    UH scnt, rcnt;
    UB cur_smode, rem_fmode, rectype;
    ER ercd;
    int i;

    /* Get the packet and the report, record & source pointers */
    ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
    if (ercd != E_OK) {
        return ercd;
    }
    tot_len = sizeof(T_IGMP3_REP);
    rcnt = 0;

    /* In Source List Change report, there can be two type of records */
    /* ALLOW_NEW_SOURCES and BLOCK_OLD_SOURCES */
    cur_smode = ALLOW;
    rem_fmode = MODE_IS_EXCLUDE;
    rectype = ALLOW_NEW_SOURCES;
    for (i = 0; i < 2; i++) {
        src = gaddr->src_list;
        scnt = 0;
        while (src) {
            if (src->src_mode == cur_smode) {
                if ((tot_len + sizeof(T_IGMP3_REC) + 4) > MAX_DATA_SZ) {
                    if (scnt == 0) {
                        /* Already, record information added. So, no need to */
                        /* fill again */
                        ercd = igmp3_snd_rep(nif, ppkt, rcnt, 0, 0,0, tot_len);
                    }
                    else {
                        /* Send the sources added till now. */
                        ercd = igmp3_snd_rep(nif, ppkt, rcnt + 1, rectype,
                          scnt, gaddr->ipaddr, tot_len + sizeof(T_IGMP3_REC));
                    }
                    if (ercd != E_OK) {
                        return ercd;
                    }
                    ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
                    if (ercd != E_OK) {
                        return ercd;
                    }
                    tot_len = sizeof(T_IGMP3_REP);
                    rcnt = scnt = 0;
                }
                srcbuf[scnt] = htonl(src->ipaddr);
                scnt++;
                tot_len += 4;
                src->ret_cnt--;
                /* After sending robust variable times, if filter mode is */
                /* INCLUDE and source is BLOCK, remove the source. Like that */
                /* if filter mode is EXCLUDE and source is ALLOW, remove it */
                /* else, make it NOT_APPLICABLE */
                if (src->ret_cnt == 0) {
                    if (gaddr->filt_mode == rem_fmode) {
                        /* Remove the source */
                        temp = src;
                        if (gaddr->src_list == src) {
                            gaddr->src_list = src->nxt;
                        }
                        else {
                            prev->nxt = src->nxt;
                        }
                        src = src->nxt;
                        ercd = rel_mpf(ID_IGMP3_SRC_MPF, temp);
                        if (ercd != E_OK) {
                            ip_internal_error(ercd);
                            return ercd;
                        }
                        continue;
                    }
                    else {
                        src->src_mode = NOT_APPLICABLE;
                    }
                }
            }
            prev = src;
            src = src->nxt;
        }
        /* If there was atleast one source in the previous record, prepare */
        /* a second record. Else, use the same */
        if (scnt) {
            rcnt++;
            rec->aux_dat_len = 0;
            rec->num_src = htons(scnt);
            rec->rec_type = rectype;
            rec->group = htonl(gaddr->ipaddr);
            tot_len += sizeof(T_IGMP3_REC);
            /* Get record pointer */
            rec = (T_IGMP3_REC *)(srcbuf + scnt);
            srcbuf = (UW *)((UB *)rec + sizeof(T_IGMP3_REC));
        }
        cur_smode = BLOCK;
        rem_fmode = MODE_IS_INCLUDE;
        rectype = BLOCK_OLD_SOURCES;
    }
    rep->num_rec = htons(rcnt);

    rep->cs = igmp3_checksum((UH *)rep, tot_len);

    return igmp3_snd_out(nif, ppkt, tot_len);
}

/******************************************************************************
*                              Query Processing                               *
******************************************************************************/
/******************************************************************************
* Routine for sending Group Specific Record or Group and Source Specific      *
* Record.                                                                     *
******************************************************************************/
static ER igmp3_snd_spec_report(T_NIF *nif, T_GADDR *gaddr)
{
    T_IP4 *ppkt;
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec;
    T_IGMP3_SRC *src, *temp, *prev = NULL;
    UW tot_len, *srcbuf;
    UH scnt;
    ER ercd;

    /* Get the packet and the report, record & source pointers */
    ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
    if (ercd != E_OK) {
        return ercd;
    }
    tot_len = sizeof(T_IGMP3_REP) + sizeof(T_IGMP3_REC);
    scnt = 0;

    /* Since it is group specific or group and source specific report */
    /* It has only one record */
    src = gaddr->src_list;
    /* This is for Group Specific Query response */
    if (gaddr->res_type == PEND_RESP_GRP_SPECIFIC_QUERY) {
        /* Reset the flag */
        gaddr->res_type = NOT_IN_USE;

        /* All sources are sent for this group */
        while (src) {
            if ((tot_len + 4) > MAX_DATA_SZ) {
                ercd = igmp3_snd_rep(nif, ppkt, 1, gaddr->filt_mode, scnt,
                                                      gaddr->ipaddr, tot_len);
                if (ercd != E_OK) {
                    return ercd;
                }
                if ((gaddr->filt_mode == MODE_IS_EXCLUDE) || (ercd != E_OK)) {
                    return ercd;
                }
                /* Get the new packet and the pointers */
                ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
                if (ercd != E_OK) {
                    return ercd;
                }
                tot_len = sizeof(T_IGMP3_REP) + sizeof(T_IGMP3_REC);
                scnt = 0;
            }
            srcbuf[scnt] = htonl(src->ipaddr);
            scnt++;
            tot_len += 4;
            src = src->nxt;
        }
        return igmp3_snd_rep(nif, ppkt, 1, gaddr->filt_mode, scnt,
                                              gaddr->ipaddr, tot_len);
    }
    else{
        /* Reset the flag */
        gaddr->res_type = NOT_IN_USE;
        /* Group and Source specific response */
        /* Take account of all sources in the query */
        while (src) {
            if (src->qry_flg == QUERIED) {
                if ((tot_len + 4) > MAX_DATA_SZ) {
                    ercd = igmp3_snd_rep(nif, ppkt, 1, MODE_IS_INCLUDE, scnt,
                                           gaddr->ipaddr, tot_len);
                    if (ercd != E_OK) {
                        return ercd;
                    }
                    /* Get the new packet and the pointers */
                    ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
                    if (ercd != E_OK) {
                        return ercd;
                    }
                    tot_len = sizeof(T_IGMP3_REP) + sizeof(T_IGMP3_REC);
                    scnt = 0;
                }
                srcbuf[scnt] = htonl(src->ipaddr);
                scnt++;
                tot_len += 4;
                /* If filter mode is INCLUDE, reset the qry_flg */
                if (gaddr->filt_mode == MODE_IS_INCLUDE) {
                    src->qry_flg = NOT_QUERIED;
                }
                /* if filter mode is EXCLUDE the non-existing source has */
                /* been added for the sake of sending the response in */
                /* igmp3_updt_response(). So, just remove it. */
                else {
                    temp = src;
                    if (gaddr->src_list == src) {
                        gaddr->src_list = src->nxt;
                    }
                    else {
                        prev->nxt = src->nxt;
                    }
                    src = src->nxt;
                    ercd = rel_mpf(ID_IGMP3_SRC_MPF, temp);
                    if (ercd != E_OK) {
                        ip_internal_error(ercd);
                        return ercd;
                    }
                    continue;
                }
            }
            prev = src;
            src = src->nxt;
        }
    }
    return igmp3_snd_rep(nif, ppkt, 1, MODE_IS_INCLUDE, scnt,
                                           gaddr->ipaddr, tot_len);
}

/******************************************************************************
* Routine for sending response to IGMPv3 General Query                        *
******************************************************************************/
static ER igmp3_snd_all_report(T_NIF *nif)
{
    T_IP4 *ppkt;
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec = NULL;
    T_IGMP3_SRC *src;
    T_GADDR *gaddr;
    UW tot_len = 0, *srcbuf = NULL;
    UH rcnt = 0, scnt;
    ER ercd = E_OK;

    ppkt= NULL;
    /* Copy all Group addresses and their Sources */
    /* The first entry, all-system-multicast address is ignored */
    gaddr = nif->gaddr_list->nxt;
    while (gaddr) {
        if (ppkt == NULL) {
            /* Get the packet and the report, record & source pointers */
            ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
            if (ercd != E_OK) {
                return ercd;
            }
            tot_len = sizeof(T_IGMP3_REP);
            rcnt = 0;
        }
        scnt = 0;
        src = gaddr->src_list;
        while (src) {
            if ((tot_len + sizeof(T_IGMP3_REC) + 4) > MAX_DATA_SZ) {
                if (scnt == 0) {
                    ercd = igmp3_snd_rep(nif, ppkt, rcnt, 0, 0, 0, tot_len);
                }
                else {
                    ercd = igmp3_snd_rep(nif, ppkt, rcnt + 1, gaddr->filt_mode,
                           scnt, gaddr->ipaddr, tot_len + sizeof(T_IGMP3_REC));
                }
                if (ercd != E_OK) {
                    return ercd;
                }
                /* Get the new packet and the pointers */
                ercd = igmp3_get_pkt(nif, &ppkt, &rep, &rec, &srcbuf);
                if (ercd != E_OK) {
                    return ercd;
                }
                tot_len = sizeof(T_IGMP3_REP);
                rcnt = scnt = 0;
            }
            srcbuf[scnt] = htonl(src->ipaddr);
            scnt++;
            tot_len += 4;
            src = src->nxt;
        }
        rcnt++;
        rec->aux_dat_len = 0;
        rec->num_src = htons(scnt);
        rec->rec_type = gaddr->filt_mode;
        rec->group = htonl(gaddr->ipaddr);
        tot_len += sizeof(T_IGMP3_REC);
        if ((tot_len + sizeof(T_IGMP3_REC)) > MAX_DATA_SZ) {
            ercd = igmp3_snd_rep(nif, ppkt, rcnt, 0, 0, 0, tot_len);
            if (ercd != E_OK) {
                return ercd;
            }
            ppkt = NULL;
        }
        /* Get record pointer */
        rec = (T_IGMP3_REC *)(srcbuf + scnt);
        srcbuf = (UW *)((UB *)rec + sizeof(T_IGMP3_REC));
        gaddr = gaddr->nxt;
    }
    if (ppkt) {
        return igmp3_snd_rep(nif, ppkt, rcnt, 0, 0, 0, tot_len);
    }
    return E_OK;
}

/******************************************************************************
* IGMPv3 Query processing Routine                                             *
******************************************************************************/
T_IP4 *igmp3_reception(T_IP4 *pkt)
{
    T_IGMP3_QRY *query;
    UW max_resp_cod, maddr, data_len;
    UH numsrc;
    T_GADDR *gaddr;
    T_NIF *nif;

    nif = pkt->ctl.nif;
    data_len = ntohs(pkt->ip.tl) - IP4_HEADER_SZ;

    /* Decide wheather IGMPv3 or IGMPv2/IGMPv1 */
    if (data_len == 8) {
        return igmp_reception(pkt);
    }
    else if (data_len < 12) { /* Invalid packet */
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        return pkt;
    }

    /* Check for Alert option. If no alert option, return */
    if ((pkt->ip.ver & 0x0f) * 4 != (IP4_HEADER_SZ + 4)) {
        (*nif->func)(nif, TFN_NET_IGN_PKT);
        return pkt;
    }

    /* IGMPv3 Mode: Read the packet */
    if (!(*nif->func)(nif, TFN_NET_RED_PKT_END, pkt->data, (int)data_len, PATH_MTU4)) {
        return pkt;
    }

    /* Checksum */
    if (igmp3_checksum((UH *)pkt->data, data_len) != 0)
        return pkt;

    query = (T_IGMP3_QRY *)pkt->data;
    /* Ignore all messages except IGMPv3 Query */
    if (query->type != 0x11) {
        return pkt;
    }
    maddr = ntohl(query->group);

    /* If the general query, does not have all-system as src address, return */
    if ((maddr == 0) &&
              (ntohl(pkt->ip.da) != byte4_to_long(all_sys_maddr))) {
        return pkt;
    }

    /* Reset the compatibility timer */
    if (nif->iprinfo.compt_timer != 0) {
        nif->iprinfo.compt_timer = 0;
        nif->iprinfo.compt_mode = IGMP_VER_3;
    }

    nif->iprinfo.qrv = (query->info & 0x07);
    nif->iprinfo.qqi = query->qqic;
    /* Check whether the addr is already in Retransmit list */
    gaddr = nif->ipret_list;
    while (gaddr) {
        if (gaddr->ipaddr == maddr) {
            return pkt;
        }
        gaddr = gaddr->nxt_ipret;
    }
    /* Calculate Maximum Response Delay */
    max_resp_cod = query->mrc;
    if (max_resp_cod < 128) {
        max_resp_cod = max_resp_cod / 10; /* Units 1/10 seconds */
    }
    else {
        max_resp_cod = ((max_resp_cod & 0x0f) | 0x10) <<
                                     (((max_resp_cod & 0x70) >> 4) + 3);
    }
    nif->iprinfo.max_res_time = max_resp_cod;
    /* Calculate the randomm value */
    max_resp_cod = SYSCK.ltime % max_resp_cod;
    /* Now, classify the query and process */
    gaddr = nif->gaddr_list;
    if (maddr == 0) {
        igmp3_updt_tmr(nif, NULL, (UB)max_resp_cod, IGMP3_GEN_QRY, pkt);
    }
    else {
        while (gaddr) {
            if (maddr == gaddr->ipaddr) {
                numsrc = ntohs(query->numsrc);
                if (numsrc == 0) {
                    igmp3_updt_tmr(nif, gaddr, (UB)max_resp_cod,
                                                           IGMP3_GRP_QRY, pkt);
                    break;
                }
                else {
                    igmp3_updt_tmr(nif, gaddr, (UB)max_resp_cod,
                                                           IGMP3_SRC_QRY, pkt);
                    break;
                }
            }
            gaddr = gaddr->nxt;
        }
    }
    return pkt;
}

/******************************************************************************
* Marks the list to respond the Query                                         *
******************************************************************************/
static void igmp3_updt_tmr(T_NIF *nif, T_GADDR *gaddr, UB max_resp_dly,
                                                        BOOL flag, T_IP4 *pkt)
{
    ER ercd;
    T_IGMP3_SRC *src, *prev = NULL, *temp;

    /* Already there is pending response for General Query.So, just leave it */
    if (nif->ipif_tmr != 0 && nif->ipif_tmr < max_resp_dly) {
        return;
    }
    switch (flag) {
    case IGMP3_GEN_QRY:
        /* Handle in case of zero */
        if (max_resp_dly == 0) {
            nif->ipif_tmr = 1;
        }
        else {
            nif->ipif_tmr = max_resp_dly;
        }
        return;

    case IGMP3_GRP_QRY:
    case IGMP3_SRC_QRY:
        if (gaddr->res_type == NOT_IN_USE) {
            /* if no pending response, respond for the query as it is */
            if (flag == IGMP3_GRP_QRY) {
                gaddr->res_type = PEND_RESP_GRP_SPECIFIC_QUERY;
            }
            else {
                /* If empty set of sources, no response is sent */
                if (igmp3_updt_response(gaddr, pkt) == 0) {
                    return;
                }
                gaddr->res_type = PEND_RESP_GRP_SRC_SPECIFIC_QUERY;
            }
            gaddr->grp_tmr = max_resp_dly;
            igmp3_add_resp_list(nif, gaddr);
            return;
        }
        else if (gaddr->res_type == PEND_RESP_GRP_SPECIFIC_QUERY) {
            /* already pending group specific query response. just update */
            /* the delay */
            if (max_resp_dly < gaddr->grp_tmr) {
                gaddr->grp_tmr = max_resp_dly;
            }
        }
        else if (gaddr->res_type == PEND_RESP_GRP_SRC_SPECIFIC_QUERY) {
            /* already pending group & source specific query response */
            /* if the new query is group specific, then combine it as group */
            /* specific query */
            if (flag == IGMP3_GRP_QRY) {
                /* Make it as group specific response */
                gaddr->res_type = PEND_RESP_GRP_SPECIFIC_QUERY;
                /* Clear the pending group & source specific response */
                src = gaddr->src_list;
                while (src) {
                    if (src->qry_flg == QUERIED) {
                        src->qry_flg = NOT_QUERIED;
                        /* Non-existing source was added for sending source */
                        /* specifi response in EXCLUDE mode. Remove it now */
                        if (gaddr->filt_mode == MODE_IS_EXCLUDE) {
                            temp = src;
                            if (gaddr->src_list == src) {
                                gaddr->src_list = src->nxt;
                            }
                            else {
                                prev->nxt = src->nxt;
                            }
                            src = src->nxt;
                            ercd = rel_mpf(ID_IGMP3_SRC_MPF, temp);
                            if (ercd != E_OK) {
                                ip_internal_error(ercd);
                                return;
                            }
                            continue;
                        }
                    }
                    prev = src;
                    src = src->nxt;
                }
            }
            else {
                /* Combine all pending source specific responses */
                gaddr->res_type = PEND_RESP_GRP_SRC_SPECIFIC_QUERY;
                igmp3_updt_response(gaddr, pkt);
            }
            /* Update the delay of the pending response */
            if (max_resp_dly < gaddr->grp_tmr) {
                gaddr->grp_tmr = max_resp_dly;
            }
        }
    }
    return;
}

/******************************************************************************
* Marks the list to respond the Query                                         *
******************************************************************************/
static ER igmp3_updt_response(T_GADDR *gaddr, T_IP4 *pkt)
{
    T_IGMP3_QRY *query;
    T_IGMP3_SRC *cur, *prev = NULL, *tmp;
    UW *qrysrc;
    ER ercd;
    int numsrc, i, cnt;

    query = (T_IGMP3_QRY *)pkt->data;
    numsrc = ntohs(query->numsrc);
    qrysrc = (UW *)(query->saddr);
    cnt = 0;

    for (i = 0; i < numsrc; i++) {
        cur = gaddr->src_list;
        while (cur) {
            if (ntohl(qrysrc[i]) == cur->ipaddr) {
                if (gaddr->filt_mode == MODE_IS_INCLUDE) {
                    cur->qry_flg = QUERIED;
                    cnt++;
                }
                break;
            }
            prev = cur;
            cur = cur->nxt;
        }
        if (cur == NULL && gaddr->filt_mode == MODE_IS_EXCLUDE) {
            /* If the source does not exist in EXCLUDE, it means the source */
            /* has to be included. So, add it for sending response in */
            /* igmp3_snd_spec_report() */
            ercd = pget_mpf(ID_IGMP3_SRC_MPF, (VP *)&tmp);
            if (ercd != E_OK) {
                ip_internal_error(ercd);
                return ercd;
            }
            if (gaddr->src_list == NULL) {
                gaddr->src_list = tmp;
            }
            else {
                prev->nxt = tmp;
            }
            tmp->ipaddr = ntohl(qrysrc[i]);
            tmp->nxt = NULL;
            tmp->qry_flg = QUERIED;
            cnt++;
        }
    }
    return cnt;
}

/******************************************************************************
* Add the Multicast Group address to the Pending Response list. This is when  *
* the response for General/Group specific/Group & Source specific Query is    *
* generated.                                                                  *
******************************************************************************/
static ER igmp3_add_resp_list(T_NIF *nif, T_GADDR *gaddr)
{
    T_GADDR *cur, *prev = NULL;

    if (nif->ipres_list == NULL) {
        nif->ipres_list = gaddr;
    }
    else {
        cur = nif->ipres_list;
        while (cur) {
            if (cur == gaddr) {
                return E_OK;
            }
            prev= cur;
            cur = cur->nxt_ipres;
        }
        prev->nxt_ipres = gaddr;
    }
    gaddr->nxt_ipres = NULL;
    return E_OK;
}

/******************************************************************************
* Periodic Timer Processing: For each NIF                                     *
******************************************************************************/
void igmp3_tmr_check(void)
{
    T_NIF *tmr_nif;

    tmr_nif = getnif_default();
    while (tmr_nif) {
        igmp3_tmr_nif(tmr_nif);
        tmr_nif = tmr_nif->next;
    }
}

/******************************************************************************
* Periodic Timer Processing: For single NIF                                   *
******************************************************************************/
static void igmp3_tmr_nif(T_NIF *nif)
{
    T_GADDR *cur;
    int i;

    if (nif->iprinfo.compt_timer != 0) {
        nif->iprinfo.compt_timer = nif->iprinfo.compt_timer - 1;
        if (nif->iprinfo.compt_timer == 0) {
            /* Switch to IGMPv3 mode */
            nif->iprinfo.compt_mode = IGMP_VER_3;

            /* Reset all items related to IGMPv2 timer */
            nif->ip.igmp_flag = 0; /* Clear IGMPv1 Router Present flag */
            /* Clear all pending items */
            for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
                if (mgrp_cb[i].ipaddr != 0) {
                    mgrp_cb[i].rptime = 0;
                }
            }
        }
        else{
            /* MLDv1 Timer Check */
            if (ip_miscflag & IGMP_MEMBER_EXISTS) {
                check_igmp_tmo();
            }
            return;
        }
    }
    /* IGMPv3 Mode */
    /* Check the retransmission list */
    if (nif->ipret_list != NULL) {
        cur = nif->ipret_list;
        while (cur) {
            igmp3_snd_state_change_report(nif, cur);
            cur = cur->nxt_ipret;
        }
        igmp3_rmv_retran_list(nif);
    }
    /* When interface is not scheduled for general response remains zero*/
    if (nif->ipif_tmr != 0) {
        nif->ipif_tmr = nif->ipif_tmr - 1;
        if (nif->ipif_tmr == 0) {
            igmp3_snd_all_report(nif);
        }
    }
    /* Check the response list */
    if (nif->ipres_list != NULL) {
        cur = nif->ipres_list;
        while (cur) {
            if (cur->grp_tmr == 0) {
                igmp3_snd_spec_report(nif, cur);
            }
            else {
                cur->grp_tmr = cur->grp_tmr - 1;
            }
            cur = cur->nxt_ipres;
        }
        igmp3_rmv_response_list(nif);
    }
    return;
}

/*****************************************************************************/
/* Remove the entry, if (robust varible - 1) reports has been sent           */
/*****************************************************************************/
static void igmp3_rmv_retran_list(T_NIF *nif)
{
    T_GADDR *prev = NULL, *rnode;
    T_IGMP3_SRC *src;

    rnode = nif->ipret_list;

    while (rnode) {
        src = rnode->src_list;
        /* If there is atleast one source that has to be retransmitted, then */
        /* donot remove the entry */
        while (src) {
            if (src->src_mode != NOT_APPLICABLE) {
                break;
            }
            src = src ->nxt;
        }
        /* If mode change transmit count also 0, then remove the entry */
        if ((rnode->ret_cnt == 0) && (src == NULL)) {
            /* INCLUDE & Src list = NULL, then it does not exist */
            if ((rnode->filt_mode == MODE_IS_INCLUDE) &&
                    (rnode->src_list == NULL) && (rnode->leave_flag == TRUE)) {
                igmp3_rmv_addr(nif, rnode);
            }
            if (rnode == nif->ipret_list) {
                nif->ipret_list = rnode->nxt_ipret;
                rnode->nxt_ipret = NULL;
                rnode = nif->ipret_list;
            }
            else {
                prev->nxt_ipret = rnode->nxt_ipret;
                rnode->nxt_ipret = NULL;
                rnode = prev->nxt_ipret;
            }
            continue;
        }
        prev = rnode;
        rnode = rnode->nxt_ipret;
     }
     return;
}

/*****************************************************************************/
/* Remove the entry, if State Report is sent                                 */
/*****************************************************************************/
static void igmp3_rmv_response_list(T_NIF *nif)
{
    T_GADDR *prev = NULL, *rnode;

    rnode = nif->ipres_list;

    while (rnode) {
        if (rnode->res_type == NOT_IN_USE) {
            if (rnode == nif->ipres_list) {
                nif->ipres_list = rnode->nxt_ipres;
                rnode->nxt_ipres = NULL;
                rnode = nif->ipres_list;
            }
            else {
                prev->nxt_ipres = rnode->nxt_ipres;
                rnode->nxt_ipres = NULL;
                rnode = prev->nxt_ipres;
            }
            continue;
        }
        prev = rnode;
        rnode = rnode->nxt_ipres;
    }
    return;
}

/*****************************************************************************/
/* Cancel All pending retransmissions due to State Change from API           */
/*****************************************************************************/
static ER cancel_pending_ipret(T_NIF *nif)
{
    T_IGMP3_SRC *src, *prev = NULL, *temp;
    T_GADDR *cur_list, *tmp;
    UB cur_smode, rem_fmode;
    ER ercd;
    int i;

    cur_list = nif->ipret_list;

    while (cur_list) {
        cur_smode = ALLOW;
        rem_fmode = MODE_IS_EXCLUDE;
        for (i = 0; i < 2; i++) {
            src = cur_list->src_list;
            cur_list->ret_cnt = 0;
            while (src) {
                if ((src->ret_cnt != 0) && (src->src_mode == cur_smode)) {
                    if (cur_list->filt_mode == rem_fmode) {
                        /* Remove the source */
                        temp = src;
                        if (cur_list->src_list == src) {
                            cur_list->src_list = src->nxt;
                        }
                        else {
                            prev->nxt = src->nxt;
                        }
                        src = src->nxt;
                        ercd = rel_mpf(ID_IGMP3_SRC_MPF, temp);
                        if (ercd != E_OK) {
                            ip_internal_error(ercd);
                            return ercd;
                        }
                        continue;
                    }
                    else{
                        src->ret_cnt = 0;
                        src->src_mode = NOT_APPLICABLE;
                    }
                }
                prev = src;
                src = src->nxt;
            }
            cur_smode = BLOCK;
            rem_fmode = MODE_IS_INCLUDE;
        }
        tmp = cur_list;
        cur_list = cur_list->nxt_ipret;
        tmp->nxt_ipret = NULL;
    }
    return E_OK;
}

/*****************************************************************************/
/* Cancel all pending response due to mldv2 query                            */
/*****************************************************************************/
static ER cancel_pending_ipres(T_GADDR *resp_list)
{
    T_IGMP3_SRC *src,* prev = NULL, *tmp;
    T_GADDR *cur_list;
    ER ercd;

    cur_list = resp_list;

    while (cur_list) {
        src = cur_list->src_list;
        while (src) {
            /* All queried sources are reset */
            if ( src->qry_flg == QUERIED) {
                if (cur_list->filt_mode == MODE_IS_INCLUDE) {
                    src->qry_flg = NOT_QUERIED;
                }
                else {
                    /* Non-existing source was added in EXCLUDE mode. */
                    /* Remove it */
                    tmp = src;
                    if (cur_list->src_list == src) {
                        cur_list->src_list = src->nxt;
                    }
                    else {
                        prev->nxt = src->nxt;
                    }
                    src = cur_list->src_list;
                    ercd = rel_mpf(ID_IGMP3_SRC_MPF, tmp);
                    if (ercd != E_OK) {
                        ip_internal_error(ercd);
                        return ercd;
                    }
                    continue;
                }
            }
            prev = src;
            src = src->nxt;
        }
        resp_list = cur_list;
        /* Response type is reset */
        cur_list->res_type = NOT_IN_USE;
        cur_list = cur_list->nxt_ipres;
        resp_list->nxt_ipres = NULL;
    }
    return E_OK;
}

/*****************************************************************************/
/* Make the IGMPv3 Packet                                                    */
/*****************************************************************************/
static ER igmp3_get_pkt(T_NIF *nif, T_IP4 **ppkt, T_IGMP3_REP **prep,
                      T_IGMP3_REC **prec, UW **psrcbuf)
{
    T_IP4 *pkt;
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec;
    UW *srcbuf;
    ER ercd;

    ercd = pget_mpf(ID_ETH_MPF, (VP *)&pkt);
    if (ercd != E_OK) {
        ip_internal_error(ercd);
        return ercd;
    }
    memset(&pkt->ctl, 0, sizeof (T_CTL_HEADER));
    pkt->ctl.mpfid = (H)ID_ETH_MPF;

    /* Alert option(4) + IGMP message(8) + (IGMP record(8) + Sources) */

    /* Leave space for Alert(4 bytes) option */
    /* Get one message pointer & record pointer */
    rep = (T_IGMP3_REP *)(pkt->data + 4);
    rec = (T_IGMP3_REC *)((UB *)rep + sizeof(T_IGMP3_REP));
    srcbuf = (UW *)((UB *)rec + sizeof(T_IGMP3_REC));
    memset(rep, 0, sizeof(T_IGMP3_REP));

    rep->type = IGMPV3_REPORT;

    *ppkt = pkt;
    *prep = rep;
    *prec = rec;
    *psrcbuf = srcbuf;
    return E_OK;
}

/*****************************************************************************/
/* To fill the Report and Record fields and send out the packet              */
/*****************************************************************************/
ER igmp3_snd_rep(T_NIF *nif, T_IP4 *pkt, UH nrec, UB typ, UH nsrc, UW ipaddr,
                                                                       UW len)
{
    T_IGMP3_REP *rep;
    T_IGMP3_REC *rec;

    /* Alert option(4) + IGMP message(8) + (IGMP record(8) + Sources) */

    /* Leave space for Alert(4 bytes) option */
    /* Get one message pointer & record pointer */
    rep = (T_IGMP3_REP *)(pkt->data + 4);

    /* Record has been filled already */
    if (typ != 0) {
        /* Trace the last record */
        rec = (T_IGMP3_REC *)((UB *)rep + len - (nsrc * 4) -
                                                   sizeof(T_IGMP3_REC));
        rec->rec_type = typ;
        rec->aux_dat_len = 0;
        rec->num_src = htons(nsrc);
        rec->group = htonl(ipaddr);
    }
    rep->num_rec = htons(nrec);
    rep->cs = igmp3_checksum((UH *)rep, len);
    return igmp3_snd_out(nif, pkt, len);

}

/*****************************************************************************/
/* Send the IGMPv3 Packet out                                                */
/*****************************************************************************/
static ER igmp3_snd_out(T_NIF *nif, T_IP4 *pkt, UW igmp3_len)
{
    pkt->ip.da = htonl(byte4_to_long(all_rtr_maddr));
    pkt->ip.sa = htonl(byte4_to_long(nif->ipaddr));

    pkt->ip.ver = 0x46;
    pkt->ip.tl = htons(IP4_HEADER_SZ + (UH)igmp3_len + 4);

    pkt->ip.tos = 0;
    pkt->ip.id = htons(ip_ident++);
    pkt->ip.fo = 0;
    pkt->ip.ttl = 1;
    pkt->ip.prot = PROT_IGMP;

    memset(pkt->eth.da, 0, 6);
    pkt->eth.etype = htons(ETYPE_IP4);

    pkt->ctl.hedflg = FALSE;

    *pkt->data = 0x94;
    *(pkt->data + 1) = 0x04;
    *(pkt->data + 2) = 0x00;
    *(pkt->data + 3) = 0x00;

    return snd_mbx(nif->smbxid, (T_MSG *)pkt);
}

/*****************************************************************************/
/* Clear the IGMPv3 Source List                                              */
/*****************************************************************************/
ER igmp3_free_src(T_IGMP3_SRC *src)
{
    T_IGMP3_SRC *nxt;
    ER ercd;

    while (src) {
        nxt = src->nxt;
        ercd = rel_mpf(ID_IGMP3_SRC_MPF, src);
        if (ercd != E_OK) {
            ip_internal_error(ercd);
            return ercd;
        }
        src = nxt;
    }
    return E_OK;
}

/*****************************************************************************/
/* Delete the IGMPv3 Address node from the Interface address list            */
/*****************************************************************************/
static ER igmp3_rmv_addr(T_NIF *nif, T_GADDR *gaddr)
{
    T_GADDR *tmp, *prev = NULL;
    ER ercd;

    if (nif->gaddr_list == gaddr) {
        nif->gaddr_list = gaddr->nxt;
    }
    else {
        tmp = nif->gaddr_list;
        while (tmp) {
            if (tmp == gaddr) {
                break;
            }
            prev = tmp;
            tmp = tmp->nxt;
        }
        prev->nxt = gaddr->nxt;
    }
    ercd = rel_mpf(ID_IGMP3_ADR_MPF, gaddr);
    if (ercd != E_OK) {
        ip_internal_error(ercd);
        return ercd;
    }
    return E_OK;
}

/*****************************************************************************/
/* Returns the Group address structure of NIF, for the given IP address      */
/*****************************************************************************/
static T_GADDR *igmp3_util_getgaddr(T_NIF *nif, UW maddr)
{
    T_GADDR *gaddr;

    gaddr = nif->gaddr_list;
    while (gaddr) {
        if (gaddr->ipaddr == maddr) {
            /* The addr exists here already, do the corresponding action */
            return gaddr;
        }
        gaddr = gaddr->nxt;
    }
    return NULL;
}

/*****************************************************************************/
/* IGMPv3 Checksum calculation                                               */
/*****************************************************************************/
static UH igmp3_checksum(UH *msg, UW tot_len)
{
    UW chksum;
    UW cnt;

   /* Initialize to zero */
   chksum = 0;

   /* IGMP3 Message */
    for (cnt = 0; cnt < (tot_len/2); cnt++) {
        chksum += *msg++;
    }
    chksum = (chksum & 0xffff) + (chksum >> 16);
    chksum += (chksum >> 16);
    return (UH)~chksum;
}

/*****************************************************************************/
/* IGMPv3 initialization: Join all-system-multicast address. Initialize the  */
/* system variables.                                                         */
/*****************************************************************************/
ER igmp3_ini(T_NIF *nif)
{
    /* Initialize the interface system variables */
    nif->gaddr_list = NULL;
    nif->ipret_list = NULL;
    nif->ipres_list = NULL;

    nif->iprinfo.compt_timer = 0;
    nif->iprinfo.compt_mode = IGMP_VER_3;
    nif->iprinfo.qrv = IGMP_ROBUSTNESS;
    nif->iprinfo.qqi = IGMP_ROUTER_QUERY_INTERVAL;
    nif->iprinfo.max_res_time = IGMP_MAX_RESP;

    /* Join the all-system-multicast address */
    return igmp3_if_jgrp(nif, NULL);
}

/*****************************************************************************/
/* Release all resources allocated by IGMPv3. It is user application`s       */
/* responsibility to leave the groups, before calling this function.         */
/*****************************************************************************/
ER igmp3_rel_addrlist(T_NIF *nif)
{
    T_GADDR *gaddr;
    ER ercd;

    if (nif == NULL) {
        nif = getnif_default();
    }
    if (nif == NULL) {
        return E_OBJ;
    }

    gaddr = nif->gaddr_list;
    while (gaddr) {
        /* Release the Source Address List */
        ercd = igmp3_free_src(gaddr->src_list);
        if (ercd != E_OK) {
            return ercd;
        }
        gaddr->src_list = NULL;

        nif->gaddr_list = gaddr->nxt;
        /* Release the address node */
        ercd = rel_mpf(ID_IGMP3_ADR_MPF, gaddr);
        if (ercd != E_OK) {
            ip_internal_error(ercd);
            return ercd;
        }
        gaddr = nif->gaddr_list;
    }
    return E_OK;
}

/*****************************************************************************/
/* When IGMPv2/1 Query is recieved, this function is called from IGMP module */
/* to set the system in IGMPv2/1 compatible mode.                            */
/*****************************************************************************/
ER igmp3_setv2_mod(T_NIF *nif)
{
    ER ercd;

    /* Get back to IGMPv2 Mode. Clear any retransmission due to APIs */
    if (nif->ipret_list != NULL) {
        ercd = cancel_pending_ipret(nif);
        if (ercd != E_OK) {
            return ercd;
        }
        nif->ipret_list = NULL;
    }
    nif->iprinfo.compt_timer = nif->iprinfo.qrv * nif->iprinfo.qqi +
                                              nif->iprinfo.max_res_time;

    /* If it is first query when system is in IGMPv3 mode, */
    /* Cancel the pending responses due to IGMPv3 Query */
    /* and set the mode to IGMPv2. All igmp3 timer check items have to */
    /* be reset here */
    if (nif->iprinfo.compt_mode == IGMP_VER_3) {
        /* Set the flag to start the timer check */
        ip_miscflag |= IGMP_MEMBER_EXISTS;
        /* Reset the Interface timer */
        nif->ipif_tmr = 0;
        if (nif->ipres_list != NULL) {
            ercd = cancel_pending_ipres(nif->ipres_list);
            if (ercd != E_OK) {
                return ercd;
            }
            nif->ipres_list = NULL;
        }
        nif->iprinfo.compt_mode = IGMP_VER_2;
    }
    return E_OK;
}
/************************** END **********************************************/
