/******************************************************************************
* NORTi TCP/IP Stack - Initialization & Common Subroutines                    *
*                                                                             *
*  Copyright (c) 1999-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05 Created                                                          *
* 2000-10-03 Released as Ver.4.02                                             *
* 2000-11-20 Modified remove_queued_packet() & remove_snd/rcvque_udppkt()     *
* 2000-12-01 Released as Ver.4.03                                             *
* 2001-02-10 Modified tcp_portany() and udp_portany()                         *
* 2002-03-30 Modified for loopback interface                                  *
* 2002-06-26 Added support for IP fragmentation and reassembly             AK *
* 2003-04-14 Added ARP timer initialization code                              *
* 2003-04-28 Added initialization code for mgrb_cp and ipq_hash               *
* 2004-07-01 Modified for IPv6 stack                                       PK *
* 2004-09-17 Modified tcp_nif_ini() for updation in MAC address            PK *
* 2004-09-30 Modified tcp_ini() & tcp_nif_ini() for IPv6 manual config     PK *
* 2005-01-21 Added initialization of retrans and reachable timer           PK *
* 2005-01-21 Added creation of mailmox for retrying IPv6 packet            PK *
* 2005-04-04 Added configurable TCP/IP parameters for each interface       AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2005-10-01 Added DUAL_STK macro for nif->rmbxid2                         AK *
* 2006-01-27 Updated SNMP refresh for chg_cep_ipaddr function              MK *
* 2006-03-24 Added TCP_DACK_TMO,TCP_DUP_ACK & IGMPV1_PRESENT_TMO           AK *
* 2006-07-22 Added support for MLDv2                                       GS *
* 2006-07-29 Added support for SNMP of IPv6                                MK *
* 2008-03-04 Added nestable tcpip_critical() to replace tcpip_cretical()   OK *
* 2008-05-13 Tuned loop of searching UDP/TCP end points & reception points OM *
* 2008-06-30 Added support for RAW communication end point                 OM *
* 2008-07-01 Removed ID_IP_SND/_RCV_TSK, ID_TCPIP_SEM and ID_IP_RETRY_MBX  FY *
* 2008-07-01 Changed id_udp_mbx and ID_IP_SND_MBX initialization process   FY *
* 2008-07-01 Changed stskid, rtskid and smbxid initialization process      FY *
* 2008-07-01 Added NIF clear process in tcp_nif_ini()                      FY *
* 2008-07-01 Added clear of object ID number of NIF in tcp_nif_ext()       FY *
* 2008-07-15 Changed initialization of global or constant variables        OM *
* 2008-07-18 Adjusted indent of switch-case sentence                       GS *
* 2008-07-31 Added support for PPPoE multi session                         FY *
* 2008-10-16 Deleted some unnecessary spaces at end of line                FY *
* 2008-10-22 Fixed tcp_nif_ini() not to call ipv6_ini() when PPP or PPPoE  FY *
* 2008-10-26 Modified for IPv6 stack                                       IS *
* 2008-12-17 Added support for IGMPv3                                      GS *
* 2008-12-24 Modified getnif_from_ch()                                     IS *
* 2008-12-24 Modified getnif_from_name()                                   IS *
* 2009-02-10 Modified tcp_nif_ini()                                        IS *
* 2009-02-19 Modified chk_ip_nif()                                         IS *
* 2009-08-31 Replaced some compiler unsupported atoi() with strtol()       JO *
* 2009-09-14 Added release of memory pool of ID_MLDV2_MPF                     *
*                          when IPv6 cyclic handler initialization failed  GS *
* 2009-12-21 Added net_get_transmission_pkt()/net_set_transmission_pkt()      *
*                for fixing sending order of UDP packet when ARP overlaps  KZ *
* 2010-01-13 Added is_nif_ipaddr() to fix UDP unsendable to another NIF    KZ *
* 2010-01-28 Changed htonl & htons from macro to function in big endian    KZ *
* 2010-04-21 Added missing IGMPv3 memory pool release after tcp_ini error  FY *
* 2010-07-14 Replaced wait macro by MSEC2TICK macro                        FY *
* 2011-06-30 Corrected NC100 compiler warning of callback function type    HE *
* 2011-07-05 Changed modifier of *mbx from NEAR to SNEAR                   HE *
* 2012-02-08 Added counting of CEPs which use multihome in netif_chg_ipa   FY *
* 2012-02-08 Skipped check of CEP IP addresses when multihome is not used  FY *
* 2012-02-09 Removed is_ip_uniq(), since chk_ip_nif() can be used instead  FY *
* 2012-02-09 Skipped check of unused CEP/REPs using pTCP_xEP/pUDP_CEP list FY *
* 2012-03-02 Removed unnecessary check of CEP type in is_nif_ipaddr()      FY *
* 2012-03-21 Corrected compiler warning by adding (FP) to tcpip_timer_func SZ *
* 2012-03-29 Corrected insufficient exclusion control of can_cep_process() FY *
* 2012-04-14 Moved initialization of modem, before starting IP task        FY *
* 2012-05-28 Deleted unused tcpip_cretical() due to added tcpip_critical() FY *
* 2012-06-08 Added initialization of IPv4 and IPv6 static routing tables   GS *
* 2012-07-05 Added function to choose NIF with static route to remote host FY *
* 2012-11-13 Reduced ID variables size to UH (ex. ID_IP_xxx, ID_ETH_MPF)   FY *
* 2012-11-13 Deleted processing for IP fragment initialization,               *
*            and added call of initialization function in ini_tcpip_var()  FY *
* 2013-01-24 Added ip4addr_to_ascii() not to convert byte-order of ipaddr  FY *
* 2013-06-18 Added missing UDP/RAW mailbox/memorypool release in tcp_ext   FY *
* 2013-06-18 Added missing RAW canceling process in can_cep_process()      FY *
* 2013-06-18 Fixed problem that it bocomes impossible to use IPv6,            *
*             when initialization of channel of 2nd henceforth went wrong  FY *
* 2013-06-18 Changed dcls_id type (UH->H) to avoid RXC misjadge with (-1)  FY *
* 2013-06-18 Added dcls_id = 0 when calling rel_wai(dcls_id)               FY *
* 2014-10-20 Added process of ARP table pointer                            FY *
* 2015-01-21 Changed handling of host_id                                   FY *
* 2015-05-27 Added Simulator support and adjusted style                    PB *
* 2016-03-31 Added ascii_to_ipxaddr() to change ascii to IPv4/IPv6 address FY *
* 2016-04-04 Added getnif_dstxaddr() to get NIF for IPv4/IPv6 address      FY *
* 2017-04-19 Fixed do-while to while in tcp_ext() to avoid nif NULL access GS *
* 2020-07-27 Removed setup of tcp_iss in ini_tcpip_var() to randomize it   FY *
* 2021-06-08 Deleted initialization of removed tcp_tim_pkt & ip_tim_pkt    FY *
* 2021-06-22 Replaced tTCPIP_TIMER_FLAG/IGMP_MEMBER_EXISTS = FALSE            *
*                                 with ip_miscflag = 0 in ini_tcpip_var()  FY *
* 2021-06-22 Removed nif->nd_retry_time = 0 in tcp_nif_ini()               FY *
* 2021-06-22 Removed creating mailbox for ARP retry queue in tcp_nif_ini() FY *
* 2021-06-22 Changed 2nd parameter of remove_queued_packet() and              *
*             remove_sndque_udppkt/_rawpkt() from ID rmbxid to T_ETH *wpkt FY *
* 2021-06-22 Removed 3rd param of arp_request() calling in netif_chg_ipa() FY *
* 2021-06-22 Modified net_set_transmission_pkt()'s packet queuing way         *
*                        from ARP retry count order to simplly FIFO order  FY *
* 2021-09-05 Added setup of nif->icmpdu in tcp_nif_ini()                   FY *
* 2021-11-18 Added nif->tim_pkt.ctl.fncd=TFN_IP_TIM_ON in tcp_nif_ini()       *
*             and tcpip_timer_flag/wup_stsk_inuse=FALSE in ini_tcpip_var() FY *
* 2022-10-20 Tuned ascii_to_ipaddr_sub(), unusing non-reentrant strtol()   FY *
* 2023-10-19 Simplified tcp_init()'s tcpip_timer setup, removing its const FY *
* 2023-10-19 Replaced ipv6_ini_cyc() call to tcp6_init() call, and moved      *
*                IPv6 initialization process in tcp_init() to tcp6_init()  FY *
******************************************************************************/

#include <string.h>
#include <stdlib.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/* Internal Variables */

static const UH order = 0x1234;
T_NIF *netif;

/* Object IDs */

UH ID_IP_SND_MBX;
UH ID_ETH_MPF;
UH ID_IP_TIM;

/******************************************************************************
* Module Name   : tcpip_internal_error                                        *
* Purpose       : This function is called by TCP/IP stack whenever an internal*
*                 error occurred. DEBUG option must be enabled for this.      *
* Arguments     : ER ercd - Error code.                                       *
* Return value  : Returns the error code.                                     *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

#ifndef DEBUG
ER tcpip_internal_error(ER ercd)
{
    return ercd;
}
#endif

/************************************************/
/* 32-bit Host/Network Byte Order Convertsion   */
/************************************************/

UW htonl(UW hl)
{
    UW nl;

    /* nothing to do for BIG ENDIAN */
    if (*(UB *)(&order) == 0x12)
        return hl;

    /* reverse the byte order */
    nl = hl;
    nl <<= 8; hl >>= 8; nl |= (UB)hl;
    nl <<= 8; hl >>= 8; nl |= (UB)hl;
    nl <<= 8; hl >>= 8; nl |= (UB)hl;
    return nl;
}

/************************************************/
/* 16-bit Host/Network Byte Order Convertsion   */
/************************************************/

UH htons(UH hs)
{
    UH ns;

    /* nothing to do for Big Endian */
    if (*(UB *)(&order) == 0x12)
        return hs;

    /* reverse the byte order */
    ns = hs;
    ns <<= 8; hs >>= 8; ns |= (UB)hs;
    return ns;
}

/************************************************/
/* 4 bytes Array to Long Integer                */
/************************************************/

UW byte4_to_long(const UB *b)
{
    UW d;

    d  = b[0]; d <<= 8;
    d |= b[1]; d <<= 8;
    d |= b[2]; d <<= 8;
    d |= b[3];

    return d;
}

/************************************************/
/* Long Integer to 4 bytes Array                */
/************************************************/

void long_to_byte4(UB *b, UW d)
{
    b[3] = (UB)d; d >>= 8;
    b[2] = (UB)d; d >>= 8;
    b[1] = (UB)d; d >>= 8;
    b[0] = (UB)d;
}

/************************************************/
/* IP Address String to Long Integer            */
/************************************************/

ER ascii_to_ipaddr_sub(const char *s, UW *d)
{
    UW ipaddr;
    int i, c, n;

    for (ipaddr = i = 0;; ipaddr <<= 8) {
        while ((c = *s++) == ' ')
            ;
        if (c < '0' || c > '9')
            return E_PAR;;
        n = c - '0';
        while ((c = *s++) >= '0' && c <= '9') {
            n = n * 10 + c - '0';
            if (n > 255)
                return E_PAR;
        }
        ipaddr |= n;
        while (c == ' ')
            c = *s++;
        if (++i == 4) {
            if (c != '\0')
                return E_PAR;
            break;
        }
        if (c != '.')
            return E_PAR;
    }
    *d = ipaddr;
    return E_OK;
}

UW ascii_to_ipaddr(const char *s)
{
    UW ipaddr;

    if (ascii_to_ipaddr_sub(s, &ipaddr) != E_OK)
        return 0;

    return ipaddr;
}

/************************************************/
/* IP Address String to T_IPEP Format           */
/************************************************/

ER ascii_to_ipxaddr(const char *s, T_IPEP *addr)
{
  #ifdef DUAL_STK
    int i;

    for (i = 0; s[i] != '\0'; i++) {
        if ((s[i] >= 'A' && s[i] <= 'F') ||
            (s[i] >= 'a' && s[i] <= 'f') ||
            (s[i] == ':')) {
            addr->type = IPV6_ADDR;
            /* get IPv6 address */
            return ascii_to_ip6addr_sub(s, addr->ip6addr);
        }
        if (s[i] == '.') {
            addr->type = IPV4_ADDR;
  #endif
            /* get IPv4 address */
            return ascii_to_ipaddr_sub(s, &addr->ipaddr);
  #ifdef DUAL_STK
        }
    }
    return E_PAR;
  #endif
}

/************************************************/
/* Long Integer to IP Address String            */
/************************************************/

INT ip4addr_to_ascii(char *s, UW ipaddr)
{
    INT i, n;
    UB d[4];
    char *ss = s;

    for (i = 3;;) {
        d[i] = (UB)ipaddr;
        if (--i < 0)
            break;
        ipaddr >>= 8;
    }
    for (i = 0;;) {
        n = itoulen(d[i]);
        itou((char *)s, d[i], n);
        s += n;
        if (++i > 3)
            break;
        *s++ = '.';
    }
    *s = '\0';
    return s - ss;
}

INT ipaddr_to_ascii(char *s, UW ipaddr)
{
    return ip4addr_to_ascii(s, ntohl(ipaddr));
}

/******************************************************************************
* Module Name   : assign_obj_id                                               *
* Purpose       : This function initializes the ID value for all the TCP and  *
*                 UDP CEP's.                                                  *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void assign_obj_id(void)
{
    int id, i;

    /* mailbox ID */
    ID_ETH_MPF = TCP_MPFID_TOP;
    if (TCP_MBXID_TOP != 0) {
        id = TCP_MBXID_TOP;
        for (i = 0; i < UDP_CEPID_MAX; i++)
            UDP_CEP[i].id_udp_mbx = (UH)(id++);
        ID_IP_SND_MBX = (UH)id;
    } else {
        ID_IP_SND_MBX = 0;
    }

    /* memory pool ID */
    if (ID_ETH_MPF != 0) { /* ID auto */
        id = ID_ETH_MPF + 1;
        for (i = 0; i < UDP_CEPID_MAX; i++)
            UDP_CEP[i].id_udp_mpf = (UH)(id++);
        /* assign object IDs for IGMPv3, MLDv2 memory pools */
        ID_IGMP3_ADR_MPF = (UH)(id++);
        ID_IGMP3_SRC_MPF = (UH)(id++);
      #ifdef DUAL_STK
        ID_MLDV2_MPF = (UH)(id++);
      #endif
    }
}

/******************************************************************************
* Module Name   : ini_tcp_rep                                                 *
* Purpose       : This function initializes TCP REP to its default values.    *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void ini_tcp_rep(void)
{
    int i;

    for (i = 0; i < TCP_REPID_MAX; i++) {
        memset(&TCP_REP[i], 0, sizeof (T_TCP_REP));
        TCP_REP[i].repid = (UH)(i + 1);
    }
    pTCP_REP = NULL;
}

/******************************************************************************
* Module Name   : ini_tcp_cep                                                 *
* Purpose       : This function initializes TCP CEP to its default values.    *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void ini_tcp_cep(void)
{
    int i;

    for (i = 0; i < TCP_CEPID_MAX; i++) {
        memset(&TCP_CEP[i], 0, sizeof (T_TCP_CEP));
        TCP_CEP[i].cepid = (UH)(i + 1);
    }
    pTCP_CEP = NULL;
}

/******************************************************************************
* Module Name   : ini_udp_cep                                                 *
* Purpose       : This function initializes UDP CEP to its default values.    *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void ini_udp_cep(void)
{
    int i;

    for (i = 0; i < UDP_CEPID_MAX; i++) {
        memset(&UDP_CEP[i], 0, sizeof (T_UDP_CEP));
        UDP_CEP[i].cepid = (UH)(i + 1);
    }
    pUDP_CEP = NULL;
}

/******************************************************************************
* Module Name   : ini_raw_cep                                                 *
* Purpose       : This function initializes RAW CEP to its default values.    *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

static void ini_raw_cep(void)
{
    int i;

    for (i = 0; i < RAW_CEPID_MAX; i++) {
        memset(&RAW_CEP[i], 0, sizeof (T_RAW_CEP));
        RAW_CEP[i].cepid = (UH)(i + 1);
    }
    pRAW_CEP = NULL;
}

/******************************************************************************
* Module Name   : ini_mgrp_blk                                                *
* Purpose       : This function initializes Multicast group control blocks to *
*                 its default values.                                         *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void ini_mgrp_blk(void)
{
    int i;

    for (i = 0; i < MULTICAST_GROUP_CNT; i++) {
        mgrp_cb[i].ipaddr = 0;
        mgrp_cb[i].portno = 0;
        mgrp_cb[i].cep = NULL;
        mgrp_cb[i].nif = NULL;
    }
}

/******************************************************************************
* Module Name   : ini_tcpip_var                                               *
* Purpose       : This function initializes various global variables used in  *
*                 the TCP/IP stack.                                           *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

static void ini_tcpip_var(void)
{
    /* end point initialization */
    ini_tcp_rep();
    ini_tcp_cep();
    ini_udp_cep();
    ini_raw_cep();

    ini_route_table();  /* initialize IPv4 routing table */

    ip_ident = 0;
    port_any = (UH)TCP_PORT_EPHEMERAL;

    ip_timer = 0;
    ip_miscflag = 0;
    tcpip_timer_flag = FALSE;
    wup_stsk_inuse = FALSE;

    pICMP_CB = NULL;
    pIP_CB   = NULL;
    pARP_CB  = NULL;

    ini_mgrp_blk();

    reass_ini();        /* initialize IP reassembly module */

  #ifdef DUAL_STK
    pICMP6_CB = NULL;
    reass6_ini();
  #endif
}

/******************************************************************************
* Module Name   : tcp_portany                                                 *
* Purpose       : This function searches a free port to be allocated for TCP  *
*                 or UDP CEP. The range of available port are starts from the *
*                 Ephemeral port to maximum of 0xFFFF.                        *
* Arguments     : None.                                                       *
* Return value  : Returns a free port number.                                 *
* Author        : AK                                                          *
* Date          : 11-Jul-2002                                                 *
******************************************************************************/

UH tcp_portany(void)
{
    T_TCP_REP *rep;
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;

L1:
    if (++port_any == 0xFFFF)
        port_any = (UH)(TCP_PORT_EPHEMERAL + 1);

    for (rep = pTCP_REP; rep != NULL; rep = rep->next)
        if (rep->portno == port_any)
            goto L1;

    for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next)
        if (tcep->portno == port_any)
            goto L1;

    for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next)
        if (ucep->portno == port_any)
            goto L1;

    return port_any;
}

/******************************************************************************
* Module Name   : tcp_set_iss                                                 *
* Purpose       : This API can be used to set any random value as TCP ISS.    *
* Arguments     : None.                                                       *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

void tcp_set_iss(UW iss)
{
    tcp_iss = iss;
}


/******************************************************************************
* Module Name   : netif_set_opt                                               *
* Purpose       : This API can be used to configure various parameters of the *
*                 TCP/IP stack.                                               *
* Arguments     : T_NIF *nif      - Network interface address.                *
*                 INT optname     - TCP/IP Parameter to be configured.        *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER netif_set_opt(T_NIF *nif, INT optname, const VP optval, INT optlen)
{
    ER ercd;
    UW tval;
    UH val;
    UB b;
    PRI save_pri;

    /* return err if invalid interface specified */
    if (nif == NULL)
        return E_PAR;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    ercd = E_OK;

    switch (optname) {
    case SET_IF_MTU:
        val = *((UH *)optval);
        /* check for valid MTU size */
        if (val > ETHERNET_MTU || val < NIF_MTU_MIN) {
            ercd = E_PAR;
            break;
        }

        /* update the values in NIF structure */
        nif->mtu      = val;
        nif->path_mtu = val - (UH)IP4_HEADER_SZ;
        break;

    case SET_IP_TTL:
        b = *((UB *)optval);
        if (b < 1) {
            ercd = E_PAR;
            break;
        }
        nif->ip.ttl = b;
        break;

    case SET_IP_MTTL:
        b = *((UB *)optval);
        if (b < 1) {
            ercd = E_PAR;
            break;
        }
        nif->ip.m_ttl = b;
        break;

    case SET_IP_REASM_TMO:
        val = *((UH *)optval);
        nif->ip.reasm_tmo = val;
        break;

    case SET_TCP_SYN_RCNT:
        val = *((UH *)optval);
        nif->tcp.syn_rcnt = val;
        break;

    case SET_TCP_DAT_RCNT:
        val = *((UH *)optval);
        nif->tcp.dat_rcnt = val;
        break;

    case SET_TCP_RTO_INI:
        tval = *((UW *)optval);
        nif->tcp.rto_ini = tval;
        break;

    case SET_TCP_RTO_MIN:
        tval = *((UW *)optval);
        nif->tcp.rto_min = tval;
        break;

    case SET_TCP_RTO_MAX:
        tval = *((UW *)optval);
        nif->tcp.rto_max = tval;
        break;

    case SET_TCP_KEEPALIVE_TMO:
        tval = *((UW *)optval);
        nif->tcp.ktime_tmo = tval;
        break;

    case SET_TCP_KEEPALIVE_PRO:
        tval = *((UW *)optval);
        nif->tcp.ktime_pro = tval;
        break;

    case SET_TCP_KEEPALIVE_SUC:
        if (optlen != sizeof (UW))
            return E_OBJ;
        tval = *((UW *)optval);
        nif->tcp.ktime_suc = tval;
        break;

    case SET_TCP_DACK_TMO:
        val = *((UH *)optval);
        nif->tcp.dack_tmo = val;
        break;

    case SET_TCP_DUP_ACK:
        val = *((UH *)optval);
        nif->tcp.dup_ack = val;
        break;

    default:
        optlen = 0;
        ercd = E_PAR;
        break;
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : net_set_opt                                                 *
* Purpose       : This API can be used to configure various parameters of the *
*                 TCP/IP stack.                                               *
* Arguments     : INT optname     - TCP/IP Parameter to be configured.        *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 08-Mar-2004                                                 *
******************************************************************************/

ER net_set_opt(INT optname, const VP optval, INT optlen)
{
    T_NIF *nif;
    nif = getnif_default();
    return netif_set_opt(nif, optname, optval, optlen);
}

ER netif_set_byname(const char *name, INT optname, const VP optval, INT optlen)
{
    T_NIF *nif;
    nif = getnif_from_name(name);
    return netif_set_opt(nif, optname, optval, optlen);
}

/******************************************************************************
* Module Name   : netif_get_opt                                               *
* Purpose       : This API can be used to check the value of various          *
*                 parameters of the TCP/IP stack.                             *
* Arguments     : T_NIF *nif      - Network interface address.                *
*                 INT optname     - TCP/IP Parameter to be viewed.            *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

ER netif_get_opt(T_NIF *nif, INT optname, const VP optval, INT optlen)
{
    ER ercd;
    UW *tval;
    UH *val;
    UB *b;
    PRI save_pri;

    /* return err if invalid interface specified */
    if (nif == NULL)
        return E_PAR;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    ercd = E_OK;

    switch (optname) {
    case SET_IF_MTU:
        val  = (UH *)optval;
        *val = nif->mtu;
        break;

    case SET_IP_TTL:
        b  = (UB *)optval;
        *b = nif->ip.ttl;
        break;

    case SET_IP_MTTL:
        b  = (UB *)optval;
        *b = nif->ip.m_ttl;
        break;

    case SET_IP_REASM_TMO:
        val  = (UH *)optval;
        *val = nif->ip.reasm_tmo;
        break;

    case SET_TCP_SYN_RCNT:
        val  = (UH *)optval;
        *val = nif->tcp.syn_rcnt;
        break;

    case SET_TCP_DAT_RCNT:
        val  = (UH *)optval;
        *val = nif->tcp.dat_rcnt;
        break;

    case SET_TCP_RTO_INI:
        tval  = (UW *)optval;
        *tval = nif->tcp.rto_ini;
        break;

    case SET_TCP_RTO_MIN:
        tval  = (UW *)optval;
        *tval = nif->tcp.rto_min;
        break;

    case SET_TCP_RTO_MAX:
        tval  = (UW *)optval;
        *tval = nif->tcp.rto_max;
        break;

    case SET_TCP_KEEPALIVE_TMO:
        tval  = (UW *)optval;
        *tval = nif->tcp.ktime_tmo;
        break;

    case SET_TCP_KEEPALIVE_PRO:
        tval  = (UW *)optval;
        *tval = nif->tcp.ktime_pro;
        break;

    case SET_TCP_KEEPALIVE_SUC:
        if (optlen != sizeof (UW))
            return E_OBJ;
        tval  = (UW *)optval;
        *tval = nif->tcp.ktime_suc;
        break;

    case SET_TCP_DACK_TMO:
        val  = (UH *)optval;
        *val = nif->tcp.dack_tmo;
        break;

    case SET_TCP_DUP_ACK:
        val  = (UH *)optval;
        *val = nif->tcp.dup_ack;
        break;

    default:
        optlen = 0;
        ercd = E_PAR;
        break;
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : net_get_opt                                                 *
* Purpose       : This API can be used to check the value of various          *
*                 parameters used by the TCP/IP stack.                        *
* Arguments     : INT optname     - TCP/IP Parameter to be viewed.            *
*                 const VP optval - Value of the parameter.                   *
*                 INT optlen      - Length of the option value.               *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : AK                                                          *
* Date          : 08-Mar-2004                                                 *
******************************************************************************/

ER net_get_opt(INT optname, const VP optval, INT optlen)
{
    T_NIF *nif;
    nif = getnif_default();
    return netif_get_opt(nif, optname, optval, optlen);
}

ER netif_get_byname(const char *name, INT optname, const VP optval, INT optlen)
{
    T_NIF *nif;
    nif = getnif_from_name(name);
    return netif_get_opt(nif, optname, optval, optlen);
}

/******************************************************************************
* Module Name   : netif_ini_opt                                               *
* Purpose       : This function initializes the TCP/IP configurable values to *
*                 its default value.                                          *
* Arguments     : T_NIF *nif - Network interface address.                     *
* Return value  : None.                                                       *
* Author        : AK                                                          *
* Date          : 2004                                                        *
******************************************************************************/

void netif_ini_opt(T_NIF *nif)
{
    /* initialize loopback mode */
    nif_loop_back      = 0;

    /* initialize MTU values */
    nif->mtu           = (UH)ETHERNET_MTU;
    nif->path_mtu      = (UH)(ETHERNET_MTU - IP4_HEADER_SZ);
  #ifdef DUAL_STK
    nif->path_mtu6     = PATH_MTU6;
  #endif

    /* initialize IP options */
    nif->ip.ttl        = (UB)IP_DEF_TTL;
    nif->ip.m_ttl      = (UB)IP_DEF_MTTL;
    nif->ip.reasm_tmo  = IPF_REASM_TMO;

    /* initialize IGMP variables */
    nif->ip.igmp_flag  = 0;
    nif->ip.igmpv1_tmo = 0;

    /* initialize TCP options */
    nif->tcp.rto_ini   = MSEC2TICK(TCP_RTO_INI);
    nif->tcp.rto_min   = MSEC2TICK(TCP_RTO_LBOUND);
    nif->tcp.rto_max   = MSEC2TICK(TCP_RTO_UBOUND);

    nif->tcp.syn_rcnt  = (UH)TCP_SYN_RETRY;
    nif->tcp.dat_rcnt  = (UH)TCP_DATA_RETRY;

    nif->tcp.ktime_tmo = (UW)TCP_KTIME_INI;
    nif->tcp.ktime_pro = (UW)TCP_KTIME_PRO;
    nif->tcp.ktime_suc = (UW)TCP_KTIME_SUC;

    nif->tcp.dack_tmo  = MSEC2TICK(TCP_DACK_TMO);
    nif->tcp.dup_ack   = (UH)TCP_DUP_ACK;
}

ER set_arp_index(T_NIF *nif)
{
    T_NIF *t_nif;

    /* assign ARP for Ethernet interface */
    if (nif->type != NI_ETH) {
        nif->arp_index = -1; /* interface does not use ARP */
        return E_OK;
    }

    nif->arp_index = 0;  /* initial value */

    /* check any other interface using the same index value */
    t_nif = netif;
    while (t_nif) {
        if (t_nif->type == NI_ETH && t_nif != nif && t_nif->arp_index == nif->arp_index) {
            /* other interface using this index value, try to use other value */
            nif->arp_index++;
            t_nif = netif;      /* continue check with new entry */
            continue;
        }
        t_nif = t_nif->next;
    }

    /* no index value available */
    if (nif->arp_index < ARP_NIF_CNT) {
        nif->arp_table = &arp_table[nif->arp_index * ARP_TABLE_CNT];
    } else {
        nif->arp_table = (T_ARP_TABLE *)sys_alloc(sizeof (T_ARP_TABLE) * ARP_TABLE_CNT);
        if (nif->arp_table == NULL)
            return E_NOMEM;
    }

    /* initialize the interface ARP table */
    nif_ini_arp(nif);

    return E_OK;
}

static ID get_next_tid(ID n, UB i)
{
    T_NIF *t;

    /* n -> curr stskid, n+1 curr rtskid, n+i must be next stskid */
L1:
    t = netif;
    while (t) {
        if (t->stskid == n) {
            n = n + i;
            goto L1;
        }
        t = t->next;
    }

    /* no match for n, we can use this n as next id */
    return n;
}

static ID get_next_mbxid(ID n, UB i)
{
    T_NIF *t;

    /* n -> curr smbxid, n+i must be next smbxid */
L1:
    t = netif;
    while (t) {
        if (t->smbxid == n) {
            n = n + i;
            goto L1;
        }
        t = t->next;
    }

    /* no match for n, we can use this n as next id */
    return n;
}


static ER tcp_init(void)
{
    T_CCYC tcpip_timer;
    ER ercd;

    /* initialize TCP/IP stack variables & structures */
    ini_tcpip_var();

    /* assign object ID numbers */
    assign_obj_id();

    /* create memory pool for Ethernet frame */
    if (TCP_MPFID_TOP == 0) { /* ID auto */
        ercd = acre_mpf(&c_eth_mpf);
        if (ercd < 0)
            goto ERR6;
        ID_ETH_MPF = (UH)ercd;
    } else {
        ercd = cre_mpf(ID_ETH_MPF, &c_eth_mpf);
        if (ercd != E_OK)
            goto ERR6;
    }

    /* create memory pool for IGMPv3 address list */
    if (TCP_MPFID_TOP == 0) { /* ID auto */
        ercd = acre_mpf(&c_igmp3_adr_mpf);
        if (ercd < 0)
            goto ERR5;
        ID_IGMP3_ADR_MPF = (UH)ercd;
    } else {
        ercd = cre_mpf(ID_IGMP3_ADR_MPF, &c_igmp3_adr_mpf);
        if (ercd != E_OK)
            goto ERR5;
    }

    /* create memory pool for IGMPv3 source address list */
    if (TCP_MPFID_TOP == 0) { /* ID auto */
        ercd = acre_mpf(&c_igmp3_src_mpf);
        if (ercd < 0)
            goto ERR4;
        ID_IGMP3_SRC_MPF = (UH)ercd;
    } else {
        ercd = cre_mpf(ID_IGMP3_SRC_MPF, &c_igmp3_src_mpf);
        if (ercd != E_OK)
            goto ERR4;
    }

    /* initialize ARP timer */
    tcpip_timer.cycatr = TA_HLNG;
    tcpip_timer.exinf  = NULL;
    tcpip_timer.cychdr = (FP)tcpip_timer_func;
    tcpip_timer.cyctim = MSEC2TICK(IP_ARP_TIMER);
    tcpip_timer.cycphs = 0;
    ercd = acre_cyc(&tcpip_timer);
    if (ercd <= 0)
        goto ERR3;
    ID_IP_TIM = (UH)ercd;

    /* initialize for IPv6 */
  #ifdef DUAL_STK
    ercd = tcp6_init();
    if (ercd != E_OK)
        goto ERR2;
  #endif
    return E_OK;

  #ifdef DUAL_STK
ERR2:
    del_cyc(ID_IP_TIM);
  #endif
ERR3:
    del_mpf(ID_IGMP3_SRC_MPF);
ERR4:
    del_mpf(ID_IGMP3_ADR_MPF);
ERR5:
    del_mpf(ID_ETH_MPF);
ERR6:
  #ifdef DUAL_STK
    ID_MLDV2_MPF = 0;
  #endif
    ID_IP_TIM = 0;
    ID_IGMP3_SRC_MPF = 0;
    ID_IGMP3_ADR_MPF = 0;
    ID_ETH_MPF = 0;

    return ercd;
}

/******************************************************************************
* Module Name   : tcp_ini                                                     *
* Purpose       : This function initializes various resources used in the     *
*                 TCP/IP stack.                                               *
* Arguments     : None.                                                       *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER tcp_ini(void)
{
    T_NIF_ADDR addr;
    ER ercd;

    /* initialize TCP/IP global value */
    netif = NULL;

    /* initialize TCP/IP resources */
    ercd = tcp_init();
    if (ercd != E_OK)
        return ercd;   /* 24OCT2005 - E_OBJ -> ercd */

    /* initialize default network interface */
    addr.hwaddr  = (UB *)ethernet_addr;
    addr.ipaddr  = (UB *)default_ipaddr;
    addr.gateway = (UB *)default_gateway;
    addr.mask    = (UB *)subnet_mask;
  #ifdef DUAL_STK
    addr.host_id = p_host_id;
  #endif

    /* invoke network interface */
    ercd = tcp_nif_ini(&default_inet, default_inet_name, default_inet_func, &addr);
    if (ercd < 0)
        tcp_ext(NULL);
    return ercd;
}

/******************************************************************************
* Module Name   : tcp_nif_ini                                                 *
* Purpose       : This function adds an interface to the TCP/IP stack.        *
* Arguments     : T_NIF *nif       - Interface to be added.                   *
*                 const B *name    - Name of the interface.                   *
*                 NIF_FP func      - Interface callback function.             *
*                 T_NIF_ADDR *addr - Address structure for the interface      *
* Return value  : E_OK on success otherwise returns the error code.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER tcp_nif_ini(T_NIF *nif, const char *name, NIF_FP func, T_NIF_ADDR *addr)
{
    T_NIF *p = NULL;
    ER ercd = E_OK;
    B ch = 0;
    int n;
    PRI save_pri;

    if (nif == NULL || func == (NIF_FP)NULL || addr == NULL || name == NULL)
        return E_PAR;

    if (strlen(name) < 1)
        return E_PAR;

    memset(nif, 0, sizeof (T_NIF));

    nif->func = func;
    nif->ch = ch = (*nif->func)(nif, TFN_GET_NIF_NUM);
    nif->tim_pkt.ctl.fncd = TFN_IP_TIM_ON;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    p = netif;
    if (netif != NULL) {
        for (;;) {
            if (p->ch == ch || strncmp(name, p->name, NIF_NAME_MAX_LEN) == 0) {
                tcpip_critical(FALSE, &save_pri);
                return E_OBJ;
            }
            if (p->next == NULL)
                break;
            p = p->next;
        }
        p->next = nif;
    }
    nif->next = NULL;

    if (strlen(name) > NIF_NAME_MAX_LEN) {
        strncpy(nif->name, name, NIF_NAME_MAX_LEN);
        nif->name[NIF_NAME_MAX_LEN] = '\0';
    } else {
        strcpy(nif->name, name);
    }

    memcpy(nif->hwaddr, addr->hwaddr, 6);
    memcpy(nif->ipaddr, addr->ipaddr, 4);
    memcpy(nif->gateway, addr->gateway, 4);
    memcpy(nif->mask, addr->mask, 4);

  #ifdef DUAL_STK
    if (addr->host_id != NULL)
        memcpy(nif->host_id, addr->host_id, 6);
    memset((UB *)&(nif->uaddr_list[0]), 0, sizeof (T_UADDR) * MAX_ADDR_CNT);
    memset((UB *)&(nif->maddr_list[0]), 0, sizeof (T_MADDR) * MAX_ADDR_CNT);
    nif->retr_timer = RETRNS_TIME;
    nif->rch_time = RCHBLE_TIME;
  #endif

    netif_ini_opt(nif);

    /* pseudo time for 1st ICMP destination unreachable repling */
    nif->icmpdu = SYSCK.ltime - MSEC2TICK(ICMP_DU_RATE);

    tcpip_critical(FALSE, &save_pri);

    /* initialize network device */
    ercd = (*nif->func)(nif, TFN_NET_INI, nif->hwaddr);
    if (ercd != E_OK) {
        tcpip_critical(TRUE, &save_pri);
        goto ERR;
    }

    tcpip_critical(TRUE, &save_pri);

    /* 'hwaddr' may be changed during initialization */
    /* keep 'ethernet_addr' value same as 'hwaddr' */
    /* modified 'ethernet_addr' as 'addr->hwaddr' */
    if (nif->type == NI_ETH)
        memcpy(addr->hwaddr, nif->hwaddr, 6);

    /* set ARP cache for this interface */
    ercd = set_arp_index(nif);
    if (ercd != E_OK) {
        goto ERR;
    }

    if (nif->type != NI_PPPOE) {
        if (TCP_TSKID_TOP) {
            nif->stskid = (UH)get_next_tid(TCP_TSKID_TOP, NIF_TSK_NUM);
            ercd = cre_tsk(nif->stskid, &c_ip_snd_tsk);
            if (ercd != E_OK) {
                nif->stskid = 0;
                goto ERR;
            }
            nif->rtskid = nif->stskid + 1;
            ercd = cre_tsk(nif->rtskid, &c_ip_rcv_tsk);
            if (ercd != E_OK) {
                nif->rtskid = 0;
                goto ERR;
            }
        } else {
            ercd = acre_tsk(&c_ip_snd_tsk);
            if (ercd <= 0)
                goto ERR;
            nif->stskid = (UH)ercd;
            ercd = acre_tsk(&c_ip_rcv_tsk);
            if (ercd <= 0)
                goto ERR;
            nif->rtskid = (UH)ercd;
        }

        if (ID_IP_SND_MBX) {
            nif->smbxid = (UH)get_next_mbxid(ID_IP_SND_MBX, NIF_MBX_NUM);
            ercd = cre_mbx(nif->smbxid, &c_tcpip_mbx);
            if (ercd != E_OK) {
                nif->smbxid = 0;
                goto  ERR;
            }
        } else {
            ercd = acre_mbx(&c_tcpip_mbx);
            if (ercd <= 0)
                goto ERR;
            nif->smbxid = (UH)ercd;
        }
    }

    if (netif == NULL)
        netif = nif;

    if (nif->type == NI_PPP) {
        ercd = (*nif->func)(nif, TFN_PPP_MDM_INI, nif->hwaddr);
        if (ercd != E_OK && ercd != E_NOSPT) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }
    }

    tcpip_critical(FALSE, &save_pri);

    /* start IP tasks */
    if (nif->type != NI_PPPOE) {
        n = (int)ch;
        ercd = sta_tsk(nif->stskid, n);
        if (ercd != E_OK) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }

        ercd = sta_tsk(nif->rtskid, n);
        if (ercd != E_OK) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }
    }

    /* setup IGMPv3 */
    ercd = igmp3_ini(nif);
    if (ercd != E_OK) {
        tcpip_critical(TRUE, &save_pri);
        goto ERR;
    }

  #ifdef DUAL_STK
    /* initialize IPv6 stack */
    if (nif->type != NI_PPP && nif->type != NI_PPPOE) {
        ercd = ipv6_ini(nif);
        if (ercd != E_OK) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }
    }
  #endif

    /* activate TCPIP timer when initialize first interface */
    if (netif->next == NULL) {
        ercd = sta_cyc(ID_IP_TIM);
        if (ercd != E_OK) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }
  #ifdef DUAL_STK
        ercd = ipv6_sta_cyc();
        if (ercd != E_OK) {
            tcpip_critical(TRUE, &save_pri);
            goto ERR;
        }
  #endif
    }
    return ch;

ERR:
    if (nif->stskid) {
        ter_tsk(nif->stskid);
        del_tsk(nif->stskid);
        nif->stskid = 0;
    }
    if (nif->rtskid) {
        ter_tsk(nif->rtskid);
        del_tsk(nif->rtskid);
        nif->rtskid = 0;
    }

    /* terminate network interface */
    (*nif->func)(nif, TFN_NET_EXT);

    if (nif->smbxid) {
        del_mbx(nif->smbxid);
        nif->smbxid = 0;
    }

    if (netif != NULL) {
        if (netif->next == NULL)
            netif = NULL; /* only one interface */
        else
            p->next = NULL; /* remove this interface from list */
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

ER tcp_dev_ini(T_NIF *nif, const char *name, NIF_FP func, T_NIF_ADDR *addr)
{
    ER ercd;

    if (netif == NULL) {
        /* initializing first interface */
        ercd = tcp_init();
        if (ercd != E_OK)
            return E_OBJ;
    }

    ercd = tcp_nif_ini(nif, name, func, addr);
    if (ercd < 0)
        tcp_ext(NULL);
    return ercd;
}

/******************************************************************************
* Module Name   : getnif_from_name                                            *
* Purpose       : This function is used to find an interface address for a    *
*                 corresponding interface name.                               *
* Arguments     : const char *name    - Name of the interface.                *
* Return value  : Interface address on success otherwise returns NULL.        *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
*                 06Dec2004 B *name -> const char *name                       *
******************************************************************************/

T_NIF *getnif_from_name(const char *name)
{
    T_NIF *nif;

    if (netif == NULL || name == NULL)
        return NULL;

    if (strlen(name) < 1)
        return NULL;

    nif = netif;
    do {
        if (strcmp(name, nif->name) == 0)
            return nif;
        nif = nif->next;
    } while (nif != NULL);

    return NULL;
}

/******************************************************************************
* Module Name   : getnif_from_ch                                              *
* Purpose       : This function is used to find an interface address for a    *
*                 corresponding channel number.                               *
* Arguments     : int ch - Channel number.                                    *
* Return value  : Interface address on success otherwise returns NULL.        *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

T_NIF *getnif_from_ch(int ch)
{
    T_NIF *nif;

    if (netif == NULL)
        return NULL;

    nif = netif;
    do {
        if (ch == (int)nif->ch)
            return nif;
        nif = nif->next;
    } while (nif != NULL);

    return NULL;
}

/******************************************************************************
* Module Name   : getnif_default                                              *
* Purpose       : This function is used to find the default interface of the  *
*                 TCP/IP stack.                                               *
* Arguments     : None.                                                       *
* Return value  : Default interface address.                                  *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

T_NIF *getnif_default(void) { return netif; }

/******************************************************************************
* Module Name   : getnif_ppp                                                  *
* Purpose       : This function is used to find the PPP interface of the      *
*                 TCP/IP stack.                                               *
* Arguments     : None.                                                       *
* Return value  : PPP interface address if present or returns NULL.           *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

T_NIF *getnif_ppp(void)
{
    T_NIF *nif;

    if (netif == NULL)
        return NULL;

    nif = netif;
    do {
        if (nif->type == NI_PPP)
            return nif;
        nif = nif->next;
    } while (nif != NULL);

    return NULL;
}

/******************************************************************************
* Module Name   : getnif_loop                                                 *
* Purpose       : This function is used to find the LoopBack interface of the *
*                 TCP/IP stack.                                               *
* Arguments     : None.                                                       *
* Return value  : loopBack interface address if present or returns NULL.      *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

T_NIF *getnif_loop(void)
{
    T_NIF *nif;

    if (netif == NULL)
        return NULL;

    nif = netif;
    do {
        if (nif->type == NI_LOOP)
            return nif;
        nif = nif->next;
    } while (nif != NULL);

    return NULL;
}

/******************************************************************************
* Module Name   : getnif_addr                                                 *
* Purpose       : This function is used to find an interface for a specified  *
*                 IP address.                                                 *
* Arguments     : UW ipaddr - IP address for which interface to be searched.  *
* Return value  : Interface address on success otherwise returns NULL.        *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

T_NIF *getnif_addr(UW ipaddr)
{
    T_NIF *p;
    UW mask, myip;

    if (netif == NULL)
        return NULL;

    /* check for local IP address */
    p = netif;
    while (p != NULL) {
        myip = byte4_to_long(p->ipaddr);
        if (ipaddr == myip )
            return p;
        p = p->next;
    }

    /* check for same network */
    p = netif;
    while (p != NULL) {
        mask = byte4_to_long(p->mask);
        myip = byte4_to_long(p->ipaddr);
        if ((ipaddr & mask) == (myip & mask))
            return p;
        p = p->next;
    }
    return NULL;
}

/******************************************************************************
* Module Name   : getnif_dstaddr                                              *
* Purpose       : To choose an appropriate interface to the specified         *
*                 destination IP address.                                     *
* Arguments     : UW dstaddr - Destination IP address                         *
* Return value  : Pointer to interface. Returns NULL, if no interface exists. *
* Author        : MiSPO                                                       *
* Date          : 2012                                                        *
******************************************************************************/

T_NIF *getnif_dstaddr(UW dstaddr)
{
    T_NIF *p;
    int i;

    /* return if any interface has static route to dstaddr */
    for (i = 0; i < ROUTE_TABLE_CNT; i++)
        if (route_table[i].nif != NULL &&
            route_table[i].dstnet == (dstaddr & route_table[i].netmask))
            return route_table[i].nif;

    /* return interface with same IP address or subnet */
    p = getnif_addr(dstaddr);
    if (p != NULL)
        return p;

    /* return default interface */
    return getnif_default();
}

/************************************************/
/* Get NIF for IPv4 or IPv6 Address             */
/************************************************/

T_NIF *getnif_dstxaddr(T_IPEP *addr)
{
  #ifdef DUAL_STK
    if (addr->type == IPV6_ADDR)
        return getnif_dst6addr(addr->ip6addr);
  #endif
    return getnif_dstaddr(addr->ipaddr);
}

/******************************************************************************
* Module Name   : is_same_network                                             *
* Purpose       : This function is used to check whether an ipaddr belongs    *
*                 to the specified interface or not.                          *
* Arguments     : T_NIF *nif - Interface address.                             *
*                 UW ipaddr  - IP address.                                    *
* Return value  : TRUE if matchs otherwise returns FALSE.                     *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

BOOL is_same_network(T_NIF *nif, UW ipaddr)
{
    UW mask, myip;

    mask = byte4_to_long(nif->mask);
    myip = byte4_to_long(nif->ipaddr);
    if ((ipaddr & mask) != (myip & mask))
        return FALSE;

    return TRUE;
}

/******************************************************************************
* Module Name   : is_nif_ipaddr                                               *
* Purpose       : This function is used to check whether an IP address is     *
*                 bound to the interface.                                     *
* Arguments     : T_NIF *nif - Pointer to the Interface                       *
*                 UW ipaddr  - IP address                                     *
* Return value  : TRUE if ipaddr is bound to the interface. Otherwise, FALSE. *
* Author        : MiSPO                                                       *
* Date          : 2009                                                        *
******************************************************************************/

BOOL is_nif_ipaddr(T_NIF *nif, UW addr)
{
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;

    /* check if interface IP address */
    if (addr == byte4_to_long(nif->ipaddr))
        return TRUE;

    /* check if any UDP or TCP CEP using this address */
    if (nif->multihome == 0)
        return FALSE;

    for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next)
        if (addr == tcep->ipaddr && nif == tcep->nif)
            return TRUE;

    for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next)
        if (addr == ucep->ipaddr && nif == ucep->nif)
            return TRUE;

    return FALSE;
}

/******************************************************************************
* Module Name   : chk_ip_nif                                                  *
* Purpose       : This function is used to check whether an IP address is     *
*                 unique to only one interface.                               *
* Arguments     : T_NIF *nif - Pointer to the Interface                       *
*                 UW ipaddr  - IP address                                     *
* Return value  : TRUE, if ipaddr is not unique. Otherwise, FALSE.            *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

BOOL chk_ip_nif(T_NIF *nif, UW addr)
{
    T_NIF *tnif;
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;
    BOOL mhome_used;

    mhome_used = FALSE;
    for (tnif = netif; tnif != NULL; tnif = tnif->next) {
        if (tnif == nif)
            continue;
        if (byte4_to_long(tnif->ipaddr) == addr)
            return TRUE;
        if (tnif->multihome != 0)
            mhome_used = TRUE;
    }
    if (!mhome_used)
        return FALSE;

    for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next)
        if (addr == tcep->ipaddr && nif != tcep->nif)
            return TRUE;

    for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next)
        if (addr == ucep->ipaddr && nif != ucep->nif)
            return TRUE;

    return FALSE;
}

B is_nif_exists(T_NIF *nif)
{
    T_NIF *tnif;

    if (netif == NULL)
        return 0;

    if (nif == NULL) {
        return 1; /* default interface exists */
    } else {
        tnif = netif;
        while (tnif) {
            if (tnif == nif)
                return 1;
            tnif = tnif->next;
        }
    }
    return 0;
}

#ifndef NORTiSIM
/******************************************************************************
* Module Name   : remove_queued_packet                                        *
* Purpose       : This function removes all the packets corresponding to the  *
*                 CEP from send or receive message box.                       *
* Arguments     : ID smbxid - Send message box ID.                            *
*                 T_ETH *wpkt - ARP waiting packet.                           *
*                 VP cep    - Packets for this CEP will be cleared.           *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

void remove_queued_packet(ID smbxid, T_ETH *wpkt, VP cep)
{
    T_MBX SNEAR *mbx;
    T_ETH *pkt;
    T_ETH *ppkt;
    T_ETH *rpkt;
    T_ETH *que;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    if (smbxid) {
        mbx = pMBX[smbxid];
        if (mbx == NULL) return;
        ppkt = que = NULL;
      #ifdef KRNL_V3
        mtop = mbx;
      #else
        mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
      #endif
        pkt = (T_ETH *)mtop->top;
        while (pkt != NULL) {
            if (pkt->ctl.cep == cep) {
                rpkt = pkt;
                pkt = pkt->next;
                if (ppkt == NULL)
                    mtop->top = (V3_T_MSG *)pkt;
                else
                    ppkt->next = pkt;
                rpkt->next = que;
                que = rpkt;
            } else {
                ppkt = pkt;
                pkt = pkt->next;
            }
        }
        mtop->end = (V3_T_MSG *)ppkt;

        for (pkt = que; pkt != NULL;) {
            rpkt = pkt;
            pkt = pkt->next;
            rel_mpf(rpkt->ctl.mpfid, rpkt);
        }
    }

    ppkt = wpkt;
    pkt = (T_ETH *)ppkt->next;
    while (pkt != NULL) {
        if (pkt->ctl.cep == cep) {
            ppkt->next = (VP)pkt->next;
            rel_mpf(pkt->ctl.mpfid, pkt);
        } else {
            ppkt = pkt;
        }
        pkt = ppkt->next;
    }
}

#endif
#ifndef NORTiSIM
/******************************************************************************
* Module Name   : remove_sndque_udppkt                                        *
* Purpose       : This function removes all the UDP packets corresponding to  *
*                 a CEP from send or receive message box. It also invokes the *
*                 task or function bind with the packets.                     *
* Arguments     : ID smbxid - Send message box ID.                            *
*                 T_ETH *wpkt - ARP waiting packet.                           *
*                 VP cep    - Packets for this CEP will be cleared.           *
*                 ER code   - Specifies whether task or function bind to the  *
*                             to be invoked or not.                           *
* Return value  : TRUE on success otherwise returns FALSE.                    *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

BOOL remove_sndque_udppkt(ID smbxid, T_ETH *wpkt, VP cep, ER code)
{
    T_MBX SNEAR *mbx;
    T_ETH *pkt;
    T_ETH *ppkt;
    T_ETH *rpkt;
    T_ETH *que;
    ID tskid;
    TCP_CALLBACK func;
    ER ercd;
    BOOL flg = FALSE;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    mbx = pMBX[smbxid];
    if (mbx == NULL) return FALSE;
    ppkt = que = NULL;
  #ifdef KRNL_V3
    mtop = mbx;
  #else
    mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
  #endif
    pkt = (T_ETH *)mtop->top;
    while (pkt != NULL) {
        if (pkt->ctl.cep == cep) {
            flg = TRUE;

            if (code) {

                /* any waiting task should be released */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = rel_wai(tskid);
                    if (ercd != E_OK)
                        tcpip_internal_error(ercd);
                }

                /* any callback function should be invoked */
                func = (TCP_CALLBACK)pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL) {
                    pkt->ctl.parblk = code;
                    (func)(((T_UDP_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd,
                             &pkt->ctl.parblk);
                }
            }

            rpkt = pkt;
            pkt = pkt->next;
            if (ppkt == NULL)
                mtop->top = (V3_T_MSG *)pkt;
            else
                ppkt->next = pkt;
            rpkt->next = que;
            que = rpkt;
        } else {
            ppkt = pkt;
            pkt = pkt->next;
        }
    }
    mtop->end = (V3_T_MSG *)ppkt;

    for (pkt = que; pkt != NULL; ) {
        rpkt = pkt;
        pkt = pkt->next;
        rel_mpf(rpkt->ctl.mpfid, rpkt);
    }

    ppkt = wpkt;
    pkt = (T_ETH *)ppkt->next;
    while (pkt != NULL) {
        if (pkt->ctl.cep == cep) {
            flg = TRUE;

            if (code) {

                /* any waiting task should be released */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = rel_wai(tskid);
                    if (ercd != E_OK)
                        raw_internal_error(ercd);
                }

                /* any callback function should be invoked */
                func = (TCP_CALLBACK)pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL) {
                    pkt->ctl.parblk = code;
                    (func)(((T_RAW_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd,
                             &pkt->ctl.parblk);
                }
            }

            ppkt->next = (VP)pkt->next;
            rel_mpf(pkt->ctl.mpfid, pkt);
        } else {
            ppkt = pkt;
        }
        pkt = ppkt->next;
    }
    return flg;
}

#endif
#ifndef NORTiSIM

BOOL remove_mbx_pkt(ID smbxid, T_ETH *wpkt, VP cep, T_ETH *qpkt)
{
    T_MBX SNEAR *mbx;
    T_ETH *pkt;
    T_ETH *ppkt;
    T_ETH *rpkt;
    T_ETH *que;
    BOOL flg=FALSE;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    mbx = pMBX[smbxid];
    if (mbx == NULL) return FALSE;
    ppkt = que = NULL;
  #ifdef KRNL_V3
    mtop = mbx;
  #else
    mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
  #endif
    pkt = (T_ETH *)mtop->top;
    while (pkt != NULL) {
        if ((pkt->ctl.cep == cep) && pkt == qpkt) {
            flg = TRUE;

            rpkt = pkt;
            pkt = pkt->next;
            if (ppkt == NULL)
                mtop->top = (V3_T_MSG *)pkt;
            else
                ppkt->next = pkt;
            rpkt->next = que;
            que = rpkt;
        } else {
            ppkt = pkt;
            pkt = pkt->next;
        }
    }
    mtop->end = (V3_T_MSG *)ppkt;

    for (pkt = que; pkt != NULL; ) {
        rpkt = pkt;
        pkt = pkt->next;
        rel_mpf(rpkt->ctl.mpfid, rpkt);
    }

    ppkt = wpkt;
    pkt = (T_ETH *)ppkt->next;
    while (pkt != NULL) {
        if ((pkt->ctl.cep == cep) && pkt == qpkt) {
            flg = TRUE;

            ppkt->next = (VP)pkt->next;
            rel_mpf(pkt->ctl.mpfid, pkt);
        } else {
            ppkt = pkt;
        }
        pkt = ppkt->next;
    }

    return flg;
}

#endif
#ifndef NORTiSIM
/******************************************************************************
* Module Name   : remove_rcvque_udppkt                                        *
* Purpose       : This function removes all the packets corresponding to the  *
*                 CEP from a message box.                                     *
* Arguments     : ID mbxid - Message box ID.                                  *
*                 VP buf   - Packets with this address will be cleared.       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

void remove_rcvque_udppkt(ID mbxid, VP buf)
{
    T_MBX SNEAR *mbx;
    T_UDP_RCV *pkt;
    T_UDP_RCV *ppkt;
    T_UDP_RCV *rpkt;
    T_UDP_RCV *que;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    mbx = pMBX[mbxid];
    if (mbx == NULL) return;
    ppkt = que = NULL;
  #ifdef KRNL_V3
    mtop = mbx;
  #else
    mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
  #endif
    pkt = (T_UDP_RCV *)mtop->top;
    while (pkt != NULL) {
        if (pkt->buf == buf) {
            rpkt = pkt;
            pkt = pkt->next;
            if (ppkt == NULL)
                mtop->top = (V3_T_MSG *)pkt;
            else
                ppkt->next = pkt;
            rpkt->next = que;
            que = rpkt;
        } else {
            ppkt = pkt;
            pkt = pkt->next;
        }
    }
    mtop->end = (V3_T_MSG *)ppkt;
}

#endif
#ifndef NORTiSIM
/******************************************************************************
* Module Name   : remove_sndque_rawpkt                                        *
* Purpose       : This function removes all the RAW packets corresponding to  *
*                 a CEP from send or receive message box. It also invokes the *
*                 task or function bind with the packets.                     *
* Arguments     : ID smbxid - Send message box ID.                            *
*                 T_ETH *wpkt - ARP waiting packet.                           *
*                 VP cep    - Packets for this CEP will be cleared.           *
*                 ER code   - Specifies whether task or function bind to the  *
*                             to be invoked or not.                           *
* Return value  : TRUE on success otherwise returns FALSE.                    *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

BOOL remove_sndque_rawpkt(ID smbxid, T_ETH *wpkt, VP cep, ER code)
{
    T_MBX SNEAR *mbx;
    T_ETH *pkt;
    T_ETH *ppkt;
    T_ETH *rpkt;
    T_ETH *que;
    ID tskid;
    TCP_CALLBACK func;
    ER ercd;
    BOOL flg = FALSE;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    mbx = pMBX[smbxid];
    if (mbx == NULL) return FALSE;
    ppkt = que = NULL;
  #ifdef KRNL_V3
    mtop = mbx;
  #else
    mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
  #endif
    pkt = (T_ETH *)mtop->top;
    while (pkt != NULL) {
        if (pkt->ctl.cep == cep) {
            flg = TRUE;

            if (code) {

                /* any waiting task should be released */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = rel_wai(tskid);
                    if (ercd != E_OK)
                        raw_internal_error(ercd);
                }

                /* any callback function should be invoked */
                func = (TCP_CALLBACK)pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL) {
                    pkt->ctl.parblk = code;
                    (func)(((T_RAW_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd,
                             &pkt->ctl.parblk);
                }
            }

            rpkt = pkt;
            pkt = pkt->next;
            if (ppkt == NULL)
                mtop->top = (V3_T_MSG *)pkt;
            else
                ppkt->next = pkt;
            rpkt->next = que;
            que = rpkt;
        } else {
            ppkt = pkt;
            pkt = pkt->next;
        }
    }
    mtop->end = (V3_T_MSG *)ppkt;

    for (pkt = que; pkt != NULL; ) {
        rpkt = pkt;
        pkt = pkt->next;
        rel_mpf(rpkt->ctl.mpfid, rpkt);
    }

    ppkt = wpkt;
    pkt = (T_ETH *)ppkt->next;
    while (pkt != NULL) {
        if (pkt->ctl.cep == cep) {
            flg = TRUE;

            if (code) {

                /* any waiting task should be released */
                tskid = pkt->ctl.tskid;
                if (tskid != FALSE) {
                    ercd = rel_wai(tskid);
                    if (ercd != E_OK)
                        raw_internal_error(ercd);
                }

                /* any callback function should be invoked */
                func = (TCP_CALLBACK)pkt->ctl.callback;
                if (func != (TCP_CALLBACK)NULL) {
                    pkt->ctl.parblk = code;
                    (func)(((T_RAW_CEP *)(pkt->ctl.cep))->cepid, pkt->ctl.fncd,
                             &pkt->ctl.parblk);
                }
            }

            ppkt->next = (VP)pkt->next;
            rel_mpf(pkt->ctl.mpfid, pkt);
        } else {
            ppkt = pkt;
        }
        pkt = ppkt->next;
    }
    return flg;
}

#endif
#ifndef NORTiSIM
/******************************************************************************
* Module Name   : remove_rcvque_rawpkt                                        *
* Purpose       : This function removes all the packets corresponding to the  *
*                 CEP from a message box.                                     *
* Arguments     : ID mbxid - Message box ID.                                  *
*                 VP buf   - Packets with this address will be cleared.       *
* Return value  : None.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2008                                                        *
******************************************************************************/

void remove_rcvque_rawpkt(ID mbxid, VP buf)
{
    T_MBX SNEAR *mbx;
    T_RAW_RCV *pkt;
    T_RAW_RCV *ppkt;
    T_RAW_RCV *rpkt;
    T_RAW_RCV *que;
  #ifdef KRNL_V3
    T_MBX *mtop;
  #else
    V4_T_MSGHDR *mtop;
  #endif

    mbx = pMBX[mbxid];
    if (mbx == NULL) return;
    ppkt = que = NULL;
  #ifdef KRNL_V3
    mtop = mbx;
  #else
    mtop = (V4_T_MSGHDR *)((ADDR)mbx+mbx->moff);
  #endif
    pkt = (T_RAW_RCV *)mtop->top;
    while (pkt != NULL) {
        if (pkt->buf == buf) {
            rpkt = pkt;
            pkt = pkt->next;
            if (ppkt == NULL)
                mtop->top = (V3_T_MSG *)pkt;
            else
                ppkt->next = pkt;
            rpkt->next = que;
            que = rpkt;
        } else {
            ppkt = pkt;
            pkt = pkt->next;
        }
    }
    mtop->end = (V3_T_MSG *)ppkt;
}

#endif
/******************************************************************************
* Module Name   : tcpip_critical                                              *
* Purpose       : This function used as a exclusive control for accessing the *
*                 TCP/IP stack resources. The prioriy of any application that *
*                 trying to access the resources will be changed to same as   *
*                 the priority of IP tasks. And the original priority will be *
*                 restorted after the application releases the resources.     *
* Arguments     : BOOL on - TRUE  Application entering into cretical region.  *
*                           FALSE Application leaving from cretical region.   *
* Return value  : E_OK if prioriy inversion successful else returns the error *
*                 code.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER tcpip_critical(BOOL on, PRI *oldpri)
{
    PRI pri;
    ER ercd;

    if (on) {
      #ifdef NORTiSIM
        get_pri(TSK_SELF, &pri);
      #else
        pri = pTCB[vget_tid()]->pri;
      #endif
        if (pri != PRI_TCPIP)
            ercd = chg_pri(TSK_SELF, PRI_TCPIP);
        else
            ercd = E_OK;
        *oldpri = pri;
    } else {
        if (*oldpri != PRI_TCPIP)
            ercd = chg_pri(TSK_SELF, *oldpri);
        else
            ercd = E_OK;
    }
    return ercd;
}

ER can_cep_process(T_NIF *nif, ER code)
{
    TCP_CALLBACK func;
    T_TCP_CEP *tcep, *pp;
    T_UDP_CEP *ucep;
    T_UDP_RCV *udat;
    T_RAW_CEP *rcep;
    T_RAW_RCV *rdat;
    INT parblk;
    T_NIF *tnif;
    ID id;
    ER ercd;

    /* check TCP process */
    for (tcep = pTCP_CEP; tcep != NULL;) {
        if (nif == NULL || tcep->nif == nif) {
            tcep->ercd = code;

            /* first check any process waiting in cls_cep to send
               to send FIN after get ACK for all outstanding data. */
            if ((tcep->state == CEP_CONNECTING) && (tcep->dcls_id == -1)
                && (tcep->rfncd == 0))
                tcep->rfncd = TFN_TCP_CLS_CEP;

            if (nif != NULL && tcep->unif == NULL)
                tcep->rlen = tcep->slen = E_RLWAI;
            else
                tcep->rlen = tcep->slen = code;

            if (tcep->rfncd != 0) {
                if (tcep->rtskid != 0) {
                    rel_wai(tcep->rtskid);
                } else if ((id = tcep->dcls_id) > 0) {
                    tcep->dcls_id = 0;
                    rel_wai(id);
                } else {
                    /* corrected func initialization */
                    if ((func = (TCP_CALLBACK)tcep->callback) != (TCP_CALLBACK)NULL) {
                        parblk = tcep->rlen;
                        (func)(tcep->cepid, tcep->rfncd, &parblk);
                    }
                }
            }

            if (tcep->sfncd != 0) {
                if (tcep->stskid != 0) {
                    rel_wai(tcep->stskid);
                } else {
                    /* corrected func initialization */
                    if ((func = (TCP_CALLBACK)tcep->callback) != (TCP_CALLBACK)NULL) {
                        parblk = tcep->slen;
                        (func)(tcep->cepid, tcep->sfncd, &parblk);
                    }
                }
            }

            if (nif != NULL)
                remove_queued_packet(nif->smbxid, (T_ETH *)&nif->arp_waiting, tcep);

            if (code == E_LNK) {
                if (tcep->unif == nif)
                    tcep->unif = NULL;
                pp = tcep;
                tcep = tcep->next;
                tcp_cep_unused(pp);
                continue;
            }
        }
        tcep = tcep->next;
    }

    /* check UDP process */
    for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next) {

        /* when deleting all interfaces then the sending processes should
           return E_LNK. But when deleting only one interface then all
           sending process with cep->nif as NULL should return E_RLWAI. */
        if (ucep->nif == NULL) {
            tnif = getnif_default();
            while (tnif) {
                if (code == E_LNK && nif != NULL)
                    remove_sndque_udppkt(tnif->smbxid, (T_ETH *)&tnif->arp_waiting, ucep, E_RLWAI);
                else
                    remove_sndque_udppkt(tnif->smbxid, (T_ETH *)&tnif->arp_waiting, ucep, code);
                tnif = tnif->next;
            }
        }

        if (ucep->nif == nif) {
            ucep->ercd = code;
            for (;;) {
                /* check any process pending in reception process */
                ercd = prcv_mbx(ucep->id_udp_mbx, (T_MSG **)&udat);
                if (ercd != E_OK)
                    break;

                if (udat->tskid != FALSE) {
                    *(udat->p_ercd) = code; /* delete */
                    rel_wai(udat->tskid);
                }
                if (ucep->callback != (TCP_CALLBACK)NULL) {
                    parblk = code;
                    (ucep->callback)(ucep->cepid, TFN_UDP_RCV_DAT, &parblk);
                }
            }

            /* check any process still pending for transmission */
            if (nif)
                remove_sndque_udppkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, ucep, code);

            /* clear multicast information */
            clr_mgrp_cb(ucep);

            if (code == E_LNK)
                ucep->nif = NULL;
        }
    }

    /* check RAW process */
    for (rcep = pRAW_CEP; rcep != NULL; rcep = rcep->next) {

        /* when deleting all interfaces then the sending processes should
           return E_LNK. but when deleting only one interface then all
           sending process with cep->nif as NULL should return E_RLWAI. */
        if (rcep->nif == NULL) {
            tnif = getnif_default();
            while (tnif) {
                if (code == E_LNK && nif != NULL)
                    remove_sndque_rawpkt(tnif->smbxid, (T_ETH *)&tnif->arp_waiting, rcep, E_RLWAI);
                else
                    remove_sndque_rawpkt(tnif->smbxid, (T_ETH *)&tnif->arp_waiting, rcep, code);

                tnif = tnif->next;
            }
        }

        if (rcep->nif == nif) {
            rcep->ercd = code;
            for (;;) {
                /* check any process pending in reception process */
                ercd = prcv_mbx(rcep->id_raw_rcv_mbx, (T_MSG **)&rdat);
                if (ercd != E_OK)
                    break;

                if (rdat->tskid != FALSE) {
                    *(rdat->p_ercd) = code; /* delete */
                    rel_wai(rdat->tskid);
                }
                if (rcep->callback != NULL) {
                    parblk = code;
                    (rcep->callback)(rcep->cepid, TFN_RAW_RCV_DAT, &parblk);
                }
            }

            /* check any process still pending for transmission */
            if (nif)
                remove_sndque_rawpkt(nif->smbxid, (T_ETH *)&nif->arp_waiting, rcep, code);

            if (code == E_LNK)
                rcep->nif = NULL;
        }
    }

    rot_rdq(TPRI_SELF);     /* execute continuation of canceled API */
    return E_OK;
}

/******************************************************************************
* Module Name   : chg_cep_ipaddr                                              *
* Purpose       : This function overwrites the ipaddr of CEP structure of the *
*                 interface to new specified ipaddress.                       *
* Arguments     : T_NIF *nif - Search CEP's with this interface.              *
*                 UW ipaddr  - New ipaddress value.                           *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 03-Jun-2004                                                 *
******************************************************************************/

static void chg_cep_ipaddr(T_NIF *nif, UW ipaddr, UB level)
{
    T_TCP_REP *rep;
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;

    if (level == 2)
        can_cep_process(nif, E_ADDR);

    /* change if any CEP bind with old IP address */
    for (rep = pTCP_REP; rep != NULL; rep = rep->next)
        if (rep->ipaddr != IPV4_ADDRANY && rep->ipaddr == byte4_to_long(nif->ipaddr))
            rep->ipaddr = ipaddr;

    for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next) {
        if (tcep->nif == nif && tcep->ipaddr == byte4_to_long(nif->ipaddr)) {
      #ifdef DUAL_STK
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &tcep->ipaddr,0 ,SNMP_INAT_IPV4, &tcep->dstipa,0, 0);
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &tcep->ipaddr,tcep->portno ,SNMP_INAT_IPV4, &tcep->dstipa,tcep->dstpor, 0);
            SNMP_UPD_TCPLISTEN(SNMP_CSTS_DELETETCB, SNMP_INAT_IPV4, &tcep->ipaddr, tcep->portno);
      #else
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, tcep->ipaddr, tcep->portno, 0, 0);
            SNMP_UPDTCP(SNMP_CSTS_DELETETCB, tcep->ipaddr, tcep->portno, tcep->dstipa, tcep->dstpor);
      #endif
            tcep->ipaddr = ipaddr;
            if (tcep->state == CEP_WAIT_P_OPEN) {
      #ifdef DUAL_STK
                SNMP_UPDTCP(SNMP_CSTS_LISTEN,SNMP_INAT_IPV4, &tcep->ipaddr,tcep->portno ,SNMP_INAT_IPV4, &tcep->dstipa,tcep->dstpor, 0);
                SNMP_UPD_TCPLISTEN(SNMP_CSTS_LISTEN, SNMP_INAT_IPV4, &tcep->ipaddr, tcep->portno);
      #else
                SNMP_UPDTCP(SNMP_CSTS_LISTEN, tcep->ipaddr, tcep->portno, tcep->dstipa, tcep->dstpor);
      #endif
            } else if (tcep->state == CEP_CONNECTING) {
      #ifdef DUAL_STK
                SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV4, &tcep->ipaddr,tcep->portno ,SNMP_INAT_IPV4, &tcep->dstipa,tcep->dstpor, 0);
      #else
                SNMP_UPDTCP(SNMP_CSTS_ESTABLISHED, tcep->ipaddr, tcep->portno, tcep->dstipa, tcep->dstpor);
      #endif
            }
        }
    }

    for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next) {
      #ifdef DUAL_STK
        SNMP_UPDUDP(SNMP_CSTS_DELETETCB,SNMP_INAT_IPV4, &ucep->ipaddr, ucep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
      #else
        SNMP_UPDUDP(SNMP_CSTS_DELETETCB, ucep->ipaddr, ucep->portno);
      #endif
        if (ucep->nif == nif && ucep->ipaddr == byte4_to_long(nif->ipaddr)) {
            ucep->ipaddr = ipaddr;
      #ifdef DUAL_STK
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED,SNMP_INAT_IPV4, &ucep->ipaddr, ucep->portno ,SNMP_INAT_UNKNOWN, NULL, 0, 0, 0);
      #else
            SNMP_UPDUDP(SNMP_CSTS_ESTABLISHED, ucep->ipaddr, ucep->portno);
      #endif
        }
    }
}

/******************************************************************************
* Module Name   : netif_chg_ipa                                               *
* Purpose       : Used to change ipaddr, netmask and gateway address of an    *
*                 interface.                                                  *
* Arguments     : T_NIF *nif       - Interface address.                       *
*                 T_NIF_ADDR *addr - New address values.                      *
*                 UB level         - Mode of address change.                  *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 03-Jun-2004                                                 *
******************************************************************************/

ER netif_chg_ipa(T_NIF *nif, T_NIF_ADDR *addr, UB level)
{
    T_TCP_CEP *tcep;
    T_UDP_CEP *ucep;
    UW newaddr;
    ER ercd;
    PRI save_pri;

    if (nif == NULL)
        return E_OBJ;

    ercd = tcpip_critical(TRUE, &save_pri);
    if (ercd != E_OK)
        return ercd;

    if (memcmp(nif->ipaddr, addr->ipaddr, 4) != 0) {
        newaddr = byte4_to_long(addr->ipaddr);

        if (level == 1 || level == 2)
            /* change CEP's source address */
            chg_cep_ipaddr(nif, newaddr, level);

        /* change interface IP address */
        memcpy(nif->ipaddr, addr->ipaddr, 4);

        /* send a gratuitous ARP for this IP address */
        if (nif->type == NI_ETH)
            arp_request(nif, byte4_to_long(nif->ipaddr));

        /* reset counter for CEPs using multi-home address */
        nif->multihome = 0;
        for (tcep = pTCP_CEP; tcep != NULL; tcep = tcep->next)
            if (newaddr != tcep->ipaddr
              #ifdef DUAL_STK
                && tcep->type == IPV4_ADDR
              #endif
                && nif == tcep->nif)
                nif->multihome++;

        for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next)
            if (newaddr != ucep->ipaddr
              #ifdef DUAL_STK
                && ucep->type == IPV4_ADDR
              #endif
                && nif == ucep->nif)
                nif->multihome++;
    }

    if (memcmp(nif->gateway, addr->gateway, 4) != 0)
        memcpy(nif->gateway, addr->gateway, 4);

    if (memcmp(nif->mask, addr->mask, 4) != 0)
        memcpy(nif->mask, addr->mask, 4);

    if ((getnif_default()) == nif) {
        memcpy(default_ipaddr, nif->ipaddr, 4);
        memcpy(default_gateway, nif->gateway, 4);
        memcpy(subnet_mask, nif->mask, 4);
    }

    tcpip_critical(FALSE, &save_pri);
    return ercd;
}

/******************************************************************************
* Module Name   : net_chg_ipa                                                 *
* Purpose       : Used to change ipaddr, netmask and gateway address of the   *
*                 interface.                                                  *
* Arguments     : T_NIF_ADDR *addr - New address values.                      *
*                 UB level         - Mode of address change.                  *
* Return value  : None.                                                       *
* Author        : A.K                                                         *
* Date          : 03-Jun-2004                                                 *
******************************************************************************/

ER net_chg_ipa(T_NIF_ADDR *addr, UB level)
{
    T_NIF *nif;

    nif = getnif_default();
    if (nif == NULL)
        return E_OBJ;
    return netif_chg_ipa(nif, addr, level);
}

ER netif_ipa_byname(const char *name, T_NIF_ADDR *addr, UB level)
{
    T_NIF *nif;
    nif = getnif_from_name(name);
    return netif_chg_ipa(nif, addr, level);
}

void release_nif_pkt(ID mpfid, T_NIF *nif)
{
    T_MPF SNEAR *mpf;
    B PFAR *blf, *fblf;
    T_ETH *pkt;
    unsigned blfsz;
    int i;

    mpf = pMPF[mpfid];
    if (mpf == NULL) return;

    blfsz = ((SIZE)mpf->cmpf->blfsz + SIZEOF_INT - 1) & (SIZE)(0 - SIZEOF_INT);
    if (blfsz < SIZEOF_PTR)
        blfsz = SIZEOF_PTR;

    fblf = mpf->allad;
    for (i = mpf->cmpf->blkcnt - 1; i != 0; i--) {
        blf = mpf->top;
        while (blf) {
            if (blf == fblf)
                break; /* fblf already released */
            blf = *(B PFAR * PFAR *)blf;
        }

        if (blf == NULL) {
            /* fblf is not released, check and release if this is
               a packet of specified interface */
            pkt = (T_ETH *)fblf;
            if (pkt->ctl.nif == nif)
                rel_mpf(mpfid, pkt);
        }
        fblf = fblf + blfsz;
    }

    /* release the packet that tries transmission */
    while ((pkt = (T_ETH*)net_get_transmission_pkt(nif)) != NULL)
        rel_mpf(mpfid, pkt);

    return;
}

/******************************************************************************
* Module Name   : tcp_nif_ext                                                 *
* Purpose       : This function cancels all the operations of TCP/UDP CEP and *
*                 also deletes the end point.                                 *
* Arguments     : T_NIF *nif - Interface to be released.                      *
* Return value  : E_OK.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER tcp_nif_ext(T_NIF *nif)
{
    T_IP4 *pkt;
    int i;
    ER ercd;

    can_cep_process(nif, E_LNK);

    if (nif != NULL) {
        if (nif->type != NI_PPPOE) {
            i = nif->smbxid;
            for (;;) {
                /* release if any packet pending in message box for this interface */
                ercd = prcv_mbx(i, (T_MSG **)&pkt);
                if (ercd == E_OK) {
                    rel_mpf(pkt->ctl.mpfid, pkt);
                } else {
                    if (nif->smbxid != 0) {
                        del_mbx(i);
                        nif->smbxid = 0;
                        break;
                    }
                }
            }

            /* delete IP send task */
            ter_tsk(nif->stskid);
            del_tsk(nif->stskid);
            nif->stskid = 0;

            /* delete IP recv task */
            ter_tsk(nif->rtskid);
            del_tsk(nif->rtskid);
            nif->rtskid = 0;

            /* free ARP table */
            if (nif->arp_index >= ARP_NIF_CNT)
                sys_free(nif->arp_table, sizeof (T_ARP_TABLE) * ARP_TABLE_CNT);
        }

        /* terminate LAN controller */
        (*nif->func)(nif, TFN_NET_EXT);

        /* release the IGMPv3 address lists */
        igmp3_rel_addrlist(nif);

        release_ipf_que(nif);
      #ifdef DUAL_STK
        release_ip6f_que(nif);
      #endif
        release_nif_pkt(ID_ETH_MPF, nif);
    }
    return E_OK;
}

/******************************************************************************
* Module Name   : tcp_ext                                                     *
* Purpose       : This function release all the TP/IP resources used by the   *
*                 specified interface. If NULL is specified as 'nif' then all *
*                 existing interface resources will be released.              *
* Arguments     : T_NIF *nif - Interface to be released.                      *
* Return value  : E_OK.                                                       *
* Author        : MiSPO                                                       *
* Date          : 2004                                                        *
******************************************************************************/

ER tcp_ext(T_NIF *nif)
{
    T_NIF *pnif, *tnif;
    T_UDP_CEP *ucep;
    T_RAW_CEP *rcep;
    ER ercd, rtcd;
    PRI save_pri;

    rtcd = tcpip_critical(TRUE, &save_pri);
    if (rtcd != E_OK)
        return rtcd;

    /* only 1 channel exists? */
    tnif = getnif_default();

    if (tnif != NULL && tnif == nif && tnif->next == NULL)
        nif = NULL;

    if (nif != NULL) {
        /* delete 'nif' from channel list */
        pnif = tnif = getnif_default();
        while (tnif) {
            if (tnif == nif) {
                rtcd = tcp_nif_ext(nif);
                pnif->next = tnif->next;
                if (nif == netif)
                    netif = pnif->next;
                break;
            }
            pnif = tnif;
            tnif = tnif->next;
        }
    } else {
      #ifdef DUAL_STK
        ipv6_free_rsrc();
      #endif
        /* cancel the process bind with NULL interface first */
        ercd = tcp_nif_ext(NULL);
        nif = getnif_default();
        while (nif) {
            rtcd = tcp_nif_ext(nif);
            if (ercd == E_OK)
                ercd = rtcd;
            nif = nif->next;
        }

        /* delete resources related with CEP of UDP */
        for (ucep = pUDP_CEP; ucep != NULL; ucep = ucep->next) {
            del_mbx(ucep->id_udp_mbx);
            del_mpf(ucep->id_udp_mpf);
        }

        /* delete resources related with CEP of RAW */
        for (rcep = pRAW_CEP; rcep != NULL; rcep = rcep->next) {
            del_mbx(rcep->id_raw_rcv_mbx);
            del_mpf(rcep->id_raw_snd_mpf);
        }

        /* delete timer and memory pool */
        if (ID_IGMP3_SRC_MPF) {
            del_mpf(ID_IGMP3_SRC_MPF);
            ID_IGMP3_SRC_MPF = 0;
        }
        if (ID_IGMP3_ADR_MPF) {
            del_mpf(ID_IGMP3_ADR_MPF);
            ID_IGMP3_ADR_MPF = 0;
        }
      #ifdef DUAL_STK
        if (ID_MLDV2_MPF) {
            del_mpf(ID_MLDV2_MPF);
            ID_MLDV2_MPF = 0;
        }
      #endif
        if (ID_IP_TIM) {
            del_cyc(ID_IP_TIM);
            ID_IP_TIM = 0;
        }
        if (ID_ETH_MPF) {
            del_mpf(ID_ETH_MPF);
            ID_ETH_MPF = 0;
        }

        netif = NULL;
    }

    ercd = tcpip_critical(FALSE, &save_pri);
    if (ercd < 0 && rtcd == E_OK)
        rtcd = ercd;
    return rtcd;
}

/******************************************************************************
* Module Name   : net_get_transmission_pkt                                    *
* Purpose       : This function is used to get a packet that retries          *
*                 transmission.                                               *
* Arguments     : T_NIF *nif - Network Interface of the processing packet     *
* Return value  : This function returns a pointer to the packet, and returns  *
*                 NULL if packet is nothing.                                  *
* Author        : MiSPO                                                       *
* Date          : 2009                                                        *
******************************************************************************/

T_CTL_PKT *net_get_transmission_pkt(T_NIF *nif)
{
    T_CTL_PKT *pkt = nif->retry_pkt;
    if (pkt != NULL)
        nif->retry_pkt = pkt->next;
    return pkt;
}

/******************************************************************************
* Module Name   : net_set_transmission_pkt                                    *
* Purpose       : This function is used to set a packet to the queue of       *
*                 packet that retries transmission.                           *
* Arguments     : T_NIF *nif - Network Interface of the processing packet     *
*                 T_CTL_PKT *pkt - Pointer to the packet                      *
* Author        : MiSPO                                                       *
* Date          : 2009                                                        *
******************************************************************************/

void net_set_transmission_pkt(T_NIF *nif, T_CTL_PKT *pkt)
{
    T_CTL_PKT *pre = (T_CTL_PKT *)&nif->retry_pkt;

    while (pre->next != NULL)
        pre = pre->next;
    pre->next = pkt;
    pkt->next = NULL;
}

/* end */
