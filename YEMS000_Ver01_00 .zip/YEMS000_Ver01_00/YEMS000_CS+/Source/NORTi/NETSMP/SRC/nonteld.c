/******************************************************************************
* Telnet Server Sample                                                        *
*                                                                             *
*  Copyright (c) 1999-2021, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-23 Created                                                          *
* 1999-03-22 Added signal handler                                             *
* 1999-04-25 Modified all functions                                           *
* 1999-05-01 Modified timeout                                                 *
* 1999-05-05 Added terminal_kbhit() and terminal_getch()                      *
* 1999-05-08 Added telnetd_opt_nego() to negotiate Telnet options             *
* 1999-05-29 Changed telnet_tmout from 10 to 5 min                            *
* 1999-09-22 Added auto ID assignment of cre_???() for specified id = 0    YS *
* 2000-11-16 Changed telnet_tmout to TELNET_TMOUT                             *
* 2002-02-23 Changed sta_tsk() into vsta_tsk() for 16-bit INT              HM *
* 2004-07-14 Added IPv6 support                                            PK *
* 2005-04-20 Removed cast of strings with (B *)                            PK *
* 2005-05-13 Added telnetd_ext() to uninitialize Telnet server             AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2009-08-03 Moved timeout processing from tcp_rcv_dat() to trcv_mbf()     FY *
* 2009-08-03 Added initialization of 'tmo' member of T_CONSOLE             FY *
* 2009-08-05 Added handling of DEL code of delete key                      FY *
* 2010-12-28 Corrected compiler warning by adding (FP) to T_CTSK           HE *
* 2012-03-26 Fixed telnetd_tsk() to notify close in telnetd_opt_nego() to     *
*               shell, and to dequeue data in message buffer before close  GS *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2012-11-23 Corrected telnetd_ini() to not delete uncreated objects          *
*                     in error, and to also return E_OBJ of tcp_cre_rep()  FY *
* 2015-02-13 Added initialization of term_print & term_getch of T_TELNETD  FY *
* 2015-02-13 Changed terminal_print() and telnetd_tsk()                       *
*                          to not use console_print() and console_getch()  FY *
* 2015-07-02 Added parameter definition of keep-alive and retransmission,     *
*                      and made their timeout short for Telnet connection  FY *
* 2015-09-12 Changed TELNET_TMOUT & RTO_MAX time units, tick & msec -> sec MI *
* 2015-09-12 Added missing del_mbf() and tcp_del_cep() to telnetd_ext()    MI *
* 2015-09-12 Moved current_terminal declaration & CTRL_C definition           *
*                      to nonteln.h, and deleted unused SYSCK declaration  MI *
* 2015-09-12 telnetd_ctsk's TELNETD_SSZ+COMMAND_LINE_LEN -> TELNETD_SSZ    MI *
* 2015-09-12 Added ipv param to telnetd_ini, and merged telnetd6_ini to it MI *
* 2016-06-21 Corrected "prcv_mbf(..) == E_OK" to "> 0" to check               *
*                    received data length for dequeueing in telnetd_tsk()  FY *
* 2017-05-08 Modified handling of c = 0 to enable NUL character receive    FY *
* 2021-04-01 Added missing "current_terminal = NULL" before ter_tsk()      FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosio.h"
#include "nonet.h"
#include "nonteln.h"

/* Customization Macros */

#define TELNET_TMOUT    5*60    /* Telnet session timeout [sec] */
#define KEEPALIVE_TMO   60      /* keep-alive start time after connection idle [sec] */
#define KEEPALIVE_PRO   15      /* keep-alive probe timeout time [sec] */
#define KEEPALIVE_SUC   5       /* keep-alive probes interval [sec] */
#define RTO_MAX KEEPALIVE_TMO-1 /* maximum RTO [sec] (< KEEPALIVE_TMO) */
#define DAT_RCNT        3       /* TCP data retransmission maximum count */

/* Object Creation Information */

TASK telnetd_tsk(T_TELNETD *);
const T_CTSK telnetd_ctsk = { TA_HLNG, NULL, (FP)telnetd_tsk, TELNETD_PRI, TELNETD_SSZ, NULL, "telnetd_tsk" };
const T_CMBF telnetd_cmbf = { TA_TFIFO, 2, 16, NULL, "telnetd_mbf" };

/* End Point Creation Information */

const T_TCP_CREP telnetd_crep  = { 0, { IPV4_ADDRANY, TCP_PORT_TELNET } };
#ifdef DUAL_STK /* for IPv6 */
const T_TCP_CREP telnetd6_crep = { 0, { IPV4_ADDRANY, TCP_PORT_TELNET, IPV6_ADDRANY, IPV6_ADDR } };
#endif

/************************************************/
/* Put String to Telnet or Console              */
/************************************************/

BOOL terminal_print(T_TERMINAL *t, const char *s)
{
    if (t == NULL) {
        t = current_terminal;
        if (t == NULL)
            return FALSE;
    }
    return t->term_print(t, s);
}

/************************************************/
/* Put String and CR+LF to Telnet or Console    */
/************************************************/

BOOL terminal_puts(T_TERMINAL *t, const char *s)
{
    if (!terminal_print(t, s))
        return FALSE;
    return terminal_print(t, "\r\n");
}

/************************************************/
/* Put CR+LF and String to Telnet or Console    */
/************************************************/

BOOL terminal_rputs(T_TERMINAL *t, const char *s)
{
    if (!terminal_print(t, "\r\n"))
        return FALSE;
    return terminal_print(t, s);
}

/************************************************/
/* Put Charactor to Telnet or Console           */
/************************************************/

BOOL terminal_putch(T_TERMINAL *t, INT c)
{
    char s[2];

    s[0] = (char)c;
    s[1] = '\0';
    return terminal_print(t, s);
}

/************************************************/
/* Get Sized String from Telnet or Console      */
/************************************************/

INT terminal_input(T_TERMINAL *t, char *s, INT size, TMO tmo)
{
    H c;
    INT i, skip;
    ER ercd;

    if (t == NULL) {
        if ((t = current_terminal) == NULL) {
            dly_tsk(100/MSEC);
            return 0;
        }
    }

    for (i = skip = 0;;) {

        ercd = trcv_mbf(t->rx_mbfid, &c, tmo);
        if (ercd <= 0 || ercd != 2)
            return ercd;

        if (c < 0)
            return c;
        if (i == 0 && c == '\n')        /* ignore last LF */
            continue;
        if (skip != 0) {
            skip--;
            continue;
        }
        if (c == '\r' || c == CTRL_C) { /* CR or Ctrl-C */
            s[i] = '\0';
            return c;
        }
        if (c == '\b' || c == 0x7f) {   /* backspace or DEL */
            if (i > 0) {
                i--;
                if (t->echo_on != 0) {
                    if (!terminal_print(t, "\b \b"))
                        break;
                }
            }
            continue;
        }
        if (c == 0x1b) {                /* ESC sequence */
            skip = 2;
            continue;
        }
        if ((UB)c < 0x20 || (UB)c > 0x7e)
            continue;
        if (i >= size - 1)
            continue;
        s[i++] = (char)c;
        if (t->echo_on != 0) {
            if (t->echo_on == '*')
                c = '*';
            if (!terminal_putch(t, c))
                break;
        }
    }
    s[i] = '\0';
    if (c & 0x80)
        c |= 0xff00;
    return c;                           /* last charactor */
}

/************************************************/
/* Get String from Telnet or Console            */
/************************************************/

char *terminal_gets(T_TERMINAL *t, char *s, INT size)
{
    INT c;

    for (;;) {
        c = terminal_input(t, s, size, TMO_FEVR);
        if (c == '\r')
            break;
        dly_tsk(1000/MSEC);
    }
    terminal_print(t, "\r\n");
    return s;
}

/************************************************/
/* Check if a Character is Available            */
/************************************************/

BOOL terminal_kbhit(T_TERMINAL *t)
{
    T_RMBF rmbf;
    ER ercd;

    if (t == NULL) {
        if ((t = current_terminal) == NULL)
            return FALSE;
    }

    ercd = ref_mbf(t->rx_mbfid, &rmbf);
    if (ercd == E_OK && rmbf.smsgcnt != 0)
        return TRUE;
    else
        return FALSE;
}

/************************************************/
/* Get Character from Telnet or Console         */
/************************************************/

INT terminal_getch(T_TERMINAL *t)
{
    H c;
    ER ercd;

    if (t == NULL) {
        if ((t = current_terminal) == NULL) {
            dly_tsk(100/MSEC);
            return 0;
        }
    }

    ercd = rcv_mbf(t->rx_mbfid, &c);
    if ((ercd <= 0) || (ercd != 2))
        return 0;
    return c;
}

/************************************************/
/* Define Signal Handler                        */
/************************************************/

SIGNAL_FUNC terminal_signal(T_TERMINAL *t, int sig, SIGNAL_FUNC func)
{
    SIGNAL_FUNC prev;

    if (t == NULL) {
        if ((t = current_terminal) == NULL)
            return FALSE;
    }

    if (sig != SIGINT)
        return SIG_ERR;
    prev = (SIGNAL_FUNC)t->sigint;
    t->sigint = (FP)func;
    return prev;
}

/************************************************/
/* Telnet Low Level Put String                  */
/************************************************/

BOOL telnetd_print(T_TELNETD *t, const char *s)
{
    INT n;
    ER len;

    n = strlen(s);
    if (n == 0)
        return TRUE;

    for (;;) {
        len = tcp_snd_dat(t->cepid, s, n, TMO_FEVR);
        if (len <= 0)
            return FALSE;
        if ((n -= len) == 0)
            return TRUE;
        s += len;
    }
}

/************************************************/
/* Telnet Low Level Get a Charactor             */
/************************************************/

INT telnetd_getch(T_TELNETD *t)
{
    UB c;
    ER len;

    for (;;) {
        len = tcp_rcv_dat(t->cepid, &c, 1, TMO_FEVR);
        if (len > 0)
            return c;
        if (len == 0)
            return E_CLS;
        return len;
    }
}

/************************************************/
/* Telnet Option Negotiation                    */
/************************************************/

INT telnetd_opt_nego(T_TELNETD *t)
{
    INT c;

    telnetd_print(t, "\xff""\xfb""\x03"     /* <IAC><WILL><suppress GA> */
                     "\xff""\xfb""\x01"     /* <IAC><WILL><echo> */
                     "\xff""\xfe""\x01");   /* <IAC><DONT><echo> */
    for (;;) {
        c = telnetd_getch(t);
        if (c <= 0)
            return c;
        c = telnetd_getch(t);
        if (c <= 0)
            return c;
        c = telnetd_getch(t);
        if (c != 0xff)
            return c;
    }
}

/************************************************/
/* Telnet Server Task                           */
/************************************************/

TASK telnetd_tsk(T_TELNETD *t)
{
    const UW optval[] = { KEEPALIVE_TMO, KEEPALIVE_PRO, KEEPALIVE_SUC, ((RTO_MAX)*1000)/MSEC };
    const UH optval4  = DAT_RCNT;
    H c;
    ER ercd;
    BOOL sio;
    SIGNAL_FUNC func;

    sio = (t->cepid == 0);

    for (;;) {

        t->logged_in = FALSE;

        /* accept TCP connection */
        while (!sio) {
            ercd = tcp_acp_cep(t->cepid, t->repid, &t->dstaddr, TMO_FEVR);
            if (ercd == E_OK) { /* shorten keep-alive and retransmission timeout */
                if ((tcp_set_opt(t->cepid, SET_TCP_KEEPALIVE_TMO, &optval[0], sizeof (UW)) == E_OK) &&
                    (tcp_set_opt(t->cepid, SET_TCP_KEEPALIVE_PRO, &optval[1], sizeof (UW)) == E_OK) &&
                    (tcp_set_opt(t->cepid, SET_TCP_KEEPALIVE_SUC, &optval[2], sizeof (UW)) == E_OK) &&
                    (tcp_set_opt(t->cepid, SET_TCP_RTO_MAX,       &optval[3], sizeof (UW)) == E_OK) &&
                    (tcp_set_opt(t->cepid, SET_TCP_DAT_RCNT,      &optval4,   sizeof (UH)) == E_OK)) {
                    telnetd_opt_nego(t);
                    break;
                }
                ercd = E_PAR;
            }
            if (ercd == E_TMOUT || ercd == E_CLS || ercd == E_RLWAI) {
                dly_tsk(1000/MSEC);
            } else {
                /* panic error! can't continue process */
                tcp_can_cep(t->cepid, TFN_TCP_ALL);
                tcp_del_cep(t->cepid);
                tcp_del_rep(t->repid);
                del_mbf(t->rx_mbfid);
                t->cepid = 0;
                /* check whether telnetd_tsk is used by shell */
                if (t->shell_tskid == 0)
                    exd_tsk();
            }
        }

        /* start command shell task */
        if (t->shell_tskid != FALSE) {
            while (sta_tsk(t->shell_tskid, (VP)t) != E_OK) {
                if (current_terminal == t)
                    current_terminal = NULL;
                ter_tsk(t->shell_tskid);
                dly_tsk(1000/MSEC);
            }
        }

        /* queue received charactors */
        for (;;) {
            c = (H)t->term_getch(t);
            if (!sio) {
                if (c == 0xff)              /* IAC */
                    c = telnetd_opt_nego(t);
                if (c == E_TMOUT)           /* abnormally closed by */
                    c = E_CLS;              /* keep-alive or retransmission timeout */
            }
            if (t->logged_in == (B)-1)
                break;
            ercd = snd_mbf(t->rx_mbfid, &c, 2);
            if (ercd != E_OK)
                break;
            if (c == CTRL_C) {
                if (t->echo_on != 0)
                    terminal_print(t, "^C");
            }
            if (c == CTRL_C || c <= 0) {
                func = (SIGNAL_FUNC)t->sigint;
                if (func != SIG_DFL)
                    func(SIGINT);
            }
            if (c < 0) {
                dly_tsk(1000/MSEC);
                /* dequeue undelivered data from message buffer */
                while (prcv_mbf(t->rx_mbfid, &c) > 0)
                    ;
                break;
            }
        }

        /* close TCP connection */
        if (!sio)
            tcp_cls_cep(t->cepid, TMO_FEVR);
    }
}

/************************************************/
/* Uninitialize Telnet Server                   */
/************************************************/

void telnetd_ext(T_TELNETD *t)
{
    if (t->telnetd_tskid != 0)
        del_tsk(t->telnetd_tskid);
    if (t->rx_mbfid != 0)
        del_mbf(t->rx_mbfid);
    if (t->cepid != 0) {
        tcp_can_cep(t->cepid, TFN_TCP_ALL);
        tcp_del_cep(t->cepid);
    }
    if (t->repid != 0)
        tcp_del_rep(t->repid);
}

static ER telnetd_err(T_TELNETD *t, ER ercd)
{
    telnetd_ext(t);
    return ercd;
}

/************************************************/
/* Initialize Telnet Server                     */
/************************************************/

ER (telnetd_ini)(T_TELNETD *t, ID tskid, ID mbfid, ID cepid, ID repid, int ipv)
{
    const T_TCP_CREP *crep;
    T_TCP_CCEP ccep;
    ER ercd;

    /* initialize control block */
    memset(t, 0, sizeof (T_TELNETD));
    t->term_print = (BOOL (*)(T_TERMINAL *, const char *))telnetd_print;
    t->term_getch = (INT (*)(T_TERMINAL *))telnetd_getch;
    t->tmo = ((TELNET_TMOUT)*1000)/MSEC;
    t->echo_on = 1;

    /* initialize commnunication end point */
    memset(&ccep, 0, sizeof (T_TCP_CCEP));
    ccep.sbuf = t->sbuf;
    ccep.sbufsz = sizeof t->sbuf;
    ccep.rbuf = t->rbuf;
    ccep.rbufsz = sizeof t->rbuf;

    /* create Telnet server task */
    if (tskid == 0)
        ercd = tskid = acre_tsk(&telnetd_ctsk);
    else
        ercd = cre_tsk(tskid, &telnetd_ctsk);
    if (ercd < 0)
        return telnetd_err(t, ercd);
    t->telnetd_tskid = (UH)tskid;

    /* create message buffer */
    if (mbfid == 0)
        ercd = mbfid = acre_mbf(&telnetd_cmbf);
    else
        ercd = cre_mbf(mbfid, &telnetd_cmbf);
    if (ercd < 0)
        return telnetd_err(t, ercd);
    t->rx_mbfid = (UH)mbfid;

    /* create TCP commnunication end point */
    if (cepid == 0)
        ercd = cepid = tcp_vcre_cep(&ccep);
    else
        ercd = tcp_cre_cep(cepid, &ccep);
    if (ercd < 0)
        return telnetd_err(t, ercd);
    t->cepid = (UH)cepid;

    /* create TCP reception point */
    if (ipv == 6)
      #ifdef DUAL_STK
        crep = &telnetd6_crep;
      #else
        return telnetd_err(t, E_PAR);
      #endif
    else
        crep = &telnetd_crep;
    if (repid == 0)
        ercd = repid = tcp_vcre_rep(crep);
    else
        ercd = tcp_cre_rep(repid, crep);
    if (ercd < 0)
        return telnetd_err(t, ercd);
    t->repid = (UH)repid;
    return E_OK;
}

/* end */
