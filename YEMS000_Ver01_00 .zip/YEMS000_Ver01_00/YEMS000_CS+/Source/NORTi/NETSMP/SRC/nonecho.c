/******************************************************************************
* NORTi Network Echo Server Sample                                            *
*                                                                             *
*  Copyright (c) 1998-2016, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1998-12-26                                                                  *
* 1999-09-22 resource ID auto assign added                                    *
* 2001-02-12 Change Task priority 4 -> 5                                   KA *
* 2003-03-18 udpecho_tsk����tcpip_cretical���폜                              *
* 2003-04-28 udpecho_tsk was modified to use call-back                     YS *
* 2004-07-19 IPv6 support added                                            PK *
* 2005-05-13 Added uninitialization code for echo server.                  AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2008-11-21 The usage of tcp_snd_dat is corrected.                        FY *
* 2010-12-28 Corrected compiler warning by adding (FP) to T_CTSK           HE *
* 2016-03-28 Adjusted coding style and comments                            FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonecho.h"

/* Window Buffer */

#define WINDOW_SIZE 1024
static UH tcpecho_swin[WINDOW_SIZE/2];      /* sending window buffer */
static UH tcpecho_rwin[WINDOW_SIZE/2];      /* receiving window buffer */

#ifdef DUAL_STK
static UH tcpecho6_swin[WINDOW_SIZE/2];     /* sending window buffer */
static UH tcpecho6_rwin[WINDOW_SIZE/2];     /* receiving window buffer */
#endif

/* Creation Information */

#if defined(GAIO) && defined(H8300H)
TASK udpecho_tsk(VP_INT);
TASK tcpecho_tsk(VP_INT);
#ifdef DUAL_STK
TASK udpecho6_tsk(VP_INT);
TASK tcpecho6_tsk(VP_INT);
#endif
#else
TASK udpecho_tsk(ID);
TASK tcpecho_tsk(int);
#ifdef DUAL_STK
TASK udpecho6_tsk(ID);
TASK tcpecho6_tsk(int);
#endif
#endif

ER udpecho_cbk(ID, FN, VP);
ER tcpecho_cbk(ID, FN, VP);

const T_CTSK c_udpecho_tsk = { TA_HLNG, NULL, (FP)udpecho_tsk, 5, ECHO_SSZ, NULL, "udpecho_tsk" };
const T_CTSK c_tcpecho_tsk = { TA_HLNG, NULL, (FP)tcpecho_tsk, 5, ECHO_SSZ, NULL, "tcpecho_tsk" };
const T_TCP_CCEP c_tcpecho_cep = { 0, tcpecho_swin, sizeof tcpecho_swin, tcpecho_rwin, sizeof tcpecho_rwin, (FP)tcpecho_cbk };

#ifdef DUAL_STK
ER udpecho6_cbk(ID, FN, VP);

const T_CTSK c_udpecho6_tsk = { TA_HLNG, NULL, (FP)udpecho6_tsk, 5, ECHO_SSZ, NULL, "udpecho6_tsk" };
const T_CTSK c_tcpecho6_tsk = { TA_HLNG, NULL, (FP)tcpecho6_tsk, 5, ECHO_SSZ, NULL, "tcpecho6_tsk" };

const T_UDP_CCEP c_udpecho_cep = { 0, { IPV4_ADDRANY, UDP_PORT_ECHO, IPV6_ADDRANY, IPV4_ADDR}, (FP)udpecho_cbk };
const T_TCP_CREP c_tcpecho_rep = { 0, { IPV4_ADDRANY, TCP_PORT_ECHO, IPV6_ADDRANY, IPV4_ADDR } };

const T_UDP_CCEP c_udpecho6_cep = { 0, { IPV4_ADDRANY, UDP_PORT_ECHO, IPV6_ADDRANY, IPV6_ADDR}, (FP)udpecho6_cbk };
const T_TCP_CREP c_tcpecho6_rep = { 0, { IPV4_ADDRANY, TCP_PORT_ECHO, IPV6_ADDRANY, IPV6_ADDR } };
const T_TCP_CCEP c_tcpecho6_cep = { 0, tcpecho6_swin, sizeof tcpecho6_swin, tcpecho6_rwin, sizeof tcpecho6_rwin, (FP)tcpecho_cbk };
#else
const T_UDP_CCEP c_udpecho_cep = { 0, { IPV4_ADDRANY, UDP_PORT_ECHO }, (FP)udpecho_cbk };
const T_TCP_CREP c_tcpecho_rep = { 0, { IPV4_ADDRANY, TCP_PORT_ECHO } };
#endif

/* Local Data */

#define ECHO_BUFSZ      1024
static UH udpecho_buf[ECHO_BUFSZ/2];        /* UH and /2 for word aglinement */
static UH tcpecho_buf[ECHO_BUFSZ/2];

static ID echo_tskid, techo_cepid, techo_repid, uecho_cepid;
static T_IPEP uecho_dstaddr;
static int uecho_len;

#ifdef DUAL_STK
static UH udpecho6_buf[ECHO_BUFSZ/2];       /* UH and /2 for word aglinement */
static UH tcpecho6_buf[ECHO_BUFSZ/2];

static ID echo6_tskid, techo6_cepid, techo6_repid, uecho6_cepid;
static T_IPEP uecho6_dstaddr;
static int uecho6_len;
#endif

/************************************************/
/* UDP Based Echo Server Callback               */
/************************************************/

ER udpecho_cbk(ID cepid, FN fncd, VP parblk)
{
    switch (fncd)
    {
    case TFN_UDP_RCV_DAT:
        break;
    case TEV_UDP_RCV_DAT:
        uecho_len = udp_rcv_dat(cepid, &uecho_dstaddr, udpecho_buf, sizeof udpecho_buf, TMO_POL);
        wup_tsk(echo_tskid);
        break;
    }
    return E_OK;
}

/************************************************/
/* UDP Based Echo Server Task                   */
/************************************************/

#if defined(GAIO) && defined(H8300H)
TASK udpecho_tsk(VP_INT c)
#else
TASK udpecho_tsk(ID cepid)
#endif
{
  #if defined(GAIO) && defined(H8300H)
    ID cepid;
    cepid = (ID) c;
  #endif

    echo_tskid = vget_tid();
    uecho_cepid = cepid;

    for (;;) {
        /* waiting for receive UDP echo packet */
        /* it wake up from udpecho_cbk */

        slp_tsk();

        udp_snd_dat(cepid, &uecho_dstaddr, udpecho_buf, uecho_len, TMO_FEVR);
    }
}

/************************************************/
/* UDP Based Echo Server Uninitialize           */
/************************************************/

void udpecho_ext(void)
{
    udp_can_cep(uecho_cepid, TFN_TCP_ALL);
    udp_del_cep(uecho_cepid);
    ter_tsk(echo_tskid);
    del_tsk(echo_tskid);
    echo_tskid = uecho_cepid = 0;
}

/************************************************/
/* UDP Based Echo Server Intialize              */
/************************************************/

ER udpecho_ini(ID tskid, ID cepid)
{
    ER ercd;

    /* Create Echo Server Task */

    if (tskid == 0) {
        ercd = acre_tsk(&c_udpecho_tsk);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    } else {
        ercd = cre_tsk(tskid, &c_udpecho_tsk);
        if (ercd != E_OK)
            return ercd;
    }

    /* Create UDP Commnunication End Point */

    if (cepid == 0) {
        ercd = cepid = udp_vcre_cep(&c_udpecho_cep);
        if (cepid <= 0)
            goto ERR;
    } else {
        ercd = udp_cre_cep(cepid, &c_udpecho_cep);
        if (ercd != E_OK)
            goto ERR;
    }

    ercd = udp_set_opt(cepid, SET_UDP_RPKT_OPT, (VP)TRUE, sizeof(BOOL));
    if (ercd != E_OK)
        goto ERR;

  #ifdef DUAL_STK
    uecho_dstaddr.type = IPV4_ADDR;
  #endif

    /* Start Echo Server Task */

    ercd = sta_tsk(tskid, cepid);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    udp_del_cep(cepid);
    del_tsk(tskid);
    return ercd;
}

#ifdef DUAL_STK
/************************************************/
/* UDP Based Echo Server Callback               */
/************************************************/

ER udpecho6_cbk(ID cepid, FN fncd, VP parblk)
{
    switch (fncd)
    {
    case TFN_UDP_RCV_DAT:
        break;
    case TEV_UDP_RCV_DAT:
        uecho6_len = udp_rcv_dat(cepid, &uecho6_dstaddr, udpecho6_buf, sizeof udpecho6_buf, TMO_POL);
        wup_tsk(echo6_tskid);
        break;
    }
    return E_OK;
}

/************************************************/
/* UDP Based Echo Server Task                   */
/************************************************/

#if defined(GAIO) && defined(H8300H)
TASK udpecho6_tsk(VP_INT c)
#else
TASK udpecho6_tsk(ID cepid)
#endif
{
  #if defined(GAIO) && defined(H8300H)
    ID cepid;
    cepid = (ID) c;
  #endif

    echo6_tskid = vget_tid();
    uecho6_cepid = cepid;

    for (;;) {
        /* waiting for receive UDP echo packet */
        /* it wake up from udpecho_cbk */

        slp_tsk();

        udp_snd_dat(cepid, &uecho6_dstaddr, udpecho6_buf, uecho6_len, TMO_FEVR);
    }
}

/************************************************/
/* UDP Based Echo Server Uninitialize           */
/************************************************/

void udpecho6_ext(void)
{
    udp_can_cep(uecho6_cepid, TFN_TCP_ALL);
    udp_del_cep(uecho6_cepid);
    ter_tsk(echo6_tskid);
    del_tsk(echo6_tskid);
    echo6_tskid = uecho6_cepid = 0;
}

/************************************************/
/* UDP Based Echo Server Intialize              */
/************************************************/

ER udpecho6_ini(ID tskid, ID cepid)
{
    ER ercd;

    /* Create Echo Server Task */

    if (tskid == 0) {
        ercd = acre_tsk(&c_udpecho6_tsk);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    } else {
        ercd = cre_tsk(tskid, &c_udpecho6_tsk);
        if (ercd != E_OK)
            return ercd;
    }

    /* Create UDP Commnunication End Point */

    if (cepid == 0) {
        ercd = cepid = udp_vcre_cep(&c_udpecho6_cep);
        if (cepid <= 0)
            goto ERR;
    } else {
        ercd = udp_cre_cep(cepid, &c_udpecho6_cep);
        if (ercd != E_OK)
            goto ERR;
    }

    ercd = udp_set_opt(cepid, SET_UDP_RPKT_OPT, (VP)TRUE, sizeof(BOOL));
    if (ercd != E_OK)
         goto ERR;

    uecho6_dstaddr.type = IPV6_ADDR;

    /* Start Echo Server Task */

    ercd = sta_tsk(tskid, cepid);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    udp_del_cep(cepid);
    del_tsk(tskid);
    return ercd;
}

#endif
/************************************************/
/* TCP Based Echo Server Callback               */
/************************************************/

ER tcpecho_cbk(ID cepid, FN fncd, VP parblk)
{
    return E_OK;
}

/************************************************/
/* TCP Based Echo Server Task                   */
/************************************************/

#if defined(GAIO) && defined(H8300H)
TASK tcpecho_tsk(VP_INT c)
#else
TASK tcpecho_tsk(int cepid_repid)
#endif
{
    T_IPV4EP dstaddr;
    ER len, ercd;
    int i;
  #if defined(GAIO) && defined(H8300H)
    int cepid_repid;

    cepid_repid = (int) c;
  #endif

    techo_repid = cepid_repid & 0xff;
    techo_cepid = (cepid_repid >> 8) & 0xff;

    for (;;) {
      #ifdef DUAL_STK
        dstaddr.type = IPV4_ADDR;
      #endif
        len = tcp_acp_cep(techo_cepid, techo_repid, &dstaddr, TMO_FEVR);

        if (len != E_OK) {
            if ((len == E_TMOUT) || (len == E_CLS)) {
                dly_tsk(1000/MSEC);
                continue;
            } else {
                /* Panic Error! Can't continue process */
                tcp_del_rep(techo_repid);
                tcp_can_cep(techo_cepid, TFN_TCP_ALL);
                tcp_del_cep(techo_cepid);
                techo_cepid = 0;
                techo_repid = 0;
                exd_tsk();
            }
        }

        for (;;) {
            len = tcp_rcv_dat(techo_cepid, tcpecho_buf, sizeof tcpecho_buf, TMO_FEVR);
            if (len <= 0)
                break;
            i = 0;
            do
            {
                ercd = tcp_snd_dat(techo_cepid, tcpecho_buf + i, len - i, TMO_FEVR);
                if (ercd <= 0)
                    break;
                i += ercd;
            } while (i < len);
        }
        tcp_cls_cep(techo_cepid, TMO_FEVR);
    }
}

/************************************************/
/* TCP Based Echo Server Uninitialize           */
/************************************************/

void tcpecho_ext(void)
{
    tcp_del_rep(techo_repid);
    tcp_can_cep(techo_cepid, TFN_TCP_ALL);
}

/************************************************/
/* TCP Based Echo Server Intialize              */
/************************************************/

ER tcpecho_ini(ID tskid, ID cepid, ID repid)
{
    ER ercd;

    /* Create Echo Server Task */

    if (tskid == 0) {
        ercd = acre_tsk(&c_tcpecho_tsk);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    } else {
        ercd = cre_tsk(tskid, &c_tcpecho_tsk);
        if (ercd != E_OK)
            return ercd;
    }

    /* Create TCP Reception End Point */

    if (repid == 0) {
        ercd = repid = tcp_vcre_rep(&c_tcpecho_rep);
        if (repid <= 0)
            goto ERR;
    } else {
        ercd = tcp_cre_rep(repid, &c_tcpecho_rep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* Create TCP Commnunication End Point */

    if (cepid == 0) {
        ercd = cepid = tcp_vcre_cep(&c_tcpecho_cep);
        if (cepid <= 0)
            goto ERR;
    } else {
        ercd = tcp_cre_cep(cepid, &c_tcpecho_cep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* Start Echo Server Task */

    ercd = sta_tsk(tskid, (cepid << 8) + repid);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    tcp_del_cep(cepid);
    tcp_del_rep(repid);
    del_tsk(tskid);
    return ercd;
}

#ifdef DUAL_STK
/************************************************/
/* TCP Based Echo Server Task                   */
/************************************************/

#if defined(GAIO) && defined(H8300H)
TASK tcpecho6_tsk(VP_INT c)
#else
TASK tcpecho6_tsk(int cepid_repid)
#endif
{
    T_IPEP dstaddr;
    ER len, ercd;
    int i;
  #if defined(GAIO) && defined(H8300H)
    int cepid_repid;

    cepid_repid = (int) c;
  #endif

    techo6_repid = cepid_repid & 0xff;
    techo6_cepid = (cepid_repid >> 8) & 0xff;

    for (;;) {
        dstaddr.type = IPV6_ADDR;
        len = tcp_acp_cep(techo6_cepid, techo6_repid, &dstaddr, TMO_FEVR);

        if (len != E_OK) {
            if (len == E_TMOUT || len == E_CLS) {
                dly_tsk(1000/MSEC);
                continue;
            } else {
                /* Panic Error! Can't continue process */
                tcp_del_rep(techo6_repid);
                tcp_can_cep(techo6_cepid, TFN_TCP_ALL);
                tcp_del_cep(techo6_cepid);
                techo6_cepid = 0;
                techo6_repid = 0;
                exd_tsk();
            }
        }

        for (;;) {
            len = tcp_rcv_dat(techo6_cepid, tcpecho6_buf, sizeof tcpecho6_buf, TMO_FEVR);
            if (len <= 0)
                break;
            i = 0;
            do
            {
                ercd = tcp_snd_dat(techo6_cepid, tcpecho6_buf + i, len - i, TMO_FEVR);
                if (ercd <= 0)
                    break;
                i += ercd;
            } while (i < len);
        }
        tcp_cls_cep(techo6_cepid, TMO_FEVR);
    }
}

/************************************************/
/* TCP Based Echo Server Uninitialize           */
/************************************************/

void tcpecho6_ext(void)
{
    tcp_del_rep(techo6_repid);
    tcp_can_cep(techo6_cepid, TFN_TCP_ALL);
}

/************************************************/
/* TCP Based Echo Server Intialize              */
/************************************************/

ER tcpecho6_ini(ID tskid, ID cepid, ID repid)
{
    ER ercd;

    /* Create Echo Server Task */

    if (tskid == 0) {
        ercd = acre_tsk(&c_tcpecho6_tsk);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    } else {
        ercd = cre_tsk(tskid, &c_tcpecho6_tsk);
        if (ercd != E_OK)
            return ercd;
    }

    /* Create TCP Reception End Point */

    if (repid == 0) {
        ercd = repid = tcp_vcre_rep(&c_tcpecho6_rep);
        if (repid <= 0)
            goto ERR;
    } else {
        ercd = tcp_cre_rep(repid, &c_tcpecho6_rep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* Create TCP Commnunication End Point */

    if (cepid == 0) {
        ercd = cepid = tcp_vcre_cep(&c_tcpecho6_cep);
         if (cepid <= 0)
            goto ERR;
    } else {
        ercd = tcp_cre_cep(cepid, &c_tcpecho6_cep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* Start Echo Server Task */

    ercd = sta_tsk(tskid, (cepid << 8) + repid);
    if (ercd != E_OK)
            goto ERR;

    return E_OK;

ERR:
    tcp_del_cep(cepid);
    tcp_del_rep(repid);
    del_tsk(tskid);
    return ercd;
}

#endif

/* end */
