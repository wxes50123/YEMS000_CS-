/******************************************************************************
* FTP Server Sample                                                           *
*                                                                             *
*  Copyright (c) 1999-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-28 Created                                                          *
* 1999-05-08 DELE is added                                                    *
* 1999-05-29 FTPD_IDLE_TMOUT is added                                         *
* 1999-06-09 APPE is added                                                    *
* 1999-09-23 CEP,REP ID auto assign added (Create tcp_vcre_cep,tcp_vcre_rep)  *
* 1999-11-26 Removal warning for exeGCC                                       *
* 2000-04-25 Removal VP_INT for NORTi v4                                      *
* 2001-02-12 Change FTPD_TMOUT 5000 �� 30000/MSEC                             *
* 2002-02-08 Changed literal string type(B->char) for CC32R                OK *
*            written 'B str[] = "?";' then it is error in CC32R               *
* 2002-02-23 vsta_tsk is called for 16-bit INT CPU                         HM *
* 2003-03-18 modified ftp_pass_command for return string from call back    YS *
* 2004-07-14 Added IPv6 Support                                            PK *
* 2004-09-27 Warning about typecast corrected                              PK *
* 2004-11-12 ftp_server_tsk modified for processing of QUIT command        PK *
* 2005-04-20 tcp_ref_cep added; extra typecasting removed                  PK *
* 2005-04-20 NOFILE_VER macro was added                                    NA *
* 2005-05-13 Added FTP uninitialization code                               AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2006-03-03 Added TYPE A support (For Dummy Response)                     MK *
* 2007-03-13 Modified crep,crep2 member name for DUAL_STK(TRUE->IPV6_ADDR  OK *
* 2009-04-09 Added the closing of the data port 'ftp->cepid2' in           FY *
*            ftp_server_tsk                                                   *
* 2010-09-14 FFFTP client supported                                        IM *
* 2011-06-30 Corrected compiler warning by adding (FP) and (FTP_COMMAND)   HE *
* 2012-04-06 Added '#ifdef DUAL_STK' to EPRT and EPSV command processing   GS *
* 2012-04-06 Fixed reply of Unimplemented command to Unrecognized command  GS *
* 2012-05-26 Corrected tcp_ref_cep of ftp_port_command to use ftp->cepid1  GS *
* 2012-05-26 Added tcp_ref_cep in ftp_eprt_command to fix local address    GS *
* 2012-10-02 Added REP creation with ephemeral port within FTP_PASV_MIN~MAX   *
*            for passive mode, instead of fixed REP with port number 1010  IM *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2014-06-04 Added waiting for non blocking call of tcp_acp_cep()          FY *
* 2023-03-16 Added specifying server IP address and NIF with ftp_sta_srv() FY *
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"
#include "nonitod.h"
#include "nonfile.h"
#include "nonftp.h"
#include "nonteln.h"

#ifndef ITRON_H
#ifndef VP_INT
#define VP_INT  int
#endif
#endif

/* Creation Information */

TASK ftp_server_tsk(T_FTP *ftp);
const T_CTSK ftp_server_ctsk = { TA_HLNG, NULL, (FP)ftp_server_tsk, FTP_SERVER_PRI, FTP_SERVER_SSZ, NULL, "ftp_server_tsk" };

/* Timeout */

#define FTPD_TMOUT      (30000/MSEC)
#if 1
#define FTPD_IDLE_TMOUT (5*60*(1000/MSEC))
#else /* for debugging */
#define FTPD_IDLE_TMOUT (30*(1000/MSEC))
#endif

/* Data Port Number in Passive Mode */

#ifndef FTP_PASV_MIN
#define FTP_PASV_MIN    TCP_PORT_EPHEMERAL
#endif
#ifndef FTP_PASV_MAX
#define FTP_PASV_MAX    0xffff
#endif

/* FTP Server Responce */

const char msg_ftp_openning[]      = "150 Opening data connection\r\n";
const char msg_ftp_successful[]    = "200 Command successful\r\n";
const char msg_ftp_port_ok[]       = "200 PORT Command successful\r\n";
const char msg_ftp_unimplemented[] = "202 Unimplemented command\r\n";
const char msg_ftp_server_ready[]  = "220 FTP Server ready\r\n";
const char msg_ftp_goodbye[]       = "221 Goodbye\r\n";
const char msg_ftp_complete[]      = "226 Transfer complete\r\n";
const char msg_ftp_logged_in[]     = "230 Logged in\r\n";
const char msg_ftp_password[]      = "331 Password required\r\n";
const char msg_ftp_cant_open[]     = "425 Can't open data connection\r\n";
const char msg_ftp_disconnected[]  = "426 Data connection disconnected\r\n";
const char msg_ftp_file_busy[]     = "450 File busy\r\n";
const char msg_ftp_disk_full[]     = "452 Disk full\r\n";
const char msg_ftp_unrecognized[]  = "500 Unrecognized command\r\n";
const char msg_ftp_invalid_arg[]   = "501 Invalid arguments\r\n";
const char msg_ftp_unimple_arg[]   = "504 Unimplemented arguments\r\n";
const char msg_ftp_not_logged_in[] = "530 Not logged in\r\n";
const char msg_ftp_incorrect[]     = "530 Login incorrect\r\n";
const char msg_ftp_not_found[]     = "550 File not found\r\n";
const char msg_ftp_cant_write[]    = "550 Can't write file\r\n";
static char msg_ftp_enter_pasv[55];

/* FTP Command Table */

typedef char *(*FTP_COMMAND)(T_FTP *, const char *);
typedef struct t_ftp_command_table {
    char command[4+1];
    FTP_COMMAND func;
} T_FTP_COMMAND_TABLE;

static const char *ftp_user_command(T_FTP *ftp, const char *arg);
static const char *ftp_pass_command(T_FTP *ftp, const char *arg);
static const char *ftp_quit_command(T_FTP *ftp, const char *arg);
static const char *ftp_port_command(T_FTP *ftp, const char *arg);
static const char *ftp_type_command(T_FTP *ftp, const char *arg);
static const char *ftp_retr_command(T_FTP *ftp, const char *arg);
static const char *ftp_stor_command(T_FTP *ftp, const char *arg);
static const char *ftp_appe_command(T_FTP *ftp, const char *arg);
static const char *ftp_list_command(T_FTP *ftp, const char *arg);
static const char *ftp_nlst_command(T_FTP *ftp, const char *arg);
static const char *ftp_dele_command(T_FTP *ftp, const char *arg);
static const char *ftp_pasv_command(T_FTP *ftp, const char *arg);
#ifdef DUAL_STK
static const char *ftp_eprt_command(T_FTP *ftp, const char *arg);
static const char *ftp_epsv_command(T_FTP *ftp, const char *arg);
#endif
static const char *ftp_pwd_command(T_FTP *ftp, const char *arg);
static const char *ftp_cwd_command(T_FTP *ftp, const char *arg);

static const T_FTP_COMMAND_TABLE ftp_command_table[] = {
    { "USER" , (FTP_COMMAND)ftp_user_command },
    { "PASS" , (FTP_COMMAND)ftp_pass_command },
    { "QUIT" , (FTP_COMMAND)ftp_quit_command },
    { "PORT" , (FTP_COMMAND)ftp_port_command },
    { "TYPE" , (FTP_COMMAND)ftp_type_command },
    { "RETR" , (FTP_COMMAND)ftp_retr_command },
    { "STOR" , (FTP_COMMAND)ftp_stor_command },
    { "APPE" , (FTP_COMMAND)ftp_appe_command },
    { "LIST" , (FTP_COMMAND)ftp_list_command },
    { "NLST" , (FTP_COMMAND)ftp_nlst_command },
    { "DELE" , (FTP_COMMAND)ftp_dele_command },
    { "PASV" , (FTP_COMMAND)ftp_pasv_command },
#ifdef DUAL_STK
    { "EPRT" , (FTP_COMMAND)ftp_eprt_command },
    { "EPSV" , (FTP_COMMAND)ftp_epsv_command },
#endif
    { "XPWD" , (FTP_COMMAND)ftp_pwd_command  },
    { "PWD"  , (FTP_COMMAND)ftp_pwd_command  },
    { "CWD"  , (FTP_COMMAND)ftp_cwd_command  },
    { "" , (FTP_COMMAND)NULL },
};

/* Local Value */

static int acp_cep_tskid;

/************************************************/
/* Put String to PI Connection                  */
/************************************************/

ER ftp_put_str(T_FTP *ftp, const char *str)
{
    INT len;
    ER ercd;

    len = strlen(str);
    while (len != 0) {
        ercd = tcp_snd_dat(ftp->cepid1, str, len, FTPD_TMOUT);
        if (ercd < 0)
            return ftp->ercd = ercd;
        len -= ercd;
        str += ercd;
    }
    return E_OK;
}

/************************************************/
/* Get String from PI Connection                */
/************************************************/

ER ftp_get_str(T_FTP *ftp, char *buf, INT bufsz)
{
    ER ercd;
    INT i;
    char c;

    for (i = 0;;) {
        ercd = tcp_rcv_dat(ftp->cepid1, &c, 1, FTPD_IDLE_TMOUT);
        if (ercd <= 0) {
            if (ercd == 0)
                ercd = E_CLS;
            break;
        }
        if (c == '\r')      /* Ignore CR */
            continue;
        if (c == '\n') {    /* End if LF */
            buf[i] = '\0';
            return E_OK;
        }
        if (i >= bufsz - 1)
            continue;
        buf[i++] = c;
    }
    buf[i] = '\0';
    if (i == 4)
        buf[++i] = '\0';
    return ftp->ercd = ercd;
}

/************************************************/
/* Send Data to DTP Connection                  */
/************************************************/

ER ftp_snd_dat(T_FTP *ftp, const char *dat, INT len)
{
    ER ercd;

    while (len > 0) {
        ercd = tcp_snd_dat(ftp->cepid2, dat, len, FTPD_TMOUT);
        if (ercd < 0)
            return ftp->ercd = ercd;
        dat += ercd;
        len -= ercd;
    }
    return E_OK;
}

/************************************************/
/* Receive Data from DTP Connection             */
/************************************************/

ER ftp_rcv_dat(T_FTP *ftp, INT *len, char *buf, INT bufsz)
{
    ER ercd;

    for (*len = 0;;) {
        ercd = tcp_rcv_dat(ftp->cepid2, buf, bufsz, FTPD_TMOUT);
        if (ercd < 0)
            return ftp->ercd = ercd;
        if (ercd == 0)
            return E_OK;
        *len += ercd;
        buf += ercd;
        if ((bufsz -= ercd) <= 0)
            return E_OK;
    }
}

/************************************************/
/* Receive File Data                            */
/************************************************/

const char *ftp_rcv_fil(T_FTP *ftp, FILE *fp)
{
    INT len;
    ER ercd = E_OK;
    B full = FALSE;

    if (fp == NULL) {
        tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        ftp->flag &= ~(FTP_STOR|FTP_DTP_OPEN);
        return NULL;
    }

    for (;;) {
        ercd = ftp_rcv_dat(ftp, &len, ftp->buf, sizeof ftp->buf);
        if (ercd != E_OK || len == 0)
            break;
        if (!full) {
            len -= (INT)fwrite(ftp->buf, 1, len, fp);
            if (len != 0)
                full = TRUE;
        }
    }
    fclose(ftp->fp);
    ftp->fp = NULL;
    tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
    ftp->flag &= ~(FTP_STOR|FTP_DTP_OPEN);
    if (ercd < 0)
        return msg_ftp_disconnected;
    if (full)
        return msg_ftp_disk_full;
    else
        return msg_ftp_complete;
}

/************************************************/
/* Send File Data                               */
/************************************************/

const char *ftp_snd_fil(T_FTP *ftp, FILE *fp)
{
    INT len;
    ER ercd = E_OK;

    if (fp == NULL) {
        tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        ftp->flag &= ~(FTP_RETR|FTP_DTP_OPEN);
        return NULL;
    }

    for (;;) {
        len = (INT)fread(ftp->buf, 1, sizeof ftp->buf, fp);
        if (len == 0)
            break;
        ercd = ftp_snd_dat(ftp, ftp->buf, len);
        if (ercd != E_OK)
            break;
    }
    fclose(ftp->fp);
    ftp->fp = NULL;
    tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
    ftp->flag &= ~(FTP_RETR|FTP_DTP_OPEN);
    if (ercd == E_OK)
        return msg_ftp_complete;
    else
        return msg_ftp_disconnected;
}

/************************************************/
/* Wild Card Check                              */
/************************************************/

static BOOL wildcard_check(const char *w, const char *s)
{
    char c;

    if (*w == '\0' || strcmp(w, "*.*") == 0)
        return TRUE;
    if (strcmp(w, s) == 0)
        return TRUE;
    for (;;) {
        c = *s++;
        if (c == '\0')
            return TRUE;
        if (c == *w) {
            w++;
            continue;
        }
        if (c == '.') {
            w = strchr(w, '.');
            if (w == NULL)
                break;
            w++;
            continue;
        }
        if (*w == '?') {
            w++;
            continue;
        }
        if (*w == '*')
            continue;
        break;
    }
    return FALSE;
}

/************************************************/
/* Send File List                               */
/************************************************/
#define DATE_FTP        " May  1 10:00 "

const char *ftp_snd_dir(T_FTP *ftp, FILE *fp)
{
    struct _direct *dir = (struct _direct *)(ftp->buf);
    char *t = (char *)(dir + 1);
    char *s = (char *)(dir + 2);
    char *filename = ftp->buf + FTP_BUFSZ - 16;
    W len;
    INT i;
    ER ercd = E_OK;

    if (fp == NULL) {
        tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        ftp->flag &= ~(FTP_LIST|FTP_NLST|FTP_DTP_OPEN);
        return NULL;
    }

    for (i = 0;;) {
        len = fread(dir, 1, sizeof (struct _direct), fp);
        if (len == 0) {
            if (ftp->flag & FTP_NLST) {
                strcpy(s, "\r\n");
                ercd = ftp_snd_dat(ftp, s, strlen(s));
                if (ercd < 0) /* 13MAY2005 - Return Error */
                    goto END;
            }
            break;
        }
        if (dir->d_ino == 0)
            continue;
        strncpy(t, dir->d_name, DIRSIZ);
        strlwr(t);
        if (!wildcard_check(filename, t))
            continue;

        if (!(ftp->flag & FTP_NLST)) {                  /* not NLST */
            strcpy(s, "-rwxrwxrwx 1 root root ");       /* set the dummy attributes(23bytes) */

          #ifdef DIRECT_FSIZE
            strcat(s, "            ");
            strcpy(s + 12 + 23, dir->fsize);            /* add the file size */
          #endif
            strcat(s, DATE_FTP);                        /* dummy date */
            strcat(s, "  ");
        } else {
            strcpy(s, "              ");
            s[14] = '\0';
            if (++i >= 5)
                i = 0;
        }
        strcat(s, t);                                   /* add file name */
        strcat(s, "\r\n");
        ercd = ftp_snd_dat(ftp, s, strlen(s));
        if (ercd != E_OK)
            break;
    }

END:
    fclose(ftp->fp);
    ftp->fp = NULL;
    tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
    ftp->flag &= ~(FTP_LIST|FTP_NLST|FTP_DTP_OPEN);
    if (ercd == E_OK)
        return msg_ftp_complete;
    else
        return msg_ftp_disconnected;
}

/************************************************/
/* USER Command                                 */
/************************************************/

static const char *ftp_user_command(T_FTP *ftp, const char *arg)
{
    strncpy(ftp->user, arg, sizeof ftp->user - 1);
    ftp->flag &= ~FTP_LOGGED_IN;
    return msg_ftp_password;
}

/************************************************/
/* PASS Command                                 */
/************************************************/

static const char *ftp_pass_command(T_FTP *ftp, const char *arg)
{
    FTP_CALLBACK func;
    const char *s;

    func = (FTP_CALLBACK)ftp->callback;
    if (func != (FTP_CALLBACK)NULL) {
        if ((s = (*func)(ftp, ftp->user, arg)) == NULL)
            return msg_ftp_incorrect;
    }
    else
        s = msg_ftp_logged_in;

    ftp->flag |= FTP_LOGGED_IN;
    return s;
}

/************************************************/
/* QUIT Command                                 */
/************************************************/

static const char *ftp_quit_command(T_FTP *ftp, const char *arg)
{
    ftp->flag &= ~FTP_LOGGED_IN;
    ftp->flag |= FTP_QUIT;
    return msg_ftp_goodbye;
}

/************************************************/
/* PORT Command                                 */
/************************************************/

static const char *ftp_port_command(T_FTP *ftp, const char *arg)
{
    T_IPEP myaddr;
    T_IPEP dstaddr;
    ER ercd;
    INT i;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    if (ftp->flag & FTP_DTP_OPEN) {
        ftp->flag &= ~FTP_DTP_OPEN;
        ercd = tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        if (ercd != E_OK) {
            ftp->ercd = ercd;
            return msg_ftp_cant_open;
        }
    }

    dstaddr.ipaddr = 0L;
    dstaddr.portno = 0;
    for (i = 0;;) {
        if (i < 4)
            dstaddr.ipaddr = (dstaddr.ipaddr << 8) + atoi(arg);
        else
            dstaddr.portno = (dstaddr.portno << 8) + atoi(arg);
        if (++i == 6)
            break;
        arg = strchr(arg, ',');
        if (arg == NULL)
            return msg_ftp_invalid_arg;
        arg++;
    }

    ercd = tcp_ref_cep(ftp->cepid1, &myaddr);
    if (ercd <= 0) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    tcp_set_opt(ftp->cepid2, IP_IF_NAME, ftp->nif->name, 0);
    myaddr.portno = TCP_PORT_FTPDATA;
#ifdef DUAL_STK
    dstaddr.type = IPV4_ADDR;
#endif
    ercd = tcp_con_cep(ftp->cepid2, &myaddr, &dstaddr, FTPD_TMOUT);
    if (ercd != E_OK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    ftp->flag |= FTP_DTP_OPEN;
    return msg_ftp_port_ok;
}

/************************************************/
/* EPRT Command                                 */
/************************************************/
#ifdef DUAL_STK

static const char *ftp_eprt_command(T_FTP *ftp, const char *arg)
{
    T_IPEP myaddr;
    T_IPEP dstaddr;
    ER ercd;
    INT i;
    B delimit;
    char *e_ptr = NULL;
    char *s_ptr = NULL;
    char addr[45];

    memset(&myaddr, 0, sizeof(T_IPEP));
    memset(&dstaddr, 0, sizeof(T_IPEP));

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;       /* FTPd response # 530 */

    if (ftp->flag & FTP_DTP_OPEN) {
        ftp->flag &= ~FTP_DTP_OPEN;
        ercd = tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        if (ercd != E_OK) {
            ftp->ercd = ercd;
            return msg_ftp_cant_open;
        }
    }

    /* Start parsing the argument of EPRT command */
    delimit = *arg;

    for (i = 0; i < 3; i++) {
        arg = strchr(arg, delimit);
        if (arg == NULL)
            return msg_ftp_invalid_arg;     /* FTPd response # 501 */
        arg++;
        switch (i) {
            case 0: /*Get AF number */
                if (*arg == '1')
                    dstaddr.type = IPV4_ADDR;
                else if (*arg == '2')
                    dstaddr.type = IPV6_ADDR;
                else
                    return msg_ftp_invalid_arg;     /* FTPd response # 501 */
                break;
            case 1:
                s_ptr = (char *) arg;

                arg = strchr(arg, '%');
                if (arg == NULL)
                    arg = s_ptr;
                else
                    e_ptr =  (char *) arg++;
                break;
            case 2:
                if (e_ptr == NULL)
                    e_ptr = (char *) arg - 1;
                memcpy(addr, s_ptr, e_ptr-s_ptr);
                addr[e_ptr-s_ptr] = '\0';
                if (dstaddr.type == IPV6_ADDR)
                    ascii_to_ip6addr(addr, dstaddr.ip6addr);
                else
                    dstaddr.ipaddr = ascii_to_ipaddr(addr);

                dstaddr.portno = atoi(arg);
                break;
        }
    }

    ercd = tcp_ref_cep(ftp->cepid1, &myaddr);
    if (ercd <= 0) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    tcp_set_opt(ftp->cepid2, IP_IF_NAME, ftp->nif->name, 0);
    myaddr.portno = TCP_PORT_FTPDATA;
    ercd = tcp_con_cep(ftp->cepid2, &myaddr, &dstaddr, FTPD_TMOUT);
    if (ercd != E_OK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    ftp->flag |= FTP_DTP_OPEN;
    return msg_ftp_port_ok;
}

#endif

/************************************************/
/* get passive mode port number                 */
/************************************************/

UH ftp_pasvport(void)
{
    return (SYSCK.ltime % (FTP_PASV_MAX - FTP_PASV_MIN + 1)) + FTP_PASV_MIN;
}

/************************************************/
/* PASV Command                                 */
/************************************************/

static const char *ftp_pasv_command(T_FTP *ftp, const char *arg)
{
    static T_IPEP dstaddr;
    T_TCP_CREP crep;
    ER ercd;
    INT i;
    UH port;
    char buf[5];

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    if (ftp->flag & FTP_DTP_OPEN) {
        ftp->flag &= ~FTP_DTP_OPEN;
        ercd = tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        if (ercd != E_OK) {
            ftp->ercd = ercd;
            return msg_ftp_cant_open;
        }
    }

    crep.repatr = 0;
    crep.myaddr = ftp->myaddr;
  #ifdef DUAL_STK
    crep.myaddr.type = IPV4_ADDR;
  #endif
    if (ftp->repid2) {
        tcp_del_rep(ftp->repid2);
        ftp->repid2 = 0;
    }
    for (;;) {
        port = ftp_pasvport();
        if (port == 0)
            return msg_ftp_cant_open;
        crep.myaddr.portno = port;
        ercd = tcp_vcre_rep(&crep);
        if (ercd > 0) {
            ftp->repid2 = (UH)ercd;
            break;
        }
        if (ercd == E_OBJ) {
            dly_tsk(1);
            continue;   /* retry other port number */
        }
        return msg_ftp_cant_open;
    }

    ercd = tcp_set_opt(ftp->cepid2, IP_IF_NAME, ftp->nif->name, 0);
    if (ercd != E_OK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    acp_cep_tskid = vget_tid();
    ercd = tcp_acp_cep(ftp->cepid2, ftp->repid2, &dstaddr, TMO_NBLK);
    if (ercd != E_WBLK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    strcpy(msg_ftp_enter_pasv, "227 Entering Passive Mode ");
    strcat(msg_ftp_enter_pasv, "(");
    for (i = 3; i >= 0; i--) {
        itou(buf, (ftp->myaddr.ipaddr >> (8 * i)) & 0xFF, 0);
        strcat(msg_ftp_enter_pasv, buf);
        strcat(msg_ftp_enter_pasv, ",");
    }
    itou(buf, port >> 8, 0);
    strcat(msg_ftp_enter_pasv, buf);
    strcat(msg_ftp_enter_pasv, ",");
    itou(buf, port & 0xff, 0);
    strcat(msg_ftp_enter_pasv, buf);
    strcat(msg_ftp_enter_pasv, ")\r\n");

    ftp->flag |= FTP_DTP_OPEN;
    return msg_ftp_enter_pasv;
}

/************************************************/
/* EPSV Command                                 */
/************************************************/
#ifdef DUAL_STK

static const char *ftp_epsv_command(T_FTP *ftp, const char *arg)
{
    T_IPEP myaddr;
    static T_IPEP dstaddr;
    T_TCP_CREP crep;
    ER ercd;
    INT i;
    UH port;
    char buf[5];

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    if (ftp->flag & FTP_DTP_OPEN) {
        ftp->flag &= ~FTP_DTP_OPEN;
        ercd = tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        if (ercd != E_OK) {
            ftp->ercd = ercd;
            return msg_ftp_cant_open;
        }
    }

    crep.repatr = 0;
    crep.myaddr = ftp->myaddr;
    crep.myaddr.type = IPV6_ADDR;
    if (ftp->repid2) {
        tcp_del_rep(ftp->repid2);
        ftp->repid2 = 0;
    }
    for (;;) {
        port = ftp_pasvport();
        if (port == 0)
            return msg_ftp_cant_open;
        crep.myaddr.portno = port;
        ercd = tcp_vcre_rep(&crep);
        if (ercd > 0) {
            ftp->repid2 = (UH)ercd;
            break;
        }
        if (ercd == E_OBJ) {
            dly_tsk(1);
            continue;   /* retry other port number */
        }
        return msg_ftp_cant_open;
    }

    ercd = tcp_set_opt(ftp->cepid2, IP_IF_NAME, ftp->nif->name, 0);
    if (ercd != E_OK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    dstaddr.type = ftp->dstaddr.type;
    acp_cep_tskid = vget_tid();
    ercd = tcp_acp_cep(ftp->cepid2, ftp->repid2, &dstaddr, TMO_NBLK);
    if (ercd != E_WBLK) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    ercd = tcp_ref_cep(ftp->cepid2, &myaddr);
    if (ercd <= 0) {
        ftp->ercd = ercd;
        return msg_ftp_cant_open;
    }

    strcpy(msg_ftp_enter_pasv, "229 Entering Extended Passive Mode ");
    strcat(msg_ftp_enter_pasv, "(   ");
    for (i = 0; i < 0; i++) {
        itou(buf, (UB)(myaddr.ipaddr >> (i*8)), sizeof(UB));
        strcat(msg_ftp_enter_pasv, buf);
        strcat(msg_ftp_enter_pasv, ",");
    }
    itou(buf, port, itoulen(port));
    strcat(msg_ftp_enter_pasv, buf);
    strcat(msg_ftp_enter_pasv, " )\r\n");

    ftp->flag |= FTP_DTP_OPEN;
    return msg_ftp_enter_pasv;
}

#endif
/************************************************/
/* TYPE Command                                 */
/************************************************/

static const char *ftp_type_command(T_FTP *ftp, const char *arg)
{
    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    if (arg[0] == 'I' || arg[0] == 'A') /* Image or ASCII(Dummy) */
        return msg_ftp_successful;
    else
        return msg_ftp_unimple_arg;
}

/************************************************/
/* Convert directory separator '/' -> '\\'      */
/************************************************/

static void conv_dirsep( char *tmp )
{
    char *p;

    while ((p = strchr(tmp,'/')) != NULL)
        *p = '\\';
}

/************************************************/
/* RETR Command                                 */
/************************************************/

static const char *ftp_retr_command(T_FTP *ftp, const char *arg)
{
    char *filename = ftp->buf + FTP_BUFSZ - 16;
    ftp->flag |= FTP_RETR;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    strncpy(filename, arg, 16);
    conv_dirsep(filename);
    ftp->fp = fopen(filename, "r");
    if (ftp->fp == NULL)
        return msg_ftp_not_found;
    else
        return msg_ftp_openning;
}

/************************************************/
/* STOR Command                                 */
/************************************************/

static const char *ftp_stor_command(T_FTP *ftp, const char *arg)
{
    char *filename = ftp->buf + FTP_BUFSZ - 16;
    ftp->flag |= FTP_STOR;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    strncpy(filename, arg, 16);
    conv_dirsep(filename);
    ftp->fp = fopen(filename, "w");
    if (ftp->fp == NULL)
        return msg_ftp_cant_write;
    else
        return msg_ftp_openning;
}

/************************************************/
/* APPE Command                                 */
/************************************************/

static const char *ftp_appe_command(T_FTP *ftp, const char *arg)
{
    char *filename = ftp->buf + FTP_BUFSZ - 16;
    ftp->flag |= FTP_STOR;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    strncpy(filename, arg, 16);
    conv_dirsep(filename);
    ftp->fp = fopen(filename, "a");
    if (ftp->fp == NULL)
        return msg_ftp_cant_write;
    else
        return msg_ftp_openning;
}

/************************************************/
/* LIST Command                                 */
/************************************************/

static const char *ftp_list_command(T_FTP *ftp, const char *arg)
{
    char *filename = ftp->buf + FTP_BUFSZ - 16;

    ftp->flag |= FTP_LIST;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    strncpy(filename, arg, 16);
    ftp->fp = fopen(".", "r");

    if (ftp->fp == NULL)
        return msg_ftp_not_found;
    else
        return msg_ftp_openning;
}

static const char *ftp_nlst_command(T_FTP *ftp, const char *arg)
{
    if (strcmp(arg, "-alL") != 0)
        ftp->flag |= FTP_NLST;
    return ftp_list_command(ftp, "");
}

/************************************************/
/* DELE Command                                 */
/************************************************/

static const char *ftp_dele_command(T_FTP *ftp, const char *arg)
{
    int r;
    char *filename = ftp->buf + FTP_BUFSZ - 16;

    if (!(ftp->flag & FTP_LOGGED_IN))
        return msg_ftp_not_logged_in;

    strncpy(filename, arg, 16);
    conv_dirsep(filename);
    r = remove(filename);
    if (r != 0)
        return msg_ftp_not_found;
    else
        return msg_ftp_successful;
}

/************************************************/
/* PWD Command                                  */
/************************************************/

static const char *ftp_pwd_command(T_FTP *ftp, const char *arg)
{
    return "257 \"A:/\" is current directory\r\n";
}

/************************************************/
/* CWD Command                                  */
/************************************************/

static const char *ftp_cwd_command(T_FTP *ftp, const char *arg)
{
    return "250 Requested file action completed\r\n";
}

/************************************************/
/* FTP Server Task                              */
/************************************************/

TASK ftp_server_tsk(T_FTP *ftp)
{
    const T_FTP_COMMAND_TABLE *t;
    const char *s;
    ER ercd;

    for (;;) {
        /* Accept Connection */

        while (1) {
            ercd = tcp_acp_cep(ftp->cepid1, ftp->repid, &ftp->dstaddr, TMO_FEVR);
            if (ercd == E_OK)
                break;

            if ((ercd == E_TMOUT) || (ercd == E_CLS)) {
                dly_tsk(1000/MSEC);
            } else {

                /* Panic Error! Can't continue process */

                tcp_can_cep(ftp->cepid2, TFN_TCP_ALL);
                tcp_can_cep(ftp->cepid1, TFN_TCP_ALL);
                tcp_del_rep(ftp->repid);
                if (ftp->repid2)
                    tcp_del_rep(ftp->repid2);
                tcp_del_cep(ftp->cepid2);
                tcp_del_cep(ftp->cepid1);
                ftp->cepid1 = ftp->cepid2 = 0;
                exd_tsk();
            }
        }

        ftp->nif = TCP_CEP[ftp->cepid1 - 1].nif;

        s = msg_ftp_server_ready;

        /* FTP Process Loop */

        for (;;) {

            /* Send FTP Response */

            if (s != NULL)
                if (ftp_put_str(ftp, s) != E_OK)
                    break;

            /* Receive FTP Command */

            memset(ftp->buf, 0, 4 + 1 + 1);
            if (ftp_get_str(ftp, ftp->buf, sizeof ftp->buf) != E_OK)
                break;

            /* Jump Each Command */

            for (t = (T_FTP_COMMAND_TABLE*)ftp_command_table; t->func !=  (FTP_COMMAND)NULL; t++)
                if (memcmp(t->command, ftp->buf, strlen(t->command)) == 0)
                    break;

            if (t->func != (FTP_COMMAND)NULL) {
                s = strchr(ftp->buf, ' ');
                if (s == NULL)
                    s = (*t->func)(ftp, "");
                else
                    s = (*t->func)(ftp, s + 1);
            } else {
                s = msg_ftp_unrecognized;
            }

            /* Send FTP Response */

            if (s != NULL)
                if (ftp_put_str(ftp, s) != E_OK)
                    break;

            /* Wait for tcp_acp_cep(..., TMO_NBLK) */
            if (acp_cep_tskid != 0) {
                dly_tsk(FTPD_TMOUT);
                if (acp_cep_tskid != 0)
                    break;
            }

            /* Quit or File Transfer */

            if (ftp->flag & FTP_QUIT)
                break;
            else if ((ftp->flag & FTP_STOR) && (ftp->flag & FTP_DTP_OPEN))
                s = ftp_rcv_fil(ftp, ftp->fp);
            else if ((ftp->flag & FTP_RETR) && (ftp->flag & FTP_DTP_OPEN))
                s = ftp_snd_fil(ftp, ftp->fp);
            else if ((ftp->flag & FTP_LIST) && (ftp->flag & FTP_DTP_OPEN))
                s = ftp_snd_dir(ftp, ftp->fp);
            else
                s = NULL;
        }

        /* Close Connection */

        tcp_cls_cep(ftp->cepid1, FTPD_TMOUT);
        acp_cep_tskid = 0;
        tcp_can_cep(ftp->cepid2, TFN_TCP_ALL);
        tcp_cls_cep(ftp->cepid2, FTPD_TMOUT);
        ftp->flag = 0;
    }
}

/************************************************/
/* FTPd callback                                */
/************************************************/

ER ftp_callback(ID cepid, FN fncd, VP parblk)
{
    ID id;

    if ((id = acp_cep_tskid) != 0 && fncd == TFN_TCP_ACP_CEP) {
        acp_cep_tskid = 0;
        rel_wai(id);
    }
    return E_OK;
}

/************************************************/
/* Delete FTP Server resources                  */
/************************************************/

void ftpd_ext(T_FTP *ftp)
{
    /* Delete all FTP Server resources */

    tcp_del_rep(ftp->repid);
    if (ftp->repid2)
        tcp_del_rep(ftp->repid2);
    tcp_can_cep(ftp->cepid2, TFN_TCP_ALL);
    tcp_can_cep(ftp->cepid1, TFN_TCP_ALL);

}

/************************************************/
/* Start FTP Server                             */
/************************************************/

ER ftp_sta_srv(T_FTP *ftp)
{
    static T_TCP_CREP crep;
    ER ercd;

    acp_cep_tskid = 0;

    /* create TCP reception point */

    crep.repatr = 0;
    crep.myaddr = ftp->myaddr;
    crep.myaddr.portno = TCP_PORT_FTP;
    if (ftp->repid == 0) {
        ercd = tcp_vcre_rep(&crep);
        if (ercd <= 0)
            return ercd;
        ftp->repid = (UH)ercd;
    } else {
        ercd = tcp_cre_rep(ftp->repid, &crep);
        if (ercd != E_OK && ercd != E_OBJ)
            return ercd;
    }

    /* clear TCP reception point ID for passive mode */

    ftp->repid2 = 0;

    /* set interface for TCP commnunication end points */

    if (ftp->nif != NULL)
        tcp_set_opt(ftp->cepid1, IP_IF_NAME, ftp->nif->name, 0);

    /* start server task */

    ercd  = vsta_tsk(ftp->tskid, (VP)ftp);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    tcp_del_rep(ftp->repid);
    return ercd;
}

/************************************************/
/* Create FTP Server                            */
/************************************************/

ER ftp_cre_srv(T_FTP *ftp, ID tskid, ID cepid1, ID cepid2, ID repid, FTP_CALLBACK callback)
{
    T_TCP_CCEP ccep;
    ER ercd;

    /* FTP control block initialize */

    memset(ftp, 0, sizeof (T_FTP));
    ftp->tskid = (UH)tskid;
    ftp->cepid1 = (UH)cepid1;
    ftp->cepid2 = (UH)cepid2;
    ftp->repid = (UH)repid;
    ftp->callback = (FP)callback;

    /* create TCP commnunication end points */

    memset(&ccep, 0, sizeof (T_TCP_CCEP));
    ccep.sbuf = ftp->sbuf1;
    ccep.sbufsz = sizeof ftp->sbuf1;
    ccep.rbuf = ftp->rbuf1;
    ccep.rbufsz = sizeof ftp->rbuf1;

    if (ftp->cepid1 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            return ercd;
        ftp->cepid1 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid1, &ccep);
        if (ercd != E_OK)
            return ercd;
    }

    ccep.sbuf = ftp->sbuf2;
    ccep.sbufsz = sizeof ftp->sbuf2;
    ccep.rbuf = ftp->rbuf2;
    ccep.rbufsz = sizeof ftp->rbuf2;
    ccep.callback = (FP)ftp_callback;

    if (ftp->cepid2 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            goto ERR;
        ftp->cepid2 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid2, &ccep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* create FTP server task */

    if (ftp->tskid == 0) {
        ercd = acre_tsk(&ftp_server_ctsk);
        if (ercd <= 0)
            goto ERR;
        ftp->tskid = (UH)ercd;
    } else {
        ercd = cre_tsk(ftp->tskid, &ftp_server_ctsk);
        if (ercd != E_OK)
            goto ERR;
    }

    return E_OK;

ERR:
    tcp_del_cep(ftp->cepid2);
    tcp_del_cep(ftp->cepid1);
    del_tsk(ftp->tskid);
    return ercd;
}

#ifdef DUAL_STK

ER ftp_cre_srv6(T_FTP *ftp, ID tskid, ID cepid1, ID cepid2, ID repid, FTP_CALLBACK callback)
{
    static const T_TCP_CREP crep = { 0, { IPV4_ADDRANY, TCP_PORT_FTP, IPV6_ADDRANY, IPV6_ADDR } };
    T_TCP_CCEP ccep;
    ER ercd;

    /* FTP control block initialize */

    memset(ftp, 0, sizeof (T_FTP));
    ftp->tskid = (UH)tskid;
    ftp->cepid1 = (UH)cepid1;
    ftp->cepid2 = (UH)cepid2;
    ftp->repid = (UH)repid;
    ftp->callback = (FP)callback;

    /* create TCP commnunication end points */

    memset(&ccep, 0, sizeof (T_TCP_CCEP));
    ccep.sbuf = ftp->sbuf1;
    ccep.sbufsz = sizeof ftp->sbuf1;
    ccep.rbuf = ftp->rbuf1;
    ccep.rbufsz = sizeof ftp->rbuf1;

    if (ftp->cepid1 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            return ercd;
        ftp->cepid1 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid1, &ccep);
        if (ercd != E_OK)
            return ercd;
    }

    ccep.sbuf = ftp->sbuf2;
    ccep.sbufsz = sizeof ftp->sbuf2;
    ccep.rbuf = ftp->rbuf2;
    ccep.rbufsz = sizeof ftp->rbuf2;

    if (ftp->cepid2 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            goto ERR;
        ftp->cepid2 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid2, &ccep);
        if (ercd != E_OK)
            goto ERR;
    }

    /* create TCP reception point */

    if (ftp->repid == 0) {
        ercd = tcp_vcre_rep(&crep);
        if (ercd <= 0)
            goto ERR;
        ftp->repid = (UH)ercd;
    } else {
        ercd = tcp_cre_rep(ftp->repid, &crep);
        if (ercd != E_OK && ercd != E_OBJ)
            goto ERR;
    }

    /* clear TCP reception point ID for passive mode */
    ftp->repid2 = 0;

    /* create FTP server task */

    if (ftp->tskid == 0) {
        ercd = acre_tsk(&ftp_server_ctsk);
        if (ercd <= 0)
            goto ERR;
        ftp->tskid = (UH)ercd;
    } else {
        ercd = cre_tsk(ftp->tskid, &ftp_server_ctsk);
        if (ercd != E_OK)
            goto ERR;
    }

    return E_OK;

ERR:
    tcp_del_rep(ftp->repid);
    tcp_del_cep(ftp->cepid2);
    tcp_del_cep(ftp->cepid1);
    del_tsk(ftp->tskid);
    return ercd;

}

#endif

/* end */
