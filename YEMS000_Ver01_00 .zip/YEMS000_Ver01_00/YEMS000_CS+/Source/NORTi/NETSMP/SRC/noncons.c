/******************************************************************************
* Serial Console Functions                                                    *
*                                                                             *
*  Copyright (c) 1999-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-23 Created                                                          *
* 1999-03-15 Deleted "#include nosio3.h"                                      *
* 1999-09-22 Added auto ID assignment of cre_???() for specified id = 0    YS *
* 2005-04-20 Replaced 'B *' for string type with 'char *'                  PK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2009-08-03 Added initialization of 'tmo' member of T_CONSOLE             FY *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2015-02-13 Added initialization of term_print & term_getch of T_CONSOLE  FY *
* 2015-09-12 Added missing del_mbf() to console_ini() in case of error     MI *
* 2015-09-12 Moved CTRL_C definition to nonteln.h                          MI *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosio.h"
#include "nonet.h"
#include "noncons.h"
#include "nonteln.h"

/* Object Creation Information in nonteld.c */

extern const T_CTSK telnetd_ctsk;
extern const T_CMBF telnetd_cmbf;

/************************************************/
/* Serial Console Low Level Put String          */
/************************************************/

BOOL console_print(T_CONSOLE *t, const char *s)
{
    UB c;
    INT ch;

    ch = t->ch;
    while ((c = (UB)*s++) != '\0')
        put_sio(ch, c, TMO_FEVR);
    return TRUE;
}

/************************************************/
/* Serial Console Low Level Get Sized String    */
/************************************************/

INT console_input(T_CONSOLE *t, char *s, int size)
{
    UB c;
    INT ch, i, skip;
    ER ercd;
    TMO tmout;
    SIGNAL_FUNC func;

    ch = t->ch;
    tmout = 40/MSEC;

    for (i = skip = 0;;) {

        ercd = get_sio(ch, &c, tmout);
        if (ercd == E_TMOUT)
            return E_TMOUT;
        if (ercd != E_OK)
            continue;
        if (i == 0 && c == '\n')    /* ignore last LF */
            continue;
        tmout = TMO_FEVR;

        if (skip != 0) {
            skip--;
            continue;
        }
        if (c == '\r') {            /* CR */
            s[i] = '\0';
            return '\r';
        }
        if (c == '\b') {            /* backspace */
            if (i > 0) {
                i--;
                if (t->echo_on != 0) {
                    put_sio(ch, '\b', TMO_FEVR);
                    put_sio(ch, ' ',  TMO_FEVR);
                    put_sio(ch, '\b', TMO_FEVR);
                }
            }
            continue;
        }
        if (c == CTRL_C) {          /* Ctrl-C */
            if (t->echo_on != 0) {
                put_sio(ch, '^', TMO_FEVR);
                put_sio(ch, 'C', TMO_FEVR);
            }
            s[i] = '\0';
            func = (SIGNAL_FUNC)t->sigint;
            if (func != SIG_DFL)
                func(SIGINT);
            return CTRL_C;
        }
        if (c == 0x1b) {            /* ESC sequence */
            skip = 2;
            continue;
        }
        if (c < 0x20 || c > 0x7e)
            continue;
        if (i >= size - 1)
            continue;
        s[i++] = c;
        if (t->echo_on != 0) {
            if (t->echo_on == '*')
                c = '*';
            put_sio(ch, c, TMO_FEVR);
        }
    }
}

/************************************************/
/* Serial Console Low Level Get Character       */
/************************************************/

INT console_getch(T_CONSOLE *t)
{
    UB c;
    ER ercd;

    ercd = get_sio(t->ch, &c, TMO_FEVR);
    if (ercd == E_RLWAI)
        return ercd;
    return c;
}

/************************************************/
/* Serial Console Low Level Input Check         */
/************************************************/

BOOL console_kbhit(T_CONSOLE *t)
{
    T_SIOS sios;

    ref_sio(t->ch, &sios);
    if (sios.rxlen != 0)
        return TRUE;
    else
        return FALSE;
}

/************************************************/
/* Initialize Serial Console                    */
/************************************************/

ER console_ini(T_CONSOLE *t, ID tskid, ID mbfid, INT ch, const char *param)
{
    ER ercd;

    /* initialize control block */
    memset(t, 0, sizeof (T_CONSOLE));
    t->term_print = (BOOL (*)(T_TERMINAL *, const char *))console_print;
    t->term_getch = (INT (*)(T_TERMINAL *))console_getch;
    t->ch = ch;
    t->tmo = TMO_FEVR;
    t->echo_on = 1;

    /* initialize UART device */
    ercd = ini_sio(t->ch, param);
    if (ercd != E_OK)
        return ercd;
    ercd = ctl_sio(t->ch, TSIO_RXE|TSIO_TXE|TSIO_RTSON|TSIO_DTRON);
    if (ercd != E_OK)
        return ercd;

    /* create message buffer */
    if (mbfid == 0)
        ercd = mbfid = acre_mbf(&telnetd_cmbf);
    else
        ercd = cre_mbf(mbfid, &telnetd_cmbf);
    if (ercd < 0)
        return ercd;
    t->rx_mbfid = (UH)mbfid;

    /* create Telnet server task */
    if (tskid == 0)
        ercd = tskid = acre_tsk(&telnetd_ctsk);
    else
        ercd = cre_tsk(tskid, &telnetd_ctsk);
    if (ercd < 0) {
        del_mbf(mbfid);
        return ercd;
    }
    t->telnetd_tskid = (UH)tskid;
    return E_OK;
}

/* end */
