/******************************************************************************
* NORTi Network Packet Dump Routine for Debug                                 *
*                                                                             *
*  Copyright (c) 1998-2021, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-05                                                                  *
* 1999-03-15 '#include nosio3.h' is deleted.                                  *
* 1999-05-25 1�p�P�b�g1�s�ɕύX, OVF��\�����đ҂����N���Ȃ��悤�ύX          *
* 1999-06-12 sprintf���g��Ȃ�, ��                                            *
* 1999-09-22 resource ID auto assign added.                                   *
* 2001-11-08 dump_packet�o�O�C��                                           MI *
* 2002-04-15 analyze_packet(), cnt<=0����strncpy�T�C�Y�v�Z�C��             HM *
* 2002-09-08 ���[�j���O�΍� B * -> char *                                  MI *
* 2002-11-28 landump_msg �C��, ���b�Z�[�W�̏ꍇ�͂���̂ݕ\��              MI *
* 2005-03-04 Telnet�֏o�͂ł���悤�ɕύX                                  YS *
* 2005-05-13 Added 'landump_ext' function.                                 AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2008-07-29 The processing of the fragmentation packet is changed.        FY *
* 2008-08-18 Added 'landump_get_msgbuf', 'landump_add_msg',                   *
*            'landump_end_msg' and 'landump_wait' function.                FY *
* 2010-12-28 Corrected compiler warning by adding (FP) to T_CTSK           HE *
* 2012-05-21 Replaced VP by T_DUMP_MSG* in landump_xxx to suppress warning FY *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2013-06-18 Added support for IPv6 packet                                 FY *
* 2016-07-13 Removed (int)dd cast by changing its type in analyze_packet() MT *
* 2021-06-22 Added support for PPPoE packet                                FY *
* 2021-06-22 Added "\r\n" after dump_puts() of analyze_packet() result     FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nosio.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#ifdef TELNET
#include "nonteln.h"
#endif

#ifndef CH
#define CH      1
#endif
#ifndef DATASZ
#define DATASZ  6+6+2+ETHERNET_MTU
#endif
#ifndef QCNT
#define QCNT    10
#endif

extern SYSTIME SNEAR cdecl SYSCK;

static UH landump_tskid;
static UH landump_mbxid;
static UH landump_mpfid;

TASK LanDumpTask(void);
const T_CTSK cLanDumpTask = { TA_HLNG, NULL, (FP)LanDumpTask, 6, 2048, NULL, "LanDumpTask" };

typedef struct t_dump_msg {
    struct t_dump_msg *next;
    H len;
    H cnt;
    UW tim;
    B data[DATASZ];
} T_DUMP_MSG;

const T_CMBX c_landump_mbx = { TA_TFIFO|TA_MFIFO, 0, NULL, "landump_mbx" };
const T_CMPF c_landump_mpf = { TA_TFIFO, QCNT, sizeof (T_DUMP_MSG), NULL, "landump_mbf" };

/************************************************/
/* Output 1 Charactor                           */
/************************************************/

void dump_putc(int c)
{
#ifdef TELNET
    terminal_putch(NULL, c);
#else
    while (put_sio(CH, (UB)c, 40/MSEC) != E_OK)
        ;
#endif
}

/************************************************/
/* Output 1 Line                                */
/************************************************/

void dump_puts(const char *s)
{
    char c;

    while ((c = *s++) != '\0')
#ifdef TELNET
        terminal_putch(NULL, c);
#else
        put_sio(CH, c, TMO_FEVR);
#endif
}

/************************************************/
/* Analyze Packet (ICMP)                        */
/************************************************/

static BOOL analyze_packet_icmp(char *s, char *end, UB *d, int cnt)
{
    int j;
    UB c;

    if (cnt <= 0)
        return FALSE;
    if (s + 3 >= end)
        return TRUE;
    c = d[0];
    *s++ = ' ';
    j = end - s;
    switch (c)
    {
    case  3: strncpy(s, (char *)"Destination Unreachable", j); break;
    case  5: strncpy(s, (char *)"Redirect", j); break;
    case  4: strncpy(s, (char *)"Source Quench", j); break;
    case 11: strncpy(s, (char *)"Time Exceeded", j); break;
    case 12: strncpy(s, (char *)"Parameter Problems", j); break;
    case  0: strncpy(s, (char *)"Echo Reply", j); break;
    case  8: strncpy(s, (char *)"Echo Request", j); break;
    case 15: strncpy(s, (char *)"Information Request", j); break;
    case 16: strncpy(s, (char *)"Information Reply", j); break;
    case 13: strncpy(s, (char *)"Timestamp Request", j); break;
    case 14: strncpy(s, (char *)"Timestamp Reply", j); break;
    case 17: strncpy(s, (char *)"Address Mark Request", j); break;
    case 18: strncpy(s, (char *)"Address Mark Reply", j); break;
    case  9: strncpy(s, (char *)"Router Advertisement", j); break;
    case 10: strncpy(s, (char *)"Solicition Message", j); break;
    default: ito0X(s, c, 2); break;
    }
    return TRUE;
}

/************************************************/
/* Analyze Packet (UDP)                         */
/************************************************/

static BOOL analyze_packet_udp(char *s, char *end, UB *d, int cnt)
{
    UH dd;

    /* Port Number */

    if (cnt <= 5)
        return FALSE;
    if (s + 6 >= end)
        return TRUE;
    *s++ = ' ';
    dd = ((UH)d[0] << 8) + d[1]; s = itou(s, dd, 0);
    if (s + 7 >= end)
        return TRUE;
    strcpy(s, (char *)"->"); s += 2;
    dd = ((UH)d[2] << 8) + d[3]; s = itou(s, dd, 0);

    /* Length */

    if (s + 9 >= end)
        return TRUE;
    strcpy(s, (char *)" Len"); s += 4;
    dd = ((UH)d[4] << 8) + d[5]; s = itou(s, dd, 0);
    return TRUE;
}

/************************************************/
/* Analyze Packet (TCP)                         */
/************************************************/

static BOOL analyze_packet_tcp(char *s, char *end, UB *d, int cnt)
{
    int i;
    UB c;
    UH dd;
    UW ddd;

    /* Port Number */

    if (cnt <= 10)
        return FALSE;
    if (s + 5 >= end)
        return TRUE;
    *s++ = ' ';
    dd = ((UH)d[0] << 8) + d[1];
    s = itou(s, dd, 0);
    if (s + 6 >= end)
        return TRUE;
    strcpy(s, (char *)"->"); s += 2;
    dd = ((UH)d[2] << 8) + d[3];
    s = itou(s, dd, 0);

    /* SEQ and ACK number */

    if (s + 11 >= end)
        return TRUE;
    *s++ = ' ';
    ddd = ((UW)d[4] << 24) + ((UW)d[5] << 16) + ((UH)d[6] << 8) + d[7];
    s = ltou(s, ddd, 0);
    if (s + 11 >= end)
        return TRUE;
    *s++ = '/';
    ddd = ((UW)d[8] << 24) + ((UW)d[9] << 16) + ((UH)d[10] << 8) + d[11];
    s = ltou(s, ddd, 0);

    /* Flag */

    if (cnt <= 13)
        return FALSE;
    c = d[13];
    if (c & 0x20) { if (s + 4 <= end) { strcpy(s, (char *)" URG"); s += 4; }}
    if (c & 0x10) { if (s + 4 <= end) { strcpy(s, (char *)" ACK"); s += 4; }}
    if (c & 0x08) { if (s + 4 <= end) { strcpy(s, (char *)" PSH"); s += 4; }}
    if (c & 0x04) { if (s + 4 <= end) { strcpy(s, (char *)" RST"); s += 4; }}
    if (c & 0x02) { if (s + 4 <= end) { strcpy(s, (char *)" SYN"); s += 4; }}
    if (c & 0x01) { if (s + 4 <= end) { strcpy(s, (char *)" FIN"); s += 4; }}

    /* Window Size */

  #ifdef WIN
    if (cnt <= 15)
        return FALSE;
    if (s + 5 + 5 >= end)
        return;
    strcpy(s, " Win="); s += 5;
    dd = ((UH)d[14] << 8) + d[15];
    s = itou(s, dd, 0);
  #endif

    /* TCP Data */

    if (s + 2 >= end)
        return TRUE;
    *s++ = ' ';
    i = (int)((d[12] >> 4) & 0x0f) * 4;
    for (;;)
    {   if (cnt <= i)
            break;
        if (s + 1 >= end)
            break;
        c = d[i++];
        if (c < 0x20 || (c >= 0x80 && c < 0xa0) || c >= 0xe0)
            c = '.';
        *s++ = (B)c;
    }
    *s++ = '\0';
    return TRUE;
}

/************************************************/
/* Analyze Packet (Main)                        */
/************************************************/

static int analyze_packet(char *buf, int size, int cnt, UW tim, void *data)
{
    static UW tt;
    char *s, *end;
    int i, c;
    int dd;
    UW t;
    UB *d = data;
    BOOL ok;

    s = buf;
    end = buf + size - 1;
    *s++ = '\r'; *s++ = '\n';

    /* Delta Time */

    t = tim - tt; tt = tim;
    s = lto_u(s, t, 3); *s++ = ':';

    if (cnt <= 0) {
        strncpy(s, data, end - s);
        return 0;
    }

    /* MAC Address */

  #ifdef MAC
    if (cnt > 11)
    {   if (s + 13 * 2 >= end)
            return cnt;
        for (i = 6; i <= 11; i++)
            s = ito0X(s, d[i], 2);
        *s++ = '-'; *s++ = '>';
        for (i = 0; i <= 5; i++)
            s = ito0X(s, d[i], 2);
    }
  #endif

    /* Frame Type */

    if (cnt < ETH_HEADER_SZ)
        return cnt;
    if (s + 23 >= end)
        return cnt;
    dd = ((UH)d[12] << 8) + d[13];
    switch (dd)
    {
    case ETYPE_IP4: break; /* IP */
    case ETYPE_IP6:
L1:
        strcpy(s, " IPv6");
        s += 5;
        break;
    case ETYPE_SESSION:
        strcpy(s, " PPPoE :");
        s += 8;
        d += 8;
        dd = ((UH)d[12] << 8) + d[13];
        if (dd == 0x0021) {
            dd = ETYPE_IP4;
            break;
        } else if (dd == 0x0057) {
            dd = ETYPE_IP6;
            goto L1;
        }
        goto L2;
    case 0x0600: strcpy(s, " Xerox XNS"); s += 10; break;
    case 0x0806: strcpy(s, " ARP");       s += 4;  break;
    case 0x0807: strcpy(s, " XNS");       s += 4;  break;
    case 0x80d5: strcpy(s, " IBM SNA");   s += 8;  break;
    case 0x8137: strcpy(s, " Old IPX");   s += 8;  break;
    case 0x8138: strcpy(s, " IPX");       s += 4;  break;
    case 0x9000: strcpy(s, " Loop Back"); s += 10; break;
L2:
    default:     strcpy(s, " FrameType=");s += 11; s = ito0X(s, dd, 4);  break;
    }

    /* When IP */

    if (dd == ETYPE_IP4) {
        /* Protocol Type */

        if (cnt < ETH_HEADER_SZ + IP4_HEADER_SZ)
            return cnt;
        if (s + 17 >= end)
            return cnt;
        dd = ((int)d[ETH_HEADER_SZ + 2] << 8) + d[ETH_HEADER_SZ + 3];   /* total length */
        if ((UH)cnt > (UH)dd + ETH_HEADER_SZ)
            cnt = dd + ETH_HEADER_SZ;
        if ((d[ETH_HEADER_SZ + 6] & 0x1f) || d[ETH_HEADER_SZ + 7]) {    /* flagment offset */
            strcpy(s, " Fragment packet");
            s += 16;
        } else {
            c = d[ETH_HEADER_SZ + 9];
            switch (c) {
            case  1: strcpy(s, " ICMP"); s += 5; break;
            case  6: strcpy(s, " TCP");  s += 4; break;
            case 17: strcpy(s, " UDP");  s += 4; break;
            default: strcpy(s, " IP");   s += 3; break;
            }

            i = ETH_HEADER_SZ + (d[ETH_HEADER_SZ] & 0x0f) * 4; /* Next part of IP header */

            if (c == 1) /* ICMP */
                ok = analyze_packet_icmp(s, end, d + i, cnt - i);
            else if (c == 6) /* TCP */
                ok = analyze_packet_tcp(s, end, d + i, cnt - i);
            else if (c == 17) /* UDP */
                ok = analyze_packet_udp(s, end, d + i, cnt - i);
            else
                ok = TRUE;
            if (!ok)
                strcat(s, "?");
        }
    } else if (dd == ETYPE_IP6) {
        /* Protocol Type */

        if (cnt < ETH_HEADER_SZ + IP6_HEADER_SZ)
            return cnt;
        if (s + 17 >= end)
            return cnt;
        dd = ((int)d[ETH_HEADER_SZ + 4] << 8) + d[ETH_HEADER_SZ + 5];   /* payload length */
        if (cnt > dd + (int)ETH_HEADER_SZ + IP6_HEADER_SZ)
            cnt = dd + ETH_HEADER_SZ + IP6_HEADER_SZ;

        i = ETH_HEADER_SZ + IP6_HEADER_SZ;  /* Next part of IPv6 header */

        c = d[ETH_HEADER_SZ + 6];
        if (c == 0) {       /* hop by hop option */
            c = d[i + 0];
            i += d[i + 1] * 8;
        }
        switch (c) {
        case  6: strcpy(s, " TCP");             s += 4;  break;
        case 17: strcpy(s, " UDP");             s += 4;  break;
        case 44: strcpy(s, " Fragment packet"); s += 16; break;
        case 51: strcpy(s, " AH");              s += 3;  break;
        case 58: strcpy(s, " ICMPv6");          s += 7;  break;
        default: strcpy(s, " IPv6");            s += 5;  break;
        }

      #if 0
        if (c == 1) /* ICMP */
            ok = analyze_packet_icmpv6(s, end, d + i, cnt - i);
        else
      #endif
        if (c == 6) /* TCP */
            ok = analyze_packet_tcp(s, end, d + i, cnt - i);
        else if (c == 17) /* UDP */
            ok = analyze_packet_udp(s, end, d + i, cnt - i);
        else
            ok = TRUE;
        if (!ok)
            strcat(s, "?");
    }
    return cnt;
}

/************************************************/
/* Dump Packet                                  */
/************************************************/
#ifdef DATA
static void dump_packet(char *buf, void *data, int cnt)
{
    char *s;
    int i, j, k, c, jj, kk;
    UB *d = data;

    if (cnt <= 0)
        return;

    dump_puts((char *)"\r\n");

    for (j = 0; ; j += 16 * 16)
    {
        for (i = 0; i < 16; i++)
        {
            jj = cnt - (j + (i + 1) * 16);
            s = buf;
            s = ito0X(s, j + i * 16, 4); *s++ = ' '; *s++ = ' ';
            for (k = 0; k < 16; k++)
            {   s = ito0X(s, d[k], 2); *s++ = ' ';
                if (k == 7)
                    *s++ = ' ';
            }
            *s= '\0';
            s = buf;
            if (jj < 0)
            {   kk = 16 + jj;
                for (k = 16 + jj; k < 16; k++)
                {   if (k < 8)
                        s[6 + k * 3] = s[6 + k * 3 + 1] = ' ';
                    else
                        s[7 + k * 3] = s[7 + k * 3 + 1] = ' ';
                }
            }
            else
                kk = 16;
            dump_puts(s);
            for (k = 0; k < kk; k++)
            {   c = d[k];
                if (c < 0x20 || (c >= 0x80 && c < 0xa0) || c >= 0xe0)
                    c = '.';
                dump_putc(c);
            }
            dump_puts((char *)"\r\n");
            d += 16;
            if (jj <= 0)
                return;
        }
    }
}
#endif

/************************************************/
/* Packet Dump Task                             */
/************************************************/

TASK LanDumpTask(void)
{
    T_DUMP_MSG *msg;
  #ifdef DATA
    int cnt;
  #endif
    static B buf[128];

    dump_puts((char *)"\r\nLAN packets dump program started\r\n");

    for (;;)
    {
        if (rcv_mbx(landump_mbxid, &msg) != E_OK)
            continue;
        if (msg->len == 0) {
            dump_puts((char *)msg->data);
            rel_mpf(landump_mpfid, msg);
            continue;
        }
      #if (defined(TCP) && defined(ARP))
        if ((((UH *)(msg->data))[12/2] != 0x0806)
         && (((UB *)(msg->data))[23] != 6)) {
            rel_mpf(landump_mpfid, msg);
            continue;
        }
      #elif defined(ARP)
        if (((UH *)(msg->data))[12/2] != 0x0806) {
            rel_mpf(landump_mpfid, msg);
            continue;
        }
      #elif defined(TCP)
        if (((UB *)(msg->data))[23] != 6) {
            rel_mpf(landump_mpfid, msg);
            continue;
        }
      #endif

      #ifdef DATA
        cnt = analyze_packet((char *)buf, sizeof buf, msg->cnt, msg->tim, msg->data);
      #else
        analyze_packet((char *)buf, sizeof buf, msg->cnt, msg->tim, msg->data);
      #endif

        dump_puts((char *)buf);
        dump_puts("\r\n");
      #ifdef DATA
        dump_packet((char *)buf, msg->data, cnt);
      #endif
        rel_mpf(landump_mpfid, msg);
    }
}

/************************************************/
/* End of Dump Data                             */
/************************************************/

void landump_end(T_DUMP_MSG *msg)
{
    if (landump_mbxid != 0 && msg != NULL)
        snd_mbx(landump_mbxid, msg);
}

/************************************************/
/* Receided/Transfer Packet Length              */
/************************************************/

void landump_len(T_DUMP_MSG **b, int len)
{
    UW t;
    T_DUMP_MSG *msg;
    T_RMPF rmpf;
    B ovf;

    t = SYSCK.ltime;

    if (landump_mpfid == 0)
    {   *b = NULL;
        return;
    }
    ref_mpf(landump_mpfid, &rmpf);
    if (rmpf.fblkcnt == 0)
    {   ovf = TRUE;
        len = 0;
        while (prcv_mbx(landump_mbxid, &msg) == E_OK)
            rel_mpf(landump_mpfid, msg);
    }
    else
        ovf = FALSE;

    if (pget_mpf(landump_mpfid, &msg) != E_OK)
    {   *b = NULL;
        return;
    }
    msg->len = (H)len;
    msg->cnt = 0;
    msg->tim = t;
    if (ovf)
        strcpy((char *)(msg->data), (char *)"OVF");
    if (len <= 0)
    {   landump_end(msg);
        *b = NULL;
    }
    else
        *b = msg;
}

/************************************************/
/* Get message buffer                           */
/************************************************/

void landump_get_msgbuf(T_DUMP_MSG **b)
{
    landump_len(b, DATASZ);
    if (*b != NULL)
        (*b)->len = 0;
}

/************************************************/
/* Add message                                  */
/************************************************/

void landump_add_msg(T_DUMP_MSG **b, const char* s)
{
    T_DUMP_MSG *msg, *msg2;

    if (*b == NULL)
        return;

    msg = (T_DUMP_MSG *)*b;

    while (*s != '\0') {
        if (msg->len >= DATASZ - 1) {
            while (msg->len >= 1 && ((char *)msg->data)[msg->len-1] != '\n')
                msg->len--;
            if (msg->len < 1)
                msg->len = DATASZ - 1;
            landump_get_msgbuf(&msg2);
            if (msg2 != NULL) {
                msg2->len = DATASZ - 1 - msg->len;
                if (msg->len < DATASZ - 1)
                    memcpy(msg2->data, &msg->data[msg->len], msg2->len);
                ((char *)msg->data)[msg->len] = '\0';
                msg->len = 0;
                landump_end(*b);
                *b = (VP)msg2;
                msg = msg2;
            }
            else {
                if (msg->len < DATASZ - 1)
                    memmove(msg->data, &msg->data[msg->len], DATASZ - 1 - msg->len);
                msg->len = DATASZ - 1 - msg->len;
            }
        }
        ((char *)msg->data)[msg->len++] = *s++;
    }
}

/************************************************/
/* End message                                  */
/************************************************/

void landump_end_msg(T_DUMP_MSG *msg)
{
    if (msg == NULL)
        return;

    if (msg->len==0) {
        rel_mpf(landump_mpfid, msg);
    }
    else {
        ((char *)msg->data)[msg->len] = '\0';
        msg->len = 0;
        landump_end(msg);
    }
}

/************************************************/
/* Message for Debug                            */
/************************************************/

void landump_msg(char *s)
{
    T_DUMP_MSG *msg;

    if (landump_mpfid == 0)
        return;
    if (pget_mpf(landump_mpfid, &msg) != E_OK)
        return;
    msg->len = 0;
    strcpy((char *)(msg->data), s);
    landump_end(msg);
}

/************************************************/
/* Receided/Transfer Data                       */
/************************************************/

void landump_dat(T_DUMP_MSG *msg, const void *data, int len)
{
    if (landump_mpfid == 0)
        return;
    if (msg == NULL)
        return;
    if (len > (int)(sizeof msg->data - msg->cnt))
        len = sizeof msg->data - msg->cnt;
    if (data != NULL)
        memcpy((VP)(msg->data + msg->cnt), data, len);
    else
        memset((VP)(msg->data + msg->cnt), 0, len);
    msg->cnt += len;
}

void landump_ext(void)
{
    /* Delete all LanDump resources */

    ter_tsk(landump_tskid);

    del_mbx(landump_mbxid);
    del_mpf(landump_mpfid);
    del_tsk(landump_tskid);

    landump_mbxid = 0;
    landump_mpfid = 0;
    landump_tskid = 0;
}

/************************************************/
/* waiting for landump                          */
/************************************************/

void landump_wait(void)
{
    T_RMBX rmbx;

    while (ref_mbx(landump_mbxid, &rmbx) == E_OK) {
        if (rmbx.wtskid == (ID)landump_tskid && rmbx.pk_msg==NULL)
            break;
        dly_tsk(200/MSEC);
    }
}

/************************************************/
/* Packet Dump Initialize                       */
/************************************************/

ER landump_ini(ID tskid, ID mbxid, ID mpfid)
{
    ER ercd;

    /* Create LAN dump task */

    if(tskid == 0){/* ID auto (Add by Y.Y) */
        ercd = acre_tsk(&cLanDumpTask);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    }
    else{
        ercd = cre_tsk(tskid, &cLanDumpTask);
        if (ercd != E_OK)
            return ercd;
    }
    landump_tskid = (UH)tskid;

    /* Create Mailbox for LAN dump */

    if(mbxid == 0){/* ID auto (Add by Y.Y) */
        ercd = acre_mbx(&c_landump_mbx);
        if (ercd < 0)
            goto ERR;
        mbxid = ercd;
    }
    else{
        ercd = cre_mbx(mbxid, &c_landump_mbx);
        if (ercd != E_OK)
            goto ERR;
    }
    landump_mbxid = (UH)mbxid;

    /* Create Memory pool for LAN dump */

    if(mpfid == 0){/* ID auto (Add by Y.Y) */
        ercd = acre_mpf(&c_landump_mpf);
        if (ercd < 0)
            goto ERR;
        mpfid = ercd;
    }
    else{
        ercd = cre_mpf(mpfid, &c_landump_mpf);
        if (ercd != E_OK)
            goto ERR;
    }
    landump_mpfid = mpfid;

    ercd = sta_tsk(tskid, 0);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    del_mbx(landump_mbxid);
    del_mpf(landump_mpfid);
    del_tsk(landump_tskid);
    landump_mbxid = landump_mpfid = landump_tskid = 0;

    return ercd;
}

/* end */
