/******************************************************************************
* TCP Performance Test Program using TTCP Command                             *
*                                                                             *
*  Copyright (c) 2011-2016, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-07-28 Created                                                  KM & MI *
* 2012-03-30 Added support for NORTi Oceans                                HE *
* 2015-03-03 Changed ttcp_r_loop() to save received host IP address, and      *
*              ttcp_t_loop() to update host IP address when unconnectable  FY *
* 2016-03-15 Equalized tcp_cre_???() style with multi-channel's nonttcp2.c FY *
* 2016-06-23 Added support for NTttcp                                      FY *
******************************************************************************/

#include "kernel.h"
#ifdef NORTi_Oceans
#include "nocnet.h"
#else
#include "nonet.h"
#endif
#include "nonttcp.h"

/* Configuration */

#ifndef TCP_PORT_TTCP
#define TCP_PORT_TTCP   5001    /* TTCP port number */
#endif
#ifndef TCP_PORT_NTCP
#define TCP_PORT_NTCP   6001    /* NTttcp command port number */
#endif
#ifndef BUFLEN
#define BUFLEN          8192    /* length of Tx/Rx buffer */
#endif
#ifndef NBUF
#define NBUF            2048    /* number of transmission */
#endif
#ifndef TXWINSZ
#define TXWINSZ         BUFLEN  /* Tx window buffer size (2~32768, 2^n) */
#endif
#ifndef RXWINSZ
#define RXWINSZ         BUFLEN  /* Rx window buffer size (2~32768, 2^n) */
#endif

/* Timeout Parameters */

#define DAT_TMOUT  (60000/MSEC) /* data transmit/receive timeout */
#define CON_TMOUT  (3000/MSEC)  /* connect/close timeout */
#define ACP_TMOUT  (20/MSEC)    /* NTttcp command accept timeout */

/* TTCP Data Buffer (shared by Tx and Rx) */

static UB buffer[BUFLEN];

/* Window Buffer of End Point */

static UH txwin[TXWINSZ/2];     /* for TTCP transmit */
static UH r1win[1];
static UH rxwin[RXWINSZ/2];     /* for TTCP receive */
static UH t1win[1];
static UH ntwin[4][1];          /* for NTttcp command transmit/receive */

/* Local Variables */

static UH ntcp_repid, ntcp_cepid;
static UH ntcp_tskid;
static B ntcp_mode;

/*****************************************************************************
* Send TCP data until the specified data length
*
******************************************************************************/

static int tcp_send(ID cepid, const UB *data, int len)
{
    ER ercd;
    int i;

    for (i = 0; i < len; i += ercd) {
        ercd = tcp_snd_dat(cepid, data + i, len - i, DAT_TMOUT);
        if (ercd <= 0)
            return ercd;
    }
    return i;   /* sent data length */
}

/*****************************************************************************
* Receive TCP data until the specified buffer size
*
******************************************************************************/

static int tcp_recv(ID cepid, UB *buf, int size)
{
    ER ercd;
    int i;

    for (i = 0; i < size; i += ercd) {
        ercd = tcp_rcv_dat(cepid, buf + i, size - i, DAT_TMOUT);
        if (ercd <= 0)
            return ercd;
    }
    return i;   /* received data length */
}

/*****************************************************************************
* TTCP Transmitter Loop
*
******************************************************************************/

void ttcp_t_loop(UW *ipaddr)
{
    T_TCP_CCEP ccep = { 0, txwin, TXWINSZ, r1win, 1, NULL };
    T_TCP_CCEP ccen = { 0, ntwin[0], 1, ntwin[1], 1, NULL };
    T_IPV4EP dstaddr, srcaddr;
    ID cepid, cenid;
    int len, n, i;
    UB cmd[1];
    ER ercd;

    ntcp_mode = FALSE;

    /* create TCP communication end point */
    cepid = tcp_vcre_cep(&ccep);
    cenid = tcp_vcre_cep(&ccen);

    srcaddr.ipaddr = IPV4_ADDRANY;
    srcaddr.portno = TCP_PORTANY;
    dstaddr.ipaddr = *ipaddr;

    for (;;) {
        /* request connection */
        dstaddr.portno = TCP_PORT_TTCP;
        if ((ercd = tcp_con_cep(cepid, &srcaddr, &dstaddr, CON_TMOUT)) != E_OK) {
            dstaddr.ipaddr = *ipaddr;   /* update host IP address */
            if (ercd != E_TMOUT)
                tslp_tsk(CON_TMOUT);
            continue;
        }

        if (ntcp_mode) {
            /* request command port connection */
            dstaddr.portno = TCP_PORT_NTCP;
            for (i = 0; i < 3; i++) {
                if ((ercd = tcp_con_cep(cenid, &srcaddr, &dstaddr, CON_TMOUT)) == E_OK) {
                    /* receive command */
                    if (tcp_rcv_dat(cenid, cmd, 1, DAT_TMOUT) > 0) {
                        /* send command */
                        cmd[0] = 0x58;
                        tcp_snd_dat(cenid, cmd, 1, DAT_TMOUT);
                    }
                    break;
                }
                if (ercd != E_TMOUT)
                    tslp_tsk(CON_TMOUT);
            }
            /* close command port connection */
            tcp_cls_cep(cenid, CON_TMOUT);
        }

        /* send TCP data until BUFLEN x NBUF bytes */
        for (n = 0; n < NBUF; n++) {
            len = tcp_send(cepid, buffer, BUFLEN);
            if (len < BUFLEN)
                break;
        }
        /* close connection */
        tcp_cls_cep(cepid, CON_TMOUT);
    }
}


/*****************************************************************************
* Callback Function to Accept NTttcp Command
*
******************************************************************************/

ER ntcp_callback(ID cepid, FN fncd, VP parblk)
{
    if (*(ER *)parblk == E_OK)
        ntcp_mode = TRUE;
    else
        ntcp_mode = FALSE;
    wup_tsk(ntcp_tskid);
    return E_OK;
}

/*****************************************************************************
* TTCP Receiver Loop
*
******************************************************************************/

void ttcp_r_loop(UW *ipaddr)
{
    T_TCP_CREP crep = { 0, { IPV4_ADDRANY, TCP_PORT_TTCP } };
    T_TCP_CCEP ccep = { 0, t1win, 1, rxwin, RXWINSZ, NULL };
    T_TCP_CREP cren = { 0, { IPV4_ADDRANY, TCP_PORT_NTCP } };
    T_TCP_CCEP ccen = { 0, ntwin[2], 1, ntwin[3], 1, (FP)ntcp_callback };
    T_IPV4EP dstaddr, dstaddr1;
    ID repid, cepid;
    int len;
    ER ercd;
    UB cmd[1];

    /* create TCP reception point */
    repid = tcp_vcre_rep(&crep);
    ntcp_repid = (UH)tcp_vcre_rep(&cren);

    /* create TCP communication end point */
    cepid = tcp_vcre_cep(&ccep);
    ntcp_cepid = (UH)tcp_vcre_cep(&ccen);

    for (;;) {
        /* connection request for command port */
        ntcp_tskid = (UH)vget_tid();
        ercd = tcp_acp_cep(ntcp_cepid, ntcp_repid, &dstaddr1, TMO_NBLK);
        if (ercd == E_OK)
            ntcp_mode = TRUE;

        /* wait for connection request */
        while (tcp_acp_cep(cepid, repid, &dstaddr, TMO_FEVR) != E_OK)
            ;
        *ipaddr = dstaddr.ipaddr;   /* save host IP address */

        /* wait for command port connection */
        if (ercd == E_WBLK) {
            if (tslp_tsk(ACP_TMOUT) != E_OK || !ntcp_mode) {
                ntcp_mode = FALSE;
                tcp_can_cep(ntcp_cepid, TFN_TCP_ALL);
                tcp_cls_cep(ntcp_cepid, TMO_POL);
                vcan_wup();
            }
        }
        if (ntcp_mode) {
            /* send command */
            cmd[0] = 0x58;
            if (tcp_snd_dat(ntcp_cepid, cmd, 1, DAT_TMOUT) > 0) {
                /* receive command */
                for (;;) {
                    if (tcp_rcv_dat(ntcp_cepid, cmd, 1, DAT_TMOUT) <= 0)
                        break;
                }
            }
            /* close connection */
            tcp_cls_cep(ntcp_cepid, CON_TMOUT);
        }

        /* receive TCP data until client disconnects */
        for (;;) {
            len = tcp_recv(cepid, buffer, BUFLEN);
            if (len < BUFLEN)
                break;
        }
        /* close connection */
        tcp_cls_cep(cepid, CON_TMOUT);
    }
}

/* end */
