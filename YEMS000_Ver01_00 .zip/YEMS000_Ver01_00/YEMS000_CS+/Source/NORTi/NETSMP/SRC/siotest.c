/******************************************************************************
* Serial Test Program                                                         *
*                                                                             *
*  Copyright (c) 2011-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-08-26 Created                                                       MI *
* 2012-03-30 Added support for NORTi Oceans                                HE *
* 2013-07-18 Changed default baud rate 57600->38400 as with other samples  FY *
* 2015-03-03 Added TSIO_RTSON to argument of ctl_sio()                     MI *
******************************************************************************/

#include "kernel.h"
#ifdef NORTi_Oceans
#include "nocsio.h"
#include "noccfg.h"
#else
#include "nosio.h"
#include "nocfg4.h"
#endif

/* Serial Port Parameters (baud rate, data bits, etc.) */

#ifndef PARAM
#define PARAM   "38400 B8 PN S1"    /* 8 data bits, no parity, 1 stop bit */
#endif

/* Number of Channels */

#ifndef CHS
#define CHS     1
#endif

/* Object Creation Information */

TASK EchoTask(INT);
const T_CTSK cEchoTask = { TA_HLNG, NULL, (FP)EchoTask, 1, 256, NULL };

/*****************************************************************************
* Echo Back Task
*
******************************************************************************/

TASK EchoTask(INT ch)
{
    ER ercd;
    UB c;

    /* initialize serial communication */
    ini_sio(ch, PARAM);
    ctl_sio(ch, TSIO_RXE | TSIO_TXE | TSIO_RTSON);

    /* send back received data */
    for (;;) {
        ercd = get_sio(ch, &c, TMO_FEVR);
        if (ercd == E_OK) {
            put_sio(ch, c, TMO_FEVR);
            if (c == '\r')
                put_sio(ch, '\n', TMO_FEVR);
        }
    }
}

/*****************************************************************************
* Main
*
******************************************************************************/

int main(void)
{
    int ch;

    /* initialize system */
    sysini();

    /* create and start all tasks */
    for (ch = 0; ch < CHS; ch++) {
        cre_tsk(ch + 1, &cEchoTask);
        sta_tsk(ch + 1, ch);
    }

    /* start system */
    intsta();                       /* start interval timer interrupt */
    return syssta();                /* enter into multitasking */
}

/* end */
