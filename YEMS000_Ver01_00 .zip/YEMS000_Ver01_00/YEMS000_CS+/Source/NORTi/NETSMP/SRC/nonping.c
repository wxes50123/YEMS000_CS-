/******************************************************************************
* NORTi Network Ping Command Sample                                           *
*                                                                             *
*  Copyright (c) 1999-2013, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-21                                                                  *
* 1999-04-03 �\������� IP �A�h���X�Ⴂ���C��                                 *
* 2002-02-08 Changed literal string type(B->char) for CC32R                OK *
*            written 'B str[] = "?";' then it is error in CC32R               *
* 2004-04-27 Added channel selection                                       PK *
* 2004-07-17 PING6 and PING combined                                       PK *
* 2004-10-25 ping6_proc modified to cancel ping request                    PK *
* 2005-04-20 Extra typecast removed                                        PK *
* 2005-04-20 ping_proc and ping6_proc modified for multi-channel stack     PK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2007-03-13 Modified for return val of callback (no NULL)                 OK *
* 2008-12-23 Modified ping6_proc                                           IS *
* 2008-12-23 indent is corrected                                           IS *
* 2012-07-05 Modified to get NIF with static route to remote if it is NULL FY *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2012-11-23 Fixed problem that interprets IPv6 address                       *
*                                 whose double figures is 'c' as c option  FY *
* 2013-01-24 Changed ipaddr_to_ascii() to ip4addr_to_ascii()               FY *
* 2013-06-18 Reduced size of 'buf' from 180 to 90 to reduce stack usage    FY *
* 2014-10-20 Added arp_del_entry() when icmp_snd_dat() returned E_TMOUT    FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#include "nonteln.h"

#define MAX_PING_SIZE   128

extern SYSTIME SNEAR cdecl SYSCK;

/* Message String */

const char msg_icmp_err[]   = "ICMP Internal Error.\r\n";
const char msg_ping_tmout[] = "Error: No answer\r\n";
const char msg_ping_abort[] = "\r\nCommand Aborted: ping\r\n";
const char msg_ping_addr[]  = "Invalid IP address.\r\n";
const char msg_ping_help[]  = "Usage: ping host [-i ch] [-t timeout] [-c count]\r\n"
                            "host       Host IP address\r\n"
                            "timeout    Timeout in msec to wait for each reply\r\n"
                            "count      Number of echo requests to send\r\n"
                            "ch         Interface to be used\r\n";

const char msg_ping6_help[]  = "Usage: ping6 host [-i ch] [-t timeout] [-c count]\r\n"
                            "host       Host IPv6 address\r\n"
                            "timeout    Timeout in msec to wait for each reply\r\n"
                            "count      Number of echo requests to send\r\n"
                            "ch         Interface to be used\r\n";

/* Loacal Variable */

static UH ping_ctrl_c_tid;
static B ping_ctrl_c_flg;

/* Ping Control Block */

typedef struct t_ping_cb {
    T_ICMP_CB *next;        /* Pointer to Next Control Block (*1) */
    FP callback;            /* ICMP Callback Routine (*1) */
    UH id;                  /* ICMP Identifier (Using Task ID) */
    UH seq;                 /* ICMP Sequence Number */
    UH len;                 /* ICMP Message Length */
    B ng;                   /* Data NG */
    B rsv;                  /* Reserved */
    UW ipa;                 /* Host IP Address */
    UW rtt;                 /* Round Trip Time [ms] */
    B data[MAX_PING_SIZE];  /* Data of ICMP Message */
} T_PING_CB;

/* (*1) 'next' and 'callback' members are same as T_ICMP_CB */

#ifdef DUAL_STK
typedef struct t_ping6_cb
{
    T_ICMP6_CB *next;       /* Pointer to Next Control Block (*1) */
    FP callback;            /* ICMP Callback Routine (*1) */
    UH id;                  /* ICMP Identifier (Using Task ID) */
    UH seq;                 /* ICMP Sequence Number */
    UH len;                 /* ICMP Message Length */
    B ng;                   /* Data NG */
    B rsv;                  /* Reserved */
    UW ipa[4];              /* Host IP Address */
    UW rtt;                 /* Round Trip Time [ms] */
    B data[MAX_PING_SIZE];  /* Data of ICMP Message */
} T_PING6_CB;

#endif

/************************************************/
/* Print Result Message of Ping                 */
/************************************************/

void print_ping_result(INT len, UW ipaddr, UH seq, UW rtt, BOOL ng)
{
    char buf[80];
    char *s = buf;
    INT n;

    /* ddd bytes from ddd.ddd.ddd.ddd */

    ito_u(s, (UH)len, 3); s += 3;
    memcpy(s, " bytes from ", 12); s += 12;
    s += ip4addr_to_ascii(s, ipaddr);

    /* : icmp_seq = ddd, time = ddddd ms */

    memcpy(s, ": icmp_seq = ", 13); s += 13;
    n = itoulen(seq);
    itou(s, seq, n); s += n;

    memcpy(s, ", time = ", 9); s += 9;
    n = ltoulen(rtt);
    ltou(s, rtt, n); s += n;
    memcpy(s, " ms", 3 + 1); s += 3;

    if (ng)
        memcpy(s, ", data NG", 9 + 1);

    puts(buf);
}

/************************************************/
/* ICMP Callback Routine for Ping               */
/************************************************/

VP ping_callback(T_ICMP_CB *cb, T_IP *pkt, T_ICMP_MSG *icmp, INT len)
{
    T_PING_CB *ping = (T_PING_CB *)cb;

    if ((icmp->type != TYPE_ECHO_REP)
     || (icmp->id != ping->id))
        return pkt;

    ping->rtt = (SYSCK.ltime - *(UW *)icmp->data) * MSEC;
    ping->ng = FALSE;
    if ((ping->len != (UH)len)
     || (memcmp(ping->data + 4, icmp->data + 4, len - 8 - 4) != 0))
        ping->ng = TRUE;
    ping->seq = icmp->seq;
    ping->ipa = ntohl(pkt->ip.sa);
    if (ping->id != 0)
        wup_tsk(ping->id);
    return pkt;
}

/************************************************/
/* Ping Process                                 */
/************************************************/

ER ping_proc(T_PING_CB *ping, UW srcaddr, UW ipaddr, TMO tmout, INT count, const char *str)
{
    TMO pause = 1000/MSEC;
    T_ICMP_HEADER icmp;
    INT len;
    ER ercd;
    UH seq;

    /* Define ICMP Callback Routine */

    ercd = icmp_def_cbk((T_ICMP_CB *)ping, ping_callback);
    if (ercd != E_OK) {
        print(msg_icmp_err);
        return ercd;
    }

    /* Store Echo String to Compare */

    len = 4 + strlen(str);
    if (len > MAX_PING_SIZE)
        len = MAX_PING_SIZE;
    memcpy(ping->data + 4, str, len - 4);
    ping->len = len + 8;

    /* Idenfier and Init. Sequence Number */

    vcan_wup();
    ping->id = (UH)vget_tid();
    seq = 1;

    /* Send and Receive ICMP Messages */

    while (count-- > 0) {

        /* Make Header of ICMP Echo Message */

        icmp.type = TYPE_ECHO_REQ;
        icmp.code = 0;
        icmp.id = ping->id;
        icmp.seq = seq++;

        /* Send Echo Request */

        *(UW *)ping->data = SYSCK.ltime;
        ercd = icmp_snd_dat(srcaddr, ipaddr, &icmp, ping->data, len);
        if (ercd != E_OK) {
            print(msg_icmp_err);
            break;
        }

        /* Wait Echo Reply */

        ping_ctrl_c_tid = (UH)vget_tid();
        ercd = tslp_tsk(tmout);
        ping_ctrl_c_tid = 0;
        if (ping_ctrl_c_flg) {
            print(msg_ping_abort);
            break;
        }
        else if (ercd == E_TMOUT) {
            arp_del_entry(ipaddr);
            print(msg_ping_tmout);
            break;
        }
        else if (ercd != E_OK) {
            print(msg_icmp_err);
            break;
        }

        /* Print Result */

        else {
            do {
                print_ping_result(ping->len, ping->ipa, ping->seq, ping->rtt, ping->ng);
            } while (tslp_tsk(0) == E_OK);
        }
        ping_ctrl_c_tid = (UH)vget_tid();
        dly_tsk(pause);
        ping_ctrl_c_tid = 0;
        if (ping_ctrl_c_flg) {
            print(msg_ping_abort);
            break;
        }
    }

    /* Remove ICMP Callback Routine */

    icmp_can_snd(&icmp);
    icmp_def_cbk((T_ICMP_CB *)ping, NULL);
    return ercd;
}

/************************************************/
/* Ping CTRL-C Signal Handler                   */
/************************************************/

static void ping_ctrl_c(int sig)
{
    ID id;

    if (sig == SIGINT) {
        ping_ctrl_c_flg = TRUE;
        if ((id = (ID)ping_ctrl_c_tid) != 0)
            rel_wai(id);
    }
}

/************************************************/
/* Ping Command Sample                          */
/************************************************/

int ping_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    TMO tmout = 10000/MSEC;
    INT count = 3, i;
    T_PING_CB ping;
    UW ipaddr = 0, srcaddr;
    B c;

    /* Print Help */

    if (argc < 2) {
        print(msg_ping_help);
        return 0;
    }

    /* Arguments Convert */
    for (i = 1; i < argc; i++) {
        c = argv[i][0];
        if (argv[i][0] == '-') {
            if (argv[i][1] == 'c') {
                count = atoi(argv[++i]);
            }
            else if (argv[i][1] == 't') {
                tmout = atol(argv[++i]) / MSEC;
            }
            else if (argv[i][1] == 'i') {
                nif = getnif_from_name(argv[++i]);
                if (nif == NULL) {
                    print(" Invalid Interface specified. \r\n");
                    return 0;
                }
            }
        } else if (c >= '0' && c <= '9') {
            ipaddr = ascii_to_ipaddr(argv[i]);
        }
    }

    if (ipaddr == 0L) {
        print(msg_ping_addr);
        return 0;
    }

    if (nif == NULL) {
        nif = getnif_dstaddr(ipaddr);
        if (nif == NULL) {      /* 10MAY2005 - Added */
            print(" Interface does not exist \r\n");
            return  E_OBJ;
        }
    }

    srcaddr = byte4_to_long(nif->ipaddr);

    /* Define CTRL-C Signal Handler */

    ping_ctrl_c_tid = 0;
    ping_ctrl_c_flg = 0;
    signal(SIGINT, ping_ctrl_c);

    /* Ping Process */

    ping_proc(&ping, srcaddr, ipaddr, tmout, count, "0123456789ABCDEFGHIJ");

    /* Remove CTRL-C Signal Handler */

    signal(SIGINT, SIG_DFL);

    return 0;
}

#ifdef DUAL_STK
/*******************************************/
/* Print Result Message of Ping6           */
/*******************************************/
void print_ping6_result(INT len, UW ipaddr[], UH seq, UW rtt, BOOL ng)
{
    char buf[90];
    char *s = buf;
    INT n;

    /* ddd bytes from ddd.ddd.ddd.ddd */

    ito_u(s, (UH)len, 3); s += 3;
    memcpy(s, " bytes from ", 12); s += 12;

    /* Modified by GS */
    s += ip6addr_to_ascii(s, ipaddr);

    /* : icmp_seq = ddd, time = ddddd ms */

    memcpy(s, " icmp_seq=", 10); s += 10;
    n = itoulen(seq);
    itou(s, seq, n); s += n;

    memcpy(s, ", time=", 7); s += 7;
    n = ltoulen(rtt);
    ltou(s, rtt, n); s += n;
    memcpy(s, " ms", 3 + 1); s += 3;

    if (ng)
        memcpy(s, ", data NG", 9 + 1);

    puts(buf);
}

/*******************************************/
/* ICMPv6 Callback Routine for Ping6       */
/*******************************************/
VP ping6_callback(T_ICMP6_CB *cb, T_IP6 *pkt, T_ICMP6_MSG *icmp6, INT len)
{
    T_PING6_CB *ping = (T_PING6_CB *)cb;
    UH icmp_id,icmp_seq;
    UB *icmp_data;
    UW srcaddr[4];

    if(icmp6->icmpv6.type != ICMPV6_ECHO_REPLY)
      return pkt;
    icmp_id = icmp6->icmpv6.echo_id;
    icmp_data = (UB *)((&icmp6->icmpv6.info.echo) + 1);
    icmp_seq = icmp6->icmpv6.echo_seqno;
    memcpy( ping->ipa, ntohl6(pkt->ip6.sa, srcaddr), IP6_ADDR_SZ);

    if (icmp_id != ping->id)
        return pkt;

    ping->rtt = (SYSCK.ltime - *(UW *)icmp6->data) * MSEC;
    ping->ng = FALSE;
    if ((ping->len != (UH)len)
     || (memcmp(ping->data + 4, icmp_data + 4, len - 8 - 4) != 0))
        ping->ng = TRUE;
    ping->seq = icmp_seq;
    if (ping->id != 0)
        wup_tsk(ping->id);
    return pkt;
}

/*******************************************/
/* Ping6 Process                           */
/*******************************************/

ER ping6_proc(T_PING6_CB *ping, UW *srcaddr, UW *ipaddr, TMO tmout, INT count, const char *str)
{
    T_NIF *nif = NULL;
    TMO pause = 1000/MSEC;
    T_ICMPV6_HEADER icmp6;
    INT len;
    ER ercd;
    UH seq;

    if (srcaddr != NULL) {
        if ((nif = getnif_ip6addr(srcaddr)) == NULL)
            nif = getnif_default();
    } else {
        nif = getnif_dst6addr(ipaddr);
    }

    if (nif == NULL)
        return E_PAR;

    /* Define ICMP Callback Routine */

    ercd = icmpv6_def_cbk((T_ICMP6_CB *)ping, ping6_callback);
    if (ercd != E_OK) {
        print(msg_icmp_err);
        return ercd;
    }

    /* Store Echo String to Compare */

    len = 4 + strlen(str);
    if (len > MAX_PING_SIZE)
        len = MAX_PING_SIZE;
    memcpy(ping->data + 4, str, len - 4);
    ping->len = len + 8;

    /* Idenfier and Init. Sequence Number */

    vcan_wup();
    ping->id = (UH)vget_tid();
    seq = 1;

    /* Send and Receive ICMP Messages */

    while (count-- > 0) {

        /* Make Header of ICMP Echo Message */

        icmp6.type = ICMPV6_ECHO_REQUEST;
        icmp6.code = 0;
        icmp6.echo_id = ping->id;
        icmp6.echo_seqno = seq++;

        /* Send Echo Request */

        *(UW *)ping->data = SYSCK.ltime;
        ercd = icmpv6_snd_dat(srcaddr, ipaddr, &icmp6, ping->data, len);
        if (ercd != E_OK) {
            print(msg_icmp_err);
            break;
        }

        /* Wait Echo Reply */

        ping_ctrl_c_tid = (UH)vget_tid();
        ercd = tslp_tsk(tmout);
        ping_ctrl_c_tid = 0;
        if (ping_ctrl_c_flg) {
            print(msg_ping_abort);
            break;
        }
        else if (ercd == E_TMOUT) {
            print(msg_ping_tmout);
            break;
        }
        else if (ercd != E_OK) {
            print(msg_icmp_err);
            break;
        }

        /* Print Result */

        else {
            do {
                print_ping6_result(ping->len, ping->ipa, ping->seq, ping->rtt, ping->ng);
            } while (tslp_tsk(0) == E_OK);
        }
        ping_ctrl_c_tid = (UH)vget_tid();
        dly_tsk(pause);
        ping_ctrl_c_tid = 0;
        if (ping_ctrl_c_flg) {
            print(msg_ping_abort);
            break;
        }
    }

    /* Remove ICMP Callback Routine */
    icmpv6_can_snd(&icmp6, nif);
    icmpv6_def_cbk((T_ICMP6_CB *)ping, NULL);
    return ercd;
}

/************************************************/
/* Ping6 Command Sample                         */
/************************************************/

int ping6_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    TMO tmout = 10000/MSEC;
    INT count = 5, i;
    T_PING6_CB ping;
    UW ipaddr[4], *srcaddr;

    /* Print Help */

    if (argc < 2) {
        print(msg_ping6_help);
        return 0;
    }

    ipaddr[0] = ipaddr[1] = ipaddr[2] = ipaddr[3] = 0;

    /* Arguments Convert */
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            if (argv[i][1] == 'c') {
                count = atoi(argv[++i]);
            }
            else if (argv[i][1] == 't') {
                tmout = atol(argv[++i]) / MSEC;
            }
            else if (argv[i][1] == 'i') {
                nif = getnif_from_name(argv[++i]);
                if (nif == NULL) {
                    print(" Invalid Interface specified. \r\n");
                    return 0;
                }
            }
        }
        else
            ascii_to_ip6addr(argv[i], ipaddr);
    }

    if (is_ip6_addr_any(ipaddr)) {
        print(msg_ping_addr);
        return 0;
    }

    if (nif == NULL) {
        nif = getnif_dst6addr(ipaddr);
        if (nif == NULL) {      /* 10MAY2005 - Added */
            print(" Interface does not exist \r\n");
            return  E_OBJ;
        }
    }

    srcaddr = set_src_addr(nif, ipaddr);

    /* Define CTRL-C Signal Handler */

    ping_ctrl_c_tid = 0;
    ping_ctrl_c_flg = 0;
    signal(SIGINT, ping_ctrl_c);

    /* Ping Process */

    ping6_proc(&ping, srcaddr, ipaddr, tmout, count, "0123456789ABCDEFGHIJ");

    /* Remove CTRL-C Signal Handler */

    signal(SIGINT, SIG_DFL);

    return 0;
}

#endif
/* end */
