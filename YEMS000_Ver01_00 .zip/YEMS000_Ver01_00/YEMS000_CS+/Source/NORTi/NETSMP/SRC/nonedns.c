/******************************************************************************
* DNS Resolver Sample                                                         *
*                                                                             *
*  Copyright (c) 2000-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-01-10 Created                                                          *
* 2000-03-04 Fixed bug                                                        *
* 2000-09-27 Added support for little endian                                  *
* 2002-10-15 Added support for uncompressed domain name                       *
* 2003-04-19 Added retry of DNS request                                    MI *
* 2004-07-14 Added support for IPv6 on dual stack                          PK *
* 2005-04-20 Added DNS reverse lookup for IPv4                             PK *
* 2005-04-20 Added dns_resolver_byname() altering dns_resolver() to call it,  *
*             and skipped DNS process if IP address passed as domain name  PK *
* 2005-04-27 Merged functions for IPv4 and ones for IPv6                   PK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2006-03-06 Updated calculation of Answer RR Count                        MK *
* 2007-07-12 Added non-blocking call operation when NBLK macro defined     GS *
* 2008-11-21 Fixed dns_resolver_byname() not to release                       *
*               packet buffer with rel_mpf() until udp_del_cep() finishes  FY *
* 2011-01-25 Replaced get_mpf(ID_ETH_MPF, ...) with pget_mpf() in             *
*             dns_resolver_byname() not to block Ethernet frame buffering  GS *
* 2011-06-30 Added (FP) to T_UDP_CCEP's callback to avoid compiler warning HE *
* 2012-02-10 Added const to the name parameter of dns_resolver()           FY *
* 2012-04-11 Modified dns_resolver() to skip DNS when name is IP address   FY *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2013-06-28 Added T_UDP_CCEP dns_cep definition for IPv6 on dual stack    FY *
* 2021-11-11 Protected stack smashing by adding RDLENGTH check and so on   FY *
* 2021-11-11 Added check of udp_rcv_dat() == 0 (checksum error) to retry   FY *
* 2021-11-11 Added missing udp_del_cep() when udp_set_opt() returns error  FY *
* 2022-09-22 Removed NBLK macro as dedicated for UDP reception in callback FY *
* 2022-09-22 Added static to T_DNS *txdns/rxdns, minimized type of            *
*                    dns_len (int -> H), and removed unused dns_ipaddr[4]  FY *
* 2022-09-22 Modified dns_resolver_byname() to use nif->dns_ipaddr            *
*                                   when specified dns_ip is IPV4_ADDRANY  FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"
#include "nonitod.h"

/* DNS Message */

typedef struct t_dns {
    UH id;          /* Identifier */
    UH flag;        /* Flags */
    UH qdcnt;       /* Query Count */
    UH ancnt;       /* Answer Count */
    UH nscnt;       /* Authority Count */
    UH arcnt;       /* Additional information Count */
    UB data[512];   /* Query/Answer/Authority/Additional Sections */
} T_DNS;

/* Local Variables */

static T_DNS *txdns;
static T_DNS *rxdns;
static UH dns_tskid;
static H dns_len;

/* End Point Creation Information */

ER dns_cbk(ID, FN, VP);
#ifdef DUAL_STK
const T_UDP_CCEP dns_cep = { 0, { IPV4_ADDRANY, UDP_PORTANY, IPV6_ADDRANY, IPV4_ADDR }, (FP)dns_cbk };
#else
const T_UDP_CCEP dns_cep = { 0, { IPV4_ADDRANY, UDP_PORTANY }, (FP)dns_cbk };
#endif

/************************************************/
/* UDP Callback Routine for DNS                 */
/************************************************/

ER dns_cbk(ID cepid, FN fncd, VP parblk)
{
    T_IPEP dstaddr;

    switch (fncd) {
    case TFN_UDP_RCV_DAT:
        break;
    case TEV_UDP_RCV_DAT:
        if (dns_tskid) {
            dns_len = (H)udp_rcv_dat(cepid, &dstaddr, rxdns, sizeof (T_DNS), TMO_POL);
            wup_tsk(dns_tskid);
        }
        break;
    }
    return E_OK;
}

/************************************************/
/* Get Remote Host IP Address by Name           */
/************************************************/

ER dns_resolver_byname(ID cepid, UW dns_ip, const char *name, T_IPEP *host, const char *ch_name)
{
    static UH id = 0;
    T_IPEP dstaddr;
    T_NIF *nif;
    TMO tmout;
    ER ercd;
    int i, n1, n2;
    int len;
    UB *p1, *p2, *p3, c;
    int type;

    if ((host->ipaddr = ascii_to_ipaddr(name)) != 0)
        return E_OK; /* IP address specified instead of domain name */

  #ifdef DUAL_STK
    if (host->type == IPV6_ADDR)
        type = 0x1C;
    else if (host->type == IPV4_ADDR)
        type = 1;
    else
        return E_OBJ;
  #else
    type = 1;
  #endif

    /* get memory block for DNS message */
    ercd = pget_mpf(ID_ETH_MPF, &txdns);
    if (ercd == E_TMOUT)
        return E_NOMEM;
    if (ercd != E_OK)
        return ercd;

    nif = getnif_from_name(ch_name);
    if (nif == NULL)
        nif = getnif_default();

    /* create communication end point for DNS */
    if (cepid == 0)
        ercd = cepid = udp_vcre_cep(&dns_cep);
    else
        ercd = udp_cre_cep(cepid, &dns_cep);
    if (ercd >= E_OK) {
        ercd = udp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
        if (ercd != E_OK)
            udp_del_cep(cepid);
    }
    if (ercd < 0) {
        rel_mpf(ID_ETH_MPF, txdns);
        return ercd;
    }

    /* setup DNS message header */
    memset(txdns, 0, sizeof (T_DNS));
    txdns->id = htons(id++);
    txdns->flag = htons(0x0100);
    txdns->qdcnt = htons(1);
    txdns->ancnt = 0;
    txdns->nscnt = 0;
    txdns->arcnt = 0;
    rxdns = txdns + 1;

    /* set QNAME */
    p1 = txdns->data;
    p2 = (UB *)name;
    p3 = txdns->data + 1;
    for (n1 = n2 = 0;;) {
        c = *p2++;
        if (c == '.' || c == 0) {
            *p1 = (UB)n2;
            n1 += n2 + 1;
            if (c == 0)
                break;
            p1 = p3++;
            n2 = 0;
        } else {
            *p3++ = c;
            n2++;
        }
    }
    *p3++ = 0;
    *p3++ = 0;
    *p3++ = (UB)type; /* QTYPE */
    *p3++ = 0;
    *p3++ = 1; /* QCLASS */

    /* communicate with DNS server */
    dstaddr.ipaddr = (dns_ip == IPV4_ADDRANY) ? byte4_to_long(nif->dns_ipaddr) : dns_ip;
    dstaddr.portno = UDP_PORT_NAMESERVER;
  #ifdef DUAL_STK
    dstaddr.type = IPV4_ADDR;
  #endif
    p2 = (UB *)txdns;
    len = (INT)(p3 - p2);

    for (i = 10, tmout = 20/MSEC;;) {
        dns_tskid = (UH)vget_tid();
        /* send DNS Query */
        ercd = udp_snd_dat(cepid, &dstaddr, txdns, len, 3000/MSEC);
        if (ercd <= 0)
            goto END;

        ercd = tslp_tsk(5000/MSEC);
        if (ercd == E_OK)
            ercd = dns_len;
        dns_tskid = FALSE;

        if (ercd > 0)
            break;
        if (ercd == 0) /* UDP checksum error */
            ercd = E_TMOUT;
        if (ercd != E_TMOUT)
            goto END;
        if (--i == 0)
            goto END;
        txdns->id = htons(id++);
        tmout <<= 1;
    }

    /* check too short DNS message */
    len = ercd;
    ercd = E_OK;
    if ((len -= 12 + n1 + 1 + 4) < 0) /* header + NAME + NULL + TYPE/CLASS */
        goto ERR;

    /* check unexpected flags */
    i = ntohs(rxdns->flag);            /* QR == 0 */
    if (!(i & 0x8000) || (i & 0x7A7F)) /* OPCode, TC, Z, RCode != 0 */
        goto ERR;

    /* analyze Answer Section */
    p1 = rxdns->data + n1 + 1 + 4; /* p1 = NAME */
    n2 = ntohs(rxdns->ancnt);      /* n2 = Answer RR Count */

    for (i = 0; i < n2; i++) {
        while (--len >= 10 && *p1 != 0) {
            if (*p1 >= 0xC0) {
                p1++; /* p1 = TYPE */
                len--;
                break;
            }
            len -= *p1;
            p1 += 1 + *p1;
        }
        if (len < 10)
            goto ERR;
        p1++;
        n1 = (*(p1 + 8) << 8) | *(p1 + 9);
        if (len < 10 + n1)
            goto ERR;
        if (((*p1 << 8) | *(p1 + 1)) == type) {
            p1 += 10; /* + 1 p1 = RDATA */
            len -= 10;
          #ifdef DUAL_STK
            if (type == 0x1C) {
                if (n1 == IP6_ADDR_SZ) {
                    memcpy(host->ip6addr, p1, n1);
                    ntohl6(host->ip6addr, host->ip6addr);
                    goto END;
                }
            } else if (type == 1) {
          #endif
                if (n1 == 4) {
                    memcpy(&host->ipaddr, p1, n1);
                    host->ipaddr = ntohl(host->ipaddr);
                    goto END;
                }
          #ifdef DUAL_STK
            }
          #endif
            p1 += n1;
            len -= n1;
            continue;
        }
        p1 += 10 + n1; /* p1 = RDLENGTH */
        len -= 10 + n1;
    }
ERR:
    ercd = E_OBJ;
END:
    udp_del_cep(cepid);
    rel_mpf(ID_ETH_MPF, txdns);
    return ercd;
}

ER dns_resolver(ID cepid, UW dns_ip, const char *name, T_IPEP *host)
{
    return dns_resolver_byname(cepid, dns_ip, name, host, getnif_default()->name);
}

/* end */
