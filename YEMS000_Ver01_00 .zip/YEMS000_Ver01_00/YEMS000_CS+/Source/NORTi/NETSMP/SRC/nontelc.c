/******************************************************************************
* Telnet Client Sample for NORTi                                              *
*                                                                             *
*  Copyright (c) 1999-2012, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-06-20 Created                                                          *
* 1999-09-23 Supported auto ID assignment using tcp_vcre_cep/tcp_vcre_rep     *
* 2001-01-22 Changed tcp_rcv_dat()'s 3000 msec timeout into 100 msec          *
* 2003-05-14 Added reply of DON'T for all WILL options (except for ECHO)   PK *
* 2004-04-27 Added channel selection                                       PK *
* 2004-07-14 Added IPv6 support                                            PK *
* 2004-07-19 Added channel selection for IPv6 client                       PK *
* 2005-04-20 Removed extra typecasting                                     PK *
* 2005-04-20 Modified channel selection                                    PK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2008-11-21 Added repeating of tcp_snd_dat till all data is sent          FY *
* 2009-08-03 Corrected duplicate LF transmission after CR+LF               FY *
* 2009-08-03 Corresponded to divided reception of Telnet command/options   FY *
* 2009-08-17 Changed putch() to print() not to garble Kanji                FY *
* 2012-03-27 Renewed only the file header comment                          MI *
* 2012-07-05 Fixed reference to uninitialized data in telnet6_command()    FY *
* 2012-07-05 Modified to get NIF with static route to remote if it is NULL FY *
* 2012-11-23 Deleted unused external definition                            FY *
* 2013-06-28 Added setting of type member of T_IPEP                           *
*                                               in the case of dual stack  FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#include "nonteln.h"

/* Window Buffer */

#define WINDOW_SIZE 100
static UH telnet_swin[WINDOW_SIZE/2];  /* Sending Window Buffer */
static UH telnet_rwin[WINDOW_SIZE/2];  /* Receiving Window Buffer */

/* Creation Information */

const T_TCP_CCEP telnet_ccep = { 0, telnet_swin, sizeof telnet_swin, telnet_rwin, sizeof telnet_rwin, (FP)NULL };

/* Local Data */

#define TELNET_BUFSZ      1024
static UH telnet_buf[TELNET_BUFSZ/2];   /* UH and /2 for Word Aglinement */

#ifdef DUAL_STK
static const char msg_telc6_addr[]  = "Invalid IP address.\r\n";
#endif

/* Constant */

#define TELNET_TMOUT   (5000/MSEC)

/************************************************/
/* Input IP Address                             */
/************************************************/

UW input_ipaddr(char *prompt)
{
    static UB d[4];
    char buf[16];
    char *p;
    int i, len;
    UW ipaddr;

    for (;;) {
        for (;;) {
            p = buf;
            for (i = 0; i < 4; i++) {
                itou(p, d[i], itoulen(d[i])); p += strlen(p);
                if (i != 3)
                    strcat(p++, ".");
            }
            print(prompt);
            print(buf);
            len = strlen(buf);
            while (len-- > 0)
                print("\b");
            input(buf, sizeof buf);
            puts("");
            if (buf[0] == '\0')
                break;
            p = buf;
            for (i = 0; i < 4; i++) {
                d[i] = atoi(p);
                if (i != 3) {
                    p = strchr(p, '.');
                    if (p == NULL)
                        break;
                    p++;
                }
            }
            if (i == 4)
                break;
        }
        ipaddr = byte4_to_long(d);
        if (ipaddr != 0L)
            break;
    }
    return ipaddr;
}

/************************************************/
/* Send all TCP Packet                          */
/************************************************/

ER tcp_snd_dat_all(ID cepid, const VP data, INT len, TMO tmout)
{
    ER ercd;
    int i;

    i = 0;
    do
    {
        ercd = tcp_snd_dat(cepid, (B*)data + i, len - i, tmout);
        if (ercd < 0)
            return ercd;
        if (ercd == 0)
            return i;
        i += ercd;
    } while (i < len);

    return i;
}

/************************************************/
/* TELNET Client Process                        */
/************************************************/

ER telnet_client(ID cepid, UW ipaddr, T_NIF *nif)
{
    char *buf = (char*)telnet_buf;
    int bufsz = sizeof telnet_buf;
    INT len, len2, i, s, ci, c;
    UB cbuf[3];
    ER ercd;
    T_IPEP myaddr;
    T_IPEP dstaddr;

    if(cepid == 0) {
        ercd = cepid = tcp_vcre_cep(&telnet_ccep);
        if(cepid <= 0){
            puts("TCP Communication End Point can't be created!");
            return ercd;
        }
    }
    else {
        ercd = tcp_cre_cep(cepid, &telnet_ccep);
        if (ercd != E_OK) {
            puts("TCP Communication End Point can't be created!");
            return ercd;
        }
    }

    tcp_set_opt(cepid, IP_IF_NAME, nif->name, 0);

    myaddr.ipaddr = IPV4_ADDRANY;
    myaddr.portno = TCP_PORTANY;
    dstaddr.ipaddr = ipaddr;
    dstaddr.portno = TCP_PORT_TELNET;
  #ifdef DUAL_STK
    myaddr.type = IPV4_ADDR;
    dstaddr.type = IPV4_ADDR;
  #endif

    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, TELNET_TMOUT);
    if (ercd != E_OK) {
        puts("TCP connection error!");
        goto L1;
    }
    puts("connected");

    tcp_snd_dat_all(cepid, "\xff""\xfc""\x01", 3, TELNET_TMOUT); /* <IAC><WONT><Echo> */

    ci = 0;
    for (;;) {
        if (kbhit()) {
            c = getch();
            if (c == 0x03) { /* CTRL-C */
                print("\r\n");
                break;
            }
            if (c == '\r')
                len = tcp_snd_dat_all(cepid, "\r\n", 2, TELNET_TMOUT);
            else if (c == '\n')
                len = 1;
            else {
                buf[0] = (B)c;
                len = tcp_snd_dat_all(cepid, buf, 1, TELNET_TMOUT);
            }
            if (len <= 0)
                break;
        }

        len = tcp_rcv_dat(cepid, buf, bufsz-1, 100/MSEC);
        if (len == E_TMOUT)
            continue;
        if (len <= 0)
            break;

        s = 0;
        len2 = 1;
        for (i = 0; i < len;) {
            c = (UB)buf[i++];
            if (ci == 0) {
                if (c == 0xff) {
                    cbuf[ci++] = (UB)c;
                    if (s < i-1) {
                        buf[i-1] = '\0';
                        print(&buf[s]);
                    }
                    s = i;
                }
                continue;
            }
            s = i;
            cbuf[ci++] = (UB)c;
            if (ci == 2)
                continue;
            ci = 0;

            if (cbuf[1] == 0xfd) {
                cbuf[1] = 0xfc;             /* All <DO> -> <WONT> */
                len2 = tcp_snd_dat_all(cepid, cbuf, 3, TELNET_TMOUT);
                if (len2 <= 0)
                    break;
            }
            if (cbuf[1] == 0xfb && cbuf[2] != (B)0x01) {
                cbuf[1] = 0xfe;             /* All <WILL> -> <DONT> */
                len2 = tcp_snd_dat_all(cepid, cbuf, 3, TELNET_TMOUT);
                if (len2 <= 0)
                    break;
            }
        }
        if (len2 > 0 && s < len) {
            buf[len] = '\0';
            print(&buf[s]);
        }
    }

    ercd = tcp_cls_cep(cepid, TELNET_TMOUT);
    if (ercd != E_OK)
        puts("TCP closing error!");
L1:
    tcp_del_cep(cepid);
    return E_OK;
}

/************************************************/
/* TELNET Command                               */
/************************************************/

int telnet_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    UW ipaddr = 0L;
    int i;
    B c;

    /* Arguments Convert */

    for (i = 1; i < argc; i++) {
        c = argv[i][0];
        if (c >= '0' && c <= '9')
            ipaddr = ascii_to_ipaddr(argv[i]);
        else if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return 0;
            }
        }
    }

    if (ipaddr == 0L)
        ipaddr = input_ipaddr("Destination IP Address = ");

    if (ipaddr == 0L) {
        print(" Invalid destination address. \r\n");
        return 0;
    }

    if (nif == NULL)
        nif = getnif_dstaddr(ipaddr);

    /* Telnet Client Process */

    telnet_client(0, ipaddr, nif);

    return 0;
}

#ifdef DUAL_STK
ER telnet6_client(ID cepid, UW *ip6addr, T_NIF *nif)
{
    char *buf = (char *)telnet_buf;
    int bufsz = sizeof telnet_buf;
    INT len, len2, i, s, ci, c;
    UB cbuf[3];
    ER ercd;
    T_IPEP myaddr;
    T_IPEP dstaddr;

    if(cepid == 0) {
        ercd = cepid = tcp_vcre_cep(&telnet_ccep);
        if(cepid <= 0){
            puts("TCP Communication End Point can't be created!");
            return ercd;
        }
    }
    else {
        ercd = tcp_cre_cep(cepid, &telnet_ccep);
        if (ercd != E_OK) {
            puts("TCP Communication End Point can't be created!");
            return ercd;
        }
    }

    memset(&myaddr, 0, sizeof (T_IPEP));
    myaddr.portno = TCP_PORTANY;
    myaddr.type = IPV6_ADDR;

    memset(&dstaddr, 0, sizeof (T_IPEP));
    set_ip6_addr(dstaddr.ip6addr, ip6addr);
    dstaddr.portno = TCP_PORT_TELNET;
    dstaddr.type = IPV6_ADDR;

    tcp_set_opt(cepid, IP_IF_NAME, nif->name, 0);

    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, TELNET_TMOUT);
    if (ercd != E_OK) {
        puts("TCP connection error!");
        goto L1;
    }
    puts("connected");

    tcp_snd_dat_all(cepid, "\xff""\xfc""\x01", 3, TELNET_TMOUT); /* <IAC><WONT><Echo> */

    ci = 0;
    for (;;) {
        if (kbhit()) {
            c = getch();
            if (c == 0x03) { /* CTRL-C */
                print("\r\n");
                break;
            }
            if (c == '\r')
                len = tcp_snd_dat_all(cepid, "\r\n", 2, TELNET_TMOUT);
            else if (c == '\n')
                len = 1;
            else {
                buf[0] = (B)c;
                len = tcp_snd_dat_all(cepid, buf, 1, TELNET_TMOUT);
            }
            if (len <= 0)
                break;
        }

        len = tcp_rcv_dat(cepid, buf, bufsz-1, 100/MSEC);
        if (len == E_TMOUT)
            continue;
        if (len <= 0)
            break;

        s = 0;
        len2 = 1;
        for (i = 0; i < len;) {
            c = (UB)buf[i++];
            if (ci == 0) {
                if (c == 0xff) {
                    cbuf[ci++] = (UB)c;
                    if (s < i-1) {
                        buf[i-1] = '\0';
                        print(&buf[s]);
                    }
                    s = i;
                }
                continue;
            }
            s = i;
            cbuf[ci++] = (UB)c;
            if (ci == 2)
                continue;
            ci = 0;

            if (cbuf[1] == 0xfd) {
                cbuf[1] = 0xfc;             /* All <DO> -> <WONT> */
                len2 = tcp_snd_dat_all(cepid, cbuf, 3, TELNET_TMOUT);
                if (len2 <= 0)
                    break;
            }
            if (cbuf[1] == 0xfb && cbuf[2] != (B)0x01) {
                cbuf[1] = 0xfe;             /* All <WILL> -> <DONT> */
                len2 = tcp_snd_dat_all(cepid, cbuf, 3, TELNET_TMOUT);
                if (len2 <= 0)
                    break;
            }
        }
        if (len2 > 0 && s < len) {
            buf[len] = '\0';
            print(&buf[s]);
        }
    }

    ercd = tcp_cls_cep(cepid, TELNET_TMOUT);
    if (ercd != E_OK)
        puts("TCP closing error!");
L1:
    tcp_del_cep(cepid);
    return E_OK;
}

int telnet6_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    UW ipaddr[4];
    int i;

    /* Arguments Convert */

    memset(ipaddr, 0, IP6_ADDR_SZ);
    for (i = 1; i < argc; i++) {
        if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return 0;
            }
        }
        else
            ascii_to_ip6addr(argv[i], ipaddr);
    }

    if (is_ip6_addr_any(ipaddr)) {
        print(msg_telc6_addr);
        return 0;
    }

    if (nif == NULL)
        nif = getnif_dst6addr(ipaddr);

    /* Telnet Client Process */

    telnet6_client(0, ipaddr, nif);

    return 0;
}

#endif
/* end */
