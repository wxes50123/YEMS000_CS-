/******************************************************************************
* NORTi Network Echo Client Sample                                            *
*                                                                             *
*  Copyright (c) 1998-2012, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-16                                                                  *
* 1999-04-04                                                                  *
* 1999-09-23 CEP,REP ID auto assign added (Create tcp_vcre_cep,tcp_vcre_rep)  *
* 2000-04-23 Change tcp_con_cep timeout 5000->6000                            *
* 2003-01-15 udp_echo_sub()����tcpip_cretical���폜                        KA *
* 2004-07-15 Added support for IPv6                                        PK *
* 2005-04-20 techo_command, uecho_command added for Multichannel stack     PK *
* 2005-04-20 Extra typecasting removed                                     PK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2005-11-29 Added NBLK supported for udp_echo_sub                         MK *
* 2007-01-23 Corrected `B *` -> `char *`                                   OK *
* 2012-07-05 Fixed reference to uninitialized data in udp/tcp_echo6_client FY *
* 2012-07-05 Modified to get NIF with static route to remote if it is NULL FY *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2012-11-23 Added NBLK support for udp_echo6_sub()                        FY *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#include "nonteln.h"
#include "nonecho.h"

UW input_ipaddr(char *prompt);

/* Window Buffer */

#define WINDOW_SIZE 100
static UH echocli_swin[WINDOW_SIZE/2];  /* Sending Window Buffer */
static UH echocli_rwin[WINDOW_SIZE/2];  /* Receiving Window Buffer */

/* Creation Information */

ER udpecho_client_cbk(ID, FN, VP);
ER tcpecho_client_cbk(ID, FN, VP);
const T_TCP_CCEP c_tcpecho_client_cep = { 0, echocli_swin, sizeof echocli_swin, echocli_rwin, sizeof echocli_rwin, (FP)tcpecho_client_cbk };

/* Local Data */

#define ECHO_BUFSZ      1024
static UH echo_buf[ECHO_BUFSZ/2];   /* UH and /2 for Word Aglinement */
#ifdef DUAL_STK
static const char msg_echo6_addr[]  = "Invalid IP address.\r\n";
T_UDP_CCEP c_udpecho_client_cep = { 0, { IPV4_ADDRANY, UDP_PORTANY, IPV6_ADDRANY, IPV4_ADDR }, (FP)udpecho_client_cbk };
#else
T_UDP_CCEP c_udpecho_client_cep = { 0, { IPV4_ADDRANY, UDP_PORTANY }, (FP)udpecho_client_cbk };
#endif

#ifdef NBLK
static int tcpecho_len;
static int udpecho_len;
static UH tcp_client_rtskid;
static UH tcp_client_tskid;
static UH udp_client_tskid;
#endif

/************************************************/
/* UDP Based Echo Client Callback               */
/************************************************/

ER udpecho_client_cbk(ID cepid, FN fncd, VP parblk)
{
  #ifdef NBLK
    T_IPEP dstaddr;
    switch(fncd)
    {
    case TFN_UDP_RCV_DAT:
        break;
    case TEV_UDP_RCV_DAT:
        if (udp_client_tskid) {
            udpecho_len = udp_rcv_dat(cepid, &dstaddr, echo_buf, sizeof echo_buf, TMO_POL);
            wup_tsk(udp_client_tskid);
        }
        break;
    }
  #endif
    return E_OK;
}

/************************************************/
/* UDP Based Echo Client Subroutine             */
/************************************************/

int udp_echo_sub(ID cepid, UW ipaddr, char *buf, int len, int bufsz)
{
    T_IPEP dstaddr;

    dstaddr.ipaddr = ipaddr;
    dstaddr.portno = UDP_PORT_ECHO;

#ifdef DUAL_STK
    dstaddr.type = IPV4_ADDR;
#endif
  #ifdef NBLK
    udp_client_tskid = (UH)vget_tid();
  #endif
    len = udp_snd_dat(cepid, &dstaddr, buf, len, 5000/MSEC);
    if (len <= 0)
        goto END;

  #ifdef NBLK
    len = tslp_tsk(5000/MSEC);
    if (len == E_OK)
        len = udpecho_len;
    udp_client_tskid = FALSE;
  #else
    len = udp_rcv_dat(cepid, &dstaddr, buf, bufsz, 5000/MSEC);
  #endif
END:

    return len;
}

/************************************************/
/* UDP Based Echo Client Process (for test)     */
/************************************************/

static void udp_echc_proc(ID cepid, UW ipaddr, T_NIF *nif)
{
    char *buf = (char *) echo_buf;
    int bufsz = sizeof echo_buf;
    int len;
    ER ercd;

    puts("** UDP Based Echo Client **");
  #ifdef NBLK
    udp_client_tskid = FALSE;
  #endif
#ifdef DUAL_STK
    c_udpecho_client_cep.myaddr.type = IPV4_ADDR;
#endif

    if(cepid == 0)
    {   cepid = udp_vcre_cep(&c_udpecho_client_cep);
        if(cepid <= 0)
        {   puts("UDP Communication End Point can't be created!");
            return;
        }
    }
    else
    {   ercd = udp_cre_cep(cepid, &c_udpecho_client_cep);
        if (ercd != E_OK)
        {   puts("UDP Communication End Point can't be created!");
            return;
        }
    }

    ercd = udp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        puts(" Error! udp_set_opt");
        goto L1;
    }

    for (;;)
    {
        print("Tx>");
        input(buf, bufsz);
        len = strlen(buf);
        if (len == 0)
        {   puts("");
            break;
        }
        len = udp_echo_sub(cepid, ipaddr, buf, len, bufsz);
        if (len <= 0)
        {   puts("\r\nUDP Communication Error!");
            break;
        }
        if (len != 0)
        {   buf[len] = '\0';
            print(" Rx>");
            puts(buf);
        }
    }
L1:
    udp_del_cep(cepid);
}

void udp_echo_client(ID cepid)
{
    T_NIF *nif = NULL;
    UW ipaddr = 0L;

    ipaddr = input_ipaddr("Destination IP Address = ");

    if (ipaddr == 0L) {
        print(" Invalid destination address. \r\n");
        return ;
    }

    nif = getnif_dstaddr(ipaddr);

    udp_echc_proc(cepid, ipaddr, nif);
}

int uecho_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    UW ipaddr = 0L;
    int i;
    B c;

    /* Arguments Convert */

    for (i = 1; i < argc; i++) {
        c = argv[i][0];
        if (c >= '0' && c <= '9')
            ipaddr = ascii_to_ipaddr(argv[i]);
        else if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return 0;
            }
        }
    }

    if (ipaddr == 0L)
        ipaddr = input_ipaddr("Destination IP Address = ");

    if (ipaddr == 0L) {
        print(" Invalid destination address. \r\n");
        return 0;
    }

    if (nif == NULL)
        nif = getnif_dstaddr(ipaddr);

    udp_echc_proc(0, ipaddr, nif);

    return 0;
}

#ifdef DUAL_STK
/************************************************/
/* UDP (IPv6) Based Echo Client Subroutine      */
/************************************************/

int udp_echo6_sub(ID cepid, UW *ipaddr, char *buf, int len, int bufsz)
{
    T_IPEP dstaddr;

    memset(&dstaddr, 0, sizeof (T_IPEP));
    dstaddr.portno = UDP_PORT_ECHO;
    set_ip6_addr(dstaddr.ip6addr, ipaddr);
    dstaddr.type = IPV6_ADDR;

  #ifdef NBLK
    udp_client_tskid = (UH)vget_tid();
  #endif
    len = udp_snd_dat(cepid, &dstaddr, buf, len, 15000/MSEC);
    if (len <= 0)
        goto END;

  #ifdef NBLK
    len = tslp_tsk(5000/MSEC);
    if (len == E_OK)
        len = udpecho_len;
    udp_client_tskid = FALSE;
  #else
    len = udp_rcv_dat(cepid, &dstaddr, buf, bufsz, 5000/MSEC);
  #endif

END:

    return len;
}

/************************************************/
/* UDP (IPv6) Based Echo Client Process         */
/************************************************/

void udp_echo6_client(int argc, char *argv[])
{
    char *buf = (char *)echo_buf;
    int bufsz = sizeof echo_buf;
    T_NIF *nif = NULL;
    UW ipaddr[4];
    int len, i;
    ID cepid;
    ER ercd;

    /* Arguments Convert */

    memset(ipaddr, 0, IP6_ADDR_SZ);
    for (i = 1; i < argc; i++) {
        if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return;
            }
        } else {
            ascii_to_ip6addr(argv[i], ipaddr);
        }
    }

    if (is_ip6_addr_any(ipaddr)) {
        print(msg_echo6_addr);
        return ;
    }

    if (nif == NULL)
        nif = getnif_dst6addr(ipaddr);

    puts("** UDP Based Echo Client **");

    c_udpecho_client_cep.myaddr.type = IPV6_ADDR;

    cepid = udp_vcre_cep(&c_udpecho_client_cep);
    if(cepid <= 0){
        puts("UDP Communication End Point can't be created!");
        return;
    }

    ercd = udp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        puts(" Error! udp_set_opt");
        goto L1;
    }

    for (;;)
    {
        print("Tx>");
        input(buf, bufsz);
        len = strlen((char *)buf);
        if (len == 0)
        {   puts("");
            break;
        }
        len = udp_echo6_sub(cepid, ipaddr, buf, len, bufsz);
        if (len <= 0)
        {   puts("\r\nUDP Communication Error!");
            break;
        }
        if (len != 0)
        {   buf[len] = '\0';
            print(" Rx>");
            puts(buf);
        }
    }
L1:
    udp_del_cep(cepid);
}

#endif

/************************************************/
/* TCP Based Echo Client Callback               */
/************************************************/

ER tcpecho_client_cbk(ID cepid, FN fncd, VP parblk)
{
  #ifdef NBLK
    switch (fncd)
    {
    case TFN_TCP_CON_CEP:
        wup_tsk(tcp_client_tskid);
        break;

    case TFN_TCP_RCV_DAT:
        if (tcp_client_rtskid) {
            tcpecho_len = *(INT *)parblk;
            wup_tsk(tcp_client_tskid);
        }
        break;

    case TFN_TCP_SND_DAT:
        tcpecho_len = *(INT *)parblk;
        wup_tsk(tcp_client_tskid);
        break;

    case TFN_TCP_CLS_CEP:
        wup_tsk(tcp_client_tskid);
        break;
    }
  #endif
    return E_OK;
}

/************************************************/
/* TCP Based Echo Client Subroutine             */
/************************************************/

int tcp_echo_sub(ID cepid, char *buf, int len, int bufsz)
{
    ER ercd;
    int i;

    i = 0;
    do
    {
      #ifdef NBLK
        ercd = tcp_snd_dat(cepid, buf + i, len - i, TMO_NBLK);
        if (ercd == E_WBLK)
        {   ercd = slp_tsk();
            if (ercd == E_OK)
                ercd = tcpecho_len;
        }
      #else
        ercd = tcp_snd_dat(cepid, buf + i, len - i, TMO_FEVR);
      #endif
        if (ercd <= 0)
            return ercd;
        i += ercd;
    } while (i < len);

    i = 0;
  #ifdef NBLK
    tcp_client_rtskid = (UH)vget_tid();
  #endif
    do
    {
      #ifdef NBLK
        ercd = tcp_rcv_dat(cepid, buf + i, bufsz - i, TMO_NBLK);
        if (ercd == E_WBLK) {
            ercd = tslp_tsk(1000/MSEC);
            if (ercd == E_OK)
                ercd = tcpecho_len;
        }
      #else
        ercd = tcp_rcv_dat(cepid, buf + i, bufsz - i, 1000/MSEC);
      #endif
        if (ercd <= 0)
            break;
        i += ercd;
    } while (i < len);
  #ifdef NBLK
    tcp_client_rtskid = FALSE;
  #endif
    return i;
}

/************************************************/
/* TCP Based Echo Client Process (for test)     */
/************************************************/

void tcp_echc_proc(ID cepid, UW ipaddr, T_NIF *nif)
{
    char *buf = (char *)echo_buf;
    int bufsz = sizeof echo_buf;
    int len;
  #ifdef DEBUG
    int i;
  #endif
    ER ercd;
    T_IPEP myaddr;
    T_IPEP dstaddr;

    puts("** TCP Based Echo Client **");

    if(cepid == 0) {
        cepid = tcp_vcre_cep(&c_tcpecho_client_cep);
        if (cepid <= 0) {
            puts("TCP Communication End Point can't be created!");
            return;
        }
    }
    else {
        ercd = tcp_cre_cep(cepid, &c_tcpecho_client_cep);
        if (ercd != E_OK) {
            puts("TCP Communication End Point can't be created!");
            return;
        }
    }

    ercd = tcp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        puts(" Error! tcp_set_opt");
        goto L1;
    }

    myaddr.ipaddr = IPV4_ADDRANY;
    myaddr.portno = TCP_PORTANY;
#ifdef DUAL_STK
    myaddr.type = IPV4_ADDR;
    dstaddr.type = IPV4_ADDR;
#endif
    dstaddr.ipaddr = ipaddr;
    dstaddr.portno = TCP_PORT_ECHO;

  #ifdef NBLK
    tcp_client_tskid = (UH)vget_tid();
    tcp_client_rtskid = FALSE;
    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, TMO_NBLK);
    if (ercd == E_WBLK)
        ercd = slp_tsk();
  #else
    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, 8000/MSEC);
  #endif
    if (ercd != E_OK) {
        puts("TCP connection error!");
        goto L1;
    }
  #ifdef DEBUG
    for (i = 0; i < 10; i++) {
        strcpy(buf, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        len = strlen(buf);
        len = tcp_echo_sub(cepid, buf, len, bufsz);
        if (len <= 0)
            break;
    }
  #else
    for (;;) {
        print("Tx>");
        input(buf, bufsz);
        len = strlen(buf);
        if (len == 0) {
            puts("");
            break;
        }
        len = tcp_echo_sub(cepid, buf, len, bufsz);
        if (len <= 0)
            break;
        buf[len] = '\0';
        print(" Rx>");
        puts(buf);
    }
  #endif

  #ifdef NBLK
    ercd = tcp_cls_cep(cepid, TMO_NBLK);
    if (ercd == E_WBLK)
        ercd = slp_tsk();
  #else
    ercd = tcp_cls_cep(cepid, 1000/MSEC);
  #endif
    if (ercd != E_OK)
        puts("TCP closing error!");
L1:
    tcp_del_cep(cepid);
}

void tcp_echo_client(ID cepid)
{
    T_NIF *nif = NULL;
    UW ipaddr = 0L;

    ipaddr = input_ipaddr("Destination IP Address = ");

    if (ipaddr == 0L) {
        print(" Invalid destination address. \r\n");
        return ;
    }

    if (nif == NULL)
        nif = getnif_dstaddr(ipaddr);

    tcp_echc_proc(cepid, ipaddr, nif);
}


int techo_command(int argc, char *argv[])
{
    T_NIF *nif = NULL;
    UW ipaddr = 0L;
    int i;
    B c;

    /* Arguments Convert */

    for (i = 1; i < argc; i++) {
        c = argv[i][0];
        if (c >= '0' && c <= '9')
            ipaddr = ascii_to_ipaddr(argv[i]);
        else if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return 0;
            }
        }
    }

    if (ipaddr == 0L)
        ipaddr = input_ipaddr("Destination IP Address = ");

    if (ipaddr == 0L) {
        print(" Invalid destination address. \r\n");
        return 0;
    }

    if (nif == NULL)
        nif = getnif_dstaddr(ipaddr);

    tcp_echc_proc(0, ipaddr, nif);

    return 0;
}

#ifdef DUAL_STK
/************************************************/
/* TCP (IPv6) Based Echo Client Process         */
/************************************************/
void tcp_echo6_client(int argc, char *argv[])
{
    char *buf = (char *)echo_buf;
    int bufsz = sizeof echo_buf;
    T_NIF *nif = NULL;
    UW ipaddr[4];
    int len, i;
    ER ercd;
    T_IPEP myaddr;
    T_IPEP dstaddr;
    ID cepid;

    /* Arguments Convert */

    memset(ipaddr, 0, IP6_ADDR_SZ);
    for (i = 1; i < argc; i++) {
        if (argv[i][1] == 'i') {
            nif = getnif_from_name(argv[++i]);
            if (nif == NULL) {
                print(" Invalid Interface specified. \r\n");
                return ;
            }
        } else {
            ascii_to_ip6addr(argv[i], ipaddr);
        }
    }

    if (is_ip6_addr_any(ipaddr)) {
        print(msg_echo6_addr);
        return ;
    }

    if (nif == NULL)
        nif = getnif_dst6addr(ipaddr);

    puts("** TCP Based Echo Client **");

    cepid = tcp_vcre_cep(&c_tcpecho_client_cep);
    if (cepid <= 0){
        puts("TCP Communication End Point can't be created!");
        return;
    }

    ercd = tcp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        puts(" Error! tcp_set_opt");
        goto L1;
    }

    memset(&myaddr, 0, sizeof (T_IPEP));
    myaddr.portno = TCP_PORTANY;
    myaddr.type = IPV6_ADDR;

    memset(&dstaddr, 0, sizeof (T_IPEP));
    set_ip6_addr(dstaddr.ip6addr, ipaddr);
    dstaddr.portno = TCP_PORT_ECHO;
    dstaddr.type = IPV6_ADDR;

  #ifdef NBLK
    tcp_client_tskid = (UH)vget_tid();
    tcp_client_rtskid = FALSE;
    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, TMO_NBLK);
    if (ercd == E_WBLK)
        ercd = slp_tsk();
  #else
    ercd = tcp_con_cep(cepid, &myaddr, &dstaddr, 8000/MSEC);
  #endif
    if (ercd != E_OK) {
        puts("TCP connection error!");
        goto L1;
    }
  #ifdef DEBUG
    for (i = 0; i < 10; i++) {
        strcpy(buf, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        len = strlen(buf);
        len = tcp_echo_sub(cepid, buf, len, bufsz);
        if (len <= 0)
            break;
    }
  #else
    for (;;) {
        print("Tx>");
        input(buf, bufsz);
        len = strlen((char *)buf);
        if (len == 0) {
            puts("");
            break;
        }
        len = tcp_echo_sub(cepid, buf, len, bufsz);
        if (len <= 0)
            break;
        buf[len] = '\0';
        print(" Rx>");
        puts(buf);
    }
  #endif

  #ifdef NBLK
    ercd = tcp_cls_cep(cepid, TMO_NBLK);
    if (ercd == E_WBLK)
        ercd = slp_tsk();
  #else
    ercd = tcp_cls_cep(cepid, 1000/MSEC);
  #endif
    if (ercd != E_OK)
        puts("TCP closing error!");
L1:
    tcp_del_cep(cepid);
}

#endif
/* end */
