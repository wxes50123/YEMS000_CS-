/******************************************************************************
* TCP/IP Test Program using TTCP Command for Multi-Channel                    *
*                                                                             *
*  Copyright (c) 2011-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-08-22 Created                                                       MI *
* 2011-12-14 Changed #if LANC_POLL to #ifdef LANC_POLL                     GS *
* 2012-03-12 Removed const from ethernet_addr[], default_ipaddr[], etc.    HE *
* 2012-03-12 Unified sample IP address to 192.168.0.xx from 192.168.1.xx   HE *
* 2012-03-30 Added support for NORTi Oceans                                HE *
* 2015-03-03 Changed host_ipaddr to be shared with ttcp_r_loop()/_t_loop() FY *
* 2016-03-15 Corrected tcp_ini() error code check from "!= E_OK" to "< 0"  FY *
* 2016-03-15 Modified for multi-channel, and renamed from tcptest.c        FY *
* 2016-04-25 Renamed LANC_POLL macro to POL                                FY *
* 2016-11-23 Added TCP_CEPID_MAX configuration to support NTttcp           FY *
* 2016-11-24 Added guidance of this sample program                         MI *
* 2023-04-03 Increased tasks stack size from 512 to 1024 bytes             FY *
* 2023-04-03 Replaced #if 0 & #endif by comment symbols to avoid GCC error GS *
******************************************************************************/

#include "kernel.h"
#include "nonttcp2.h"

#define TSKID_MAX 9 /* 5 tasks here + 4 tasks in multi-channel TCP/IP stack */
#define TCP_CEPID_MAX 8 /* (data Tx/Rx + NTttcp command Tx/Rx) x 2 channels */
#ifdef NORTi_Oceans
#include "nocnet.h"
#include "nocnetc.h"
#include "noccfg.h"
#else
#include "nonet.h"
#include "nonetc.h"
#include "nocfg4.h"
#endif

/* For LAN Driver Test by Polling */

#ifdef POL
extern void lan_intr(void);
#endif

/* Network Interface Variables */

UB ethernet_addr[]   = { 0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC };
UB default_ipaddr[]  = { 192, 168, 0, 101 };
UB subnet_mask[]     = { 255, 255, 255, 0 };
UB default_gateway[] = { 192, 168, 0, 1 };

UB ethernet_addr1[]  = { 0x12, 0x34, 0x56, 0x78, 0x9A, 0xBD };
UB default_ipaddr1[] = { 192, 168, 0, 102 };
UB subnet_mask1[]    = { 255, 255, 255, 0 };
UB default_gateway1[]= { 192, 168, 0, 1 };
T_NIF add_inet;

const char default_host_ipaddr[] = "192.168.0.100";
const char default_host_ipaddr1[]= "192.168.0.100";
UW host_ipaddr[2];

/* Object ID Numbers */

#define ID_MainTask  1  /* ID of main task */
#define ID_RecvTask  2  /* ID of ttcp receiver task for main channel */
#define ID_SendTask  3  /* ID of ttcp transmitter task for main channel */
#define ID_RecvTask1 4  /* ID of ttcp receiver task for sub channel */
#define ID_SendTask1 5  /* ID of ttcp transmitter task for sub channel */

/* Object Creation Information */

TASK MainTask(void);    /* main task */
TASK RecvTask(int);     /* ttcp receiver task */
TASK SendTask(int);     /* ttcp transmitter task */

const T_CTSK cMainTask = { TA_HLNG, NULL, (FP)MainTask, 7, 1024, NULL };
const T_CTSK cRecvTask = { TA_HLNG, NULL, (FP)RecvTask, 5, 1024, NULL };
const T_CTSK cSendTask = { TA_HLNG, NULL, (FP)SendTask, 6, 1024, NULL };

/*****************************************************************************
* Main Task
*
******************************************************************************/

TASK MainTask(void)
{
    T_NIF_ADDR addr;
    ER ercd;

    host_ipaddr[0] = ascii_to_ipaddr(default_host_ipaddr);
    host_ipaddr[1] = ascii_to_ipaddr(default_host_ipaddr1);

    /* initialize TCP/IP stack */
    ercd = tcp_ini();
    if (ercd < 0)
        ext_tsk();

    /* initialize sub channel */
    addr.hwaddr  = (UB *)ethernet_addr1;
    addr.ipaddr  = (UB *)default_ipaddr1;
    addr.gateway = (UB *)default_gateway1;
    addr.mask    = (UB *)subnet_mask1;
    ercd = tcp_nif_ini(&add_inet, "eth1", lan_nif_dev1, &addr);
    if (ercd < 0)
        ext_tsk();

    /* start ttcp tasks */
    sta_tsk(ID_RecvTask, 0);
    sta_tsk(ID_SendTask, 0);
    sta_tsk(ID_RecvTask1, 1);
    sta_tsk(ID_SendTask1, 1);

    /* in polling mode, call LAN interrupt function directly */
    for (;;) {
      #ifdef POL
        chg_pri(TSK_SELF, 1);
        lan_intr();
        chg_pri(TSK_SELF, TPRI_INI);
      #else
        slp_tsk();
      #endif
    }
}

/*****************************************************************************
* TTCP Receiver Task
*
******************************************************************************/

TASK RecvTask(int ch)
{
    ttcp_r_loop(ch, &host_ipaddr[ch]);
}

/*****************************************************************************
* TTCP Transmitter Task
*
******************************************************************************/

TASK SendTask(int ch)
{
    ttcp_t_loop(ch, &host_ipaddr[ch]);
}

/*****************************************************************************
* Main
*
******************************************************************************/

int main(void)
{
    /* initialize system */
    sysini();

    /* create all objects */
    cre_tsk(ID_MainTask, &cMainTask);   /* create main task */
    cre_tsk(ID_RecvTask, &cRecvTask);   /* create ttcp receiver task */
    cre_tsk(ID_SendTask, &cSendTask);   /* create ttcp transmitter task */
    cre_tsk(ID_RecvTask1, &cRecvTask);  /* create another ttcp receiver task */
    cre_tsk(ID_SendTask1, &cSendTask);  /* create another ttcp transmitter task */

    /* start main task */
    sta_tsk(ID_MainTask, 0);

    /* start system */
    intsta();                           /* start interval timer interrupt */
    return syssta();                    /* enter into multitasking */
}

/* end */

/*-----------------------------------------------------------------------------
���{�T���v���v���O�����ɂ���

���� tcptest2.c �� nonttcp2.c, nonttcp2.h �ɁA�l�b�g���[�N�̃X���[�v�b�g
���v���ł���Microsoft�́uttcp�v����сA��p�́uNTttcp�v�̑��葤��������
��Ă���ALAN�Őڑ����ꂽPC��ttcp�R�}���h/ntttcp�R�}���h�Ɏ��̂悤�ɉ���
���܂��B

�b>ttcp -t 192.168.0.161
�bttcp-t: local 192.168.0.39 -> remote 192.168.0.161
�bttcp-t: buflen=8192, nbuf=2048, align=16384/+0, port=5001 tcp -> 192.168.0.161
�b
�bttcp-t: done sending, nbuf = -1
�bttcp-t: 16777216 bytes in 79642 real milliseconds = 205 KB/sec
�bttcp-t: 2048 I/O calls, msec/call = 38, calls/sec = 25, bytes/call = 8192
�b
�b>ttcp -r
�bttcp-r: local 192.168.0.39 <- remote 192.168.0.161
�bttcp-r: buflen=8192, nbuf=2048, align=16384/+0, port=5001  tcp
�bttcp-r: 16777216 bytes in 79243 real milliseconds = 206 KB/sec
�bttcp-r: 3555 I/O calls, msec/call = 22, calls/sec = 44, bytes/call = 4719

�b>ntttcp -s -m 1,*,192.168.0.101 -n 200
�bCopyright Version 5.31
�bNetwork activity progressing...
�b
�bThread  Time(s) Throughput(KB/s) Avg B / Compl
�b======  ======= ================ =============
�b     0   28.119          227.604     65536.000
�b       :
�`
�b>ntttcp -r -m 1,*,192.168.0.41
�bCopyright Version 5.31
�bNetwork activity progressing...
�b
�bThread  Time(s) Throughput(KB/s) Avg B / Compl
�b======  ======= ================ =============
�b     0   73.646          222.470       819.200
�b       :

�ڑ������PC��IP�A�h���X�́Achar default_host_ipaddr[] = "192.168.0.100";
�� tcptest2.c �ɒ��ڒ�`����Ă��܂����APC�����M���� ttcp -t �R�}���h��
ntttcp -s �R�}���h���킹�ď��������܂��̂ŁAIP�A�h���X���قȂ��Ă��Ă��A
�C���̕K�v�͂���܂���B

�Ȃ��Attcp��NTttcp�͌݊������Ȃ��A����𔻕ʂ��Ă̓���̎����؂�ւ��́A
ntttcp -s �R�}���h�ōs���Ă��܂��̂ŁANTttcp�𗘗p����ꍇ�́Antttcp -r
����� ntttcp -s �R�}���h�����s���Ă��������B

ttcp(������PCATTCP)��NTttcp�̏ڍׂɂ��ẮA���L�������Q�Ƃ��������B
http://www.atmarkit.co.jp/fwin2k/win2ktips/348ttcp/ttcp.html
https://xtech.nikkei.com/it/pc/article/knowhow/20091219/1021678/
https://learn.microsoft.com/ja-jp/azure/virtual-network/virtual-network-bandwidth-testing

�{�v���O�����́AEthernet�~2�`���l����������^�[�Q�b�g�p�ŁA���`���l����
�����ɓ���ł��܂��B1�`���l���̏ꍇ�́Atcptest.c, nonttcp.c, nonttcp.h
�̕��������p���������B
-----------------------------------------------------------------------------*/
