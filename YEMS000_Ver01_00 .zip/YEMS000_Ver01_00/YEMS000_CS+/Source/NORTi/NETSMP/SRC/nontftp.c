/******************************************************************************
* NORTi Network TFTP Sample                                                   *
*                                                                             *
*  Copyright (c) 1998-2012, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1998-11-26                                                                  *
* 1999-09-22 resource ID auto assign added.                                   *
* 2001-02-12 Change Task priority 4 -> 5                                      *
* 2004-01-08 The bug which Null of error messages lacked was corrected.    SZ *
* 2004-01-08 Excessive casts were removed. Ex. (char *) of "string"        SZ *
* 2004-01-24 ntohs and htons for tftp->code,blkno added                    EM *
* 2004-12-20 Option SET_UDP_RPKT_OPT set                                   PK *
* 2005-01-20 Corrected odd length data transfers                           AK *
* 2005-01-23 NOFILE_VER macro was added.                                   NA *
* 2005-05-13 Added TFTP uninitialization code.                             AK *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2010-12-28 Corrected compiler warning by adding (FP) to T_CTSK           HE *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2013-06-28 Added parameter for IPv6 to definition of T_UDP_CCEP             *
*                                               in the case of dual stack  FY *
******************************************************************************/

#ifndef NOFILE_VER
#define NOFILE_VER  1
#endif

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nontftp.h"
#if (NOFILE_VER == 4)
#include "nofile.h"
#else
#include "nonfile.h"
#endif

/* Creation Information */

const T_CTSK c_tftpsrv_tsk = { TA_HLNG, NULL, (FP)tftpsrv_tsk,  5,  TFTP_SERVER_SSZ, NULL, "tftpsrv_tsk" };
#ifdef DUAL_STK
const T_UDP_CCEP c_tftpsrv_cep = { 0, { IPV4_ADDRANY, UDP_PORT_TFTP, IPV6_ADDRANY, IPV4_ADDR }, (FP)tftpsrv_cbk };
#else
const T_UDP_CCEP c_tftpsrv_cep = { 0, { IPV4_ADDRANY, UDP_PORT_TFTP }, (FP)tftpsrv_cbk };
#endif

/* Local Data */

static T_TFTP tftp[1];
static UH tftp_cepid = 0;

/************************************************/
/* TFTP Server Callback                         */
/************************************************/

ER tftpsrv_cbk(ID cepid, FN fncd, VP parblk)
{
    return E_OK;
}

/************************************************/
/* TFTP Server Task Sample                      */
/************************************************/

TASK tftpsrv_tsk(ID cepid)
{
    T_IPV4EP dstaddr;
    FILE *fp = NULL;
    ER len;
    UW pos;
    int i;
    UB last_ack=0;

    tftp_cepid = (UH)cepid;

    for (;;)
    {
        len = udp_rcv_dat(cepid, &dstaddr, tftp, sizeof (T_TFTP), TMO_FEVR);
        if (len <= 0) {

            /* Don't close for E_BOVR or E_OBJ (checksum) error */
            if (len == E_BOVR || len == E_OBJ)
                continue;

            if (fp != NULL) {
                fclose(fp);
            }
            udp_del_cep(cepid);

            tftp_cepid = 0;

            exd_tsk();
        }

        if (len < 4)
            continue;

        /* Change byte order before process */

        tftp->code  = ntohs(tftp->code);

        switch (tftp->code)
        {
        case TFTP_RRQ:
            if (fp != NULL)
                fclose(fp);
            fp = fopen((const char *)&(tftp->blkno), (char *)"rb");
            if (fp == NULL)
            {   tftp->code = TFTP_ERROR;
                tftp->blkno = htons(1);
                strcpy((char *)(tftp->data), (char *)"file not found");
                len = 4 + strlen((char *)(tftp->data)) + 1;
                break;
            }
            i = (int)fread(tftp->data, 1, TFTP_SIZE, fp);
            tftp->code = TFTP_DATA;
            tftp->blkno = htons(1);
            len = 4 + i;
            if (i == TFTP_SIZE)
                last_ack = 0;
            else
                last_ack = 1;
            break;

        case TFTP_ACK:
            if (fp == NULL)
            {   tftp->code = TFTP_ERROR;
                tftp->blkno = htons(4);
                strcpy((char *)(tftp->data), (char *)"illegal sequence");
                len = 4 + strlen((char *)(tftp->data)) + 1;
                break;
            }
            tftp->blkno = ntohs(tftp->blkno);
            pos = (UW)tftp->blkno * TFTP_SIZE;
            fseek(fp, pos, SEEK_SET);
            i = (int)fread(tftp->data, 1, TFTP_SIZE, fp);
            if (i < TFTP_SIZE) {
                if (i == 0) { /* ignore last ACK */
                    if (last_ack == 0) {
                        tftp->code = TFTP_DATA;
                        tftp->blkno++;
                        tftp->blkno = htons(tftp->blkno);
                        last_ack = 1;
                        break;
                    }
                    fclose(fp);
                    fp = NULL;
                    len = 0;
                    break;
                }
            }
            tftp->code = TFTP_DATA;
            tftp->blkno++;
            tftp->blkno = htons(tftp->blkno);
            len = 4 + i;
            if (i == TFTP_SIZE)
                last_ack = 0;
            else
                last_ack = 1;
            break;

        case TFTP_WRQ:
            if (fp == NULL)
                fp = fopen((const char *)&(tftp->blkno), (char *)"wb");
            if (fp == NULL)
            {   tftp->code = TFTP_ERROR;
                tftp->blkno = htons(1);
                strcpy((char *)(tftp->data), (char *)"illegal file name");
                len = 4 + strlen((char *)(tftp->data)) + 1;
                break;
            }
            tftp->code = TFTP_ACK;
            tftp->blkno = 0;
            len = 4;
            break;

        case TFTP_DATA:
            if (fp == NULL)
            {   tftp->code = TFTP_ERROR;
                tftp->blkno = htons(4);
                strcpy((char *)(tftp->data), (char *)"illegal sequence");
                len = 4 + strlen((char *)(tftp->data)) + 1;
                break;
            }
            pos = (UW)(ntohs(tftp->blkno) - 1) * TFTP_SIZE;
            fseek(fp, pos, SEEK_SET);
            len -= 4;
            i = (int)fwrite(tftp->data, 1, len, fp);
            if (i < TFTP_SIZE)
            {   fclose(fp);
                fp = NULL;
                if (i < len)
                {   tftp->code = TFTP_ERROR;
                    tftp->blkno = htons(3);
                    strcpy((char *)(tftp->data), (char *)"disk full");
                    len = 4 + strlen((char *)(tftp->data)) + 1;
                    break;
                }
            }
            tftp->code = TFTP_ACK;
            len = 4;
            break;

        case TFTP_ERROR:
            len = 0;
            break;

        default:
            tftp->code = TFTP_ERROR;
            tftp->blkno = htons(4);
            strcpy((char *)(tftp->data), (char *)"unknown operation");
            len = 4 + strlen((char *)(tftp->data)) + 1;
            break;
        }

        if (len != 0) {
            tftp->code  = htons(tftp->code);
            udp_snd_dat(cepid, &dstaddr, tftp, len, TMO_FEVR);
        }
    }
}

/************************************************/
/* Delete TFTP Server resources                 */
/************************************************/

void tftpsrv_ext(void)
{
    /* Delete CEP */
    udp_can_cep(tftp_cepid, TFN_UDP_ALL);
    udp_del_cep(tftp_cepid);
}


/************************************************/
/* TFTP Server Intialize                        */
/************************************************/

ER tftpsrv_ini(ID tskid, ID cepid)
{
    ER ercd;

    /* Initialized already ? */
    if (tftp_cepid)
        return E_OK;

    /* Create TFTP Server Task */

    if(tskid == 0){/* ID auto (Add by Y.Y) */
        ercd = acre_tsk(&c_tftpsrv_tsk);
        if (ercd < 0)
            return ercd;
        tskid = ercd;
    }
    else{
        ercd = cre_tsk(tskid, &c_tftpsrv_tsk);
        if (ercd != E_OK)
            return ercd;
    }

    /* Create UDP Commnunication End Point */

    if(cepid == 0)
    {   ercd = cepid = udp_vcre_cep(&c_tftpsrv_cep);
        if(cepid <= 0)
            goto ERR;
    }
    else
    {   ercd = udp_cre_cep(cepid, &c_tftpsrv_cep);
        if (ercd != E_OK)
            goto ERR;
    }

    ercd = udp_set_opt(cepid, SET_UDP_RPKT_OPT, (VP)TRUE, sizeof(BOOL));
    if (ercd != E_OK) {
         goto ERR;
    }

    /* Start TFTP Server Task */

    ercd = sta_tsk(tskid, cepid);
    if (ercd != E_OK)
        goto ERR;

    return E_OK;

ERR:
    udp_del_cep(cepid);
    del_tsk(tskid);
    return ercd;
}

/* end */
