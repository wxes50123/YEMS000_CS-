/******************************************************************************
* NORTi File System Version 1 (16-bit FAT)                                    *
*                                                                             *
*  Copyright (c) 1999-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-07 Created                                                          *
* 1999-05-06 Added remove()                                                   *
* 1999-05-23 Added append mode "a" to fopen()                                 *
* 1999-05-23 Added feof() and rename()                                        *
* 1999-06-13 Corrected fseek()                                                *
* 1999-09-22 Supported auto ID assignment when semid = 0 in file_ini()        *
* 2000-11-29 Corrected make_dir_list() to handle more than 18 files           *
* 2000-11-29 Corrected fgets() to return '\n' character as end of line        *
* 2001-05-01 Added donefini for file_ini() completion check in disk_ini()     *
* 2001-04-12 Renamed direct to unconflicting _direct for GAIO XASS-V          *
* 2001-07-18 Gathered disk selecting code in each function to get_disk()      *
* 2001-07-18 Added 2 to END_CLUSTER_NUMBER not to cause early disk full       *
* 2001-09-12 Corrected file_seek() and file_getc/putc() f->byteno handling KA *
* 2001-09-13 Added SINGLE_TASK macro to omit exclusive control of API and     *
*              USE_FSYS_ERCD macro & FSYS_ERCD variable to keep error code KA *
* 2001-09-13 Corrected make_dir_list() by adding 1 to p->d_ino             KA *
* 2001-09-14 Stored more error codes in f->ercd except for E_OK            KA *
* 2001-09-15 Fixed file_putc()/file_open() return value when new_sector()     *
*              /new_cluster()=0 from EOF/EV_DISKFUL to occurred error code KA *
* 2001-12-18 Added occurred error code reset (d->ercd = 0) to get_disk()   KA *
* 2002-01-17 Replaced "B *" of string param with "char *" to avoid warning KA *
* 2002-03-27 Fixed my_fopen() not to open to write the file opened to read KA *
* 2002-03-27 Added 3rd param to new_cluster/sector() to return error code  KA *
* 2002-06-19 Shortened #define of SYSTEM_SECTOR_AREA to avoid HEW2 bug     KA *
* 2002-12-20 Corrected NFILE & ID_FILE_TSK/_SEM types (B & UB -> INT & ID) KA *
* 2003-02-03 Optimized get_le_h(p) to *(UH*)p in new_cluster()             KA *
* 2003-06-06 Removed unused ID_FILE_TSK, and added some casts to unwarn    KA *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2009-04-30 Added the 'disk' variable initialization                      FY *
* 2009-05-19 Modified the processing of 'donefini'                         FY *
* 2012-03-28 Corrected sector number in file_seek() when position is at       *
*                 EOF and file size is multiple of not cluster but sector  FY *
* 2012-11-23 Minimized type of ID_FILE_SEM from ID to UH                   FY *
* 2013-09-19 Corrected my_fgets() not to convert CRLF to LF                FY *
* 2016-12-25 Changed read_fat~write_dir's fatno/dirno type from INT to UW  MI *
* 2016-12-25 Added casts with (UH) to usual-arithmetic-converted results   MI *
* 2016-12-25 Changed 'W pos' to 'W offs' & 'UW pos' of my_fseek() (*1)     MI *
* 2018-03-13 Corrected misreading of sector data in addition to               *
*                       the above sector number correction in file_seek()  FY *
* 2018-03-16 Minimized type of NFILE from INT to UB                        FY *
* 2018-03-16 Simplified redefinitions for SINGLE_TASK and USE_FSYS_ERCD    FY *
* 2018-03-16 Changed type of ID_FILE_SEM from UH to H                      FY *
* 2018-03-16 Renamed ID_FILE_SEM & file_csem to ID_LFS_SEM & lfs_csem      FY *
* 2018-03-16 Renamed get_le_h~set_le_w() to common read_le16~write_le32()  FY *
* 2018-03-16 Renamed other local functions like path_to_name(), etc.       FY *
* 2018-03-16 Added const to disk_ini 2nd param, and renewed style totally  FY *
* 2018-03-16 Changed type of donefini from UB to UH                        FY *
* 2018-10-10 Added cast to comparing 0xe5 with T_DIR_ENTRY's name[0]       FY *
* 2020-10-29 Added missing f->stat=0 when file_seek() error in file_open() FY *
* 2022-04-18 Added my_ferror() and my_clearerr()                           FY *
* 2022-06-11 Fixed above (*1) not to seek to indefinite pos when SEEK_SET  MI *
******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonfile.h"
#include "nonitod.h"
#ifdef DEBUG
#include "nonet.h"
#include "nonteln.h"
#endif

/* Omitting Exclusive Control when Single Task */

#ifdef SINGLE_TASK
#undef sig_sem
#undef wai_sem
#define sig_sem(i)
#define wai_sem(i)
#endif

/* Keeping Error Code in Global Variable */

#ifdef USE_FSYS_ERCD
H FSYS_ERCD;
#define FSYS_ER(cd) (FSYS_ERCD = (H)(cd))
#else
static ER FSYS_ER(ER cd) { return cd; }
#endif

/* Disk Parameters */

#define SECTORS_PER_CLUSTER     (d->sc)
#define RESERVED_SECTOR_COUNT   (d->rsc)
#define NUMBER_OF_FATS          (d->fn)
#define ROOT_DIR_ENTRYS         (d->rde)
#define TOTAL_SECTORS           (d->ts)
#define SECTORS_PER_FAT         (d->sf)
#define SECTORS_PER_DIR         ((ROOT_DIR_ENTRYS*DIR_ENTRY_SZ-1)/SECTOR_SIZE+1)
#define SYSTEM_SECTOR_AREA      (d->rsc+(d->sf)*(d->fn)+SECTORS_PER_DIR)
#define END_CLUSTER_NUMBER      ((TOTAL_SECTORS-SYSTEM_SECTOR_AREA+2)/SECTORS_PER_CLUSTER)
#define DIR_ENTRYS_PER_SECTOR   (SECTOR_SIZE/DIR_ENTRY_SZ)
#define FAT_ENTRYS_PER_SECTOR   (SECTOR_SIZE/2)

/* Internal Variables */

static UB NFILE;                /* number of files allowed to be open simultaneously */
static T_FILE *file;            /* pointer to file control block */
static T_DISK *disk;            /* pointer to disk drive control block */
static UH donefini;             /* file_ini() done flag */
#ifndef SINGLE_TASK
static H ID_LFS_SEM;            /* semaphore ID */
static const T_CSEM lfs_csem = { TA_TFIFO, 1, 1, "File System" };
#endif

/************************************************/
/* For Debugging                                */
/************************************************/
#ifdef DEBUG

static void file_debug(const char *s, W d)
{
    B buf[12];

    ltod(buf, d, 8);
    print(s);
    puts(buf);
}

#endif
/************************************************/
/* Read/Write 16/32-bit Little Endian Data      */
/************************************************/

static UH read_le16(VP p)
{
    UB *pp = (UB *)p + 1;
    UH d;

    d = *pp--; d <<= 8;
    d |= *pp;
    return d;
}

static void write_le16(VP p, UH d)
{
    UB *pp = (UB *)p;

    *pp++ = (UB)d; d >>= 8;
    *pp   = (UB)d;
}

static UW read_le32(VP p)
{
    UB *pp = (UB *)p + 3;
    UW d;

    d  = *pp--; d <<= 8;
    d |= *pp--; d <<= 8;
    d |= *pp--; d <<= 8;
    d |= *pp;
    return d;
}

static void write_le32(VP p, UW d)
{
    UB *pp = (UB *)p;

    *pp++ = (UB)d; d >>= 8;
    *pp++ = (UB)d; d >>= 8;
    *pp++ = (UB)d; d >>= 8;
    *pp   = (UB)d;
}

/************************************************/
/* Convert File Name to Directory Style         */
/************************************************/

static char *path_to_dirname(const char *path, char *name)
{
    int i, dot;
    char c;

    /* "File.Txt" -> "FILE    TXT", for example */
    for (i = dot = 0; i < 8 + 3; ) {
        c = *path++;
        if (c == ' ')
            continue;
        else if (c == '\0') {
            for (; i < 8 + 3; )
                name[i++] = ' ';
            break;
        } else if (c == '.') {
            if (dot++ != 0)
                return NULL;
            for (; i < 8; )
                name[i++] = ' ';
        } else {
            if (i >= 8 && dot == 0)
                return NULL;
            name[i++] = (char)toupper(c);
        }
    }
    return name;
}

/************************************************/
/* Convert File Name from Directory Style       */
/************************************************/

static char *dirname_to_path(const char *name, char *path)
{
    char *p = path;
    int i;
    char c;

    /* "FILE    TXT" -> "FILE.TXT", for example */
    for (i = 0; i < 8 + 3; ) {
        if (i == 8)
            *p++ = '.';
        c = name[i];
        if (c == ' ') {
            if (i >= 8)
                break;
            i = 8;
        } else {
            *p++ = (char)c;
            i++;
        }
    }
    if (*(p - 1) == '.')
        p--;
    *p = '\0';
    return path;
}

/************************************************/
/* Convert Cluster Number to Sector Number      */
/************************************************/

static UW cluster_to_sector(T_DISK *d, UH clusno)
{
    return (UW)(clusno - 2) * SECTORS_PER_CLUSTER + SYSTEM_SECTOR_AREA;
}

/************************************************/
/* Convert Sector Number to Cluster Number      */
/************************************************/

static UH sector_to_cluster(T_DISK *d, UW sectno)
{
    return (UH)((sectno - SYSTEM_SECTOR_AREA) / SECTORS_PER_CLUSTER + 2);
}

/************************************************/
/* Read FAT Sector                              */
/************************************************/

static ER read_fat(T_DISK *d, UW fatno, UB **buf)
{
    /* calculate FAT sector number */
    if (fatno >= (UW)SECTORS_PER_FAT)
        return EV_DISKFULL;
    fatno += RESERVED_SECTOR_COUNT;

    /* read FAT sector */
    return (*d->func)(d, TFN_READ_SECTOR, fatno, buf);
}

/************************************************/
/* Write FAT Sector                             */
/************************************************/

static ER write_fat(T_DISK *d, UW fatno, UB *buf)
{
    /* calculate FAT sector number */
    if (fatno >= (UW)SECTORS_PER_FAT)
        return EV_DISKFULL;
    fatno += RESERVED_SECTOR_COUNT;

    /* write FAT sector */
    return (*d->func)(d, TFN_WRITE_SECTOR, fatno, buf);
}

/************************************************/
/* Read Root Directory Sector                   */
/************************************************/

static ER read_dir(T_DISK *d, UW dirno, UB **buf)
{
    /* calculate root directory sector number */
    dirno += RESERVED_SECTOR_COUNT + SECTORS_PER_FAT * NUMBER_OF_FATS;
    if (dirno >= (UW)SYSTEM_SECTOR_AREA)
        return EV_DISKFULL;

    /* read root directory sector */
    return (*d->func)(d, TFN_READ_SECTOR, dirno, buf);
}

/************************************************/
/* Write Root Directory Sector                  */
/************************************************/

static ER write_dir(T_DISK *d, UW dirno, UB *buf)
{
    /* calculate root directory sector number */
    dirno += RESERVED_SECTOR_COUNT + SECTORS_PER_FAT * NUMBER_OF_FATS;
    if (dirno >= (UW)SYSTEM_SECTOR_AREA)
        return EV_DISKFULL;

    /* write root directory sector */
    return (*d->func)(d, TFN_WRITE_SECTOR, dirno, buf);
}

/************************************************/
/* Get Next Cluster Number                      */
/************************************************/

static UH next_cluster(T_DISK *d, UH clusno)
{
    UB *buf;
    ER ercd;
    UH n, m;

    m = (UH)(clusno / FAT_ENTRYS_PER_SECTOR);
    n = (UH)(clusno % FAT_ENTRYS_PER_SECTOR);

    /* get next cluster number from FAT */
    ercd = read_fat(d, m, &buf);
    if (ercd != E_OK)
        return 0;
    buf += n * 2;
    n = read_le16(buf);
    if (n >= 0xfff7) /* bad cluster or end of FAT chain */
        return 0;
    return n;
}

/************************************************/
/* Delete Cluster and Get Next Cluster Number   */
/************************************************/

static UH del_cluster(T_DISK *d, UH clusno)
{
    UB *buf, *p;
    ER ercd;
    UH n, m;

    m = (UH)(clusno / FAT_ENTRYS_PER_SECTOR);
    n = (UH)(clusno % FAT_ENTRYS_PER_SECTOR);

    /* get next cluster number from FAT entry */
    ercd = read_fat(d, m, &buf);
    if (ercd != E_OK)
        return 0;
    p = buf + n * 2;
    n = read_le16(p);

    /* change FAT entry value to unused cluster */
    write_le16(p, 0x0000);
    ercd = write_fat(d, m, buf);
  #ifdef DEBUG
    file_debug("Erase Sector No.", cluster_to_sector(d, clusno));
  #endif
    if (ercd != E_OK)
        return 0;
    if (n >= 0xfff8) /* end of FAT chain */
        return 0;
    return n;
}

/************************************************/
/* Get Next Sector Number                       */
/************************************************/

static UW next_sector(T_DISK *d, UW sectno)
{
    UH n;

    if (SECTORS_PER_CLUSTER >= 2) {
        if ((sectno + 1 - SYSTEM_SECTOR_AREA) % SECTORS_PER_CLUSTER != 0)
            return ++sectno;
    }
    n = next_cluster(d, sector_to_cluster(d, sectno));
    if (n == 0)
        return 0;
    return cluster_to_sector(d, n);
}

/************************************************/
/* Allocate New Cluster                         */
/************************************************/

static ER new_cluster(T_DISK *d, UH clusno, UH *newclusno)
{
    UB *buf, *p;
    ER ercd;
    UH n, nn, end;  /* cluster numbers */
    UH m, mm;       /* sector numbers */

    end = (UH)(FAT_ENTRYS_PER_SECTOR * SECTORS_PER_FAT);
    if (end > (UH)END_CLUSTER_NUMBER)
        end = (UH)END_CLUSTER_NUMBER;

    n = d->saveclus; /* last allocated cluster number */
    if (++n >= end)
        n = 0;
    m = (UH)(n / FAT_ENTRYS_PER_SECTOR);
    ercd = read_fat(d, m, &buf);
    if (ercd != E_OK)
        return ercd;
    if (n < 2) {
        n = 2;
        p = (UB *)((UH *)buf + n);
    } else {
        nn = (UH)(n - m * FAT_ENTRYS_PER_SECTOR);
        p = (UB *)((UH *)buf + nn);
    }

    while (n != d->saveclus) {
        /* read next FAT sector */
        if (p >= buf + SECTOR_SIZE) {
            ercd = read_fat(d, ++m, &buf);
            if (ercd != E_OK)
                return ercd;
            p = buf;
        }
        /* search unused cluster */
        if (*(UH *)p == 0x0000) { /* read_le16(p) */
            d->saveclus = n;
            write_le16(p, 0xffff);
            ercd = write_fat(d, m, buf);
            if (ercd != E_OK)
                return ercd;
            if (clusno != 0) {
                mm = (UH)(clusno / FAT_ENTRYS_PER_SECTOR);
                if (mm != m) {
                    ercd = read_fat(d, mm, &buf);
                    if (ercd != E_OK)
                        return ercd;
                }
                p = buf + (clusno - mm * FAT_ENTRYS_PER_SECTOR) * 2;
                write_le16(p, n);
                ercd = write_fat(d, mm, buf);
                if (ercd != E_OK)
                    return ercd;
            }
            *newclusno = n;
            return E_OK;
        }
        if (++n < end) {
            p += 2;
        } else {
            m = 0;
            ercd = read_fat(d, m, &buf);
            if (ercd != E_OK)
                return ercd;
            n = 2;
            p = (UB *)((UH *)buf + n);
        }
    }
    return EV_DISKFULL;
}

/************************************************/
/* Allocate New Sector                          */
/************************************************/

static ER new_sector(T_DISK *d, UW sectno, UW *newsectno)
{
    ER ercd;
    UH n;

    if (SECTORS_PER_CLUSTER > 1) {
        if ((sectno + 1 - SYSTEM_SECTOR_AREA) % SECTORS_PER_CLUSTER != 0) {
            *newsectno = ++sectno;
            return E_OK;
        }
    }
    ercd = new_cluster(d, sector_to_cluster(d, sectno), &n);
    if (ercd != E_OK)
        return ercd;
    *newsectno = cluster_to_sector(d, n);
    return E_OK;
}

/************************************************/
/* Search Directory Entry by Name               */
/************************************************/

static ER find_dir_entry(T_DISK *d, int *entrno, T_DIR_ENTRY *dir, const char *name)
{
    T_DIR_ENTRY *p = NULL;
    ER ercd;
    UB *buf;
    int n;

    for (n = 0; n < (int)ROOT_DIR_ENTRYS; n++, p++) {
        if (n % DIR_ENTRYS_PER_SECTOR == 0) {
            ercd = read_dir(d, n / DIR_ENTRYS_PER_SECTOR, &buf);
            if (ercd != E_OK)
                return ercd;
            p = (T_DIR_ENTRY *)buf;
        }
        if (name == NULL) { /* search unused entry */
            if (p->name[0] == 0x00 || (UB)p->name[0] == 0xe5)
                break;
        } else {
            if (p->name[0] == 0x00) { /* end of entry table */
                n = -1;
                break;
            }
            if (memcmp(p->name, name, 8 + 3) == 0)
                break;
        }
    }
    if (n == (int)ROOT_DIR_ENTRYS) {
        *entrno = -1;
    } else {
        *entrno = n;
        memcpy(dir, p, DIR_ENTRY_SZ);
    }
    return E_OK;
}

/************************************************/
/* Delete Directory Entry                       */
/************************************************/

static ER del_dir_entry(T_DISK *d, int entrno)
{
    T_DIR_ENTRY *p;
    UB *buf;
    ER ercd;
    UW m;
    UH n;

    m = (UW)(entrno / DIR_ENTRYS_PER_SECTOR);
    ercd = read_dir(d, m, &buf);
    if (ercd != E_OK)
        return ercd;
    p = (T_DIR_ENTRY *)buf + entrno % DIR_ENTRYS_PER_SECTOR;
    n = read_le16(&p->clusno);
    if (n != 0 && d->saveclus > n - 1)
        d->saveclus = (UH)(n - 1);
    p->name[0] = 0xe5;
    ercd = write_dir(d, m, buf);
    if (ercd != E_OK)
        return ercd;
    while (n != 0)
        n = del_cluster(d, n);
    return E_OK;
}

/************************************************/
/* Set Directory Entry                          */
/************************************************/

static ER set_dir_entry(T_DISK *d, int entrno, T_DIR_ENTRY *dir)
{
    T_DIR_ENTRY *p;
    UB *buf;
    ER ercd;
    UW m;

    m = (UW)(entrno / DIR_ENTRYS_PER_SECTOR);
    ercd = read_dir(d, m, &buf);
    if (ercd != E_OK)
        return ercd;
  #ifdef TSTAMP
    tstamp(dir);
  #endif
    p = (T_DIR_ENTRY *)buf + entrno % DIR_ENTRYS_PER_SECTOR;
    memcpy(p, dir, DIR_ENTRY_SZ);
    return write_dir(d, m, buf);
}

/************************************************/
/* Set File Size of Directory Entry             */
/************************************************/

static ER set_filesize(T_DISK *d, int entrno, UW size)
{
    T_DIR_ENTRY *dir;
    UB *buf;
    ER ercd;
    UW m;

    m = (UW)(entrno / DIR_ENTRYS_PER_SECTOR);
    ercd = read_dir(d, m, &buf);
    if (ercd != E_OK)
        return ercd;
    dir = (T_DIR_ENTRY *)buf + entrno % DIR_ENTRYS_PER_SECTOR;
    write_le32(&dir->size, size);
    return write_dir(d, m, buf);
}

/************************************************/
/* File System Initialize                       */
/************************************************/

ER file_ini(T_FILE *f, INT nfile, ID tskid, ID semid)
{
  #ifndef SINGLE_TASK
    ER ercd;
  #endif

    if (nfile > 255)
        return E_PAR;
    NFILE = (UB)nfile;
    memset(f, 0, sizeof (T_FILE) * nfile);
    file = f;
    disk = NULL;

  #ifndef SINGLE_TASK
    if ((ID_LFS_SEM = (UH)semid) != 0) {
        if ((ercd = cre_sem(ID_LFS_SEM, &lfs_csem)) != E_OK)
            return ercd;
    } else {
        if ((ID_LFS_SEM = (UH)acre_sem(&lfs_csem)) < 0)
            return (ER)ID_LFS_SEM;
    }
  #endif
    donefini = 0x5aa5;
    return E_OK;
}

/************************************************/
/* Disk Drive Initialize                        */
/************************************************/

ER disk_ini(T_DISK *d, const char *drivename, DISK_FP func, UW addr, UW par)
{
    T_DISK *p;
    ER ercd;

    if (donefini != 0x5aa5)
        return FSYS_ER(-1); /* file_ini() not done */

    d->name = (char)toupper(drivename[0]);
    d->func = func;
    d->addr = addr;
    d->par = par;
    d->ch = 0;
    d->next = NULL;
    d->saveclus = 0;

    if (disk == NULL) {
        disk = d;
    } else {
        p = disk;
        d->ch++;
        while (p->next != NULL) {
            d->ch++;
            p = p->next;
        }
        p->next = d;
    }

    ercd = (*d->func)(d, TFN_HARDWARE_INIT, 0, NULL);
    if (ercd != E_OK)
        return ercd;
    return (*d->func)(d, TFN_IDENTIFY, 0, NULL);
}

/************************************************/
/* Make Directory List                          */
/************************************************/

static ER make_dir_list(T_FILE *f)
{
    T_DIR_ENTRY *dir = NULL;
    T_DISK *d;
    UB *buf;
    struct _direct *p;
    ER ercd;
    int i;
    UH n;

    d = f->d;
    p = (struct _direct *)f->buf;
    memset(p, 0, SECTOR_SIZE);
    n = f->entrno;
    ercd = read_dir(d, n / DIR_ENTRYS_PER_SECTOR, &buf);
    if (ercd != E_OK)
        return f->ercd = ercd;
    dir = (T_DIR_ENTRY *)buf;
    dir += n % DIR_ENTRYS_PER_SECTOR;

    for (i = 0; (n < (int)ROOT_DIR_ENTRYS && i < (SECTOR_SIZE / sizeof (struct _direct))); n++, dir++, p++, i++) {
        if (n % DIR_ENTRYS_PER_SECTOR == 0) {
            ercd = read_dir(d, n / DIR_ENTRYS_PER_SECTOR, &buf);
            if (ercd != E_OK)
                return f->ercd = ercd;
            dir = (T_DIR_ENTRY *)buf;
        }
        if (dir->name[0] == 0x00) /* end of entry table */
            break;
        dirname_to_path(dir->name, p->d_name);
        if ((UB)dir->name[0] == 0xe5) {
            p->d_name[0] = '?';
        } else {
            p->d_ino = (short)(0x1000 * d->ch + n + 1);
          #ifdef DIRECT_FSIZE
            lto_u(p->fsize, read_le32(&dir->size), 8);
          #endif
        }
    }
    f->entrno = n;
    f->size += i * sizeof (struct _direct);
    return E_OK;
}

/************************************************/
/* Get T_DISK Address                           */
/************************************************/

static ER get_disk(const char **path, T_DISK **pd)
{
    T_DISK *d;
    char c;

    if ((d = disk) == NULL)
        return FSYS_ER(EV_DRIVE);
    if ((*path)[1] == ':') {
        c = (char)toupper((*path)[0]);
        while (d->name != c) {
            d = d->next;
            if (d == NULL)
                return FSYS_ER(EV_DRIVE);
        }
        *path += 2; /* next of drive name */
    }
    if ((*path)[0] == '\\')
        *path += 1;
    *pd = d;
    return (d->ercd = E_OK);
}

/************************************************/
/* Normalize File Path                          */
/************************************************/

static ER normalize_path(char *fname, const char *path)
{
    T_DISK *d;
    ER ercd;
    char c;

    if (path == NULL || path[0] == '\0')
        return EV_FSYS_NAME;

    ercd = get_disk(&path, &d);
    if (ercd != E_OK)
        return ercd;
    *fname++ = d->name;
    *fname++ = ':';
    if (strlen(path) > FILENAME_MAX - 2)
        return EV_FSYS_NAME;
    while ((c = *path++) != '\0')
        *fname++ = (char)toupper(c);
    *fname = '\0';
    return E_OK;
}

/************************************************/
/* File Seek                                    */
/************************************************/

static ER file_seek(T_FILE *f, UW pos)
{
    T_DISK *d;
    char *p;
    ER ercd;
    W m;
    UW n, i;
    UW n0;      /* seek start sector number */
    UW nn;      /* previous sector number */

    if (f->stat == 0)
        return f->ercd = EV_FSYS_PAR;
    if (pos > f->size)
        return f->ercd = EOF;
    d = f->d;
    if (f->byteno == (UH)(-1)) {
        m = (W)(pos / SECTOR_SIZE);
        f->sectno = (UW)-1L;
        n = cluster_to_sector(d, f->start);
    } else {
        m = (W)(pos / SECTOR_SIZE - (f->pos - f->byteno) / SECTOR_SIZE);
        if ((m != 0) &&                 /* need to move sector */
            (f->stat & TFS_CHANGED)) {  /* buffer is updated */
            ercd = (*d->func)(d, TFN_WRITE_SECTOR, f->sectno, f->buf);
            if (ercd != E_OK)
                return f->ercd = ercd;
            f->stat &= ~TFS_CHANGED;
        }
        if (m >= 0) {
            n = f->sectno;
        } else {
            m = (W)(pos / SECTOR_SIZE);
            n = cluster_to_sector(d, f->start);
        }
    }

    n0 = n;
    for (i = 0; i < m; i++) {
        nn = n;
        n = next_sector(d, n);
        if (n == 0) {
            if (m - i == 1 && pos == f->size && (pos % SECTOR_SIZE == 0)) {
                n = nn;
            } else {
                if (n0 == cluster_to_sector(d, f->start))
                    f->pos = (i + 1) * SECTOR_SIZE;
                else
                    f->pos = (f->pos - f->byteno) + (i + 1) * SECTOR_SIZE;
                f->byteno = (UH)-1;
                return f->ercd = EV_FATLINK;
            }
            break;
        }
    }
    if (f->sectno != n) {
        ercd = (*d->func)(d, TFN_READ_SECTOR, n, &p);
        if (ercd != E_OK)
            return f->ercd = ercd;
        memcpy(f->buf, p, SECTOR_SIZE);
        f->sectno = n;
    }
    f->pos = pos;
    f->byteno = (UH)(pos % SECTOR_SIZE);
    if (f->byteno == 0 && pos == f->size && pos != 0) {
        f->byteno = SECTOR_SIZE;
        if (SECTORS_PER_CLUSTER >= 2 &&
            pos % (SECTORS_PER_CLUSTER * SECTOR_SIZE) != 0)
            f->sectno--;
    }
    return E_OK;
}

int my_fseek(FILE *fp, W offs, int mode)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;
    UW pos;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return -1;
    }
    wai_sem(ID_LFS_SEM);
    if (mode == SEEK_CUR)
        pos = f->pos + offs;
    else if (mode == SEEK_END)
        pos = f->size + offs;
    else /* SEEK_SET */
        pos = offs;
    ercd = file_seek(f, pos);
    f->ercd = ercd;
    if (ercd != E_OK) {
        FSYS_ER(ercd);
        sig_sem(ID_LFS_SEM);
        return -1;
    }
    sig_sem(ID_LFS_SEM);
    return 0;
}

/************************************************/
/* Open File                                    */
/************************************************/

static ER file_open(T_FILE *f, const char *path, const char *mode)
{
    T_DISK *d;
    T_DIR_ENTRY dir;
    UB *p;
    ER ercd;
    int entrno;
    UH n = 0;
    char name[8+3];

    ercd = get_disk(&path, &d);
    if (ercd != E_OK)
        return ercd;
    f->d = d;

    if (path[0] == '.') { /* opendir */
        f->stat = TFS_RD_MODE;
        f->size = 0;
        f->entrno = 0;
        f->start = 0;
        f->byteno = 0;
        f->sectno = 0;
        f->pos = 0;
        return make_dir_list(f);
    }

    if (path_to_dirname(path, name) == NULL)
        return EV_NOFILE;
    ercd = find_dir_entry(d, &entrno, &dir, name);
    if (ercd != E_OK)
        return ercd;

    if (mode[0] == 'w' || mode[0] == 'a') {
        if (entrno != -1) {
            if (mode[0] == 'w') {
                ercd = del_dir_entry(d, entrno);
                if (ercd != E_OK)
                    return ercd;
            } else { /* 'a' */
                n = read_le16(&dir.clusno);
                ercd = (*d->func)(d, TFN_READ_SECTOR, cluster_to_sector(d, n), &p);
                if (ercd != E_OK)
                    return ercd;
                memcpy(f->buf, p, SECTOR_SIZE);
                f->stat = TFS_WR_MODE|TFS_OPENED;
                f->size = read_le32(&dir.size);
                goto END;
            }
        }
        ercd = find_dir_entry(d, &entrno, &dir, NULL);
        if (ercd != E_OK)
            return ercd;
        if (entrno == -1)
            return EV_DISKFULL;
        ercd = new_cluster(d, 0, &n);
        if (ercd != E_OK)
            return ercd;
        memcpy(dir.name, name, 8 + 3);
        memset(dir.name + 8 + 3, 0, DIR_ENTRY_SZ - (8 + 3));
        write_le16(&dir.clusno, n);
        ercd = set_dir_entry(d, entrno, &dir);
        if (ercd != E_OK)
            return ercd;
        memset(f->buf, 0, SECTOR_SIZE);
        f->stat = TFS_WR_MODE|TFS_OPENED;
        f->size = 0;
    } else if (mode[0] == 'r') {
        if (entrno == -1)
            return EV_NOFILE;
        n = read_le16(&dir.clusno);
        ercd = (*d->func)(d, TFN_READ_SECTOR, cluster_to_sector(d, n), &p);
        if (ercd != E_OK)
            return ercd;
        memcpy(f->buf, p, SECTOR_SIZE);
        f->stat = TFS_RD_MODE|TFS_OPENED;
        f->size = read_le32(&dir.size);
    }
    else
        return EV_FSYS_PAR;
END:
    f->byteno = 0;
    f->pos = 0;
    f->entrno = (UH)entrno;
    f->start = n;
    f->sectno = cluster_to_sector(d, n);
    if (mode[0] == 'a') {
        if ((ercd = file_seek(f, f->size)) != E_OK) {
            f->stat = 0;
            return ercd;
        }
    }
    return E_OK;
}

FILE *my_fopen(const char *path, const char *mode)
{
    T_FILE *f;
    const char *p;
    ER ercd;
    BOOL wr;
    int n;
    char fname[FILENAME_MAX+1];

    wai_sem(ID_LFS_SEM);

    /* prevent multiple open */
    wr = FALSE;
    for (p = mode; *p != '\0'; p++) {
        if (strchr("+aAwW", *p) != 0) {
            wr = TRUE;
            break;
        }
    }
    f = file;
    ercd = normalize_path(fname, path);
    if (ercd != E_OK) {
        FSYS_ER(ercd);
        sig_sem(ID_LFS_SEM);
        return NULL;
    }
    for (n = NFILE; n != 0; n--, f++) {
        if (strcmp(f->name, fname) == 0) {
            if ((f->stat & TFS_WR_MODE) || wr) {
                FSYS_ER(EV_ALREADY);
                sig_sem(ID_LFS_SEM);
                return NULL;
            }
            break;
        }
    }

    for (n = NFILE, f = file; n != 0; n--, f++) {
        if (f->stat == 0) {
            strncpy(f->name, fname, FILENAME_MAX);
            ercd = file_open(f, fname, mode);
            if (ercd != E_OK) {
                FSYS_ER(ercd);
                memset(f->name, 0, FILENAME_MAX);
                sig_sem(ID_LFS_SEM);
                return NULL;
            } else {
                sig_sem(ID_LFS_SEM);
                return (FILE *)f;
            }
        }
    }
    FSYS_ER(EV_NOFCB);
    sig_sem(ID_LFS_SEM);
    return NULL;
}

/************************************************/
/* Close File                                   */
/************************************************/

static ER file_close(T_FILE *f)
{
    T_DISK *d;
    ER ercd;

    if (f->stat == 0)
        return f->ercd = EV_FSYS_PAR;
    d = f->d;

    if (f->stat & TFS_CHANGED) {
        ercd = (*d->func)(d, TFN_WRITE_SECTOR, f->sectno, f->buf);
        if (ercd != E_OK) {
            f->ercd = ercd;
            goto END;
        }
    }
    ercd = set_filesize(d, f->entrno, f->size);
    if (ercd != E_OK) {
        f->ercd = ercd;
        goto END;
    }
END:
    f->stat = 0;
    memset(f->name, 0, FILENAME_MAX);
    return ercd;
}

int my_fclose(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return EOF;
    }
    wai_sem(ID_LFS_SEM);
    ercd = file_close(f);
    if (ercd != E_OK) {
        FSYS_ER(ercd);
        sig_sem(ID_LFS_SEM);
        return EOF;
    }
    sig_sem(ID_LFS_SEM);
    return 0;
}

/************************************************/
/* Read Character from File                     */
/************************************************/

static ER file_getc(T_FILE *f, UB *c)
{
    T_DISK *d;
    UB *p;
    ER ercd;
    UW n;

    if (f->stat == 0)
        return E_OBJ;
    if (f->byteno == (UH)-1)
        return f->ercd = EV_FATLINK;
    d = f->d;

    if (f->byteno == SECTOR_SIZE) {
        if (f->start == 0) { /* readdir */
            ercd = make_dir_list(f);
            if (ercd != E_OK)
                return ercd;
        } else {
            if (f->stat & TFS_CHANGED) {
                ercd = (*d->func)(d, TFN_WRITE_SECTOR, f->sectno, f->buf);
                if (ercd != E_OK)
                    return f->ercd = ercd;
                f->stat &= ~TFS_CHANGED;
            }
            n = next_sector(d, f->sectno);
            if (n == 0)
                return EOF;
            ercd = (*d->func)(d, TFN_READ_SECTOR, n, &p);
            if (ercd != E_OK)
                return f->ercd = ercd;
            memcpy(f->buf, p, SECTOR_SIZE);
            f->sectno = n;
        }
        f->byteno = 0;
    }
    if (f->pos >= f->size)
        return EOF;
    *c = *((UB *)f->buf + f->byteno++);
    f->pos++;
    return E_OK;
}

int my_fgetc(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;
    UB c;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return EOF;
    }
    wai_sem(ID_LFS_SEM);
    ercd = file_getc(f, &c);
    if (ercd != E_OK) {
        FSYS_ER(ercd);
        sig_sem(ID_LFS_SEM);
        return EOF;
    }
    sig_sem(ID_LFS_SEM);
    return (int)c;
}

/************************************************/
/* Write Character to File                      */
/************************************************/

static ER file_putc(T_FILE *f, UB c)
{
    T_DISK *d;
    char *p;
    ER ercd;
    UW n;

    if (f->stat == 0)
        return f->ercd = EV_FSYS_PAR;
    if (f->byteno == (UH)-1)
        return f->ercd = EV_FATLINK;
    d = f->d;

    if (f->byteno == SECTOR_SIZE) {
        if (f->stat & TFS_CHANGED) {
            ercd = (*d->func)(d, TFN_WRITE_SECTOR, f->sectno, f->buf);
            if (ercd != E_OK)
                return f->ercd = ercd;
            f->stat &= ~TFS_CHANGED;
        }
        n = next_sector(d, f->sectno);
        if (n == 0) {
            ercd = new_sector(d, f->sectno, &n);
            if (ercd != E_OK)
                return ercd;
            memset(f->buf, 0, SECTOR_SIZE);
        } else {
            ercd = (*d->func)(d, TFN_READ_SECTOR, n, &p);
            if (ercd != E_OK)
                return f->ercd = ercd;
            memcpy(f->buf, p, SECTOR_SIZE);
        }
        f->sectno = n;
        f->byteno = 0;
    }
    *((UB *)f->buf + f->byteno++) = c;
    if (++f->pos > f->size)
        f->size = f->pos;
    f->stat |= TFS_CHANGED;
    return E_OK;
}

int my_fputc(int c, FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return EOF;
    }
    wai_sem(ID_LFS_SEM);
    ercd = file_putc(f, (UB)c);
    if (ercd != E_OK) {
        FSYS_ER(ercd);
        sig_sem(ID_LFS_SEM);
        return EOF;
    }
    sig_sem(ID_LFS_SEM);
    return c;
}

/************************************************/
/* Read String from File                        */
/************************************************/

char *my_fgets(char *buf, int len, FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;
    int i;
    UB c;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return NULL;
    }
    if (--len < 0) {
        FSYS_ER(EV_FSYS_PAR);
        return NULL;
    }
    wai_sem(ID_LFS_SEM);
    for (i = c = 0; i < len; ) {
        ercd = file_getc(f, &c);
        if (ercd != E_OK) {
            FSYS_ER(ercd);
            break;
        }
        buf[i++] = (char)c;
        if (c == '\n')  /* end if LF */
            break;
    }
    sig_sem(ID_LFS_SEM);

    buf[i] = '\0';
    if (i == 0 && len != 0)
        return NULL;    /* end of file */
    else
        return buf;
}

/************************************************/
/* Write String to File                         */
/************************************************/

int my_fputs(const char *buf, FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    ER ercd;
    int c;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return EOF;
    }
    wai_sem(ID_LFS_SEM);
    while ((c = *buf++) != '\0') {
        ercd = file_putc(f, (UB)c);
        if (ercd != E_OK) {
            FSYS_ER(ercd);
            sig_sem(ID_LFS_SEM);
            return EOF;
        }
    }
    sig_sem(ID_LFS_SEM);
    return c;
}

/************************************************/
/* Read Block from File                         */
/************************************************/

size_t my_fread(void *buf, size_t bsize, size_t n, FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    UB *b;
    ER ercd;
    UW i;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return 0;
    }
    n *= bsize;
    if (n == 0)
        return 0;
    b = (UB *)buf;
    wai_sem(ID_LFS_SEM);
    for (i = 0; i < n; i++) {
        ercd = file_getc(f, b++);
        if (ercd != E_OK) {
            FSYS_ER(ercd);
            break;
        }
    }
    sig_sem(ID_LFS_SEM);
    return (size_t)(i / bsize);
}

/************************************************/
/* Write Block to File                          */
/************************************************/

size_t my_fwrite(const void *buf, size_t bsize, size_t n, FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    UB *b;
    ER ercd;
    UW i;

    n *= bsize;
    if (n == 0)
        return 0;
    b = (UB *)buf;
    wai_sem(ID_LFS_SEM);
    for (i = 0; i < n; i++) {
        ercd = file_putc(f, *b++);
        if (ercd != E_OK) {
            FSYS_ER(ercd);
            break;
        }
    }
    sig_sem(ID_LFS_SEM);
    return (size_t)(i / bsize);
}

/************************************************/
/* Determine File Position                      */
/************************************************/

long my_ftell(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    long pos;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return -1;
    }
    wai_sem(ID_LFS_SEM);
    if (f->stat != 0)
        pos = (long)f->pos;
    else
        pos = -1;
    sig_sem(ID_LFS_SEM);
    return pos;
}

/************************************************/
/* Test for End-of-File                         */
/************************************************/

int my_feof(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;
    int r;

    if (f == NULL) {
        FSYS_ER(EV_NOOPEN);
        return 0;
    }
    wai_sem(ID_LFS_SEM);
    if (f->stat != 0)
        r = (f->pos == f->size);
    else
        r = 0;
    sig_sem(ID_LFS_SEM);
    return r;
}

/************************************************/
/* Remove File                                  */
/************************************************/

static ER file_delete(const char *path)
{
    T_DISK *d;
    T_DIR_ENTRY dir;
    ER ercd;
    int entrno;
    char name[8+3];

    ercd = get_disk(&path, &d);
    if (ercd != E_OK)
        return ercd;

    if (path_to_dirname(path, name) == NULL)
        return EV_NOFILE;
    ercd = find_dir_entry(d, &entrno, &dir, name);
    if (ercd != E_OK)
        return ercd;
    if (entrno == -1)
        return EV_NOFILE;
    return del_dir_entry(d, entrno);
}

int my_remove(const char *path)
{
    T_FILE *f;
    ER ercd;
    int n;
    char fname[FILENAME_MAX+1];

    wai_sem(ID_LFS_SEM);
    ercd = normalize_path(fname, path);
    if (ercd != E_OK)
        goto ERR;

    for (n = NFILE, f = file; n != 0; n--, f++) {
        if ((f->stat != 0) && (strcmp(f->name, fname) == 0)) {
            ercd = EV_ALREADY;
            goto ERR;
        }
    }
    ercd = file_delete(fname);
    if (ercd == E_OK) {
        sig_sem(ID_LFS_SEM);
        return 0;
    }
ERR:
    FSYS_ER(ercd);
    sig_sem(ID_LFS_SEM);
    return -1;
}

/************************************************/
/* Rename File                                  */
/************************************************/

static ER file_rename(const char *oldpath, const char *newpath)
{
    T_DISK *d;
    T_DIR_ENTRY dir;
    ER ercd;
    int entrno;
    char c;
    char name[8+3];
    char newname[8+3];

    ercd = get_disk(&oldpath, &d);
    if (ercd != E_OK)
        return ercd;
    if (newpath[1] == ':') {
        c = (char)toupper(newpath[0]);
        if (d->name != c)
            return EV_DRIVE;
        newpath += 2;
    }
    if (newpath[0] == '\\')
        newpath += 1;

    if (path_to_dirname(newpath, newname) == NULL)
        return EV_NOFILE;
    ercd = find_dir_entry(d, &entrno, &dir, newname);
    if (ercd != E_OK)
        return ercd;
    if (entrno != -1)
        return EV_EXIST;

    if (path_to_dirname(oldpath, name) == NULL)
        return EV_NOFILE;
    ercd = find_dir_entry(d, &entrno, &dir, name);
    if (ercd != E_OK)
        return ercd;
    if (entrno == -1)
        return EV_NOFILE;

    memcpy(dir.name, newname, 8 + 3);
    return set_dir_entry(d, entrno, &dir);
}

int my_rename(const char *oldpath, const char *newpath)
{
    T_FILE *f;
    ER ercd;
    int n;
    char oldbuf[FILENAME_MAX+1];
    char newbuf[FILENAME_MAX+1];

    wai_sem(ID_LFS_SEM);

    ercd = normalize_path(oldbuf, oldpath);
    if (ercd != E_OK)
        goto ERR;
    ercd = normalize_path(newbuf, newpath);
    if (ercd != E_OK)
        goto ERR;

    for (n = NFILE, f = file; n != 0; n--, f++) {
        if ((f->stat != 0) &&
            (strcmp(f->name, oldbuf) == 0 || strcmp(f->name, newbuf) == 0)) {
            ercd = EV_ALREADY;
            goto ERR;
        }
    }
    ercd = file_rename(oldbuf, newbuf);
    if (ercd == E_OK) {
        sig_sem(ID_LFS_SEM);
        return 0;
    }
ERR:
    FSYS_ER(ercd);
    sig_sem(ID_LFS_SEM);
    return -1;
}

/************************************************/
/* Get Error                                    */
/************************************************/

int my_ferror(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;

    return f->ercd;
}

/************************************************/
/* Clear Error                                  */
/************************************************/

void my_clearerr(FILE *fp)
{
    T_FILE *f = (T_FILE *)fp;

    f->ercd = 0;
}

/************************************************/
/* Disk Fromat                                  */
/************************************************/

int my_dformat(const char *drivename)
{
    T_FILE *f;
    T_DISK *d;
    ER ercd;
    int n;
    char path[3];

    wai_sem(ID_LFS_SEM);

    if ((path[0] = drivename[0]) != '\0') {
        path[1] = ':';
        path[2] = '\0';
    }
    drivename = path;
    ercd = get_disk(&drivename, &d);
    if (ercd != E_OK)
        goto ERR;

    for (n = NFILE, f = file; n != 0; n--, f++) {
        if (f->stat != 0 && f->d == d) {
            ercd = EV_ALREADY;
            goto ERR;
        }
    }

    ercd = (*d->func)(d, TFN_FORMAT, 0, NULL);
    if (ercd == E_OK) {
        sig_sem(ID_LFS_SEM);
        return 0;
    }
ERR:
    FSYS_ER(ercd);
    sig_sem(ID_LFS_SEM);
    return -1;
}

/* end */
