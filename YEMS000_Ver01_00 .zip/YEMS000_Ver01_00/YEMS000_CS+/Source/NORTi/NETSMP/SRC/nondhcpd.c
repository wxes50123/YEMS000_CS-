/******************************************************************************
* DHCP Server Sample                                                          *
*                                                                             *
*  Copyright (c) 2003-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2003-06-17 Created                                                          *
* 2008-06-23 Fixed bug of dhcpd_get_unused() when check == 1                  *
* 2024-06-13 Replaced NORTi3 based system calls with NORTi4 based ones     FY *
* 2024-06-13 Removed excessive cast of memset/memcpy/memcmp() arguments    FY *
* 2024-06-13 Fixed memcmp() 1'st argument &hw to hw in dhcpd_add_addr()    FY *
* 2024-06-13 Corrected timeout in dhcp_lease_check() not to be negative    FY *
* 2024-06-13 Removed unfunctional address match check in dhcpd_get_unused  FY *
* 2024-06-13 Removed unused hname member (client name) of T_DHCP_LIST      FY *
* 2024-06-13 Changed API error code from -1/-2/-3 to E_PAR/NOID/OBJ/NOEXS  FY *
* 2024-06-13 Fixed lease time & subnet of reply packet in dhcpd_process()  FY *
* 2024-06-13 Renamed dhcpinfo[DHCPD_IP_LIST to assigned_ipaddr[CLIENT_CNT,    *
*            dhcp_user_conf[DHCPD_USERIP_LIST to userdef_ipaddr[USERDEF_CNT,  *
*            dhcp_addr_pool[DHCPD_ADDR_POOL to pooled_ipaddr[POOL_CNT and     *
*            T_DHCP_SUB to T_DHCP_POOL, and minimized T_DHCP_LIST's haddr  FY *
* 2024-06-13 Fixed dhcpd_process() to reflect client requested lease time  FY *
* 2024-06-13 Modified dhcpd_ini() to create 2nd task with tskid+1 not auto FY *
* 2024-06-13 Replaced fixed-size memorypool by local buffer in dhcp_server FY *
* 2024-06-13 Removed dhcpd_del_group() 1st parameter, subnet mask          FY *
* 2024-06-13 Added received packet length and its option length check      FY *
* 2024-06-13 Replaced dhcpd_internal_error() after udp_rcv_dat by dly_tsk  FY *
* 2024-06-13 Swapped TA_HLNG and NULL in T_CTSK dhcpd_ctsk/lease_ctsk      GS *
* 2024-06-14 Replaced include of nonetc.h with nosys4.h to reference SYSCK FY *
* 2024-06-14 Replaced *(UW *)p=htonl(..) with long_to_byte4(p,..) to avoid    *
*               address error not on long-word boundary in dhcpd_process() FY *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nosys4.h"
#include "nonet.h"
#include "nonets.h"
#include "nondhcp.h"

/* Configuration */

#define CLIENT_CNT          10      /* maximum number of DHCP clients */
#define USERDEF_CNT         2       /* maximum number of user defined IP addresses */
#define POOL_CNT            1       /* number of IP address pools */

/* Timing for DHCP Server (in seconds) */

#define DEFAULT_LEASE       86400   /* default lease time */
#define DHCP_RELEASE_TIM    1       /* defautl Release time */
#define DHCP_OFFER_TIM      10      /* time to keep offered address */
#define DHCP_MIN_LEASE      10      /* minimum lease time */
#define DHCP_MAX_LEASE      86400   /* maximum lease time */

/* Object Creation Information */

TASK dhcp_server(void);
TASK dhcp_lease_check(void);
const T_CTSK dhcpd_ctsk = { TA_HLNG, NULL, (FP)dhcp_server, DHCPD_TSK_PRI, DHCPD_TSK_SSZ };
const T_CTSK lease_ctsk = { TA_HLNG, NULL, (FP)dhcp_lease_check, DHCPD_TSK_PRI, 512 };

#define BOOTP_SERVER_PORT   67      /* BOOTP server port number */
#define BOOTP_CLIENT_PORT   68      /* BOOTP client port number */
const T_UDP_CCEP dhcpd_cep = { 0, { 0, BOOTP_SERVER_PORT }, NULL };

/* Option for Reply */

const UB dhcpoffer[] = { 99, 130, 83, 99, DHCP_OP_MSGTYP, 01, DHCPOFFER };
const UB dhcpack[]   = { 99, 130, 83, 99, DHCP_OP_MSGTYP, 01, DHCPACK };
const UB dhcpnak[]   = { 99, 130, 83, 99, DHCP_OP_MSGTYP, 01, DHCPNAK };

/* Assigned IP Address List */

typedef struct t_dhcp_list {
    UW ipaddr;                      /* client IP address */
    UW subnet;                      /* client subnet mask */
    UW lease;                       /* requested lease time */
    UW rtime;                       /* lease expired time */
    UB haddr[6];                    /* client hardware address (MAC address) */
    UB state;                       /* DHCP state */
} T_DHCP_LIST;

#define DHCP_UNUSED       0
#define DHCP_OFFERED      1
#define DHCP_USED         2
#define DHCP_RELEASED     3

T_DHCP_LIST assigned_ipaddr[CLIENT_CNT];

/* User Defined IP Address list */

T_DHCP_LIST userdef_ipaddr[USERDEF_CNT];

/* IP Address Pool (assignable range) */

typedef struct t_dhcp_pool {
    UW subnet;                      /* subnet mask */
    UW ipaddr1;                     /* start IP address */
    UW ipaddr2;                     /* end IP address */
} T_DHCP_POOL;

T_DHCP_POOL pooled_ipaddr[POOL_CNT];

/* DHCP Server Control Block */

typedef struct t_dhcpd_cb {
    UH tskid;
    UH timid;
    UH cepid;
} T_DHCPD_CB;

T_DHCPD_CB dhcpd;

/*****************************************************************************
* DHCP Server Lease Check Task
*
******************************************************************************/

TASK dhcp_lease_check()
{
    TMO r, t;
    int i;

    for (;;) {
        t = 1000/MSEC;

        /* check for lease expired time */
        for (i = 0; i < CLIENT_CNT; i++) {
            if (assigned_ipaddr[i].state == DHCP_USED ||
                assigned_ipaddr[i].state == DHCP_OFFERED) {
                r = assigned_ipaddr[i].rtime - SYSCK.ltime;
                if (r <= 0) {
                    /* lease expired */
                    assigned_ipaddr[i].state = DHCP_RELEASED;
                    assigned_ipaddr[i].rtime = SYSCK.ltime + DHCP_RELEASE_TIM * 1000/MSEC;
                } else if (r < t) {
                    t = r;
                }
            }
        }

        /* check for release time */
        for (i = 0; i < CLIENT_CNT; i++) {
            if (assigned_ipaddr[i].state == DHCP_RELEASED) {
                r = assigned_ipaddr[i].rtime - SYSCK.ltime;
                if (r <= 0)
                    memset(&assigned_ipaddr[i], 0, sizeof (T_DHCP_LIST));
                else if (r < t)
                    t = r;
            }
        }

        /* wait for time to expire */
        tslp_tsk(t);
    }
}

/*****************************************************************************
* Search DHCP Vender Option
*
******************************************************************************/

static UB *search_option(UB tag, UB *opt, int optsz, int optlen)
{
    UB n;

    if (opt == NULL)
        return NULL;

    /* skip magic cookie */
    if ((optlen -= 4) <= 0)
        return NULL;
    opt += 4;

    /* search option */
    while (optlen != 0) {
        if (*opt == 255)
            return NULL;
        if ((optlen -= 2) < 0)
            return NULL;
        if ((optlen -= *(opt + 1)) < 0)
            return NULL;
        if (*opt++ == tag) {
            if (*opt++ < optsz)
                return NULL;
            return opt;
        }
        n = *opt++;
        opt += n;
    }
    return NULL;
}

/*****************************************************************************
* Search and Return Required or Unused Address
*
******************************************************************************/

int dhcpd_get_unused(T_DHCP *pkt, int optlen)
{
    UW myip, mask, reqipaddr, addr1, addr2;
    UB *p, check;
    int i, n;

    /* check for free space for new entry */
    for (n = -1, i = 0; i < CLIENT_CNT; i++) {
        if (assigned_ipaddr[i].state == DHCP_UNUSED) {
            n = i;
            break;
        }
    }

    /* free space not available */
    if (n == -1)
        return n;

    /* search for a match in user entry */
    for (i = 0; i < USERDEF_CNT; i++) {
        if (memcmp(pkt->chaddr, userdef_ipaddr[i].haddr, 6) == 0) {
            memcpy(&assigned_ipaddr[n], &userdef_ipaddr[i], sizeof (T_DHCP_LIST));
            return n;
        }
    }

    /* get client requested ipaddr */
    reqipaddr = 0;
    p = search_option(DHCP_OP_ADRREQ, pkt->option, 4, optlen);
    if (p != NULL) {
        reqipaddr = byte4_to_long(p);

        /* check for consistancy */
        for (i = 0; i < CLIENT_CNT; i++) {
            if (reqipaddr == assigned_ipaddr[i].ipaddr)
                return -1;
        }

        for (i = 0; i < POOL_CNT; i++) {
            addr1 = pooled_ipaddr[i].ipaddr1;
            mask = pooled_ipaddr[i].subnet;
            if (addr1 == 0 || mask == 0)
                continue;
            addr2 = pooled_ipaddr[i].ipaddr2;
            if (reqipaddr >= addr1 && reqipaddr <= addr2) {
                assigned_ipaddr[n].ipaddr = reqipaddr;
                assigned_ipaddr[n].subnet = mask;
                assigned_ipaddr[n].lease = DEFAULT_LEASE;
                memcpy(assigned_ipaddr[n].haddr, pkt->chaddr, 6);
                return n;
            }
        }
    }

    check = 0;
    /* get unused ipaddr from address pool */
    for (i = 0; i < POOL_CNT; i++) {
        addr1 = pooled_ipaddr[i].ipaddr1;
        mask = pooled_ipaddr[i].subnet;
        if (addr1 == 0 || mask == 0)
            continue;
        addr2 = pooled_ipaddr[i].ipaddr2;
        for (myip = addr1; myip <= addr2; myip++) {
            check = 0;
            /* check for existance */
            for (i = 0; i < CLIENT_CNT; i++) {
                if (myip == assigned_ipaddr[i].ipaddr) {
                    check = 1;
                    break;
                }
            }
            if (check == 0) {
                for (i = 0; i < USERDEF_CNT; i++) {
                    if (myip == userdef_ipaddr[i].ipaddr) {
                        check = 1;
                        break;
                    }
                }
            }
            if (check == 0)
                break;
        }

        if (check != 0)
            continue;

        assigned_ipaddr[n].ipaddr = myip;
        assigned_ipaddr[n].subnet = mask;
        assigned_ipaddr[n].lease = DEFAULT_LEASE;
        memcpy(assigned_ipaddr[n].haddr, pkt->chaddr, 6);
        return n;
    }
    return -1;
}

/*****************************************************************************
* Process DHCP Client Request
*
******************************************************************************/

static ER dhcpd_process(T_DHCP *pkt, int pktlen)
{
    T_IPV4EP dstaddr;
    UW ipaddr, reqipaddr, ciaddr;
    UB *p, type, msgtype;
    int optlen, i;

    optlen = pktlen - (sizeof (T_DHCP) - DHCP_OPTLEN);
    if (optlen < 0)
        return -1;

    ipaddr = ntohl(pkt->siaddr);
    if (ipaddr != 0 && ipaddr != byte4_to_long(default_ipaddr))
        return -1;

    /* check for DHCP server */
    ipaddr = 0;
    p = search_option(DHCP_OP_SERVID, pkt->option, 4, optlen);
    if (p != NULL) {
        ipaddr = byte4_to_long(p);
        if (ipaddr != byte4_to_long(default_ipaddr))
            return -1;
    }

    /* get client requested ipaddr */
    reqipaddr = 0;
    p = search_option(DHCP_OP_ADRREQ, pkt->option, 4, optlen);
    if (p != NULL)
        reqipaddr = byte4_to_long(p);

    /* get address for this client */
    for (i = 0; ; i++) {
        if (memcmp(pkt->chaddr, assigned_ipaddr[i].haddr, 6) == 0)
            break;
        if (i == CLIENT_CNT - 1) {
            i = -1;
            break;
        }
    }

    /* get DHCP Message Type */
    p = search_option(DHCP_OP_MSGTYP, pkt->option, 1, optlen);
    if (p == NULL)
        return -1;

    switch (msgtype = *p) {
    case DHCPDISCOVER:
        if (i < 0) {
            if ((i = dhcpd_get_unused(pkt, optlen)) == -1)
                return -1;
        }
        break;
    case DHCPREQUEST:
        if (i < 0) {
            if ((i = dhcpd_get_unused(pkt, optlen)) == -1)
                return -1;
            pkt->flag = htons(0x8000);
        }
        break;
    case DHCPDECLINE:
    case DHCPRELEASE:
    case DHCPINFORM:
        if (i < 0)
            return -1;
    default:
        return -1;
    }

    /* get client requested lease time */
    p = search_option(DHCP_OP_ADDRTM, pkt->option, 4, optlen);
    if (p != NULL) {
        assigned_ipaddr[i].lease = byte4_to_long(p);

        if (assigned_ipaddr[i].lease < DHCP_MIN_LEASE)
            assigned_ipaddr[i].lease = DHCP_MIN_LEASE;
        else if (assigned_ipaddr[i].lease >  DHCP_MAX_LEASE)
            assigned_ipaddr[i].lease = DHCP_MAX_LEASE;
    }

    type = 0;
    ciaddr = ntohl(pkt->ciaddr);

    switch (msgtype) {
    case DHCPDISCOVER:
        pkt->yiaddr = htonl(assigned_ipaddr[i].ipaddr);
        assigned_ipaddr[i].state = DHCP_OFFERED;
        assigned_ipaddr[i].rtime = SYSCK.ltime + DHCP_OFFER_TIM * 1000/MSEC;
        type = DHCPOFFER;
        pkt->flag = htons(0x8000);
        break;
    case DHCPREQUEST:
        /* check for server identifier */
        if (ipaddr != 0) {  /* a reply of DHCPOFFER */
            pkt->flag = htons(0x8000);
            if (ciaddr == 0) {
                assigned_ipaddr[i].state = DHCP_USED;
                assigned_ipaddr[i].rtime = SYSCK.ltime + assigned_ipaddr[i].lease * 1000/MSEC;
                type = DHCPACK;
                /* send DHCP ACK */
            }
        } else {    /* reboot state */
            if (ciaddr == 0) {
                pkt->flag = htons(0x8000);
                if (reqipaddr == assigned_ipaddr[i].ipaddr) {
                    assigned_ipaddr[i].state = DHCP_USED;
                    assigned_ipaddr[i].rtime = SYSCK.ltime + assigned_ipaddr[i].lease * 1000/MSEC;
                    type = DHCPACK;
                    /* send ACK */
                } else {
                    type = DHCPNAK;
                    /* send NACK */
                }
            } else {    /* renewing or rebinding state */
                /* send DHCP ACK */
                assigned_ipaddr[i].state = DHCP_USED;
                assigned_ipaddr[i].rtime = SYSCK.ltime + assigned_ipaddr[i].lease * 1000/MSEC;
                type = DHCPACK;
            }
        }
        break;
    case DHCPDECLINE:
        /* mark address as unused */
        memset(&assigned_ipaddr[i], 0, sizeof (T_DHCP_LIST));
        return -1;
    case DHCPRELEASE:
        /* mark address as released */
        assigned_ipaddr[i].state = DHCP_RELEASED;
        assigned_ipaddr[i].rtime = SYSCK.ltime + DHCP_RELEASE_TIM * 1000/MSEC;
        return -1;
    case DHCPINFORM:
        /* send DHCPACK */
        dstaddr.ipaddr = htonl(ciaddr);
        pkt->yiaddr = 0;
        pkt->flag = htons(0x8000);
        type = DHCPACK;
        break;
    }
    if (type == 0)
        return -1;

    p = pkt->option;

    switch (type) {
    case DHCPNAK:
        pkt->ciaddr = 0;
        pkt->siaddr = 0;
        memcpy(p, dhcpnak, sizeof dhcpnak);
        p += sizeof dhcpnak;
        *p++ = DHCP_OP_SERVID;
        *p++ = 4;
        memcpy(p, default_ipaddr, 4);
        p += 4;
        break;
    case DHCPOFFER:
        pkt->ciaddr = 0;
        memcpy(p, dhcpoffer, sizeof dhcpoffer);
        p += sizeof dhcpoffer;
        break;
    case DHCPACK:
        pkt->yiaddr = htonl(assigned_ipaddr[i].ipaddr);
        memcpy(p, dhcpack, sizeof dhcpack);
        p += sizeof dhcpack;
        break;
    default:
        return -1;
    }

    /* fill required options */
    if (type != DHCPNAK) {
        /* server ID */
        *p++ = DHCP_OP_SERVID;
        *p++ = 4;
        memcpy(p, default_ipaddr, 4);
        p += 4;

        /* lease time */
        *p++ = DHCP_OP_ADDRTM;
        *p++ = 4;
        long_to_byte4(p, assigned_ipaddr[i].lease);
        p += 4;

        /* subnet mask */
        *p++ = DHCP_OP_SUBNET;
        *p++ = 4;
        long_to_byte4(p, assigned_ipaddr[i].subnet);
        p += 4;

        /* router ipaddr */
        *p++ = DHCP_OP_ROUTER;
        *p++ = 4;
        memcpy(p, default_gateway, 4);
        p += 4;

        /* DNS address */
        if (byte4_to_long(getnif_default()->dns_ipaddr) != 0) {
            *p++ = DHCP_OP_DNS;
            *p++ = 4;
            memcpy(p, getnif_default()->dns_ipaddr, 4);
            p += 4;
        }
    }
    *p++ = 255; /* end option */

    /* send DHCP reply */
    pkt->op   = BOOT_REPLY;
    pkt->hops = 0;
    pkt->secs = 0;

    if (ntohs(pkt->flag) == 0x8000)
        dstaddr.ipaddr = (UW)(-1);
    else
        dstaddr.ipaddr = htonl(assigned_ipaddr[i].ipaddr);

    dstaddr.portno = BOOTP_CLIENT_PORT;

    return udp_snd_dat(dhcpd.cepid, &dstaddr, pkt, (UW)p - (UW)pkt, 500/MSEC);
}

/*****************************************************************************
* DHCP Server Task
*
******************************************************************************/

TASK dhcp_server()
{
    static T_DHCP dhcp_pkt;
    T_IPV4EP dstaddr;
    ER ercd;

    /* intialize DHCP control address list */
    memset(assigned_ipaddr, 0, sizeof assigned_ipaddr);

    /* initialize User configuration list */
    memset(userdef_ipaddr, 0, sizeof userdef_ipaddr);

    /* initialize User address pool list */
    memset(pooled_ipaddr, 0, sizeof pooled_ipaddr);

    /* get memory buffer for receiving DHCP pakcet */
    for (;;) {
        ercd = udp_rcv_dat(dhcpd.cepid, &dstaddr, &dhcp_pkt, sizeof (T_DHCP), TMO_FEVR);
        if (ercd <= 0) {
            dly_tsk(100/MSEC);
        } else if (dhcp_pkt.op == BOOT_REQUEST) {
            dhcpd_process(&dhcp_pkt, ercd); /* ercd = packet length */
        }
    }
}

/*****************************************************************************
* Initialize DHCP Server
*
******************************************************************************/

ER dhcpd_ini(ID tskid, ID cepid)
{
    ID timid;
    ER ercd;

    /* create tasks */
    if (tskid != 0) {
        ercd = cre_tsk(tskid, &dhcpd_ctsk);
        if (ercd != E_OK)
            return ercd;
        timid = tskid + 1;
        ercd = cre_tsk(timid, &lease_ctsk);
        if (ercd != E_OK)
            goto ERR1;
    } else {
        tskid = acre_tsk(&dhcpd_ctsk);
        if (tskid <= 0)
            return tskid;
        ercd = acre_tsk(&lease_ctsk);
        if (ercd <= 0)
            goto ERR1;
        timid = ercd;
    }

    /* create UDP communication end point */
    if (cepid != 0) {
        ercd = udp_cre_cep(cepid, &dhcpd_cep);
        if (ercd != E_OK)
            goto ERR2;
    } else {
        ercd = udp_vcre_cep(&dhcpd_cep);
        if (ercd <= 0)
            goto ERR2;
        cepid = ercd;
    }

    /* set broadcast option */
    ercd = udp_set_opt(cepid, IP_BROADCAST, (VP)TRUE, 1);
    if (ercd != E_OK)
        goto ERR3;

    memset(&dhcpd, 0, sizeof (T_DHCPD_CB));
    dhcpd.tskid = (UH)tskid;
    dhcpd.timid = (UH)timid;
    dhcpd.cepid = (UH)cepid;

    ercd = sta_tsk(tskid, 0);
    if (ercd != E_OK)
        goto ERR3;
    ercd = sta_tsk(timid, 0);
    if (ercd != E_OK)
        goto ERR3;
    return E_OK;

ERR3:
    udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
    udp_del_cep(cepid);
ERR2:
    del_tsk(timid);
ERR1:
    del_tsk(tskid);
    return ercd;
}

/*****************************************************************************
* API to Register User Defined IP Address
*
******************************************************************************/

ER dhcpd_add_addr(UW ipaddr, UW subnet, UW lease, UB *hw)
{
    int i, n;

    /* validate parameters */
    if (ipaddr == 0 || subnet == 0 || hw == NULL)
        return E_PAR;
    if (lease == 0)
        lease = DEFAULT_LEASE;

    /* already used ? */
    for (n = -1, i = USERDEF_CNT - 1; i >= 0; i--) {
        if (userdef_ipaddr[i].ipaddr == 0)
            n = i;
        else if ((userdef_ipaddr[i].ipaddr == ipaddr) ||
                 (memcmp(userdef_ipaddr[i].haddr, hw, 6) == 0))
            return E_OBJ;
    }
    if (n < 0)
        return E_NOID; /* no space */

    userdef_ipaddr[n].ipaddr = ipaddr;
    userdef_ipaddr[n].subnet = subnet;
    userdef_ipaddr[n].lease = lease;
    memcpy(userdef_ipaddr[n].haddr, hw, 6);
    userdef_ipaddr[n].state = DHCP_UNUSED;

    return n;
}

/*****************************************************************************
* API to Unregister User Defined IP Address
*
******************************************************************************/

ER dhcpd_del_addr(UW ipaddr)
{
    int i;

    if (ipaddr == 0)
        return E_PAR;

    for (i = 0; i < USERDEF_CNT; i++) {
        if (userdef_ipaddr[i].ipaddr == ipaddr) {
            memset(&userdef_ipaddr[i], 0, sizeof (T_DHCP_LIST));
            return E_OK;
        }
    }
    return E_NOEXS;
}

/*****************************************************************************
* API to Register IP Address Group
*
******************************************************************************/

ER dhcpd_add_group(UW subnet, UW ipaddr1, UW ipaddr2)
{
    int i, n;

    if (subnet == 0 || ipaddr1 == 0 || ipaddr2 < ipaddr1 ||
        (ipaddr1 & subnet) != (ipaddr2 & subnet))
        return E_PAR;

    for (n = -1, i = POOL_CNT - 1; i >= 0; i--) {
        if (pooled_ipaddr[i].subnet == 0)
            n = i;
        else if (pooled_ipaddr[i].ipaddr1 == ipaddr1)
            return E_OBJ;
    }
    if (n < 0)
        return E_NOID; /* no space */

    pooled_ipaddr[n].subnet = subnet;
    pooled_ipaddr[n].ipaddr1 = ipaddr1;
    pooled_ipaddr[n].ipaddr2 = ipaddr2;

    return n;
}

/*****************************************************************************
* API to Unregister IP Address Group
*
******************************************************************************/

ER dhcpd_del_group(UW ipaddr1)
{
    int i;

    if (ipaddr1 == 0)
        return E_PAR;

    for (i = 0; i < POOL_CNT; i++) {
        if (pooled_ipaddr[i].ipaddr1 == ipaddr1) {
            memset(&pooled_ipaddr[i], 0, sizeof (T_DHCP_POOL));
            return E_OK;
        }
    }
    return E_NOEXS;
}

/* end */
