/******************************************************************************
* FTP Client Sample                                                           *
*                                                                             *
*  Copyright (c) 1999-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-05-30 Created                                                          *
* 1999-06-12 Added -d and -v options                                          *
* 1999-06-26 Modified responce receiving                                      *
* 1999-09-23 Auto-assigned CEP/REP IDs with tcp_vcre_cep()/tcp_vcre_rep()     *
* 2000-08-06 Added dly_tsk() for Windows NT                                   *
* 2000-02-10 Modified ftp_get_command for "No such file or directory"         *
* 2002-02-08 Changed msg_xx_yy[] type 'B' to 'char' to avoid CC32R warning OK *
* 2003-04-28 Added quit command                                            YS *
* 2003-04-28 Modified ftp_dir_command, ftp_get_command and ftp_put_command    *
             connection waiting from server                                YS *
* 2004-04-27 Added channel selection                                       PK *
* 2004-07-19 Added IPv6 Support                                            PK *
* 2004-07-19 Added channel selection for IPv6 client                       PK *
* 2004-11-12 ftp_rcv_rsp modified for response of QUIT command             PK *
* 2005-04-20 ftp_pasv_command added to support PASSIVE mode                PK *
* 2005-04-20 NOFILE_VER macro was added                                    NA *
* 2005-04-20 Channel selection updated                                     PK *
* 2005-04-25 ftp_epsv_command added to support PASSIVE mode                PK *
* 2005-05-10 Added ftp_port_command after ftp_pasv_command fails           EM *
* 2005-05-13 Modified V3 -> V4                                             AK *
* 2009-08-03 Added timeout parameter to terminal_input function            FY *
* 2012-07-05 Modified to get NIF with static route to remote if it is NULL FY *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2012-11-23 Deleted unused global variable                                FY *
* 2012-11-23 Fixed problem that interprets IPv6 address                       *
*                                 whose double figures is 'd' as c option  FY *
* 2012-12-19 Fixed so that response after 2nd might be read and thrown        *
*                                                 away by the dir command  FY *
* 2012-12-19 Fixed missing tcp_cls_cep() of data port in ftp(6)_client()   FY *
* 2013-01-24 Fixed problem that byte order of IP address becomes reverse      *
*                                                         by EPRT command  FY *
* 2014-07-04 Corrected ftp_rcv_response() to handle multi-line replies     FY *
* 2014-10-20 Fixed ftp_snd_rcv() not to write over buffer area             FY *
* 2014-10-20 Moved common part of command process to ftp_snd_rcv()         FY *
* 2014-10-20 Fixed ftp_pasv_command() to compare response code w/o message FY *
* 2014-10-20 Modified processing of parameter of commandline               FY *
* 2014-10-20 Collected calling of ftp_pasv/port_command()                  FY *
* 2014-10-20 Replaced atoi() with strtol()                                 FY *
* 2014-10-20 Added static qualifier to local function                      FY *
* 2014-10-20 Deleted meaningless retry of tcp_(v)cre_rep()                 FY *
* 2014-10-20 Changed ftp->cepid2 to ftp->cepid1 for getting                   *
*                         source IP address and port No. by tcp_ref_cep()  FY *
* 2014-10-20 Fixed violation of RFC2428 used space to delimiter               *
*                                                        for EPRT command  FY *
* 2015-11-09 Moved ANARES_LEN macro definition to here from nonftp.h       FY *
* 2016-03-28 Corrected ftp_port_command() returns value                       *
*                     from TRUE to FALSE when tcp_cre_rep() becomes error  FY *
* 2016-03-28 Fixed missing tcp_del_rep() when ftp_port_command() fails     FY *
* 2016-07-04 Modified help message and adjusted coding style               MI *
* 2023-06-21 Fixed return value TRUE to FALSE on tcp_cre_rep() error, and     *
*              added htonl() for ip4addr_to_ascii() in ftp_eprt_command()  FY *
* 2023-06-21 Added missing tcp_cls_cep()/tcp_del_rep() when returning         *
*                      FALSE by ftp_snd_rcv() failur in ftp_dir_command()  FY *
* 2023-06-21 Added missing nif = getnif_default() when getnif_addr()/         *
*                getnif_ip6addr() == NULL in ftp_command()/ftp6_command()  FY *
******************************************************************************/

#ifndef NOFILE_VER
#define NOFILE_VER  1
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#include "nonitod.h"
#if (NOFILE_VER == 4)
#include "nofile.h"
#include "nofftp.h"
#else
#include "nonfile.h"
#include "nonftp.h"
#endif
#include "nonteln.h"

extern T_FTP ftpc;
extern T_TERMINAL *current_terminal;

/* Message Strings */

static const char msg_ftpc_addr[] = "Invalid IP address.\r\n";
static const char msg_ftpc_help[] =
    "Usage : ftp [-v] [-d] [-i <nif>] <ipaddr>\r\n"
    "\t-v       - Suppresses display of FTP server responses\r\n"
    "\t-d       - Enables debugging\r\n"
    "\t<nif>    - Network interface name (e.g. eth0, eth1)\r\n"
    "\t<ipaddr> - IP address of FTP server (e.g. 192.168.1.1)\r\n";

/* Configuration */

#define FTP_TMOUT   (60000/MSEC)
#define ANARES_LEN  60      /* FTP response length to analyze in 1st line */

/*****************************************************************************
* Get token
*
******************************************************************************/

static const char *get_token(const char **s)
{
    const char *r, *t;

    t = *s;
    while (*t == ' ')
        t++;
    r = t;
    while (*t != ' ' && *t != '\0')
        t++;
    while (*t == ' ')
        t++;
    *s = t;

    return r;
}

/*****************************************************************************
* Compare Token
*
******************************************************************************/

static int cmp_token(const char *d, const char *s)
{
    while (*d != ' ' && *d != '\0' && *s != '\0') {
        if (*d != *s)
            return *s - *d;
        d++;
        s++;
    }

    return 0;
}

/*****************************************************************************
* Receive FTP Response
*
******************************************************************************/

static ER ftp_rcv_res_line(T_FTP *ftp, char *buf, INT bufsz, INT max)
{
    int i;
    char *p;
    ER ercd;

    p = buf;
    for (i = 0;;) {
        ercd = tcp_rcv_dat(ftp->cepid1, buf + i, 1, FTP_TMOUT);
        if (ercd <= 0)
            return ercd;
        if (buf[i] == '\n') {
            buf[++i] = '\0';
            if (!(ftp->flag & FTP_OPTION_V))
                print(p);
            break;
        }
        if (i + 2 >= bufsz) {
            if (!(ftp->flag & FTP_OPTION_V)) {
                buf[i + 1] = '\0';
                print(p);
            }
            i = max;
            p = buf + i;
        } else {
            i++;
        }
    }
    return (i > max) ? max : i;
}

static BOOL ftp_rcv_response(T_FTP *ftp)
{
    int len1, len2, bufsz;
    char *buf, *buf2;

    buf = ftp->buf;
    bufsz = sizeof (ftp->buf);
    /* get first line */
    for (;;) {
        len1 = ftp_rcv_res_line(ftp, buf, bufsz, ANARES_LEN);
        if (len1 <= 0)
            return FALSE;
        if (len1 >= 4 &&
            buf[0] >= '0' && buf[0] <= '9' &&
            buf[1] >= '0' && buf[1] <= '9' &&
            buf[2] >= '0' && buf[2] <= '9') {
            if (buf[3] == ' ')
                goto END;
            if (buf[3] == '-')
                break;
        }
    }

    /* get next line */
    buf2 = buf + len1;
    bufsz -= len1;
    for (;;) {
        len2 = ftp_rcv_res_line(ftp, buf2, bufsz, 4);
        if (len2 <= 0)
            return FALSE;
        if (len2 >= 4 &&
            buf2[0] == buf[0] &&
            buf2[1] == buf[1] &&
            buf2[2] == buf[2] &&
            buf2[3] == ' ') {
            goto END;
        }
    }

END:
    if (memcmp(buf, "220", 3) == 0)
        ftp->flag |= FTP_READY;
    else if (memcmp(buf, "331", 3) == 0)
        ftp->flag |= FTP_PASSWD_REQ;
    else if (memcmp(buf, "230", 3) == 0)
        ftp->flag |= FTP_LOGGED_IN;
    else if (memcmp(buf, "221", 3) == 0) {
        ftp->flag |= FTP_CLOSED;
        return FALSE;
    }

    return TRUE;
}

/*****************************************************************************
* Send FTP Command
*
******************************************************************************/

static ER ftp_snd_command_sub(T_FTP *ftp, char *buf, INT len, BOOL *f)
{
    int i;
    ER ercd;

    if (*f) {
        *f = FALSE;
        if (ftp->flag & FTP_OPTION_D)
            print("---> ");
    }

    if (ftp->flag & FTP_OPTION_D) {
        buf[len] = '\0';
        print(buf);
    }

    i = 0;
    do {
        ercd = tcp_snd_dat(ftp->cepid1, buf + i, len - i, FTP_TMOUT);
        if (ercd <= 0)
            return ercd;
        i += ercd;
    } while (i < len);
    return i;
}

static ER ftp_snd_command(T_FTP *ftp, char *buf, INT len)
{
    BOOL f;

    f = TRUE;
    return ftp_snd_command_sub(ftp, buf, len, &f);
}

/*****************************************************************************
* Send FTP Command and Reveice Response
*
******************************************************************************/

static BOOL ftp_snd_rcv_sub(T_FTP *ftp, const char *str, INT len, INT *i, BOOL *f)
{
    int sz;
    ER ercd;

    while (sizeof (ftp->buf) <= *i + len + 1) {
        sz = sizeof (ftp->buf) - *i - 1;
        memcpy(ftp->buf + *i, str, sz);
        ercd = ftp_snd_command_sub(ftp, ftp->buf, sizeof (ftp->buf) - 1, f);
        if (ercd <= 0)
            return FALSE;
        str += sz;
        len -= sz;
        *i = 0;
    }
    if (len > 0) {
        memcpy(ftp->buf + *i, str, len);
        *i += len;
    }

    return TRUE;
}

static BOOL ftp_snd_rcv(T_FTP *ftp, const char *cmd, const char *param, BOOL multi)
{
    int i, len;
    BOOL f;
    ER ercd;

    f = TRUE;
    i = 0;
    if (!ftp_snd_rcv_sub(ftp, cmd, strlen(cmd), &i, &f))
        return FALSE;
    if (param != NULL) {
        while (*param != '\0') {
            if (!ftp_snd_rcv_sub(ftp, " ", 1, &i, &f))
                return FALSE;
            for (len = 0; param[len] != '\0' && param[len] != ' '; len++)
                ;
            if (!ftp_snd_rcv_sub(ftp, param, len, &i, &f))
                return FALSE;
            if (!multi)
                break;
            param += len;
            for (; *param == ' '; param++)
                ;
        }
    }
    if (!ftp_snd_rcv_sub(ftp, "\r\n", 2, &i, &f))
        return FALSE;

    if (i > 0) {
        ercd = ftp_snd_command_sub(ftp, ftp->buf, i, &f);
        if (ercd <= 0)
            return FALSE;
    }
    return ftp_rcv_response(ftp);
}

/*****************************************************************************
* FTP Client Commands
*
******************************************************************************/

static BOOL ftp_wait_ready(T_FTP *ftp)
{
    if (ftp->flag & FTP_READY)
        return TRUE;
    if (!ftp_rcv_response(ftp))
        return FALSE;
    if (ftp->flag & FTP_READY)
        return TRUE;
    else
        return FALSE;
}

static BOOL ftp_wait_close(T_FTP *ftp)
{
    return ftp_rcv_response(ftp);
}

static BOOL ftp_etc_command(T_FTP *ftp, const char *s)
{
    return ftp_snd_rcv(ftp, s, NULL, FALSE);
}

static BOOL ftp_user_command(T_FTP *ftp, const char *s)
{
    return ftp_snd_rcv(ftp, "USER", (s[0] == '\0') ? "(none)" : s, FALSE);
}

static BOOL ftp_pass_command(T_FTP *ftp, const char *s)
{
    ftp->flag &= ~FTP_PASSWD_REQ;

    return ftp_snd_rcv(ftp, "PASS", s, FALSE);
}

static BOOL ftp_cd_command(T_FTP *ftp, const char *param)
{
    if (*param == '\0') {
        puts("cd <remote-directory>");
        return TRUE;
    }

    return ftp_snd_rcv(ftp, "CWD", param, FALSE);
}

static BOOL ftp_rm_command(T_FTP *ftp, const char *param)
{
    if (*param == '\0') {
        puts("rm <remote-filename>");
        return TRUE;
    }

    return ftp_snd_rcv(ftp, "DELE", param, FALSE);
}

static BOOL ftp_pasv_command(T_FTP *ftp)
{
    ER ercd;
    int i;
    const char *parm;
    char *endptr;

    /* send command and receive response with information */
    if (!ftp_snd_rcv(ftp, "PASV", NULL, FALSE))
        return FALSE;

    /* if no response for PASV command */
    if (memcmp(ftp->buf, "227", 3) != 0)
        return FALSE;

    /* point to parameters */
    parm = ftp->buf;
    ftp->buf[ANARES_LEN] = '\n';   /* sentinel */
    while (*parm != '(')
        if (*parm++ == '\n')
            return FALSE;
    parm++;

    /* set local IP address and port number */
    ercd = tcp_ref_cep(ftp->cepid1, &ftp->myaddr);
    if (ercd <= 0)
        return FALSE;

    /* set remote IP address and port number */
    memset(&ftp->dstaddr, 0, sizeof (T_IPEP));
    for (i = 0;;) {
        if (i < 4)
            ftp->dstaddr.ipaddr = (ftp->dstaddr.ipaddr << 8) + strtol(parm, &endptr, 10);
        else
            ftp->dstaddr.portno = (UH)((ftp->dstaddr.portno << 8) + strtol(parm, &endptr, 10));
        if (++i == 6)
            break;
        if (*endptr != ',')
            return FALSE;
        parm = endptr + 1;
    }

    /* connect to FTP server */
    for (i = 10; ; i--) {
        ercd = tcp_con_cep(ftp->cepid2, &ftp->myaddr, &ftp->dstaddr, FTP_TMOUT);
        if (ercd == E_OK)
            break;
        if (ercd != E_OBJ || i == 0) {
            puts("TCP connection error!");
            return FALSE;
        }
        ftp->myaddr.portno = TCP_PORTANY;
    }

    return TRUE;
}

static BOOL ftp_port_command(T_FTP *ftp)
{
    T_TCP_CREP crep;
    ER ercd;
    int len;
    int i, j;
    int d;
    char *s;

    /* create TCP reception point */
    memset(&crep, 0, sizeof (T_TCP_CREP));
    crep.myaddr.ipaddr = byte4_to_long(ftp->nif->ipaddr);
    crep.myaddr.portno = tcp_portany();

    if (ftp->repid == 0) {
        ercd = tcp_vcre_rep(&crep);
        if (ercd > 0)
            ftp->repid = (UH)ercd;
    } else {
        ercd = tcp_cre_rep(ftp->repid, &crep);
    }
    if (ercd < 0)
        return FALSE;

    ftp->myaddr = crep.myaddr;

    /* accept connection from FTP client */
    memset(&ftp->dstaddr, 0, sizeof (T_IPEP));
    ercd = tcp_acp_cep(ftp->cepid2, ftp->repid, &ftp->dstaddr, TMO_NBLK);
    if (ercd != E_WBLK) {
        tcp_del_rep(ftp->repid);
        return FALSE;
    }

    strcpy(ftp->buf, "PORT ");
    len = 5;
    s = ftp->buf + len;
    for (i = 0; i < 6; i++) {
        if (i < 4)
            d = (int)((ftp->myaddr.ipaddr >> (8 * (3 - i))) & 0xff);
        else
            d = (int)((ftp->myaddr.portno >> (8 * (5 - i))) & 0xff);
        if (i != 0) {
            *s++ = ',';
            len++;
        }
        j = itoulen(d);
        itou(s, d, j);
        s += j;
        len += j;
    }
    memcpy(s, "\r\n", 2 + 1);
    len += 2;

    if (ftp_snd_command(ftp, ftp->buf, len) <= 0) {
        tcp_del_rep(ftp->repid);
        return FALSE;
    }
    if (!ftp_rcv_response(ftp)) {
        tcp_del_rep(ftp->repid);
        return FALSE;
    }
    return TRUE;
}

#ifdef DUAL_STK
static BOOL ftp_epsv_command(T_FTP *ftp)
{
    ER ercd;
    int i;
    char delimit;
    const char *parm;

    /* send command and receive response with information */
    if (!ftp_snd_rcv(ftp, "EPSV", NULL, FALSE))
        return FALSE;

    /* if no response for PASV command */
    if (memcmp(ftp->buf, "229", 3) != 0)
        return FALSE;

    /* point to parameters */
    parm = ftp->buf;
    ftp->buf[ANARES_LEN] = '\n';   /* sentinel */
    while (*parm != '(')
        if (*parm++ == '\n')
            return FALSE;
    parm++;

    delimit = *parm++;
    for (i = 1; i < 3; i++) {
        while (*parm != delimit)
            if (*parm++ == '\n')
                return FALSE;
    }
    parm++;
    while (*parm == delimit)
        parm++;

    /* set local port number */
    ercd = tcp_ref_cep(ftp->cepid1, &ftp->myaddr);
    if (ercd <= 0)
        return FALSE;
    ftp->myaddr.type = ftp->dstaddr.type;

    /* set remote port number */
    ftp->dstaddr.portno = (UH)strtol(parm, NULL, 10);

    /* connect to FTP server */
    for (i = 10; ; i--) {
        ercd = tcp_con_cep(ftp->cepid2, &ftp->myaddr, &ftp->dstaddr, FTP_TMOUT);
        if (ercd == E_OK)
            break;
        if (ercd != E_OBJ || i == 0) {
            puts("TCP connection error!");
            return FALSE;
        }
        ftp->myaddr.portno = TCP_PORTANY;
    }

    return TRUE;
}

static BOOL ftp_eprt_command(T_FTP *ftp)
{
    T_TCP_CREP crep;
    ER ercd;
    int len;
    char *parm;

    memset(&crep, 0, sizeof (T_TCP_CREP));

    ercd = tcp_ref_cep(ftp->cepid1, &crep.myaddr);
    if (ercd <= 0)
        return FALSE;
    crep.myaddr.portno = tcp_portany();

    if (ftp->repid == 0) {
        ercd = tcp_vcre_rep(&crep);
        if (ercd > 0)
            ftp->repid = (UH)ercd;
    } else {
        ercd = tcp_cre_rep(ftp->repid, &crep);
    }
    if (ercd < 0)
        return FALSE;

    ftp->myaddr = crep.myaddr;

    memset(&ftp->dstaddr, 0, sizeof (T_IPEP));
    ftp->dstaddr.type = ftp->myaddr.type;

    ercd = tcp_acp_cep(ftp->cepid2, ftp->repid, &ftp->dstaddr, TMO_NBLK);
    if (ercd != E_WBLK) {
        tcp_del_rep(ftp->repid);
        return FALSE;
    }

    parm = ftp->buf + FTP_BUFSZ - 80;
    if (ftp->myaddr.type == IPV4_ADDR) {
        strcpy(parm, "|1|");
        len = ip4addr_to_ascii(parm + 3, htonl(ftp->myaddr.ipaddr));
        parm[3 + len + 0] = '|';
        itou(parm + 3 + len + 1, ftp->myaddr.portno, 0);
        strcat(parm, "|");
    } else if (ftp->myaddr.type == IPV6_ADDR) {
        strcpy(parm, "|2|");
        len = ip6addr_to_ascii(parm + 3, ftp->myaddr.ip6addr);
        parm[3 + len + 0] = '|';
        itou(parm + 3 + len + 1, ftp->myaddr.portno, 0);
        strcat(parm, "|");
    }

    ercd = ftp_snd_rcv(ftp, "EPRT", parm, FALSE);
    if (memcmp(ftp->buf, "500", 3) == 0) {
        tcp_cls_cep(ftp->cepid2, 100/MSEC);
        tcp_del_rep(ftp->repid);
        ercd = FALSE;
    }

    return ercd;
}
#endif

static BOOL ftp_connect_data_port(T_FTP *ftp)
{
  #ifdef DUAL_STK
    if (!(ftp->flag & FTP_PASV)) {
        if (ftp_eprt_command(ftp))
            return TRUE;
        if (memcmp(ftp->buf, "500", 3) != 0)
            return FALSE;
        return ftp_port_command(ftp);
    } else {
        if (ftp_epsv_command(ftp))
            return TRUE;
        if (memcmp(ftp->buf, "500", 3) != 0)
            return FALSE;
        return ftp_pasv_command(ftp);
    }
  #else
    if (!(ftp->flag & FTP_PASV))
        return ftp_port_command(ftp);
    else
        return ftp_pasv_command(ftp);
  #endif
}

static BOOL ftp_dir_command(T_FTP *ftp, const char *param, BOOL dir)
{
    ER len;
    int i;

    if (!ftp_connect_data_port(ftp))
        return FALSE;

    if (!ftp_snd_rcv(ftp, (dir) ? "LIST" : "NLST", param, TRUE)) {
        tcp_cls_cep(ftp->cepid2, 100/MSEC);
        tcp_del_rep(ftp->repid);
        return FALSE;
    }

    /* in case of 5xx error, terminate the data port connection */
    if (memcmp(ftp->buf, "5", 1) == 0) {
        tcp_cls_cep(ftp->cepid2, 100/MSEC);
        tcp_del_rep(ftp->repid);
        return TRUE;
    }

  #ifdef DUAL_STK
    for (i = 5; ftp->dstaddr.ipaddr == 0L && is_ip6_addr_any(ftp->dstaddr.ip6addr);) {
  #else
    for (i = 5; ftp->dstaddr.ipaddr == 0L;) {
  #endif
        dly_tsk(1000/MSEC);
        if (--i == 0) {
            tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
            tcp_del_rep(ftp->repid);
            return TRUE;
        }
    }
    ftp->flag |= FTP_DTP_OPEN;

    i = 0;
    for (;;) {
        len = tcp_rcv_dat(ftp->cepid2, ftp->buf + i, 1, FTP_TMOUT);
        if (len <= 0)
            break;
        i += len;
        if (ftp->buf[i - 1] == '\n') {
            if (i >= 2 && ftp->buf[i - 2] == '\r') {
                ftp->buf[i] = '\0';
            } else {
                ftp->buf[i - 1] = '\r';
                ftp->buf[i] = '\n';
                ftp->buf[i + 1] = '\0';
            }
            print(ftp->buf);
            i = 0;
        } else if (i >= sizeof (ftp->buf) - 1) {
            ftp->buf[i] = '\0';
            print(ftp->buf);
            i = 0;
        }
    }
    ftp->flag &= ~FTP_DTP_OPEN;
    tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
    tcp_del_rep(ftp->repid);

    return ftp_rcv_response(ftp);
}

static BOOL ftp_get_command(T_FTP *ftp, const char *param)
{
    ER len;
    FILE *fp;
    B full;
    UW total;
    int i;

    if (*param == '\0') {
        puts("get <remote-filename>");
        return TRUE;
    }

    if (!ftp_connect_data_port(ftp))
        return FALSE;

    if (!ftp_snd_rcv(ftp, "RETR", param, FALSE)) {
        tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
        tcp_del_rep(ftp->repid);
        return FALSE;
    }

    /* in case of 5xx error, terminate the data port connection */
    if (memcmp(ftp->buf, "5", 1) == 0) {
        tcp_cls_cep(ftp->cepid2, 100/MSEC);
        tcp_del_rep(ftp->repid);
        return TRUE;
    }

  #ifdef DUAL_STK
    for (i = 5; ftp->dstaddr.ipaddr == 0L && is_ip6_addr_any(ftp->dstaddr.ip6addr);) {
  #else
    for (i = 5; ftp->dstaddr.ipaddr == 0L;) {
  #endif
        dly_tsk(1000/MSEC);
        if (--i == 0) {
            tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
            tcp_del_rep(ftp->repid);
            return TRUE;
        }
    }
    ftp->flag |= FTP_DTP_OPEN;

    fp = fopen(param, "w");
    if (fp == NULL) {
        puts("Can't write file.");
        tcp_cls_cep(ftp->cepid2, 1);
        tcp_del_rep(ftp->repid);
        puts("Connection closed.");
        return FALSE;
    }

    total = 0L;
    full = FALSE;
    for (;;) {
        len = tcp_rcv_dat(ftp->cepid2, ftp->buf, sizeof (ftp->buf), FTP_TMOUT);
        if (len <= 0)
            break;
        total += len;
        if (!full) {
            if ((int)fwrite(ftp->buf, 1, len, fp) != len) {
                puts("Disk full");
                full = TRUE;
            }
        }
    }
    fclose(fp);

    ftp->flag &= ~FTP_DTP_OPEN;
    tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
    tcp_del_rep(ftp->repid);

    if (!ftp_rcv_response(ftp))
        return FALSE;

    ltou(ftp->buf, total, ltoulen(total));
    strcat(ftp->buf, " bytes received");
    puts(ftp->buf);
    return TRUE;
}

static BOOL ftp_put_command(T_FTP *ftp, const char *param)
{
    ER len, len2;
    int i;
    FILE *fp;
    UW total;

    if (*param == '\0') {
        puts("put <remote-filename>");
        return TRUE;
    }

    fp = fopen(param, "r");
    if (fp == NULL) {
        puts("File not found");
        return TRUE;
    }

    if (!ftp_connect_data_port(ftp)) {
        fclose(fp);
        return FALSE;
    }

    if (!ftp_snd_rcv(ftp, "STOR", param, FALSE)) {
        tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
        tcp_del_rep(ftp->repid);
        fclose(fp);
        return TRUE;
    }

    /* in case of 5xx error, terminate the data port connection */
    if (memcmp(ftp->buf, "5", 1) == 0) {
        tcp_cls_cep(ftp->cepid2, 100/MSEC);
        tcp_del_rep(ftp->repid);
        fclose(fp);
        return TRUE;
    }

  #ifdef DUAL_STK
    for (i = 5; ftp->dstaddr.ipaddr == 0L && is_ip6_addr_any(ftp->dstaddr.ip6addr);) {
  #else
    for (i = 5; ftp->dstaddr.ipaddr == 0L;) {
  #endif
        dly_tsk(1000/MSEC);
        if (--i == 0) {
            tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
            tcp_del_rep(ftp->repid);
            fclose(fp);
            return TRUE;
        }
    }
    ftp->flag |= FTP_DTP_OPEN;

    total = 0L;
    for (;;) {
        len = fread(ftp->buf, 1, sizeof (ftp->buf), fp);
        if (len == 0)
            break;
        total += len;
        i = 0;
        do {
            len2 = tcp_snd_dat(ftp->cepid2, ftp->buf + i, len, FTP_TMOUT);
            if (len2 <= 0)
                break;
            i += len2;
            len -= len2;
        } while (len > 0);
    }
    fclose(fp);

    ftp->flag &= ~FTP_DTP_OPEN;
    tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
    tcp_del_rep(ftp->repid);

    ltou(ftp->buf, total, ltoulen(total));
    strcat(ftp->buf, " bytes sent");
    puts(ftp->buf);

    return ftp_rcv_response(ftp);
}

/*****************************************************************************
* Input FTP Command
*
******************************************************************************/

static INT ftp_input(T_FTP *ftp, char *buf, INT size)
{
    T_TERMINAL *t;
    int c;

    t = current_terminal;
    if (t == NULL)
        return FALSE;

    if (ftp->flag & FTP_PASSWD_REQ)
        t->echo_on = '*';
    c = terminal_input(t, buf, size, TMO_FEVR);
    if (ftp->flag & FTP_PASSWD_REQ)
        t->echo_on = 1;
    terminal_print(t, "\r\n");
    if (c <= 0)
        return FALSE;
    return c;
}

/*****************************************************************************
* FTP Client Process
*
******************************************************************************/

ER ftp_client(T_FTP *ftp, ID cepid1, ID cepid2, ID repid, UB option, UW ipaddr, T_NIF *nif)
{
    T_TCP_CCEP ccep;
    T_IPEP myaddr;
    T_IPEP dstaddr;
    ER ercd;
    BOOL ok;
    char *s;
    const char *com, *command;
    int i;

    /* initialize FTP control block */
    memset(ftp, 0, sizeof (T_FTP));
    ftp->cepid1 = (UH)cepid1;
    ftp->cepid2 = (UH)cepid2;
    ftp->repid = (UH)repid;
    ftp->flag = option;

    /* assign the interface */
    ftp->nif = nif;

    /* create TCP commnunication end points */
    memset(&ccep, 0, sizeof (T_TCP_CCEP));
    ccep.sbuf = ftp->sbuf1;
    ccep.sbufsz = sizeof (ftp->sbuf1);
    ccep.rbuf = ftp->rbuf1;
    ccep.rbufsz = sizeof (ftp->rbuf1);

    if (ftp->cepid1 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            return ercd;
        ftp->cepid1 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid1, &ccep);
        if (ercd != E_OK)
            return ercd;
    }

    tcp_set_opt(ftp->cepid1, IP_IF_NAME, nif->name, 0);

    ccep.sbuf = ftp->sbuf2;
    ccep.sbufsz = sizeof (ftp->sbuf2);
    ccep.rbuf = ftp->rbuf2;
    ccep.rbufsz = sizeof (ftp->rbuf2);

    if (ftp->cepid2 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            goto END1;
        ftp->cepid2 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid2, &ccep);
        if (ercd != E_OK)
            goto END1;
    }

    tcp_set_opt(ftp->cepid2, IP_IF_NAME, nif->name, 0);

    /* connect */
    myaddr.ipaddr = IPV4_ADDRANY;
    myaddr.portno = TCP_PORTANY;
    dstaddr.ipaddr = ipaddr;
    dstaddr.portno = TCP_PORT_FTP;
  #ifdef DUAL_STK
    myaddr.type = IPV4_ADDR;
    dstaddr.type = IPV4_ADDR;
  #endif

    for (i = 10; ; i--) {
        ercd = tcp_con_cep(ftp->cepid1, &myaddr, &dstaddr, FTP_TMOUT);
        if (ercd == E_OK)
            break;
        if (ercd != E_OBJ || i == 0) {
            puts("TCP connection error!");
            goto END2;
        }
        myaddr.portno = TCP_PORTANY;
    }

    if (!ftp_wait_ready(ftp)) {
        puts("Server not ready!");
        goto END;
    }

    ftp->dstaddr = dstaddr;

    /* main loop */
    for (;;) {

        /* display prompt */
        if (ftp->flag & FTP_PASSWD_REQ)
            print("Password: ");
        else if (!(ftp->flag & FTP_LOGGED_IN))
            print("login: ");
        else
            print("ftp> ");

        /* input a command */
        s = ftp->buf + sizeof (ftp->buf) - 128;
        if (ftp_input(ftp, s, 128) != '\r')
            break;
        command = s;
        com = get_token(&command);

        /* execute each command */
        if (*com == '\0' && (ftp->flag & FTP_LOGGED_IN))
            continue;
        else if (ftp->flag & FTP_PASSWD_REQ)
            ok = ftp_pass_command(ftp, com);
        else if (!(ftp->flag & FTP_LOGGED_IN))
            ok = ftp_user_command(ftp, com);
        else if (cmp_token(com, "dir") == 0)
            ok = ftp_dir_command(ftp, command, TRUE);
        else if (cmp_token(com, "ls") == 0)
            ok = ftp_dir_command(ftp, command, FALSE);
        else if (cmp_token(com, "cd") == 0)
            ok = ftp_cd_command(ftp, command);
        else if (cmp_token(com, "rm") == 0)
            ok = ftp_rm_command(ftp, command);
        else if (cmp_token(com, "get") == 0)
            ok = ftp_get_command(ftp, command);
        else if (cmp_token(com, "put") == 0)
            ok = ftp_put_command(ftp, command);
        else if (cmp_token(com, "bye") == 0)
            ok = ftp_etc_command(ftp, "QUIT");
        else if (cmp_token(com, "quit") == 0)
            ok = ftp_etc_command(ftp, "QUIT");
        else if (cmp_token(com, "ascii") == 0)
            ok = ftp_etc_command(ftp, "TYPE A");
        else if (cmp_token(com, "bin") == 0)
            ok = ftp_etc_command(ftp, "TYPE I");
        else if (cmp_token(com, "passive") == 0) {
            ftp->flag ^= FTP_PASV;
            if (ftp->flag & FTP_PASV)
                print("Passive Mode is ON\r\n");
            else
                print("Passive Mode is OFF\r\n");
            ok = TRUE;
        } else {
            puts("Invalid command");
            ok = TRUE;
        }
        if (!ok)
            break;
        if (ftp->flag & FTP_CLOSED) {
            ftp_wait_close(ftp);
            break;
        }
    }

    /* end process */
END:
    tcp_cls_cep(ftp->cepid1, FTP_TMOUT);
    tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
END2:
    tcp_del_cep(ftp->cepid2);
END1:
    tcp_del_cep(ftp->cepid1);
    return ercd;
}

#ifdef DUAL_STK
ER ftp6_client(T_FTP *ftp, ID cepid1, ID cepid2, ID repid, UB option, UW *ip6addr, T_NIF *nif)
{
    T_TCP_CCEP ccep;
    T_IPEP myaddr;
    T_IPEP dstaddr;
    ER ercd;
    BOOL ok;
    char *s;
    const char *com, *command;
    int i;

    /* initialize ftp control block */
    memset(ftp, 0, sizeof (T_FTP));
    ftp->cepid1 = (UH)cepid1;
    ftp->cepid2 = (UH)cepid2;
    ftp->repid = (UH)repid;
    ftp->flag = option;

    /* assign the interface */
    ftp->nif = nif;

    /* create TCP commnunication end points */
    memset(&ccep, 0, sizeof (T_TCP_CCEP));
    ccep.sbuf = ftp->sbuf1;
    ccep.sbufsz = sizeof (ftp->sbuf1);
    ccep.rbuf = ftp->rbuf1;
    ccep.rbufsz = sizeof (ftp->rbuf1);

    if (ftp->cepid1 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            return ercd;
        ftp->cepid1 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid1, &ccep);
        if (ercd != E_OK)
            return ercd;
    }

    tcp_set_opt(ftp->cepid1, IP_IF_NAME, nif->name, 0);

    ccep.sbuf = ftp->sbuf2;
    ccep.sbufsz = sizeof (ftp->sbuf2);
    ccep.rbuf = ftp->rbuf2;
    ccep.rbufsz = sizeof (ftp->rbuf2);

    if (ftp->cepid2 == 0) {
        ercd = tcp_vcre_cep(&ccep);
        if (ercd <= 0)
            goto END1;
        ftp->cepid2 = (UH)ercd;
    } else {
        ercd = tcp_cre_cep(ftp->cepid2, &ccep);
        if (ercd != E_OK)
            goto END1;
    }

    tcp_set_opt(ftp->cepid2, IP_IF_NAME, nif->name, 0);

    /* connect */
    memset(&myaddr, 0, sizeof (T_IPEP));
    myaddr.portno = TCP_PORTANY;
    myaddr.type = IPV6_ADDR;

    memset(&dstaddr, 0, sizeof (T_IPEP));
    set_ip6_addr(dstaddr.ip6addr, ip6addr);
    dstaddr.portno = TCP_PORT_FTP;
    dstaddr.type = IPV6_ADDR;

    for (i = 10; ; i--) {
        ercd = tcp_con_cep(ftp->cepid1, &myaddr, &dstaddr, FTP_TMOUT);
        if (ercd == E_OK)
            break;
        if (ercd != E_OBJ || i == 0) {
            puts("TCP connection error!");
            goto END2;
        }
        myaddr.portno = TCP_PORTANY;
    }

    if (!ftp_wait_ready(ftp)) {
        puts("Server not ready!");
        goto END;
    }

    ftp->dstaddr = dstaddr;

    /* main loop */
    for (;;) {

        /* display prompt */
        if (ftp->flag & FTP_PASSWD_REQ)
            print("Password: ");
        else if (!(ftp->flag & FTP_LOGGED_IN))
            print("login: ");
        else
            print("ftp> ");

        /* Input a command */
        s = ftp->buf + sizeof (ftp->buf) - 128;
        if (ftp_input(ftp, s, 128) != '\r')
            break;
        command = s;
        com = get_token(&command);

        /* execute each command */
        if (*com == '\0' && (ftp->flag & FTP_LOGGED_IN))
            continue;
        else if (ftp->flag & FTP_PASSWD_REQ)
            ok = ftp_pass_command(ftp, com);
        else if (!(ftp->flag & FTP_LOGGED_IN))
            ok = ftp_user_command(ftp, com);
        else if (cmp_token(com, "dir") == 0)
            ok = ftp_dir_command(ftp, command, TRUE);
        else if (cmp_token(com, "ls") == 0)
            ok = ftp_dir_command(ftp, command, FALSE);
        else if (cmp_token(com, "cd") == 0)
            ok = ftp_cd_command(ftp, command);
        else if (cmp_token(com, "rm") == 0)
            ok = ftp_rm_command(ftp, command);
        else if (cmp_token(com, "get") == 0)
            ok = ftp_get_command(ftp, command);
        else if (cmp_token(com, "put") == 0)
            ok = ftp_put_command(ftp, command);
        else if (cmp_token(com, "bye") == 0)
            ok = ftp_etc_command(ftp, "QUIT");
        else if (cmp_token(com, "quit") == 0)
            ok = ftp_etc_command(ftp, "QUIT");
        else if (cmp_token(com, "ascii") == 0)
            ok = ftp_etc_command(ftp, "TYPE A");
        else if (cmp_token(com, "bin") == 0)
            ok = ftp_etc_command(ftp, "TYPE I");
        else if (cmp_token(com, "passive") == 0) {
            ftp->flag ^= FTP_PASV;
            if (ftp->flag & FTP_PASV)
                print("Passive Mode is ON\r\n");
            else
                print("Passive Mode is OFF\r\n");
            ok = TRUE;
        } else {
            puts("Invalid command");
            ok = TRUE;
        }
        if (!ok)
            break;
        if (ftp->flag & FTP_CLOSED) {
            ftp_wait_close(ftp);
            break;
        }
    }

    /* end process */
END:
    tcp_cls_cep(ftp->cepid1, FTP_TMOUT);
    tcp_cls_cep(ftp->cepid2, FTP_TMOUT);
END2:
    tcp_del_cep(ftp->cepid2);
END1:
    tcp_del_cep(ftp->cepid1);
    return ercd;
}
#endif

/*****************************************************************************
* FTP Command Main
*
******************************************************************************/

int ftp_command(int argc, char *argv[])
{
    T_NIF *nif;
    UW ipaddr;
    UB option;
    int i;
    B c;

    /* convert arguments */
    nif = NULL;
    ipaddr = 0L;
    option = FTP_PASV;
    for (i = 1; i < argc; i++) {
        c = argv[i][0];
        if (c == '-') {
            if (argv[i][1] == 'd') {
                option |= FTP_OPTION_D;
            } else if (argv[i][1] == 'v') {
                option |= FTP_OPTION_V;
            } else if (argv[i][1] == 'i') {
                nif = getnif_from_name(argv[++i]);
                if (nif == NULL) {
                    print(" Invalid Interface specified. \r\n");
                    return 0;
                }
            }
        } else if (c >= '0' && c <= '9') {
            ipaddr = ascii_to_ipaddr(argv[i]);
        }
    }
    if (ipaddr == 0L) {
        if (argc < 2)
           print(msg_ftpc_help);
        else
           print(msg_ftpc_addr);
        return 0;
    }
    if (nif == NULL) {
        if ((nif = getnif_addr(ipaddr)) == NULL)
           nif = getnif_default();
    }

    /* FTP client process */
    ftp_client(&ftpc, 0, 0, 0, option, ipaddr, nif);

    return 0;
}

#ifdef DUAL_STK
int ftp6_command(int argc, char *argv[])
{
    T_NIF *nif;
    UW ipaddr[4];
    UB option;
    int i;

    /* convert arguments */
    nif = NULL;
    memset(ipaddr, 0, IP6_ADDR_SZ);
    option = FTP_PASV;
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            if (argv[i][1] == 'd') {
                option |= FTP_OPTION_D;
            } else if (argv[i][1] == 'v') {
                option |= FTP_OPTION_V;
            } else if (argv[i][1] == 'i') {
                nif = getnif_from_name(argv[++i]);
                if (nif == NULL) {
                    print(" Invalid Interface specified. \r\n");
                    return 0;
                }
            }
        } else {
            ascii_to_ip6addr(argv[i], ipaddr);
        }
    }
    if (is_ip6_addr_any(ipaddr)) {
        if (argc < 2)
           print(msg_ftpc_help);
        else
           print(msg_ftpc_addr);
        return 0;
    }
    if (nif == NULL) {
        if ((nif = getnif_ip6addr(ipaddr)) == NULL)
           nif = getnif_default();
    }

    /* FTP client process */
    ftp6_client(&ftpc, 0, 0, 0, option, ipaddr, nif);

    return 0;
}
#endif

/* end */
