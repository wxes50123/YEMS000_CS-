/******************************************************************************
* TCP Performance Test Program using TTCP Command for Multi-Channel           *
*                                                                             *
*  Copyright (c) 2011-2016, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-07-28 Created                                                  KM & MI *
* 2012-03-30 Added support for NORTi Oceans                                HE *
* 2015-03-03 Changed ttcp_r_loop() to save received host IP address, and      *
*              ttcp_t_loop() to update host IP address when unconnectable  FY *
* 2016-03-15 Modified for multi-channel, and renamed from nonttcp.c        FY *
* 2016-11-24 Added support for NTttcp                                      FY *
******************************************************************************/

#include "kernel.h"
#ifdef NORTi_Oceans
#include "nocnet.h"
#else
#include "nonet.h"
#endif
#include "nonttcp2.h"

/* Configuration */

#ifndef TCP_PORT_TTCP
#define TCP_PORT_TTCP   5001    /* TTCP port number */
#endif
#ifndef TCP_PORT_NTCP
#define TCP_PORT_NTCP   6001    /* NTttcp command port number */
#endif
#ifndef BUFLEN
#define BUFLEN          8192    /* length of Tx/Rx buffer */
#endif
#ifndef NBUF
#define NBUF            2048    /* number of transmission */
#endif
#ifndef TXWINSZ
#define TXWINSZ         BUFLEN  /* Tx window buffer size (2~32768, 2^n) */
#endif
#ifndef RXWINSZ
#define RXWINSZ         BUFLEN  /* Rx window buffer size (2~32768, 2^n) */
#endif
#ifndef NCH
#define NCH             2       /* number of channels */
#endif

/* Timeout Parameters */

#define DAT_TMOUT  (60000/MSEC) /* data transmit/receive timeout */
#define CON_TMOUT  (3000/MSEC)  /* connect/close timeout */
#define ACP_TMOUT  (20/MSEC)    /* NTttcp command accept timeout */

/* TTCP Data Buffer (shared by Tx and Rx of all channels) */

static UB buffer[BUFLEN];

/* Window Buffer of End Point */

static UH txwin[NCH][TXWINSZ/2];    /* for TTCP transmit */
static UH r1win[NCH][1];
static UH rxwin[NCH][RXWINSZ/2];    /* for TTCP receive */
static UH t1win[NCH][1];
static UH ntwin[NCH][4][1];         /* for NTttcp command transmit/receive */

/* Local Variables */

static UH ntcp_repid[NCH], ntcp_cepid[NCH];
static UH ntcp_tskid[NCH];
static B ntcp_mode[NCH];

/*****************************************************************************
* Send TCP data until the specified data length
*
******************************************************************************/

static int tcp_send(ID cepid, const UB *data, int len)
{
    ER ercd;
    int i;

    for (i = 0; i < len; i += ercd) {
        ercd = tcp_snd_dat(cepid, data + i, len - i, DAT_TMOUT);
        if (ercd <= 0)
            return ercd;
    }
    return i;   /* sent data length */
}

/*****************************************************************************
* Receive TCP data until the specified buffer size
*
******************************************************************************/

static int tcp_recv(ID cepid, UB *buf, int size)
{
    ER ercd;
    int i;

    for (i = 0; i < size; i += ercd) {
        ercd = tcp_rcv_dat(cepid, buf + i, size - i, DAT_TMOUT);
        if (ercd <= 0)
            return ercd;
    }
    return i;   /* received data length */
}

/*****************************************************************************
* TTCP Transmitter Loop
*
******************************************************************************/

void ttcp_t_loop(int ch, UW *ipaddr)
{
    T_TCP_CCEP ccep = { 0, NULL, TXWINSZ, NULL, 1, NULL };
    T_TCP_CCEP ccen = { 0, NULL, 1, NULL, 1, NULL };
    T_IPV4EP dstaddr, srcaddr;
    ID cepid, cenid;
    int len, n, i;
    UB cmd[1];
    ER ercd;

    ntcp_mode[ch] = FALSE;

    /* create TCP communication end point */
    ccep.sbuf = txwin[ch];
    ccep.rbuf = r1win[ch];
    cepid = tcp_vcre_cep(&ccep);
    tcp_set_opt(cepid, IP_IF_CH, (VP)ch, 0);
    ccen.sbuf = ntwin[ch][0];
    ccen.rbuf = ntwin[ch][1];
    cenid = tcp_vcre_cep(&ccen);
    tcp_set_opt(cenid, IP_IF_CH, (VP)ch, 0);

    srcaddr.ipaddr = IPV4_ADDRANY;
    srcaddr.portno = TCP_PORTANY;
    dstaddr.ipaddr = *ipaddr;

    for (;;) {
        /* request connection */
        dstaddr.portno = TCP_PORT_TTCP;
        if ((ercd = tcp_con_cep(cepid, &srcaddr, &dstaddr, CON_TMOUT)) != E_OK) {
            dstaddr.ipaddr = *ipaddr;   /* update host IP address */
            if (ercd != E_TMOUT)
                tslp_tsk(CON_TMOUT);
            continue;
        }

        if (ntcp_mode[ch]) {
            /* request command port connection */
            dstaddr.portno = TCP_PORT_NTCP;
            for (i = 0; i < 3; i++) {
                if ((ercd = tcp_con_cep(cenid, &srcaddr, &dstaddr, CON_TMOUT)) == E_OK) {
                    /* receive command */
                    if (tcp_rcv_dat(cenid, cmd, 1, DAT_TMOUT) > 0) {
                        /* send command */
                        cmd[0] = 0x58;
                        tcp_snd_dat(cenid, cmd, 1, DAT_TMOUT);
                    }
                    break;
                }
                if (ercd != E_TMOUT)
                    tslp_tsk(CON_TMOUT);
            }
            /* close command port connection */
            tcp_cls_cep(cenid, CON_TMOUT);
        }

        /* send TCP data until BUFLEN x NBUF bytes */
        for (n = 0; n < NBUF; n++) {
            len = tcp_send(cepid, buffer, BUFLEN);
            if (len < BUFLEN)
                break;
        }
        /* close connection */
        tcp_cls_cep(cepid, CON_TMOUT);
    }
}


/*****************************************************************************
* Callback Function to Accept NTttcp Command
*
******************************************************************************/

ER ntcp_callback(ID cepid, FN fncd, VP parblk)
{
    int ch;

    ch = (ntcp_cepid[0] == cepid) ? 0 : 1;
    if (*(ER *)parblk == E_OK)
        ntcp_mode[ch] = TRUE;
    else
        ntcp_mode[ch] = FALSE;
    wup_tsk(ntcp_tskid[ch]);
    return E_OK;
}

/*****************************************************************************
* TTCP Receiver Loop
*
******************************************************************************/

void ttcp_r_loop(int ch, UW *ipaddr)
{
    T_TCP_CREP crep = { 0, { 0, TCP_PORT_TTCP } };
    T_TCP_CCEP ccep = { 0, NULL, 1, NULL, RXWINSZ, NULL };
    T_TCP_CREP cren = { 0, { 0, TCP_PORT_NTCP } };
    T_TCP_CCEP ccen = { 0, NULL, 1, NULL, 1, (FP)ntcp_callback };
    T_IPV4EP dstaddr, dstaddr1;
    ID repid, cepid;
    int len;
    ER ercd;
    UB cmd[1];

    /* create TCP reception point */
    crep.myaddr.ipaddr = byte4_to_long(getnif_from_ch(ch)->ipaddr);
    repid = tcp_vcre_rep(&crep);
    cren.myaddr.ipaddr = byte4_to_long(getnif_from_ch(ch)->ipaddr);
    ntcp_repid[ch] = (UH)tcp_vcre_rep(&cren);

    /* create TCP communication end point */
    ccep.sbuf = t1win[ch];
    ccep.rbuf = rxwin[ch];
    cepid = tcp_vcre_cep(&ccep);
    ccen.sbuf = ntwin[ch][2];
    ccen.rbuf = ntwin[ch][3];
    ntcp_cepid[ch] = (UH)tcp_vcre_cep(&ccen);

    for (;;) {
        /* connection request for command port */
        ntcp_tskid[ch] = (UH)vget_tid();
        ercd = tcp_acp_cep(ntcp_cepid[ch], ntcp_repid[ch], &dstaddr1, TMO_NBLK);
        if (ercd == E_OK)
            ntcp_mode[ch] = TRUE;

        /* wait for connection request */
        while (tcp_acp_cep(cepid, repid, &dstaddr, TMO_FEVR) != E_OK)
            ;
        *ipaddr = dstaddr.ipaddr;   /* save host IP address */

        /* wait for command port connection */
        if (ercd == E_WBLK) {
            if (tslp_tsk(ACP_TMOUT) != E_OK || !ntcp_mode[ch]) {
                ntcp_mode[ch] = FALSE;
                tcp_can_cep(ntcp_cepid[ch], TFN_TCP_ALL);
                tcp_cls_cep(ntcp_cepid[ch], TMO_POL);
                vcan_wup();
            }
        }
        if (ntcp_mode[ch]) {
            /* send command */
            cmd[0] = 0x58;
            if (tcp_snd_dat(ntcp_cepid[ch], cmd, 1, DAT_TMOUT) > 0) {
                /* receive command */
                for (;;) {
                    if (tcp_rcv_dat(ntcp_cepid[ch], cmd, 1, DAT_TMOUT) <= 0)
                        break;
                }
            }
            /* close connection */
            tcp_cls_cep(ntcp_cepid[ch], CON_TMOUT);
        }

        /* receive TCP data until client disconnects */
        for (;;) {
            len = tcp_recv(cepid, buffer, BUFLEN);
            if (len < BUFLEN)
                break;
        }
        /* close connection */
        tcp_cls_cep(cepid, CON_TMOUT);
    }
}

/* end */
