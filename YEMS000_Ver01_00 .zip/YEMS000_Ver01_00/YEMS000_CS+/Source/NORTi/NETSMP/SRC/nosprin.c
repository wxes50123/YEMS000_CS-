/******************************************************************************
* ���sprintf�n�֐�                                                           *
*                                                                             *
*  Copyright (c) 2021, MiSPO Co., Ltd.                                        *
*  All rights reserved.                                                       *
*                                                                             *
* 2021-04-26 mystdio.c����my_vsprintf()�𕪗�����my_vsnprintf()�ɒu�������A   *
*            �����֐� pr_???()���S�ʉ��C�Amy_sprintf()/my_snprintf()��ǉ� FY *
******************************************************************************/

#include "kernel.h"
#include "nostdio.h"

/*****************************************************************************
* my_vsnprintf�p�̓����֐�
*
******************************************************************************/

static int pr_sub(char *buf, int size, const char *str, int len, int width, char zero)
{
    if (width != 0 && len < width) {
        if (size < width - len) {
            memset(buf, zero, size);
            return size;
        }
        memset(buf, zero, width - len);
        if (size < width) {
            memcpy(buf + width - len, str, size - (width - len));
            return size;
        }
        memcpy(buf + width - len, str, len);
        return width;
    }

    if (size < len) {
        memcpy(buf, str, size);
        return size;
    }
    memcpy(buf, str, len);
    return len;
}

static int pr_bin(char *buf, int size, unsigned long d, int width, char zero)
{
    char s[32];
    char *p;

    p = &s[31];
    do {
        *p-- = (d & 1) + '0';
    } while ((d >>= 1) != 0);

    return pr_sub(buf, size, p+1, &s[31] - p, width, zero);
}

static int pr_hex(char *buf, int size, unsigned long d, int width, char zero, BOOL cap)
{
    char s[8];
    char *p;
    const char *hex;

    hex = cap ? "0123456789ABCDEF" : "0123456789abcdef";
    p = &s[7];
    do {
        *p-- = hex[d & 0x0f];
    } while ((d >>= 4) != 0);

    return pr_sub(buf, size, p+1, &s[7] - p, width, zero);
}

static int pr_dec(char *buf, int size, long d, int width, char zero)
{
    char s[11];
    char *p;
    BOOL m;

    if (d < 0) {
        m = TRUE;
        d = -d;
    } else {
        m = FALSE;
    }

    p = &s[10];
    do {
        *p-- = (d % 10) + '0';
    } while ((d /= 10) != 0);

    if (m) {
        *p-- = '-';
        d = -d;
        zero = ' ';
    }

    return pr_sub(buf, size, p+1, &s[10] - p, width, zero);
}

static int pr_udec(char *buf, int size, unsigned long d, int width, char zero)
{
    char s[10];
    char *p;

    p = &s[9];
    do {
        *p-- = (d % 10) + '0';
    } while ((d /= 10) != 0);

    return pr_sub(buf, size, p+1, &s[9] - p, width, zero);
}

/*****************************************************************************
* ���vsnprintf
*
******************************************************************************/

int my_vsnprintf(char *buf, size_t size, const char *fmt, va_list ap)
{
    long d;
    char *p;
    int n, width, len;
    char c, zero;

    if (size > 0x8000 || size <= 0)
        return 0;
    n = (int)(size - 1);
    p = buf;

    while (n > 0 && (c = *fmt++) != '\0') {
        if (c == '%' && *fmt != '\0') {
            zero = (*fmt == '0') ? '0' : ' ';
            for (width = 0; '0' <= *fmt && *fmt <= '9'; fmt++)
                width = width * 10 + *fmt - '0';
            switch (*fmt++) {
            case 'b':
                d = va_arg(ap, long);
                len = pr_bin(p, n, (unsigned long)d, width, zero);
                p += len;
                n -= len;
                break;
            case 'c':
                d = va_arg(ap, long);
                *p++ = (char)d;
                n--;
                break;
            case 'u':
                d = va_arg(ap, long);
                len = pr_udec(p, n, (unsigned long)d, width, zero);
                p += len;
                n -= len;
                break;
            case 'd':
            case 'i':
                d = va_arg(ap, long);
                len = pr_dec(p, n, d, width, zero);
                p += len;
                n -= len;
                break;
            case 's':
                d = (long)va_arg(ap, long);
                len = pr_sub(p, n, (char *)d, strlen((char *)d), width, zero);
                p += len;
                n -= len;
                break;
            case 'X':
                d = va_arg(ap, int);
                len = pr_hex(p, n, (unsigned long)d, width, zero, TRUE);
                p += len;
                n -= len;
                break;
            case 'x':
                d = va_arg(ap, int);
                len = pr_hex(p, n, (unsigned long)d, width, zero, FALSE);
                p += len;
                n -= len;
                break;
            default:
                fmt--;
            case '%':
                *p++ = '%';
                n--;
                break;
            }
        } else {
            *p++ = c;
            n--;
        }
    }
    *p = '\0';
    return (p - buf);
}

/*****************************************************************************
* ���sprintf
*
******************************************************************************/

int my_sprintf(char *buf, const char *format, ...)
{
    va_list argp;
    int n;

    va_start(argp, format);
    n = my_vsnprintf(buf, SPRINTF_BUFSZ, format, argp);
    va_end(argp);
    return n;
}

/*****************************************************************************
* ���snprintf
*
******************************************************************************/

int my_snprintf(char *buf, size_t size, const char *format, ...)
{
    va_list argp;
    int n;

    va_start(argp, format);
    n = my_vsnprintf(buf, size, format, argp);
    va_end(argp);
    return n;
}

/* end */
