/******************************************************************************
* Telnet Command Shell                                                        *
*                                                                             *
*  Copyright (c) 1999-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-23 Created                                                          *
* 1999-09-22 Added auto ID assignment of cre_???() for specified id = 0    YS *
* 2002-02-08 Changed 'B' of msg_xx_yy[] into 'char' to avoid CC32R warning OK *
* 2002-02-23 Changed sta_tsk() into vsta_tsk() for 16-bit INT              HM *
* 2003-04-25 Added dly_tsk() in shell_tsk()                                YS *
* 2005-04-20 Removed casting of strings with (B *)                         PK *
* 2005-05-13 Added shell_ext() to uninitialize command shell               AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based          AK *
* 2009-08-03 Added timeout parameter to terminal_input()                   FY *
* 2011-06-30 Corrected compiler warnings by adding (FP) and (PASSWD_CHECK) HE *
* 2012-03-26 Fixed shell_tsk() to clear current_terminal only after login  GS *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2015-07-02 Removed dly_tsk() between logged_in = -1 and rel_wai()        FY *
* 2015-09-12 Replaced old NORTi3-unique vsta_tsk() with sta_tsk()          MI *
* 2015-09-12 Removed unused transimission message buffer and test function MI *
* 2015-09-12 Moved CTRL_C definition to nonteln.h                          MI *
* 2015-09-12 Removed PASSWD_CHECK function type                            MI *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonteln.h"

/* Telnet Messages */

const char msg_login_ng[]     = "login incorrect.";
const char msg_telnet_busy[]  = "Telnet is already used.";
const char msg_telnet_tmout[] = "timeout.";

/* Object Creation Information */

TASK shell_tsk(T_TERMINAL *);
const T_CTSK shell_ctsk = { TA_HLNG, NULL, (FP)shell_tsk, SHELL_PRI, SHELL_SSZ+COMMAND_LINE_LEN, NULL, "shell_tsk" };

/* Global Variable */

T_TERMINAL *current_terminal = NULL;

/************************************************/
/* Login Process                                */
/************************************************/

BOOL login_proc(T_TERMINAL *t, char *login_prompt, char *passwd_prompt, FP callback)
{
    char name[LOGIN_NAME_LEN+1];
    char passwd[PASSWORD_LEN+1];
    INT n, c;
    char echo;

    for (;;) {

        /* get login name */
        for (;;) {
            if (!terminal_rputs(t, login_prompt))
                return FALSE;
            for (;;) {
                c = terminal_input(t, name, sizeof name, TMO_FEVR);
                if (c <= 0)
                    return FALSE;
                break;
            }
            if (c == '\r')
                break;
        }

        /* get password */
        for (n = 3; n > 0; n--) {
            if (!terminal_rputs(t, passwd_prompt))
                return FALSE;
            echo = t->echo_on;
            for (;;) {
                if (echo)
                    t->echo_on = '*';
                c = terminal_input(t, passwd, sizeof passwd, TMO_FEVR);
                t->echo_on = echo;
                if (c <= 0)
                    return FALSE;
                break;
            }
            if (c != '\r')
                break;

            if (callback == (FP)NULL)
                return TRUE;
            t->prompt = ((char *(*)(T_TERMINAL *, char *, char *))callback)(t, name, passwd);

            if (t->prompt != NULL)
                return TRUE;
            if (!terminal_rputs(t, msg_login_ng))
                return FALSE;
        }
    }
}

/************************************************/
/* Command Shell                                 */
/************************************************/

INT command_shell(T_TERMINAL *t)
{
    char s[COMMAND_LINE_LEN+1];
    INT c;

    for (;;) {

        /* put prompt */
        if (!terminal_rputs(t, t->prompt))
            return 0;

        /* get string */
        for (;;) {
            c = terminal_input(t, s, sizeof s, t->tmo);
            if (c <= 0)
                return c;
            break;
        }
        if (s[0] == '\0' || c != '\r')
            continue;

        /* logout command */
        if (strcmp(s, "logout") == 0 || strcmp(s, "bye") == 0) {
            terminal_rputs(t, "");
            return TRUE;
        }

        /* other commands */
        puts("");
        if (!telnetd_callback(t, s))
            return TRUE;
    }
}

/************************************************/
/* Uninitialize Command Shell                   */
/************************************************/

void shell_ext(VP t)
{
    T_TERMINAL *tt;
    ID tskid;

    tt = (T_TERMINAL *)t;
    if ((tskid = tt->shell_tskid) != 0) {
        ter_tsk(tskid);
        del_tsk(tskid);
    }
}

/************************************************/
/* Command Shell Task                           */
/************************************************/

TASK shell_tsk(T_TERMINAL *t)
{
    int c;

    for (;;) {

        dly_tsk(100/MSEC);

        if (!login_proc(t, "login: ", "Password: ", t->passwd_check))
            break;
        if (current_terminal != NULL) {
            if (!terminal_rputs(t, msg_telnet_busy))
                break;
            continue;
        }
        current_terminal = t;

        t->logged_in = TRUE;
        c = command_shell(t);
        if (c == E_TMOUT) {
            terminal_print(t, "\r\n");
            terminal_print(t, msg_telnet_tmout);
            terminal_print(t, "\r\n");
        }
        current_terminal = NULL;
        break;
    }
    t->logged_in = (B)-1;
    rel_wai(t->telnetd_tskid);
    ext_tsk();
}

/************************************************/
/* Initialize Command Shell                     */
/************************************************/

ER (shell_ini)(VP t, ID tskid, ID mbfid, FP callback)
{
    T_TERMINAL *tt;          /* mbfid is not used */
    ER ercd;

    /* setup control block (after Telnet server initialization) */
    tt = (T_TERMINAL *)t;
    tt->passwd_check = callback;

    /* create command shell task */
    if (tskid == 0)
        ercd = tskid = acre_tsk(&shell_ctsk);
    else
        ercd = cre_tsk(tskid, &shell_ctsk);
    if (ercd < 0)
        return ercd;
    tt->shell_tskid = (UH)tskid;

    /* start Telnet server task */
    ercd = sta_tsk(tt->telnetd_tskid, t);
    if (ercd != E_OK) {
        shell_ext(t);
        return ercd;
    }
    return E_OK;
}

/* end */
