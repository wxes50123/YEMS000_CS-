/******************************************************************************
* DHCP Client Sample                                                          *
*                                                                             *
*  Copyright (c) 2000-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-01-24 Created                                                          *
* 2002-10-06 Modified dhcp_snd_dat() to send also unused options padded       *
*                 with zeros since minimum option field size is 312 bytes  YS *
* 2003-04-15 Added dhcp_reb_data()                                         YS *
* 2003-12-16 Modified for multi-channel                                    AK *
* 2004-02-25 Added dhcp_ren_data()                                         YS *
* 2004-02-25 Added re-transmission for each request                        YS *
* 2005-04-20 Modified for multi-channel                                    PK *
* 2005-05-13 Added DHCP uninitialization code                              AK *
* 2005-05-13 Replaced NORTi3 based system calls with NORTi4 based ones     AK *
* 2006-01-27 Fixed dhcp_rcv_dat() to use netif_chg_ipa() to update address MK *
* 2006-03-07 Changed DHCP_TMOUT to 4 sec by default                        MK *
* 2006-03-13 Added vcan_wup() in end of dhcp_get_byname()/dhcp_rget_data()    *
*                 to clear pended wakeup requests issued by DHCP callback  AK *
* 2006-10-31 Modified dhcp_rcv_dat() to verify client hardware address     AK *
* 2007-07-25 Added yiaddr variable copying rcv_pkt->yiaddr not to refer       *
*                       overwritten value by other DHCP packets receiving  GS *
* 2007-08-09 Added gen_rand_dly() for random delay in DHCP requests to        *
*             avoid network congestion when multiple systems boot at once  GS *
* 2008-11-21 Fixed dhcp_get_byname()/dhcp_rget_data() not to release          *
*               packet buffer with rel_mpf() until udp_del_cep() finishes  FY *
* 2010-12-28 Added (FP) to T_CTSK's dhcp_req_tsk to avoid compiler warning HE *
* 2011-01-31 Replaced get_mpf(ID_ETH_MPF, ...) with pget_mpf() in             *
*                    dhcp_get_mem() not to block Ethernet frame buffering  GS *
* 2011-01-31 Restarted alarm handler in dhcp_rget_data() to avoid             *
*               infinite sleep of dhcp_req_tsk() on lease renewal failure  GS *
* 2011-06-30 Added (FP) to T_CALM's ex_ip_lease to avoid compiler warning  HE *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2013-06-28 Added T_UDP_CCEP dhcp_cep definition for IPv6 on dual stack   FY *
* 2013-07-09 Fixed dhcp_snd_dat() to keep transaction ID of DHCP request   FY *
* 2022-09-22 Removed old and unused dhcp_get_data()/dhcp_ren_data()/          *
*               dhcp_reb_data()/dhcp_ipaddr[4], and adjusted coding style  FY *
* 2022-11-07 Fixed gen_rand_dly() to calculate exactly even when MSEC!=10  MI *
******************************************************************************/

#include <string.h>
#ifndef NULL
#include <stdio.h>
#endif
#ifdef GAIO
#include <memory.h>
#endif
#include "kernel.h"
#include "nonet.h"
#include "nonets.h"
#include "nondhcp.h"
#define INCLUDED_FROM_NONET
#include "nonetc.h"

/* Configuration */

#ifndef DHCP_TMO
#define DHCP_TMO            (4000/MSEC)
#endif

/* DHCP Options */

static const UB opt1[] = { 99, 130, 83, 99, DHCP_OP_MSGTYP, 1, DHCPDISCOVER, 255 };

static const UB opt2[] = {
    99, 130, 83, 99,
    DHCP_OP_MSGTYP, 1, DHCPREQUEST,
    DHCP_OP_PRMLST, 6, DHCP_OP_SUBNET, DHCP_OP_ROUTER, DHCP_OP_DNS,
    DHCP_OP_ADDRTM, DHCP_OP_RENETM, DHCP_OP_REBITM
};

static const UB opt3[] = {
    99, 130, 83, 99,
    DHCP_OP_MSGTYP, 1, DHCPREQUEST,
    DHCP_OP_PRMLST, 3, DHCP_OP_ADDRTM, DHCP_OP_RENETM, DHCP_OP_REBITM, 255
};

/* Object Creation Information */

static ER dhcp_callback(ID, FN, VP);
#ifdef DUAL_STK
static T_UDP_CCEP dhcp_cep = { 0, { 0, UDP_PORT_BOOTPC, IPV6_ADDRANY, IPV4_ADDR }, (FP)dhcp_callback };
#else
static T_UDP_CCEP dhcp_cep = { 0, { 0, UDP_PORT_BOOTPC }, (FP)dhcp_callback };
#endif

static TASK dhcp_req_tsk(void);
static const T_CTSK dhcp_res_ctsk = { TA_HLNG, NULL, (FP)dhcp_req_tsk, DHCP_REQTSK_PRI, DHCP_REQTSK_SSZ, NULL };

static void ex_ip_lease(VP_INT);
static T_CALM calm = { TA_HLNG, NULL, (FP)ex_ip_lease };

/* Internal Functions */

static ER dhcp_sta_tsk(ID, ID, ID, DHCP_CALLBACK);
static void gen_rand_dly(T_NIF *);
static ER dhcp_sta_alm(void);

/* Internal Variables */

static T_DHCP_CB dhcp_cb;
static T_IPEP dstaddr;
static UW lease_time;
static UW xid = 1711959080;
static UW yiaddr;
static B rand_dly;

/************************************************/
/* UDP Callback Routine for DHCP                */
/************************************************/

static ER dhcp_callback(ID cepid, FN fncd, VP parblk)
{
    if (dhcp_cb.btskid != 0)
        wup_tsk(dhcp_cb.btskid);
    return E_OK;
}

/************************************************/
/* Search DHCP Vender Option                    */
/************************************************/

static UB* search_option(UB tag, UB* opt)
{
    int i;
    UB n;

    if (opt == NULL)
        return NULL;

    /* skip magic cookie */
    opt += 4;

    /* serach option */
    for (i = 0; i < 312; i++) {
        if (*opt == 255)
            return NULL;
        if (*opt++ == tag)
            return ++opt;
        n = *opt++;
        opt += n;
    }
    return NULL;
}

/************************************************/
/* Send DHCP Data                               */
/************************************************/

static ER dhcp_snd_dat(ID cepid, UB code, UB flg, T_DHCP* snd_pkt, T_DHCP* rcv_pkt, TMO tmout, T_NIF *nif)
{
    ER ercd;
    UB *p;

    memset(snd_pkt, 0, sizeof (T_DHCP));
    snd_pkt->op = BOOT_REQUEST;
    snd_pkt->htype = 1; /* (10MbEthernet) */
    snd_pkt->hlen = 6;
    if (!(code == DHCPREQUEST && flg == REQ_SELECT))
        xid++;
    snd_pkt->xid = htonl(xid);
    snd_pkt->flag = htons(0x8000);
    memcpy(snd_pkt->chaddr, nif->hwaddr, 6);
    dstaddr.portno = UDP_PORT_BOOTPS;

    switch (code) {
    case DHCPDISCOVER:
        dstaddr.ipaddr = 0xFFFFFFFF; /* broad cast */
        memcpy(snd_pkt->option, opt1, sizeof opt1);
        if (flg == REQ_REBIND)
            snd_pkt->ciaddr = htonl(byte4_to_long(nif->ipaddr));
        break;
    case DHCPREQUEST:
        /* DHCP request in SELECTING state */
        if (flg == REQ_SELECT) {
            dstaddr.ipaddr = 0xFFFFFFFF; /* broad cast */
            memcpy(snd_pkt->option, opt2, sizeof opt2);
            p = (UB *)(snd_pkt->option + sizeof opt2);
            *p++ = DHCP_OP_SERVID;
            *p++ = 4;
            memcpy(p, nif->dhcp_ipaddr, 4);
            p += 4;
            *p++ = DHCP_OP_ADRREQ;
            *p++ = 4;
            /* use DHCP server offered address */
            long_to_byte4(p, ntohl(yiaddr));
            p += 4;
            *p = 255;
        }
        /* DHCP request for lease extension */
        else {
            snd_pkt->flag = 0;
            snd_pkt->ciaddr = htonl(byte4_to_long(nif->ipaddr));
            if (flg == REQ_REBIND)
                dstaddr.ipaddr = 0xFFFFFFFF; /* broad cast */
            else
                dstaddr.ipaddr = byte4_to_long(nif->dhcp_ipaddr);
            memcpy(snd_pkt->option, opt3, sizeof opt3);
        }
        break;
    }

    ercd = udp_rcv_dat(cepid, &dstaddr, (VP)rcv_pkt, sizeof (T_DHCP), TMO_NBLK);
    if (ercd != E_WBLK)
        return ercd;

    ercd = udp_snd_dat(cepid, &dstaddr, snd_pkt, sizeof (T_DHCP), tmout);
    if (ercd <= 0)
        return ercd;
    return E_OK;
}

/************************************************/
/* Receive DHCP Data                            */
/************************************************/

static ER dhcp_rcv_dat(ID cepid, UB code, UB flg, T_DHCP *pkt, TMO tmout, T_NIF *nif)
{
    ER ercd;
    UB *p;
    T_NIF_ADDR addr;
    UB mask[4], gateway[4], new_ipaddr[4];

    /* wait for packet receiving */
    ercd = tslp_tsk(tmout);
    if (ercd != E_OK) {
        udp_can_cep(cepid, TFN_UDP_RCV_DAT);
        goto ERR;
    }

    /* receive DHCP response */
    for (;;){
        p = search_option(DHCP_OP_MSGTYP, pkt->option);
        if (p != NULL) {
            if (ntohl(pkt->xid) == xid && pkt->op == BOOT_REPLY && *p == code) {
                if ((pkt->hlen == 6) && memcmp(pkt->chaddr, nif->hwaddr, 6) == 0)
                    break;
            }
        }
        ercd = udp_rcv_dat(cepid, &dstaddr, (VP)pkt, sizeof (T_DHCP), tmout);
        if (ercd <= 0)
            goto ERR;
    }

    switch (code) {
    case DHCPOFFER:
        /* set DHCP server address */
        p = search_option(DHCP_OP_SERVID, pkt->option);
        if (p != NULL)
            memcpy(nif->dhcp_ipaddr, p, 4);
        yiaddr = pkt->yiaddr;
        break;
    case DHCPACK:
        /* set local IP address */
        long_to_byte4(new_ipaddr, ntohl(pkt->yiaddr));
        addr.ipaddr = new_ipaddr;
        addr.hwaddr = nif->hwaddr;
        addr.mask = nif->mask;
        addr.gateway = nif->gateway;
        if (flg == REQ_SELECT) {
            /* set subnet mask */
            p = search_option(DHCP_OP_SUBNET, pkt->option);
            if (p != NULL) {
                memcpy(mask, p, 4);
                addr.mask = mask;
            }
            /* set router address */
            p = search_option(DHCP_OP_ROUTER, pkt->option);
            if (p != NULL) {
                memcpy(gateway, p, 4);
                addr.gateway = gateway;
            }
            /* set DNS address */
            p = search_option(DHCP_OP_DNS, pkt->option);
            if (p != NULL)
                memcpy(nif->dns_ipaddr, p, 4);
        }
        /* change IP address of network I/F & TCP/UDP comm end points */
        netif_chg_ipa(nif, &addr, 2);
        /* get time */
        p = search_option(DHCP_OP_RENETM, pkt->option);
        if (p == NULL) {
            p = search_option(DHCP_OP_REBITM, pkt->option);
            if (p == NULL) {
                p = search_option(DHCP_OP_ADDRTM, pkt->option);
                if (p == NULL){
                    ercd = E_OBJ;
                    goto ERR;
                }
            }
        }
        lease_time = byte4_to_long(p);
        break;
    }
ERR:
    if (ercd <= 0)
        return ercd;
    return E_OK;
}

/************************************************/
/* Allocate Memory for Tx/Rx Buffer             */
/************************************************/

static ER dhcp_get_mem(T_DHCP **pkt)
{
    ER ercd;
    TMO tmo;
    int i;

    for (i = 0, tmo = DHCP_TMO; i < DHCP_RETRY; i++, tmo *= 2) {
        ercd = pget_mpf(ID_ETH_MPF, pkt);
        if (ercd == E_TMOUT) {
            tslp_tsk(tmo);
            continue;
        }
        return ercd;
    }
    return E_NOMEM;
}

/************************************************/
/* Release Memory for Tx/Rx Buffer              */
/************************************************/

static ER dhcp_rel_mem(T_DHCP *pkt)
{
    return rel_mpf(ID_ETH_MPF, pkt);
}

/************************************************/
/* Get DHCP Data                                */
/************************************************/

ER dhcp_get_byname(ID cepid, const char *ch_name)
{
    ER ercd;
    T_DHCP *rcv_pkt, *snd_pkt;
    T_NIF *nif;
    TMO tmo;
    int i;

    nif = getnif_from_name(ch_name);
    if (nif == NULL)
        nif = getnif_default();

    dhcp_cep.myaddr.ipaddr = byte4_to_long(nif->ipaddr);

    /* create UDP communication end point for DHCP */
    if (!cepid) {
        cepid = udp_vcre_cep(&dhcp_cep);
        if (cepid <= 0)
            return cepid;
    } else {
        ercd = udp_cre_cep(cepid, &dhcp_cep);
        if (ercd != E_OK)
            return ercd;
    }

    /* relate network I/F with UDP communication end point */
    ercd = udp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        udp_del_cep(cepid);
        return ercd;
    }

    /* enable broadcast send/receive */
    ercd = udp_set_opt(cepid, IP_BROADCAST, (VP)TRUE, 1);
    if (ercd != E_OK) {
        udp_del_cep(cepid);
        return ercd;
    }

    /* allocate memory for Rx ruffer */
    ercd = dhcp_get_mem(&rcv_pkt);
    if (ercd != E_OK) {
        udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
        udp_del_cep(cepid);
        return ercd;
    }

    /* allocate memory for Tx ruffer */
    ercd = dhcp_get_mem(&snd_pkt);
    if (ercd != E_OK) {
        udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
        udp_del_cep(cepid);
        dhcp_rel_mem(rcv_pkt);
        return ercd;
    }

    /* randomize the delay */
    gen_rand_dly(nif);

    dhcp_cb.btskid = (UH)vget_tid();
    dhcp_cb.cepid = (UH)cepid;

    for (i = 0, tmo = DHCP_TMO; i < DHCP_RETRY; i++, tmo *= 2) {
        /* send DHCPDISCOVER */
        ercd = dhcp_snd_dat(cepid, DHCPDISCOVER, 0, snd_pkt, rcv_pkt, tmo, nif);
        if (ercd == E_TMOUT)
            continue;
        else if (ercd != E_OK)
            goto END1;

        /* receive DHCPOFFER */
        ercd = dhcp_rcv_dat(cepid, DHCPOFFER, 0, rcv_pkt, tmo + rand_dly, nif);
        if (ercd == E_OK)
            break;
        else if (ercd != E_TMOUT)
            goto END1;
    }
    if (ercd != E_OK) /* timeout error */
        goto END1;

    for (i = 0, tmo = DHCP_TMO; i < DHCP_RETRY; i++, tmo *= 2) {
        /* send DHCPREQUEST */
        ercd = dhcp_snd_dat(cepid, DHCPREQUEST, REQ_SELECT, snd_pkt, rcv_pkt, tmo, nif);
        if (ercd == E_TMOUT)
            continue;
        else if (ercd != E_OK)
            goto END1;

        /* receive DHCPACK */
        ercd = dhcp_rcv_dat(cepid, DHCPACK, REQ_SELECT, rcv_pkt, tmo + rand_dly, nif);
        if (ercd == E_OK || ercd != E_TMOUT)
            break;
    }

END1:
    dhcp_cb.cepid = 0;
    dhcp_cb.btskid = 0;
    vcan_wup();
    udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
    udp_del_cep(cepid);
    dhcp_rel_mem(rcv_pkt);
    dhcp_rel_mem(snd_pkt);

    if (ercd == E_OK) {
        ercd = dhcp_sta_tsk(0, 0, 0, NULL);
        if (ercd == E_OK)
            ercd = dhcp_sta_alm();
    }
    return ercd;
}

/************************************************/
/* Re-Get DHCP Data                             */
/************************************************/

static ER dhcp_rget_data(ID cepid, int flg, T_NIF *nif)
{
    ER ercd;
    T_DHCP *rcv_pkt, *snd_pkt;
    TMO tmo;
    int i;

    dhcp_cep.myaddr.ipaddr = byte4_to_long(nif->ipaddr);

    if (!cepid) {
        cepid = udp_vcre_cep(&dhcp_cep);
        if (cepid <= 0)
            return cepid;
    } else {
        ercd = udp_cre_cep(cepid, &dhcp_cep);
        if (ercd != E_OK)
            return ercd;
    }

    /* relate network I/F with UDP communication end point */
    ercd = udp_set_opt(cepid, IP_IF_NAME, nif->name, 0);
    if (ercd != E_OK) {
        udp_del_cep(cepid);
        return ercd;
    }

    /* enable broadcast send/receive */
    ercd = udp_set_opt(cepid, IP_BROADCAST, (VP)TRUE, 1);
    if (ercd != E_OK) {
        udp_del_cep(cepid);
        return ercd;
    }

    /* allocate memory for Rx ruffer */
    ercd = dhcp_get_mem(&rcv_pkt);
    if (ercd != E_OK) {
        udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
        udp_del_cep(cepid);
        return ercd;
    }

    /* allocate memory for Tx ruffer */
    ercd = dhcp_get_mem(&snd_pkt);
    if (ercd != E_OK) {
        udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
        udp_del_cep(cepid);
        dhcp_rel_mem(rcv_pkt);
        return ercd;
    }

    dhcp_cb.btskid = (UH)vget_tid();
    dhcp_cb.cepid = (UH)cepid;

    for (i = 0, tmo = DHCP_TMO; i < DHCP_RETRY; i++, tmo *= 2) {
        /* send DHCPREQUEST */
        ercd = dhcp_snd_dat(cepid, DHCPREQUEST, flg, snd_pkt, rcv_pkt, tmo, nif);
        if (ercd == E_TMOUT)
            continue;
        else if (ercd != E_OK)
            goto ERR;

        /* receive DHCPACK */
        ercd = dhcp_rcv_dat(cepid, DHCPACK, flg, rcv_pkt, tmo + rand_dly, nif);
        if (ercd == E_OK || ercd != E_TMOUT)
            break;
    }

ERR:
    dhcp_cb.cepid = 0;
    dhcp_cb.btskid = 0;
    vcan_wup();
    udp_set_opt(cepid, IP_BROADCAST, (VP)FALSE, 1);
    udp_del_cep(cepid);
    dhcp_rel_mem(snd_pkt);
    dhcp_rel_mem(rcv_pkt);

    if (ercd == E_OK && dhcp_cb.rtskid != 0)
        ercd = dhcp_sta_alm();
    return ercd;
}

/************************************************/
/* Renew DHCP Data                              */
/************************************************/

ER dhcp_ren_byname(ID cepid, const char *ch_name)
{
    T_NIF *nif;

    nif = getnif_from_name(ch_name);
    if (nif == NULL)
        nif = getnif_default();
    return dhcp_rget_data(cepid, REQ_RENEW, nif);
}

/************************************************/
/* Rebind DHCP Data                             */
/************************************************/

ER dhcp_reb_byname(ID cepid, const char *ch_name)
{
    T_NIF *nif;

    nif = getnif_from_name(ch_name);
    if (nif == NULL)
        nif = getnif_default();
    return dhcp_rget_data(cepid, REQ_REBIND, nif);
}

/************************************************/
/* Delete DHCP Objects                          */
/************************************************/

void dhcp_ext(void)
{
    /* delete all the resources used by DHCP */
    udp_can_cep(dhcp_cb.cepid, TFN_UDP_ALL);
    udp_del_cep(dhcp_cb.cepid);
    dhcp_cb.cepid = 0;

    if (dhcp_cb.btskid != 0) {
        wup_tsk(dhcp_cb.btskid);
        dhcp_cb.btskid = 0;
    }

    ter_tsk(dhcp_cb.rtskid);
    del_tsk(dhcp_cb.rtskid);
    dhcp_cb.rtskid = 0;

    del_alm(dhcp_cb.almid);
    dhcp_cb.almid = 0;
}

/************************************************/
/* Start DHCP Alarm Handler                     */
/************************************************/

static ER dhcp_sta_alm(void)
{
    ER ercd;

    /* set lease timout */
  #ifdef DEBUG
    lease_time = 10;
  #endif

    if (!(lease_time & 0xFFF00000))
        ercd = sta_alm(dhcp_cb.almid, lease_time*1000/MSEC);
    else
        ercd = sta_alm(dhcp_cb.almid, 0xFFFFFFFF);
    return ercd;
}

/************************************************/
/* Start DHCP Client Task                       */
/************************************************/

ER dhcp_sta_tsk(ID tskid, ID cepid, ID almid, DHCP_CALLBACK callback)
{
    ER ercd;

    if (dhcp_cb.rtskid != 0)
        return E_OK;

    /* create task */
    if (tskid != 0) {
        ercd = cre_tsk(tskid, &dhcp_res_ctsk);
        if (ercd != E_OK)
            return ercd;
    } else {
        tskid = acre_tsk(&dhcp_res_ctsk);
        if (tskid <= 0)
            return tskid;
    }

    dhcp_cb.cepid = (UH)cepid;
    dhcp_cb.rtskid = (UH)tskid;
    dhcp_cb.callback = callback;

    /* start task */
    sta_tsk(tskid, 0);

    /* create alarm handler */
    if (almid != 0) {
        ercd = cre_alm(almid, &calm);
        if (ercd != E_OK)
            goto ERR;
        dhcp_cb.almid = (UH)almid;
    } else {
        ercd = acre_alm(&calm);
        if (ercd <= 0)
            goto ERR;
        dhcp_cb.almid = (UH)ercd;
    }
    return E_OK;

ERR:
    del_tsk(dhcp_cb.rtskid);
    del_alm(dhcp_cb.almid);
    dhcp_cb.rtskid = 0;
    dhcp_cb.almid = 0;
    return ercd;
}

/************************************************/
/* DHCP Alarm Handler                           */
/************************************************/

static void ex_ip_lease(VP_INT exinf)
{
    wup_tsk(dhcp_cb.rtskid);
}

/************************************************/
/* DHCPREQUEST Send Task                        */
/************************************************/

static TASK dhcp_req_tsk(void)
{
    ER ercd;
    T_NIF *nif;
    DHCP_CALLBACK func;

    func = dhcp_cb.callback;

    for(;;) {
        vcan_wup();
        ercd = tslp_tsk(TMO_FEVR);
        if (ercd == E_RLWAI)
            break;

        /* renew DHCP data */
        for (nif = getnif_default(); nif != NULL; nif=nif->next) {
            if (byte4_to_long(nif->dhcp_ipaddr) != 0L) {
                ercd = dhcp_ren_byname(dhcp_cb.cepid, (char *) nif->name);
                if (ercd != E_OK)
                    goto ERR;
            }
        }
ERR:
        if (func != (DHCP_CALLBACK)NULL)
            (func)(ercd);
    }
    exd_tsk();
}

/************************************************/
/* Generate Random Interval                     */
/************************************************/

static void gen_rand_dly(T_NIF *nif)
{
    UB *mac = nif->hwaddr;
    int n;

    /* random number is taken from MAC address */
    n = mac[2] + mac[3] + mac[4] + mac[5];
    /* let consecutive numbers make at least 100ms (+-50ms) difference */
    n = (n * 50/MSEC) & 0x7f;
    if (n & 1)
        n *= -1;
    rand_dly = (B)n;
}

/* end */
