/******************************************************************************
* DHCP Server/Client Sample Header                                            *
*                                                                             *
*  Copyright (c) 2000-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-02-25 Created                                                          *
* 2001-02-12 Changed task priority DHCP_REQTSK_PRI from 4 to 5                *
* 2003-12-16 Modified for multi-channel                                    AK *
* 2005-04-20 Modified again for multi-channel                              PK *
* 2005-05-13 Added dhcp_ext()                                              AK *
* 2011-01-25 Increased DHCP_REQTSK_SSZ to 1024 to avoid stack overflow     GS *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2019-07-05 Added dns_resolver() declaration to remove it in user program GS *
* 2024-06-13 Added dns_resolver_byname() declaration also                  FY *
* 2024-06-13 Added definitions and declarations for DHCP server, removing     *
*               dhcpd_del_group() 1st param (subnet mask) and dhcpd_ini()     *
*               3rd param (fixed-size memory pool ID) from 2008 prototype  FY *
* 2024-06-13 Renamed T_DHCP DHCP_OP_SIZ to DHCP_OPTLEN, and adjusted style FY *
******************************************************************************/

#ifndef NONDHCP_H
#define NONDHCP_H
#ifdef __cplusplus
extern "C" {
#endif

/* Configuration */

#define DHCP_RETRY        3

#define DHCP_REQTSK_PRI   5     /* DHCP request task priority */
#ifndef DHCP_REQTSK_SSZ
#define DHCP_REQTSK_SSZ   1024  /* DHCP request task stack size */
#endif

#define DHCPD_TSK_PRI     5     /* DHCP server task priority */
#ifndef DHCPD_TSK_SSZ
#define DHCPD_TSK_SSZ     1024  /* DHCP server task stack size */
#endif

/* DHCP Callback Routine */

typedef void (*DHCP_CALLBACK)(ER);

/* DHCP Control Block */

typedef struct t_dhcp_cb {
    UH cepid;
    UH btskid;
    UH rtskid;
    UH almid;
    DHCP_CALLBACK callback;
} T_DHCP_CB;

/* DHCP Packet */

typedef struct t_dhcp {
    UB op;                  /* message operation */
#define BOOT_REQUEST    1
#define BOOT_REPLY      2
    UB htype;               /* hardware address type */
    UB hlen;                /* hardware address length */
    UB hops;                /* hardware option */
    UW xid;                 /* transaction ID */
    UH secs;                /* progress time */
    UH flag;                /* flag field */
    UW ciaddr;              /* client IP address */
    UW yiaddr;              /* your address */
    UW siaddr;              /* server IP address */
    UW giaddr;              /* gateway IP address */
    UB chaddr[16];          /* client hardware address */
    UB sname[64];           /* server name(option) */
    UB file[128];           /* boot file name */
#define DHCP_OPTLEN 312
    UB option[DHCP_OPTLEN]; /* option */
} T_DHCP;

#define REQ_SELECT      1
#define REQ_RENEW       2
#define REQ_REBIND      3

/* DHCP Option */

#define DHCP_OP_SUBNET  1   /* subnet mask */
#define DHCP_OP_ROUTER  3   /* router address */
#define DHCP_OP_DNS     6   /* name server address */
#define DHCP_OP_ADRREQ  50  /* address request */
#define DHCP_OP_ADDRTM  51  /* IP address lease time */
#define DHCP_OP_MSGTYP  53  /* message type */
#define DHCP_OP_SERVID  54  /* DHCP server ID */
#define DHCP_OP_PRMLST  55  /* parameter request list */
#define DHCP_OP_RENETM  58  /* renewal time */
#define DHCP_OP_REBITM  59  /* rebinding time */
#define DHCP_OP_CLIENT  61  /* client ID */

/* DHCP Message Type */

#define DHCPDISCOVER    1
#define DHCPOFFER       2
#define DHCPREQUEST     3
#define DHCPDECLINE     4
#define DHCPACK         5
#define DHCPNAK         6
#define DHCPRELEASE     7
#define DHCPINFORM      8

/* DNS Resolver APIs */

ER dns_resolver(ID, UW, const char *, T_IPEP *);
ER dns_resolver_byname(ID, UW, const char *, T_IPEP *, const char *);
#define dns_name_resolver dns_resolver /* for backward compatibility on IPv6 */

/* DHCP Client APIs */

ER dhcp_get_data(ID);
ER dhcp_reb_data(ID);
ER dhcp_get_byname(ID, const char *);
ER dhcp_reb_byname(ID, const char *);
void dhcp_ext(void);

/* DHCP Server APIs */

ER dhcpd_ini(ID, ID);
ER dhcpd_add_addr(UW, UW, UW, UB *);
ER dhcpd_del_addr(UW);
ER dhcpd_add_group(UW, UW, UW);
ER dhcpd_del_group(UW);

#ifdef __cplusplus
}
#endif
#endif /* NONDHCP_H */
