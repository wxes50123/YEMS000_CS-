/******************************************************************************
* NORTi Network FTP Header                                                    *
*                                                                             *
*  Copyright (c) 1999-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-26 Created                                                          *
* 1999-06-09 FTPDATA_RBUFSZ 2048 -> 2920 (MTU - header size) * 2              *
* 2001-02-12 Change Task priority 4 -> 5  FTP_SERVER_PRI,FTP_CLIENT_PRI       *
* 2002-04-10 FTPDATA_SBUFSZ, FTPDATA_RBUFSZ and FTP_BUFSZ were enlarged.      *
* 2003-03-18 FTP_SERVER_SSZ and FTP_CLIENT_SSZ became configurable         YS *
* 2005-04-20 FTP_PASV added as flag for PASSIVE mode                       PK *
* 2005-04-20 T_FTP structure and ftp_client function modified              PK *
* 2005-05-13 Added ftpd_ext.                                               AK *
* 2011-10-15 Added const to return value of FTP_CALLBACK function type     HE *
* 2012-11-23 Changed type of variable holding resource ID (ID -> UH)       FY *
* 2012-11-23 Removed unused bufid member of T_FTP                          FY *
* 2014-10-20 Changed FTP_SERVER_SSZ value from 512 to 1024                 FY *
* 2014-10-20 Added ANARES_LEN macro for FTP response length to analyze     FY *
* 2015-11-09 Moved ANARES_LEN macro definition to nonftpc.c                FY *
******************************************************************************/

#ifndef NONFTP_H
#define NONFTP_H
#ifdef __cplusplus
extern "C" {
#endif

/* Constant */

#define FTP_SERVER_PRI  5       /* FTP Server Task Priority */
#define FTP_CLIENT_PRI  5       /* FTP Client Task Priority */
#ifndef FTP_SERVER_SSZ
#define FTP_SERVER_SSZ  1024    /* FTP Server Task Stack Size */
#endif
#ifndef FTP_CLIENT_SSZ
#define FTP_CLIENT_SSZ  512     /* FTP Client Task Stack Size */
#endif

#define FTP_SBUFSZ      128     /* Send    Buffer Size for Control */
#define FTP_RBUFSZ      128     /* Receive Buffer Size for Control */
#ifndef FTPDATA_SBUFSZ
#define FTPDATA_SBUFSZ  4380    /* Send    Buffer Size for Data Transfer */
#endif
#ifndef FTPDATA_RBUFSZ
#define FTPDATA_RBUFSZ  4380    /* Receive Buffer Size for Data Transfer */
#endif

#define FTP_USER_LEN    10      /* FTP User Name Length */
#define FTP_BUFSZ       1460    /* FTP File Read/Write Buffer Size */

/* FTP Control Block */

typedef struct t_ftp {
    ER ercd;
    UH tskid;
    UH cepid1;
    UH cepid2;
    UH repid;
    UH repid2;
    T_IPEP myaddr;
    T_IPEP dstaddr;
    UB flag;
    char user[FTP_USER_LEN+1];
    FILE *fp;
    char buf[FTP_BUFSZ];
    FP callback;
    B sbuf1[FTP_SBUFSZ];
    B rbuf1[FTP_RBUFSZ];
    B sbuf2[FTPDATA_SBUFSZ];
    B rbuf2[FTPDATA_RBUFSZ];
    T_NIF *nif;
} T_FTP;

#define FTP_LOGGED_IN   0x01
#define FTP_DTP_OPEN    0x02
#define FTP_RETR        0x04
#define FTP_STOR        0x08
#define FTP_LIST        0x10
#define FTP_NLST        0x20
#define FTP_QUIT        0x40

#define FTP_READY       0x04
#define FTP_PASSWD_REQ  0x08
#define FTP_OPTION_V    0x10    /* Suppresses Display of Daemon Responses */
#define FTP_OPTION_D    0x20    /* Enables Debugging */
#define FTP_PASV        0x40
#define FTP_CLOSED      0x80

/* Callback Routine for Password Check  */

typedef const char *(*FTP_CALLBACK)(T_FTP *, const char *, const char *);

/* FTP Service Call Prototype */

ER ftp_cre_srv(T_FTP *ftp, ID tskid, ID cepid1, ID cepid2, ID repid, FTP_CALLBACK callback);
ER ftp_sta_srv(T_FTP *ftp);
ER ftp_client(T_FTP *ftp, ID cepid1, ID cepid2, ID repid, UB option, UW ipaddr, T_NIF *nif);
int ftp_command(int argc, char *argv[]);
void ftpd_ext(T_FTP *ftp);

ER ftp_cre_srv6(T_FTP *ftp, ID tskid, ID cepid1, ID cepid2, ID repid, FTP_CALLBACK callback);
int ftp6_command(int argc, char *argv[]);

/* MT�p */

#define FTP_MAX_MEM_BLOCK 2

typedef struct {
    VP    base;      /* FTP�������擪�A�h���X */
    UW    size;      /* FTP�������T�C�Y */
    UW    use_size;  /* �g�p���̃������iByte�P��) */
    B     fname[13]; /* �t�@�C���� */
} T_FTP_MEM_CTL;

extern T_FTP_MEM_CTL ftp_mem_ctl[FTP_MAX_MEM_BLOCK];

#ifdef __cplusplus
}
#endif
#endif /* NONFTP_H */
