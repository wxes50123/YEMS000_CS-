/******************************************************************************
* SNTP Client Configuration Header                                            *
*                                                                             *
* Copyright (c) 2008-2018, MiSPO Co., Ltd.                                    *
* All rights reserved.                                                        *
*                                                                             *
* 2008-01-31 Created                                                       KK *
* 2008-03-07 Added #ifdef for C++                                          KK *
* 2008-05-22 Deleted dummy definition for NTP                              KK *
* 2008-06-17 Added sntp_rcv_pkt array data for UDP callback                KK *
* 2009-06-24 Deleted TM_RECV macro                                         KK *
* 2009-06-25 Reduced packet receiving buffer to one static buffer          KK *
* 2016-07-13 Casted NTP_SRV_MAX macro's srv_max with int to avoid warning  MT *
* 2018-10-04 Adjusted coding style                                         MI *
******************************************************************************/

#ifndef SNTPCFG_H
#define SNTPCFG_H
#ifdef __cplusplus
extern "C" {
#endif

typedef struct t_sntp_cfg {
    UW srv_max;
    UW sntp_tmout;
} T_SNTP_CFG;

#ifndef INCLUDED_FROM_SNTP

#ifndef NTP_SRV_MAX
#define NTP_SRV_MAX       1         /* the number of NTP servers to query */
#endif
#ifndef SNTP_TMOUT
#define SNTP_TMOUT        1000      /* SNTP timeout */
#endif

T_IPV4EP host[NTP_SRV_MAX];         /* NTP server information */
const T_SNTP_CFG SNTP_CFG = { NTP_SRV_MAX, SNTP_TMOUT };

#else

extern T_IPV4EP host[];
extern const T_SNTP_CFG SNTP_CFG;
#define NTP_SRV_MAX (int)SNTP_CFG.srv_max
#define SNTP_TMOUT  SNTP_CFG.sntp_tmout

#endif

#ifdef __cplusplus
}
#endif
#endif /* SNTPCFG_H */
