/******************************************************************************
* SNTP Client Header                                                          *
*                                                                             *
*  Copyright (c) 2008-2024, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2008-01-25 Created                                                       KK *
* 2008-01-30 Changed sntp_ini()/sntp_start to sntp_start()/sntp_get_tim()  KK *
* 2008-03-07 Added #ifdef~#endif for C++                                   KK *
* 2008-05-01 Added JAN_1970 & NTP_FMT_OV macros for NTP time conversion    KK *
* 2008-05-29 Added SNTP_VERSION4 macro as 0x20 (NTP ver.4)                 KK *
* 2010-01-19 Added SEC_TICK macro                                          KK *
* 2010-01-20 Modified coding style                                         KK *
* 2012-02-10 Added missing const modifier to 1st parameter of sntp_start() FY *
* 2015-12-17 Added another const modifier to 1st parameter of sntp_start() FY *
* 2016-08-25 Removed NTP_FMT_OV macro, and added CUIP macro                FY *
* 2018-10-04 Adjusted comments                                             MI *
* 2024-05-31 Altered SNTP_VERSION 0x18(ver.3)->0x20 removing SNTP_VERSION4 MI *
******************************************************************************/

#ifndef NONSNTP_H
#define NONSNTP_H
#ifdef __cplusplus
extern "C" {
#endif

#define SNTP_MODE     3         /* client mode */
#define SNTP_VERSION  0x20      /* SNTP Version 4 */
#define LEAP_INDC     0         /* leap indicator */

#define SNTP_PORT     123       /* SNTP port number */
#define SNTP_LEN      (4*12)    /* SNTP packet length */
#define SNTP_OPT      (4*5)     /* SNTP optional length - key identifier, message digest */

#define SEC_TICK  (1000/MSEC)   /* ticks per second */

#define JAN_1970  0x83AA7E80UL  /* seconds of 1900-01-01 00:00 ~ 1970-01-01 00:00 (2208988800) */
#define CUIP      0x80000000    /* correction for UIP */

typedef struct t_ntp_stmp {
    union {                     /* integer part */
        UW uip;                 /* unsigned */
        W ip;                   /* signed */
    } U_ip;
    union {                     /* decimal part */
        UW ufp;                 /* unsigned */
        W fp;                   /* signed */
    } U_fp;
} T_NTP_TIM;

#define ntp_fp  U_fp.fp
#define ntp_ufp U_fp.ufp
#define ntp_uip U_ip.uip
#define ntp_ip  U_ip.ip

typedef struct t_ntp_pkt {
    UB pkt_lvm;                 /* leap indicator, version & mode */
    UB pkt_stm;                 /* stratum */
    UB pkt_pol;                 /* polling interval */
    B pkt_psn;                  /* precision */
    W pkt_rtdly;                /* root delay */
    UW pkt_rtdisp;              /* root dispersion */
    UW pkt_refid;               /* reference clock ID */
    T_NTP_TIM pkt_reftim;       /* reference timestamp */
    T_NTP_TIM pkt_org;          /* originate timestamp */
    T_NTP_TIM pkt_rcv;          /* receive timestamp */
    T_NTP_TIM pkt_txt;          /* transmit timestamp */
} T_NTP_PKT;

ER sntp_start(const char * const [], UW, TMO);
ER sntp_get_tim(T_NTP_TIM *);
ER ntp_get_tim(T_NTP_TIM *);
void ntp_set_tim(T_NTP_TIM *);

#ifdef __cplusplus
}
#endif
#endif /* NONSNTP_H */
