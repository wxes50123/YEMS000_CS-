/******************************************************************************
* NORTi Network TFTP Sample Header                                            *
*                                                                             *
*  Copyright (c) 1998-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1998-11-28 Created                                                          *
* 2005-01-20 Added TFTP_SERVER_SSZ macro                                   AK *
* 2005-05-13 Added tftpsrv_ext                                             AK *
* 2015-05-27 Added mode and error code definitions                         PB *
******************************************************************************/

#ifndef NONTFTP_H
#define NONTFTP_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef TFTP_SERVER_SSZ
#define TFTP_SERVER_SSZ  512     /* TFTP server task stack size */
#endif

/* TFTP Packet */

#define TFTP_SIZE        512

typedef struct t_tftp {
    UH code;
    UH blkno;
    UB data[TFTP_SIZE];
} T_TFTP;

/* TFTP Mode */

#define TFTP_OCTET       1       /* binary */
#define TFTP_NETASCII    2       /* ascii */

/* TFTP Operation Code */

#define TFTP_RRQ         1       /* read request */
#define TFTP_WRQ         2       /* write request */
#define TFTP_DATA        3       /* data */
#define TFTP_ACK         4       /* ack */
#define TFTP_ERROR       5       /* error */

/* TFTP error code */

#define TFTP_NODEF       0       /* not defined */
#define TFTP_NOFILE      1       /* file not found */
#define TFTP_IGLACES     2       /* access violation */
#define TFTP_DISKFUL     3       /* disk full */
#define TFTP_IGLOP       4       /* illegal operation */
#define TFTP_UNKWNID     5       /* unknown transfer ID */
#define TFTP_FLEXIST     6       /* file already exists */
#define TFTP_NOUSER      7       /* no such user */

/* Function Prototype */

ER tftpsrv_cbk(ID, FN, VP);
TASK tftpsrv_tsk(ID);
ER tftpsrv_ini(ID, ID);
void tftpsrv_ext(void);

#ifdef __cplusplus
}
#endif
#endif /* NONTFTP_H */
