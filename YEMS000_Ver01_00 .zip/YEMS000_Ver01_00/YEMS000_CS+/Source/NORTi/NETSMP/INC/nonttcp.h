/******************************************************************************
* TCP Performance Test Program Header using TTCP Command                      *
*                                                                             *
*  Copyright (c) 2011-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-07-28 Created                                                  KM & MI *
* 2015-03-03 Changed parameters of ttcp_t_loop() and ttcp_r_loop()         FY *
******************************************************************************/

#ifndef NONTTCP_H
#define NONTTCP_H
#ifdef __cplusplus
extern "C" {
#endif

void ttcp_t_loop(UW *);
void ttcp_r_loop(UW *);

#ifdef __cplusplus
}
#endif
#endif /* NONTTCP_H */
