/******************************************************************************
* NORTi File System Version 1 Header                                          *
*                                                                             *
*  Copyright (c) 1999-2022, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-03-07 Created                                                          *
* 1999-05-06 Added remove()                                                   *
* 1999-05-23 Added feof() and rename()                                        *
* 2001-04-12 Added "#ifndef stdin" & "#ifndef FILE", and renamed struct       *
*                direct to unconflicting _direct for GAIO XASS-V compiler  KA *
* 2001-09-12 Added EV_FSYS_NAME~EV_FATLINK and T_DISK's ercd member        KA *
* 2001-09-12 Added unpacked keyword to definition of each structure        KA *
* 2002-01-17 Replaced "B *" of string param with "char *" to avoid warning KA *
* 2002-02-08 Added #undef fopen~rename not to conflict with CC32R stdlib   OK *
* 2002-03-15 Added T_DISK's saveclus member and replaced stdin by SEEK_SET KA *
* 2002-06-18 Corrected mistaken definition of dformat(n,t) to dformat(n)   KA *
* 2003-02-25 Replaced __SH7000 with __ghs to judge Green Hills C           KA *
* 2014-12-22 Added LFS_NTSK~LFS_NALM macros to simplify nonecfg.c          MI *
* 2017-07-27 Added include of stddef.h for exeGCC ver3                     FY *
* 2018-03-16 Added const to 2nd parameter of disk_ini()                    FY *
* 2018-03-16 Changed "UB name" to "char name" to omit casting in nonfile.c FY *
* 2022-04-18 Added ferror() and clearerr()                                 FY *
******************************************************************************/

#ifndef NONFILE_H
#define NONFILE_H
#ifdef __cplusplus
extern "C" {
#endif

/* FILE Structure */

#ifdef GAIO
#ifndef _MAXFILE
#include <stdio.h>
#endif
#else
#ifndef SEEK_SET
#include <stddef.h>
#include <stdio.h>
#endif
#endif
#ifndef SEEK_SET /* if FILE is not defined in stdio.h */
#define SEEK_SET    0
#define SEEK_CUR    1
#define SEEK_END    2
#endif
#ifndef FILE
#define FILE        void
#endif

/* string.h */

#if defined(__ghs) /* Green Hills */
int stricmp(const char *, const char *);
#define unpacked
#elif defined(_MCC68K) /* MCC68K */
int stricmp(const char *, const char *);
#else
#define unpacked
#endif

/* File System Parameter */

#undef  FILENAME_MAX                /* maximum file name length */
#define FILENAME_MAX    (2+8+1+3)   /* D:nnnnnnnn.eee */
#undef  NFILE
#define SECTOR_SIZE     512         /* sector size */

/* Number of Object IDs for File System */

#define LFS_NTSK    0
#define LFS_NSEM    1
#define LFS_NFLG    0
#define LFS_NMBX    0
#define LFS_NMBF    0
#define LFS_NPOR    0
#define LFS_NMPL    0
#define LFS_NMPF    0
#define LFS_NDTQ    0
#define LFS_NMTX    0
#define LFS_NISR    0
#define LFS_NCYC    1
#define LFS_NALM    0

/* Disk Parameter Block */

typedef unpacked struct t_disk {
    unpacked struct t_disk *next;   /* pointer to next disk parameter block */
    UH sc;                          /* sectors per cluster */
    UH rsc;                         /* reserved sector count */
    UH fn;                          /* number of FATs */
    UH rde;                         /* root directry entrys */
    UH sf;                          /* sectors per FAT */
    UH saveclus;                    /* last allocated cluster number */
    UW ts;                          /* total sectors */
    B ch;                           /* drive number */
    char name;                      /* drive name ('A'~'Z') */
    ER (*func)(unpacked struct t_disk *, FN, UW, VP); /* pointer to read/write function */
    UW addr;                        /* device base address */
    UW par;                         /* device dependent parameter */
    ER ercd;                        /* last error code */
} T_DISK;

typedef ER (*DISK_FP)(T_DISK *, FN, UW, VP);

/* Directry Entry */

typedef unpacked struct t_dir_entry {
    char name[8+3];
    B attr;
    B rsv[10];
    UH time;
    UH date;
    UH clusno;
    UW size;
} T_DIR_ENTRY;

#define DIR_ENTRY_SZ    (sizeof (T_DIR_ENTRY)) /* 32 */

/* File Control Block */

typedef unpacked struct t_file {
    ER ercd;
    UH entrno;
    UH byteno;                      /* offset in bytes in buffer */
    UH start;                       /* start cluster number */
    UW sectno;
    UW pos;
    UW size;
    B stat;
    char name[FILENAME_MAX+1];
    T_DISK *d;
    B buf[SECTOR_SIZE];
} T_FILE;

#define TFS_OPENED      0x01
#define TFS_CHANGED     0x02
#define TFS_RD_MODE     0x04
#define TFS_WR_MODE     0x08

/* Directry */

#define DIRECT_FSIZE
#define DIRSIZ          14

unpacked struct _direct {
    short d_ino;
    char d_name[DIRSIZ];
    char fsize[8+1];
    char filler[1];
    char dmmy[6];
};
#ifndef GAIO
#define direct _direct
#endif

/* Function Codes */

#define TFN_READ_SECTOR     1
#define TFN_WRITE_SECTOR    2
#define TFN_IDENTIFY        3
#define TFN_FORMAT          4
#define TFN_HARDWARE_INIT   5
#define TFN_HARDWARE_RESET  6

/* Error Codes */

#define EV_NOFILE       (-1)        /* file is not found */
#define EV_DISKFULL     (-2)        /* disk full */
#define EV_DRIVE        (-3)        /* drive name error */
#define EV_FSYS_NAME    (-4)        /* abnormal file name */
#define EV_ALREADY      (-5)        /* already opend at write mode */
#define EV_NOFCB        (-6)        /* no room for file control block */
#define EV_NOOPEN       (-7)        /* file is not opened */
#define EV_NOEMPTY      (-8)        /* directory is not empty */
#define EV_EXIST        (-9)        /* file already exists */
#define EV_FSYS_PAR     (-10)       /* parameter error */
#define EV_FATLINK      (-11)       /* FAT is broken */

/* Functions */

ER file_ini(T_FILE *, INT, ID, ID);
ER disk_ini(T_DISK *, const char *, DISK_FP, UW, UW);
FILE *my_fopen(const char *, const char *);
int my_fclose(FILE *);
int my_fseek(FILE *, long, int);
int my_fgetc(FILE *);
int my_fputc(int, FILE *);
char *my_fgets(char *, int, FILE *);
int my_fputs(const char *, FILE *);
size_t my_fread(void *, size_t, size_t, FILE *);
size_t my_fwrite(const void *, size_t, size_t, FILE *);
long my_ftell(FILE *);
int my_feof(FILE *);
int my_remove(const char *);
int my_rename(const char *, const char *);
int my_ferror(FILE *);
void my_clearerr(FILE *);
int my_dformat(const char *);
ER ramdisk(T_DISK *, FN, UW, VP);

#undef fopen
#undef fclose
#undef fseek
#undef fgetc
#undef fputc
#undef fgets
#undef fputs
#undef fread
#undef fwrite
#undef ftell
#undef feof
#undef remove
#undef rename
#undef ferror
#undef clearerr

#define fopen(n,m)      my_fopen(n,m)
#define fclose(f)       my_fclose(f)
#define fseek(f,p,m)    my_fseek(f,p,m)
#define fgetc(f)        my_fgetc(f)
#define fputc(c,f)      my_fputc(c,f)
#define fgets(b,l,f)    my_fgets(b,l,f)
#define fputs(b,f)      my_fputs(b,f)
#define fread(b,s,n,f)  my_fread(b,s,n,f)
#define fwrite(b,s,n,f) my_fwrite(b,s,n,f)
#define ftell(f)        my_ftell(f)
#define feof(f)         my_feof(f)
#define remove(n)       my_remove(n)
#define rename(n1,n2)   my_rename(n1,n2)
#define ferror(f)       my_ferror(f)
#define clearerr(f)     my_clearerr(f)
#define dformat(n)      my_dformat(n)

#ifdef __cplusplus
}
#endif
#endif /* NONFILE_H */
