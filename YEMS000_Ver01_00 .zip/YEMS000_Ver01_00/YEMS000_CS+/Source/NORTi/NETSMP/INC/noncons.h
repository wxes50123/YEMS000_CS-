/******************************************************************************
* Serial Console Functions Header                                             *
*                                                                             *
*  Copyright (c) 1999-2015, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1999-02-25 Created                                                          *
* 2005-04-20 Replaced 'B *' for string type with 'char *'                  PK *
* 2008-07-29 Deleted "#define puts(b) console_puts(NULL,b)" and so on      FY *
* 2009-08-03 Added 'tmo' member to T_CONSOLE                               FY *
* 2012-11-23 Minimized type of variables for object IDs (ID -> UH)         FY *
* 2015-02-13 Added term_print and term_getch member to T_CONSOLE           FY *
* 2015-09-12 Removed unused tx_mbfid & ercd members from T_CONSOLE         MI *
* 2015-09-12 Removed parameter names in function prototype declaration     MI *
******************************************************************************/

#ifndef NONCONS_H
#define NONCONS_H
#ifdef __cplusplus
extern "C" {
#endif

#include "nonteln.h"

/* Serial Console Control Block */

typedef struct t_console {
    BOOL (*term_print)(T_TERMINAL *, const char *);
    INT (*term_getch)(T_TERMINAL *);
    UH telnetd_tskid;
    UH shell_tskid;
    UH rx_mbfid;
    B logged_in;
    B echo_on;
    FP sigint;
    FP passwd_check;
    TMO tmo;
    const char *prompt;
    UH cepid; /* fixed to 0 in case of serial console */
    INT ch;
} T_CONSOLE;

/* Serial Console Functions */

BOOL console_print(T_CONSOLE *, const char *);
INT console_input(T_CONSOLE *, char *, int);
INT console_getch(T_CONSOLE *);
BOOL console_kbhit(T_CONSOLE *);
ER console_ini(T_CONSOLE *, ID, ID, INT, const char *);

#ifdef __cplusplus
}
#endif
#endif /* NONCONS_H */
