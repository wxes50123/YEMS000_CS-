/******************************************************************************
* NORTi Network Echo Service Header                                           *
*                                                                             *
*  Copyright (c) 1998-2005, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 10/Feb/1999                                                                 *
* 18/Mar/2003 Add ECHO_SSZ                                                 YS *
* 27/Sep/2004 Definition for IPv6 support added                            PK *
* 20/Apr/2005 Definition for new function for clients added                PK *
* 13/May/2005 Added uninitialization code for echo server.                 AK *
******************************************************************************/

#ifndef NONECHO_H
#define NONECHO_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef ECHO_SSZ
#define ECHO_SSZ 512
#endif

/* Echo Server Function Prototype */

ER udpecho_ini(ID tskid, ID cepid);
ER tcpecho_ini(ID tskid, ID cepid, ID repid);
void udpecho_ext(void);
void tcpecho_ext(void);

/* Echo Client Function Prototype */

int techo_command(int argc, char *argv[]);
int uecho_command(int argc, char *argv[]);
void udp_echo_client(ID cepid);
void tcp_echo_client(ID cepid);

#ifdef DUAL_STK
/* Echo Server Function Prototype */
ER udpecho6_ini(ID tskid, ID cepid);
ER tcpecho6_ini(ID tskid, ID cepid, ID repid);
void udpecho6_ext(void);
void tcpecho6_ext(void);

/* Echo Client Function Prototype */
void udp_echo6_client(int argc, char *argv[]);
void tcp_echo6_client(int argc, char *argv[]);
#endif


#ifdef __cplusplus
}
#endif
#endif /* NONECHO_H */
