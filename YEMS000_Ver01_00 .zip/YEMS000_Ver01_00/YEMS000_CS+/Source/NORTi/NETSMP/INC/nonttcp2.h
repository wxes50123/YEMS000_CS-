/******************************************************************************
* TCP Performance Test Program Header using TTCP Command for Multi-Channel    *
*                                                                             *
*  Copyright (c) 2011-2016, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2011-07-28 Created                                                  KM & MI *
* 2015-03-03 Changed parameters of ttcp_t_loop() and ttcp_r_loop()         FY *
* 2016-03-15 Modified for multi-channel, and renamed from nonttcp.h        FY *
******************************************************************************/

#ifndef NONTTCP2_H
#define NONTTCP2_H
#ifdef __cplusplus
extern "C" {
#endif

void ttcp_t_loop(int, UW *);
void ttcp_r_loop(int, UW *);

#ifdef __cplusplus
}
#endif
#endif /* NONTTCP2_H */
