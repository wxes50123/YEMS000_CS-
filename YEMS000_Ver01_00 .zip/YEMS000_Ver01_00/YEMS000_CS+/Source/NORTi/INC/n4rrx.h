/******************************************************************************
* NORTi4 CPU-dependent Definitions for RX                                     *
*                                                                             *
*  Copyright (c) 2010-2025, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2010-08-02 Created for Renesas RX600                                     FY *
* 2011-09-08 Added support for RX200                                       FY *
* 2011-10-28 Deleted (UW) cast from set_isp() argument for CC-RX V1.01     FY *
* 2012-05-14 Moved CPU dependent definitions from nosys4.h and nocfg4.h    FY *
* 2014-10-20 Removed check of RX600/RX200 macros deleted for RXv2 support  FY *
* 2014-10-20 Replaced INCLUDED_FROM_NOCFG4_H with OS_CONFIG, and moved CPU-   *
*            dependent data upward to allow multiple include thru nosys4.h FY *
* 2015-04-22 Added do-while(0) to multi-line function macros               MI *
* 2017-02-13 Adjusted coding style and comments                            FY *
* 2021-06-14 Added extern declaration of KNL_PSW for C++ external linkage  FY *
* 2023-03-02 Added prefix __ to set_isp/get_fpsw as recommended by Renesas FY *
* 2025-07-01 Added T_DRCTX, pDRCTX & macro functions to support RXv3 DPFPU FY *
******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#if (defined(__RXV3) && defined(__DPFPU))
#define DPFPU             /* double precision FPU */
#endif

/*****************************************************************************/
/* When Included from nocfg4.h via nosys4.h for Configuration                */
/*****************************************************************************/
#ifdef OS_CONFIG

/* CPU-dependent Kernel Internal Data */

#ifndef KNL_LEVEL
#define KNL_LEVEL   6
#endif

extern const UW KNL_PSW;  /* explicit declaration for C++ */
const UW KNL_PSW = (KNL_LEVEL) << 24; /* U=0, I=0 */
UW IMASK;
extern SYSTIME SYSCK;
const void * const kernel_def[] = { &CFG, &SYSCK };
#ifdef DPFPU
volatile void *pDRCTX;    /* pointer to DPFPU register context save area */
#endif

/* Extra Memory Pool and Stack Area */

#ifdef MPLMSZ
#if ((MPLMSZ)/SIZEOF_INT != 0)
#pragma section MPLMEM
int MPLMEM[(MPLMSZ)/SIZEOF_INT];
#pragma section
#endif
#endif /* MPLMSZ */

#ifdef STKMSZ
#if ((STKMSZ)/SIZEOF_INT != 0)
#pragma section STKMEM
int STKMEM[(STKMSZ)/SIZEOF_INT];
#pragma section
#endif
#endif /* STKMSZ */

#endif /* OS_CONFIG */
/*****************************************************************************/
/* When Included from nosys4.h Normally                                      */
/*****************************************************************************/
#ifndef N4RRX_H
#define N4RRX_H

extern const UW KNL_PSW;  /* interrupt mask value of kernel */
extern UW IMASK;          /* interrupt mask value of task */

/* Context Structure for RX */

#ifdef DPFPU
typedef struct t_drctx
{
    double dr0;
    double dr1;
    double dr2;
    double dr3;
    double dr4;
    double dr5;
    double dr6;
    double dr7;
    double dr8;
    double dr9;
    double dr10;
    double dr11;
    double dr12;
    double dr13;
    double dr14;
    double dr15;
    int dpsw;
    int dcmr;
} T_DRCTX;
#endif

typedef struct t_ctx { 
  #ifdef DPFPU
    T_DRCTX *drctx;       /* pointer to DPFPU register context */
  #endif
    int r6;
    int r7;
    int r8;
    int r9;
    int r10;
    int r11;
    int r12;
    int r13;
    int r14;
    int r15;
    int ercd;             /* r1 */
    ID wid;               /* r2 */
    UINT ptn;             /* r3 */
    VP ptr;               /* r4 */
    int r5;
  #ifdef __FPU
    int fpsw;
  #endif
    FP pc;
    int psw;
} T_CTX;

/* Kernel Internal Macro Functions */

#define syssta_sub()     (IMASK  =  0x00030000)
#define unl_cpu_sub()    (IMASK &= ~0x0f000000)
#define chg_ims_sub(m)   do { IMASK &= ~0x0f000000; \
                              IMASK |= (UW)((m << 24) & 0x0f000000); \
                         } while (0)
#define ref_sys_sub(m)   ((m & 0x0f000000) >= KNL_PSW)
#define ref_ims_sub(m)   ((m & 0x0f000000) >> 24)
#define ref_isr_sub()
#define cre_isr_sub()

#ifdef DPFPU
#define cre_tsk_sub()    do { if (pk_ctsk->tskatr & TA_FPU) \
                                  stksz -= sizeof (T_CTX) + sizeof (T_DRCTX); \
                              else \
                                  stksz -= sizeof (T_CTX); \
                         } while (0)
#else
#define cre_tsk_sub()    stksz -= sizeof (T_CTX)
#endif

#define c_sysini_sub()   do { if (pSTKMEM != NULL) { \
                                  sp = stktop = (B *)pSTKMEM; \
                                  sp += CFG.stkmsz; \
                              } else { \
                                  sp -= CFG.tstksz; \
                              } \
                              __set_isp(sp); /* ISP = sp; */ \
                              i = CFG.istksz; \
                              while (i-- != 0) \
                                  *--sp = 0x00; \
                         } while (0)

#ifdef DPFPU
#define sta_tsk_sub()    do { if (tcb->ctsk->tskatr & TA_FPU) { \
                                  T_DRCTX *p; \
                                  p = (T_DRCTX *)((B *)tcb->stk + tcb->ctsk->stksz) - 1; \
                                  ctx = (T_CTX *)((B *)((T_CTX *)((B *)p) - 1) - 4); \
                                  ctx->drctx = p; \
                                  ctx->drctx->dpsw = (int)__get_dpsw(); \
                              } else { \
                                  ctx = (T_CTX *)((B *)ctx - 4); \
                                  ctx->drctx = NULL; \
                              } \
                              *(VP *)(ctx + 1) = v4_ext_tsk; \
                              ctx->ercd = (ID)stacd; \
                              ctx->fpsw = (int)__get_fpsw(); \
                              ctx->psw = 0x00030000; \
                         } while (0)
#elif defined(__FPU)
#define sta_tsk_sub()    do { ctx = (T_CTX *)((B *)ctx - 4); \
                              *(VP *)(ctx + 1) = v4_ext_tsk; \
                              ctx->ercd = (ID)stacd; \
                              ctx->fpsw = (int)__get_fpsw(); \
                              ctx->psw = 0x00030000; \
                         } while (0)
#else
#define sta_tsk_sub()    do { ctx = (T_CTX *)((B *)ctx - 4); \
                              *(VP *)(ctx + 1) = v4_ext_tsk; \
                              ctx->ercd = (ID)stacd; \
                              ctx->psw = 0x00030000; \
                         } while (0)
#endif

#ifdef DPFPU
#define ras_tex_sub()    do { if (tcb->ctsk->tskatr & TA_FPU) { \
                                  T_DRCTX *p; \
                                  p = (T_DRCTX *)tcb->sp - 1; \
                                  ctx = (T_CTX *)p - 1; \
                                  ctx->drctx = p; \
                                  ctx->drctx->dpsw = (int)__get_dpsw(); \
                              } else { \
                                  ctx->drctx = NULL; \
                              } \
                              ctx->fpsw = (int)__get_fpsw(); \
                              ctx->psw = 0x00030000; \
                         } while (0)
#elif defined(__FPU)
#define ras_tex_sub()    do { ctx->fpsw = (int)__get_fpsw(); \
                              ctx->psw = 0x00030000; \
                         } while (0)
#else
#define ras_tex_sub()    (ctx->psw = 0x00030000)
#endif

#endif /* N4RRX_H */
#ifdef __cplusplus
}
#endif
