/******************************************************************************
* NORTi TCP/IP Stack Configuration Header                                     *
*                                                                             *
*  Copyright (c) 1998-2023, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 1998-11-23 Created                                                          *
* 1999-03-22 Added pICMP_CB and ID_IP_RETRY_MBX                               *
* 1999-05-22 Added PRI_TCPIP                                                  *
* 2000-01-26 Added mgrp_cb                                                    *
* 2000-12-11 Allowed mixed use of NORTi3 compatible function w/o V3 macro     *
* 2002-07-11 Added tcp_iss and port_any                                    AK *
* 2002-07-15 Added macros for TCP retransmission and keep-alive timer         *
* 2002-11-14 Added macros for TCP and IP reassembly                           *
* 2003-03-27 Made IP_SND_TSK and IP_RCV_TSK have same priority                *
* 2003-04-15 Added macros for ARP request timeout                             *
* 2004-07-01 Modified for IPv6 Stack                                       PK *
* 2004-09-30 Added MANUAL_ADDR_CONF and ADDR_CONF for IPv6 manual config   PK *
* 2004-11-09 Modified SSZ_IP_SND_TSK and SSZ_IP_RCV_TSK to support IPsec   PK *
* 2005-01-21 Changed timeout interval for IPv6 reassembly to 60 sec        PK *
* 2005-04-04 Modifeid ARP entities for Multichannel                        AK *
* 2005-05-19 Removed definitions for NORTi3 system calls                   AK *
* 2005-05-22 Modified UDP buffer size from T_UDP_PKT to T_ETH              AK *
* 2006-03-03 Added IGMPV1_PRESENT_TMO to switch IGMPv1 to IGMPv2           AK *
* 2006-03-24 Added TCP_DACK_TMO and TCP_DUP_ACK                            AK *
* 2006-07-22 Added support for MLDv2                                       GS *
* 2008-05-13 Tuned loop of searching UDP/TCP end points & reception points OM *
* 2008-06-30 Added support for RAW communication end point                 OM *
* 2008-07-01 Removed ID_IP_SND_TSK, ID_IP_RCV_TSK and ID_TCPIP_SEM         FY *
* 2008-07-15 Changed default value of RAW_CEPID_MAX to 0                   OM *
* 2008-10-22 Changed type of pRAW_CEP from T_UDP_CEP* to T_RAW_CEP*        FY *
* 2008-10-26 Modified for IPv6 stack                                       IS *
* 2008-12-03 Changed RAW_CEP declaration for IAR EW compiler               FY *
* 2008-12-17 Added support for IGMPv3                                      GS *
* 2008-12-24 Adjusted indent                                               IS *
* 2009-09-14 Added IGMP3_SRC_CNT/_ADR_CNT redefinition with TCP_CFG value  GS *
* 2009-11-06 Added type casting to avoid M16C/NC30 compiler warning        FY *
* 2010-07-14 Removed wait macro                                            FY *
* 2012-05-14 Moved mSEC variable to nocfg4.h                               FY *
* 2012-06-08 Added ROUTEx_TABLE_CNT and routex_table[] for static routing  GS *
* 2012-10-04 Added missing type casting (FP) to ipv6_cyc_tsk               FY *
* 2012-11-13 Deleted ipq_hash[], ip6q_hash[] and IPHASH_QSZ, IP6HASH_QSZ   FY *
* 2012-11-13 Changed T_TCP_CFG's some members order as in updated nonets.h FY *
* 2012-11-13 Reduced ID variables size to UH (ex. ID_IP_xxx, ID_ETH_MPF)   FY *
* 2012-11-13 Removed ipf_timer_flag and ip6f_timer_flag                    FY *
* 2012-11-23 Replaced sizeof (T_ETH) of c_udp_mpf's blfsz with (T_UDP_PKT)    *
*             and separately defined c_udp6_mpf to downsize sending buffer FY *
* 2013-09-24 Added #include "nosys4.h" to use CPU-dependent definitions    HE *
* 2013-12-24 Changed size of UDP sending que when IPsec is valid           FY *
* 2014-10-20 Extened LAN driver interface to 4 channels from 2 channels    FY *
* 2014-10-20 Removed unused ARP_TABLE_END                                  FY *
* 2015-01-21 Changed default value of MLD2_SRC_CNT from 30 to 32           FY *
* 2015-01-21 Added definitions for host ID                                 FY *
* 2015-02-13 Removed old TCP_TSKID_CNT ~ TCP_MPFID_CNT macros              MI *
* 2015-11-04 Added default value of NIF_NUM                                FY *
* 2015-11-04 Removed lan_nif_dev4() function declaration                   FY *
* 2021-06-08 Removed ip_tim_pkt & tcp_tim_pkt with adding tim_pkt to T_NIF FY *
* 2021-06-22 Reduced TCP_NMBX from 5+(UDP_CEPID_MAX) to 3+(UDP_CEPID_MAX)  FY *
* 2021-06-22 Replaced tTCPIP_TIMER_FLAG/IGMP_MEMBER_EXISTS by ip_miscflag  FY *
* 2021-06-22 Removed unused REP_QCNT and TCP_QCNT                          MI *
* 2021-09-05 Added ICMP_DU_RATE to block ICMP destination unreachable      FY *
* 2021-11-18 Added tcpip_timer_flag separated from ip_miscflag             FY *
* 2021-11-18 Added wup_stsk_inuse for exclusive control of wup_snd_tsk()   FY *
* 2022-02-04 Added lan_nif_dev4/5 to extend number of network I/Fs to 6    GS *
* 2022-03-26 Added extern declaration of const variables                      *
*                for C++ external linkage, and removed unused c_tcpip_sem  GS *
* 2022-03-26 Adjusted coding style with adding INCLUDED_FROM_NONCFG        MI *
* 2023-10-19 Removed extern declaration of ID_IPV6_TIM & ID_IPV6_CYC       FY *
******************************************************************************/

#ifndef NONETC_H
#define NONETC_H
#ifdef __cplusplus
extern "C" {
#endif

#include "nonets.h"
#include "nosys4.h"

#ifndef INCLUDED_FROM_NONET
#define INCLUDED_FROM_NONCFG        /* included from nonecfg.c */
#endif

/* Declaration for External Linkage of const in C++ */

extern const T_TCP_CFG TCP_CFG;
extern const char default_inet_name[];
extern const T_CMBX c_tcpip_mbx;
extern const T_CMPF c_eth_mpf;
extern const T_CMPF c_udp_mpf;
#ifdef DUAL_STK
extern const T_CMPF c_udp6_mpf;
#endif
extern const T_CTSK c_ip_snd_tsk;
extern const T_CTSK c_ip_rcv_tsk;
#ifdef DUAL_STK
extern const T_CMPF c_mldv2_mpf;
extern const T_CTSK c_ipv6_cyc_tsk;
#endif
extern const T_CMBX c_raw_rcv_mbx;
extern const T_CMPF c_raw_snd_mpf;
extern const T_CMPF c_igmp3_src_mpf;
extern const T_CMPF c_igmp3_adr_mpf;
extern const UB * const p_host_id;
extern T_RAW_CEP * const RAW_CEP;

/* Maximum ID Numbers of TCP/IP Stack Objects */

#ifdef INCLUDED_FROM_NONCFG
#ifndef TCP_REPID_MAX
#define TCP_REPID_MAX       4
#endif
#ifndef TCP_CEPID_MAX
#define TCP_CEPID_MAX       4
#endif
#ifndef UDP_CEPID_MAX
#define UDP_CEPID_MAX       4
#endif
#ifndef RAW_CEPID_MAX
#define RAW_CEPID_MAX       0
#endif

/* Top ID Numbers of Kernel Objects */

#ifndef TCP_TSKID_TOP
#define TCP_TSKID_TOP       0
#endif
#ifndef TCP_SEMID_TOP
#define TCP_SEMID_TOP       0
#endif
#ifndef TCP_MBXID_TOP
#define TCP_MBXID_TOP       0
#endif
#ifndef TCP_MPFID_TOP
#define TCP_MPFID_TOP       0
#endif

/* Number of Kernel Objects used in TCP/IP Stack */

#define TCP_NTSK            5
#define TCP_NSEM            1
#define TCP_NFLG            0
#define TCP_NMBX            (3+(UDP_CEPID_MAX))
#define TCP_NMBF            0
#define TCP_NPOR            0
#define TCP_NMPL            0
#define TCP_NMPF            (4+(UDP_CEPID_MAX))
#define TCP_NDTQ            0
#define TCP_NMTX            0
#define TCP_NISR            0
#define TCP_NCYC            2
#define TCP_NALM            0

/* Constants to Create Kernel Objects */

#ifndef PRI_IP_SND_TSK
#ifdef DUAL_STK
#define PRI_IP_SND_TSK      4
#else
#define PRI_IP_SND_TSK      4
#endif
#endif
#ifdef PRI_IP_RCV_TSK
#undef PRI_IP_RCV_TSK
#endif
#define PRI_IP_RCV_TSK      PRI_IP_SND_TSK
#ifndef SSZ_IP_SND_TSK
#ifdef IPSEC
#define SSZ_IP_SND_TSK      1304
#else
#define SSZ_IP_SND_TSK      1024
#endif
#endif
#ifndef SSZ_IP_RCV_TSK
#ifdef IPSEC
#define SSZ_IP_RCV_TSK      1304
#else
#define SSZ_IP_RCV_TSK      1024
#endif
#endif
#ifndef ETH_QCNT
#define ETH_QCNT            16
#endif
#ifndef UDP_QCNT
#define UDP_QCNT            2
#endif
#ifndef RAW_PKT_SND_CNT
#define RAW_PKT_SND_CNT     2
#endif

#ifndef MLD2_SRC_CNT
#define MLD2_SRC_CNT        32
#endif

#ifndef IGMP3_SRC_CNT
#define IGMP3_SRC_CNT       12
#endif

#ifndef IGMP3_ADR_CNT
#define IGMP3_ADR_CNT       6
#endif

#ifdef DUAL_STK
#ifndef PRI_IPV6_CYC_TSK
#define PRI_IPV6_CYC_TSK    4
#endif
#ifndef SSZ_IPV6_CYC_TSK
#define SSZ_IPV6_CYC_TSK    1024
#endif
#endif

#ifndef TCP_PORT_EPHEMERAL
#define TCP_PORT_EPHEMERAL  49152   /* top number of Ephemeral Port */
#endif

/* TCP Configuration */

#ifndef TCP_SYN_RETRY               /* maximum number of SYN retries */
#define TCP_SYN_RETRY       3
#endif
#ifndef TCP_DATA_RETRY              /* maximum number of data and FIN retries */
#define TCP_DATA_RETRY      12
#endif
#ifndef TCP_RTO_INI                 /* initial value of retransmission timeout */
#define TCP_RTO_INI         3000    /* msec */
#endif
#ifndef TCP_RTO_UBOUND              /* maximum value of retransmission timeout */
#define TCP_RTO_UBOUND      64000   /* msec */
#endif
#ifndef TCP_RTO_LBOUND              /* minimum value of retransmission timeout */
#define TCP_RTO_LBOUND      300     /* msec */
#endif

#ifndef TCP_DACK_TMO                /* timeout value of delayed ACK timer */
#define TCP_DACK_TMO        200     /* msec */
#endif
#ifndef TCP_DUP_ACK                 /* number of duplicate ACK causing retransmission */
#define TCP_DUP_ACK         3
#endif

#ifndef TCP_KTIME_INI               /* no-communication time to start keep-alive */
#define TCP_KTIME_INI       7200    /* sec (0: disable keep-alive) */
#endif
#ifndef TCP_KTIME_PRO               /* maximum proceeding time of keep-alive */
#define TCP_KTIME_PRO       600     /* sec */
#endif
#ifndef TCP_KTIME_SUC               /* time interval of successive sending probe */
#define TCP_KTIME_SUC       75      /* sec */
#endif

/* ARP, IP, IGMP, ICMP and Multicast Configuration */

#ifndef ARP_TABLE_CNT               /* number of entries in ARP table */
#define ARP_TABLE_CNT       8
#endif
#ifndef ARP_NIF_CNT                 /* number of interfaces using ARP */
#define ARP_NIF_CNT         2
#endif
#ifndef ARP_CACHE_TOUT              /* ARP cache timeout */
#define ARP_CACHE_TOUT      120     /* sec */
#endif
#ifndef ARP_FLUSH_TOUT              /* ARP flush timeout */
#define ARP_FLUSH_TOUT      1200    /* sec */
#endif
#ifndef ARP_RET_INTVAL              /* time interval of retransmitting ARP request */
#define ARP_RET_INTVAL      2       /* sec */
#endif
#ifndef IP_DEF_TTL                  /* time to live value for IP packets */
#define IP_DEF_TTL          32      /* hops */
#endif
#ifndef IPF_REASM_TMO               /* timeout for IP reassembly process */
#define IPF_REASM_TMO       2       /* sec */
#endif
#ifndef IGMPV1_PRESENT_TMO          /* use IGMPv1 until this timeout expires */
#define IGMPV1_PRESENT_TMO  400     /* sec */
#endif
#ifndef ROUTE_TABLE_CNT             /* number of entries in IPv4 routing table */
#define ROUTE_TABLE_CNT     2
#endif
#ifndef ICMP_DU_RATE                /* rate of ICMP destination unreachable reply */
#define ICMP_DU_RATE        1000    /* msec */
#endif
#ifndef MULTICAST_GROUP_CNT         /* number of multicast groups */
#define MULTICAST_GROUP_CNT 10
#endif

/* IPv6 Neighbor Discovery Configuration */

#ifndef NEIGH_CACHE_CNT             /* number of entries in neighbor cache table */
#define NEIGH_CACHE_CNT     8
#endif

#ifndef PREFIX_LIST_CNT             /* number of entries in prefix list */
#define PREFIX_LIST_CNT     8
#endif

#ifndef DFLT_ROUTER_CNT             /* number of default routers */
#define DFLT_ROUTER_CNT     2
#endif

#ifndef DST_CACHE_CNT               /* number of entries in destination cache table */
#define DST_CACHE_CNT       8
#endif

#ifndef ROUTE6_TABLE_CNT            /* number of entries in IPv6 routing table */
#define ROUTE6_TABLE_CNT    2
#endif

#ifndef DAD_TMO                     /* duplicate address detection timeout */
#define DAD_TMO             1000    /* msec */
#endif

/* IPv6 Reassembly, IPsec, etc. Configuration */

#ifndef IP6F_REASM_TMO              /* timeout for IPv6 reassembly process  */
#define IP6F_REASM_TMO      60      /* sec */
#endif

#ifndef MAX_IPSEC_ENTRIES           /* maximum entries in IPsec database */
#define MAX_IPSEC_ENTRIES   15
#endif

#ifdef MANUAL_ADDR_CONF             /* manual address configuration */
#define ADDR_CONF           1
#else
#define ADDR_CONF           0
#endif

/* TCP/IP Stack Configuration Information */

const T_TCP_CFG TCP_CFG = {
    TCP_REPID_MAX,
    TCP_CEPID_MAX,
    UDP_CEPID_MAX,
    RAW_CEPID_MAX,
    TCP_TSKID_TOP,
    TCP_SEMID_TOP,
    TCP_MBXID_TOP,
    TCP_MPFID_TOP,
    ARP_TABLE_CNT,
    ARP_NIF_CNT,
    ROUTE_TABLE_CNT,
    TCP_PORT_EPHEMERAL,
    ETH_QCNT,
    TCP_SYN_RETRY,
    TCP_DATA_RETRY,
    TCP_RTO_INI,
    TCP_RTO_UBOUND,
    TCP_RTO_LBOUND,
    TCP_KTIME_INI,
    TCP_KTIME_PRO,
    TCP_KTIME_SUC,
    TCP_DACK_TMO,
    TCP_DUP_ACK,
    ARP_RET_INTVAL,
    IP_DEF_TTL,
    IPF_REASM_TMO,
    NEIGH_CACHE_CNT,
    PREFIX_LIST_CNT,
    DFLT_ROUTER_CNT,
    DST_CACHE_CNT,
    ROUTE6_TABLE_CNT,
    IP6F_REASM_TMO,
    DAD_TMO,
    MULTICAST_GROUP_CNT,
    IGMPV1_PRESENT_TMO,
    MAX_IPSEC_ENTRIES,
    ADDR_CONF,
    MLD2_SRC_CNT,
    IGMP3_SRC_CNT,
    IGMP3_ADR_CNT,
    ARP_CACHE_TOUT,
    ARP_FLUSH_TOUT,
    ICMP_DU_RATE
};

#else /* INCLUDED_FROM_NONET */
#define TCP_REPID_MAX       (TCP_CFG.tcp_repid_max)
#define TCP_CEPID_MAX       (TCP_CFG.tcp_cepid_max)
#define UDP_CEPID_MAX       (TCP_CFG.udp_cepid_max)
#define RAW_CEPID_MAX       (TCP_CFG.raw_cepid_max)
#define TCP_TSKID_TOP       (TCP_CFG.tcp_tskid_top)
#define TCP_SEMID_TOP       (TCP_CFG.tcp_semid_top)
#define TCP_MBXID_TOP       (TCP_CFG.tcp_mbxid_top)
#define TCP_MPFID_TOP       (TCP_CFG.tcp_mpfid_top)
#define ARP_TABLE_CNT       (TCP_CFG.arp_table_cnt)
#define ARP_NIF_CNT         (TCP_CFG.arp_nif_cnt)
#define ROUTE_TABLE_CNT     (TCP_CFG.route_table_cnt)
#define TCP_PORT_EPHEMERAL  (TCP_CFG.tcp_ephem_port)
#define ETH_QCNT            (TCP_CFG.eth_qcnt)
#define TCP_SYN_RETRY       (TCP_CFG.tcp_syn_ret)
#define TCP_DATA_RETRY      (TCP_CFG.tcp_dat_ret)
#define TCP_RTO_INI         (TCP_CFG.tcp_rto_ini)
#define TCP_RTO_UBOUND      (TCP_CFG.tcp_rto_ubound)
#define TCP_RTO_LBOUND      (TCP_CFG.tcp_rto_lbound)
#define TCP_KTIME_INI       (TCP_CFG.tcp_ktime_ini)
#define TCP_KTIME_PRO       (TCP_CFG.tcp_ktime_pro)
#define TCP_KTIME_SUC       (TCP_CFG.tcp_ktime_suc)
#define TCP_DACK_TMO        (TCP_CFG.tcp_dack_tmo)
#define TCP_DUP_ACK         (TCP_CFG.tcp_dup_ack)
#define ARP_RET_INTVAL      (TCP_CFG.arp_ret_intval)
#define IP_DEF_TTL          (TCP_CFG.ip_def_ttl)
#define IPF_REASM_TMO       (TCP_CFG.ip_reasm_tmo)
#define NEIGH_CACHE_CNT     (TCP_CFG.neigh_cache_cnt)
#define PREFIX_LIST_CNT     (TCP_CFG.prefix_list_cnt)
#define DFLT_ROUTER_CNT     (TCP_CFG.def_rtr_cnt)
#define DST_CACHE_CNT       (TCP_CFG.dst_cache_cnt)
#define ROUTE6_TABLE_CNT    (TCP_CFG.route6_table_cnt)
#define IP6F_REASM_TMO      (TCP_CFG.ip6_reasm_tmo)
#define DAD_TMO             (TCP_CFG.dad_tmo)
#define MULTICAST_GROUP_CNT (TCP_CFG.igmp_group_cnt)
#define IGMPV1_PRESENT_TMO  (TCP_CFG.igmpv1_present_tmo)
#define MAX_IPSEC_ENTRIES   (TCP_CFG.max_ipsec_entries)
#define ADDR_CONF           (TCP_CFG.addr_conf)
#define MLD2_SRC_CNT        (TCP_CFG.mld2_src_cnt)
#define IGMP3_SRC_CNT       (TCP_CFG.igmp3_src_cnt)
#define IGMP3_ADR_CNT       (TCP_CFG.igmp3_adr_cnt)
#define ARP_CACHE_TOUT      (TCP_CFG.arp_cache_tout)
#define ARP_FLUSH_TOUT      (TCP_CFG.arp_flush_tout)
#define ICMP_DU_RATE        (TCP_CFG.icmp_du_rate)
extern UH ID_IP_SND_MBX;
extern UH ID_ETH_MPF;
extern UH ID_IP_TIM;
#ifdef DUAL_STK
extern UH ID_MLDV2_MPF;
#endif
extern UH ID_IGMP3_SRC_MPF;
extern UH ID_IGMP3_ADR_MPF;
#endif /* INCLUDED_FROM_NONET */

/* Network Interface */

#ifdef INCLUDED_FROM_NONCFG
T_NIF default_inet;

#ifndef PPP
const char default_inet_name[] = "eth0"; /* default network interface name */

#if (defined(NIF_NUM) && defined(DIF_NUM) && !defined(ETH_CH))
#define ETH_CH  DIF_NUM
#undef DIF_NUM
#endif

#ifndef NIF_NUM
#if defined(DIF_NUM)
#define NIF_NUM DIF_NUM
#elif defined(ETH_CH)
#define NIF_NUM ETH_CH
#else
#define NIF_NUM 0
#endif
#endif

#ifndef DIF_NUM
#define DIF_NUM NIF_NUM
#endif

#ifndef ETH_CH
#define ETH_CH  DIF_NUM
#endif

#if NIF_NUM == 0
extern ER lan_nif_dev(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev;
#elif NIF_NUM == 1
extern ER lan_nif_dev1(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev1;
#elif NIF_NUM == 2
extern ER lan_nif_dev2(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev2;
#elif NIF_NUM == 3
extern ER lan_nif_dev3(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev3;
#elif NIF_NUM == 4
extern ER lan_nif_dev4(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev4;
#elif NIF_NUM == 5
extern ER lan_nif_dev5(T_NIF *nif, FN fncd, ...);
NIF_FP default_inet_func = lan_nif_dev5;
#endif
#else /* PPP */
ER ppp_nif_dev(T_NIF *nif, FN fncd, ...);
const char default_inet_name[] = "ppp";
NIF_FP default_inet_func = ppp_nif_dev;
#endif

#else /* INCLUDED_FROM_NONET */
extern T_NIF default_inet;             /* default network interface control block */
extern NIF_FP default_inet_func;       /* default network interface function */
#define MULTI_NIF                      /* TCP/IP stack supporting multi network interface */
#endif

/* Host ID for Manual address configuration */

#ifdef INCLUDED_FROM_NONCFG
#if (ADDR_CONF == 1)
extern UB host_id[6];
const UB * const p_host_id = host_id;
#else
const UB * const p_host_id = NULL;
#endif

/* Kernel Objects Creation Information */

const T_CMBX c_tcpip_mbx     = { TA_TFIFO|TA_MFIFO, 0, NULL, "tcpip_mbx" };
const T_CMPF c_eth_mpf       = { TA_TFIFO, ETH_QCNT, sizeof (T_ETH), NULL, "eth_mpf" };
const T_CMPF c_udp_mpf       = { TA_TFIFO, UDP_QCNT, sizeof (T_UDP_PKT), NULL, "udp_mpf" };
#ifdef DUAL_STK
#ifdef IPSEC
const T_CMPF c_udp6_mpf      = { TA_TFIFO, UDP_QCNT, sizeof (T_ETH), NULL, "udp_mpf" };
#else
const T_CMPF c_udp6_mpf      = { TA_TFIFO, UDP_QCNT, sizeof (T_UDP6_PKT), NULL, "udp_mpf" };
#endif
#endif
const T_CTSK c_ip_snd_tsk    = { TA_HLNG, NULL, (FP)ip_snd_tsk, PRI_IP_SND_TSK, SSZ_IP_SND_TSK, NULL, "ip_snd_tsk" };
const T_CTSK c_ip_rcv_tsk    = { TA_HLNG, NULL, (FP)ip_rcv_tsk, PRI_IP_RCV_TSK, SSZ_IP_RCV_TSK, NULL, "ip_rcv_tsk" };
#ifdef DUAL_STK
const T_CMPF c_mldv2_mpf     = { TA_TFIFO, MLD2_SRC_CNT, sizeof (T_MLD2_SRC), NULL, "mldv2_mpf" };
const T_CTSK c_ipv6_cyc_tsk  = { TA_HLNG, NULL, (FP)ipv6_cyc_tsk, PRI_IPV6_CYC_TSK, SSZ_IPV6_CYC_TSK, NULL, "ipv6_cyc_tsk" };
#endif
const T_CMBX c_raw_rcv_mbx   = { TA_TFIFO|TA_MFIFO, 0, NULL, "raw_rcv_mbx" };
const T_CMPF c_raw_snd_mpf   = { TA_TFIFO, RAW_PKT_SND_CNT, sizeof (T_RAW_PKT), NULL, "raw_snd_mpf" };
const T_CMPF c_igmp3_src_mpf = { TA_TFIFO, IGMP3_SRC_CNT, sizeof (T_IGMP3_SRC), NULL, "igmp3_src_mpf" };
const T_CMPF c_igmp3_adr_mpf = { TA_TFIFO, IGMP3_ADR_CNT, sizeof (T_GADDR), NULL, "igmp3_addr_mpf" };
#else /* INCLUDED_FROM_NONET */
#define PRI_TCPIP (c_ip_rcv_tsk.itskpri)
#endif

/* TCP/IP Stack Internal Data */

#ifdef INCLUDED_FROM_NONCFG
T_TCP_REP TCP_REP[TCP_REPID_MAX];
T_TCP_CEP TCP_CEP[TCP_CEPID_MAX];
T_UDP_CEP UDP_CEP[UDP_CEPID_MAX];
#if RAW_CEPID_MAX
T_RAW_CEP RAW_CEP_ORG[RAW_CEPID_MAX];
T_RAW_CEP * const RAW_CEP = RAW_CEP_ORG;
#else
T_RAW_CEP * const RAW_CEP = NULL;
#endif
T_TCP_REP *pTCP_REP;
T_TCP_CEP *pTCP_CEP;
T_UDP_CEP *pUDP_CEP;
T_RAW_CEP *pRAW_CEP;
T_ARP_TABLE arp_table[ARP_TABLE_CNT * ARP_NIF_CNT];
T_ROUTE_INFO route_table[ROUTE_TABLE_CNT];
T_MGRP_CB mgrp_cb[MULTICAST_GROUP_CNT];
const T_TCP_REP * const TCP_REP_END = &TCP_REP[TCP_REPID_MAX];
const T_TCP_CEP * const TCP_CEP_END = &TCP_CEP[TCP_CEPID_MAX];
const T_UDP_CEP * const UDP_CEP_END = &UDP_CEP[UDP_CEPID_MAX];
#if RAW_CEPID_MAX
const T_RAW_CEP * const RAW_CEP_END = &RAW_CEP_ORG[RAW_CEPID_MAX];
#else
const T_RAW_CEP * const RAW_CEP_END = NULL;
#endif
UB nif_loop_back;
UH ip_ident;
UW tcp_iss = 0;
UH port_any;
UW ip_timer;
UB ip_miscflag;
UB tcpip_timer_flag;
UB wup_stsk_inuse;
B in_tcp_callback;
T_ICMP_CB *pICMP_CB;
T_IP_CB *pIP_CB;
T_ARP_CB *pARP_CB;
#ifdef DUAL_STK
T_NEIGH_CACHE neigh_cache[NEIGH_CACHE_CNT];
T_PREFIX_LIST prefix_list[PREFIX_LIST_CNT];
T_DFLT_ROUTER deflt_router[DFLT_ROUTER_CNT];
T_DST_CACHE dst_cache[DST_CACHE_CNT];
T_ROUTE6_INFO route6_table[ROUTE6_TABLE_CNT];
T_ICMP6_CB *pICMP6_CB;
#endif

#else /* INCLUDED_FROM_NONET */
extern T_TCP_REP TCP_REP[];
extern T_TCP_CEP TCP_CEP[];
extern T_UDP_CEP UDP_CEP[];
extern T_TCP_REP *pTCP_REP;
extern T_TCP_CEP *pTCP_CEP;
extern T_UDP_CEP *pUDP_CEP;
extern T_RAW_CEP *pRAW_CEP;
extern T_ARP_TABLE arp_table[];
extern T_ROUTE_INFO route_table[];
extern T_MGRP_CB mgrp_cb[];
extern const T_TCP_REP * const TCP_REP_END;
extern const T_TCP_CEP * const TCP_CEP_END;
extern const T_UDP_CEP * const UDP_CEP_END;
extern const T_RAW_CEP * const RAW_CEP_END;
extern UB nif_loop_back;
extern UH ip_ident;
extern UW tcp_iss;
extern UH port_any;
extern UW ip_timer;
extern UB ip_miscflag;
extern UB tcpip_timer_flag;
extern UB wup_stsk_inuse;
extern B in_tcp_callback;
extern T_ICMP_CB *pICMP_CB;
extern T_IP_CB *pIP_CB;
extern T_ARP_CB *pARP_CB;
#ifdef DUAL_STK
extern T_NEIGH_CACHE neigh_cache[];
extern T_PREFIX_LIST prefix_list[];
extern T_DFLT_ROUTER deflt_router[];
extern T_DST_CACHE dst_cache[];
extern T_ROUTE6_INFO route6_table[];
extern T_ICMP6_CB *pICMP6_CB;
#endif
#endif

#ifdef __cplusplus
}
#endif
#endif /* NONETC_H */
