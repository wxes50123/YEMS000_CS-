/******************************************************************************
* NORTi Version 4 Kernel Configuration Header                                 *
*                                                                             *
*  Copyright (c) 2000-2014, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-04-23                                                                  *
* 2000-08-07 Supported H8 Series                                              *
* 2000-08-23 Crorrected task ID type                                          *
* 2000-09-28 Supported PPC Series                                          OK *
* 2001-01-23 Supported PPC Interrupt Normal                                TA *
* 2001-03-26 Supported FR30 Series                                         TA *
* 2001-07-23 Supported XASS-V ARM series                                   TA *
* 2001-07-29 Supported MIPS Series(R4000/R3000)                            OK *
* 2001-10-04 Supported M16C/60 series                                      TA *
* 2001-10-10 Supported M32R Series by CC32R                                OK *
* 2002-11-29 SDISP field size B->TSK_ID                                    KT *
* 2003-04-03 For ARM (in the flexible executive mode.)                     TA *
* 2003-11-20 added APLPRI (latest application task priority)               TA *
* 2003-12-18 Supported Nios (with cache)                                   SK *
* 2003-12-25 Supported BlackFin                                            TA *
* 2004-04-14 Supported MicroBlaze                                          OK *
* 2004-08-20 added dummy definition for NORTi-DBGLIB/SH                    TA *
* 2004-10-11 Supported Nios II GCC Optimize                                SK *
* 2005-02-17 name pointer type "const B" -> "const char"                   TA *
* 2005-02-25 Supported Nios II full option of HAL & libc(=newlib)          SK *
* 2005-05-17 Supported H8SX Advanced                                       HM *
* 2005-05-20 for 8 byte boundary.                                          TA *
* 2005-08-26 Corrected CFG_TPRI_MAX_P cast                                 SK *
* 2007-09-10 NOWFPU field size VP_INT (SH)                                 YO *
* 2008-02-28 Supported ARM Cortex-M3 Core                                  KM *
* 2008-05-30 Supported AVR32A                                              HM *
* 2008-11-02 modified NOWFPU                                               YO *
* 2009-07-21 Added support for ColdFire                                    JO *
* 2010-02-08 Extended data type of IDLCNT from UH to UW                    KM *
* 2010-04-04 Added support for RX                                          FY *
* 2011-05-20 Added support for RENESAS R32C/100 Series                     HE *
* 2011-06-30 Corrected NC100 compiler warning of __HITACHI_VERSION__ macro HE *
* 2012-05-14 Moved CPU dependent definitions to each n4rxxx.h              FY *
* 2012-05-14 Moved mSEC variable from nonetc.h                             FY *
* 2012-05-15 Unified DELAY and INEST types to B (were UINT only in Nios)   FY *
* 2014-10-20 Removed unnecessary INCLUDED_FROM_NOCFG4_H macro for n4rxxx.h MI *
* 2014-10-20 Added OS_CONFIG to denote including nosys4.h as configuration FY *
******************************************************************************/

#ifndef NOCFG4_H
#define NOCFG4_H

#ifdef __cplusplus
extern "C" {
#endif

/* Including CPU-dependent header file */

#define OS_CONFIG
#include "nosys4.h"

#ifndef NULL
#define NULL    ((void *)0)
#endif

/* Constants for Configuration */

#ifndef TSKID_MAX
#define TSKID_MAX   8               /* 1 ~ 250 */
#endif
#ifndef SEMID_MAX
#define SEMID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef FLGID_MAX
#define FLGID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MBXID_MAX
#define MBXID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MBFID_MAX
#define MBFID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef PORID_MAX
#define PORID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MPLID_MAX
#define MPLID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MPFID_MAX
#define MPFID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef DTQID_MAX
#define DTQID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef MTXID_MAX
#define MTXID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef ISRID_MAX
#define ISRID_MAX   8               /* 1 ~ 999 */
#endif
#ifndef SVCFN_MAX
#define SVCFN_MAX   8               /* 1 ~ 50 */
#endif
#ifndef CYCNO_MAX
#define CYCNO_MAX   1               /* 1 ~ 250 */
#endif
#ifndef ALMNO_MAX
#define ALMNO_MAX   1               /* 1 ~ 250 */
#endif
#ifndef TPRI_MAX
#define TPRI_MAX    8               /* 1 ~ 31 */
#endif
#ifndef TMRQSZ
#define TMRQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef CYCQSZ
#define CYCQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef ALMQSZ
#define ALMQSZ      1               /* 1,2,4,8,16,32,64,128,256 */
#endif
#ifndef ISTKSZ
#define ISTKSZ      sizeof(T_CTX)*4
#endif
#ifndef TSTKSZ
#define TSTKSZ      sizeof(T_CTX)*4
#endif
#ifndef SYSMSZ
#define SYSMSZ      0               /* 0: use stack area */
#endif
#ifndef MPLMSZ
#define MPLMSZ      0               /* 0: use stack area */
#endif
#ifndef STKMSZ
#define STKMSZ      0               /* 0: use default stack area */
#endif

/* Configuration Information */

const V4_T_RCFG cdecl CFG =
{   TSKID_MAX,
    SEMID_MAX,
    FLGID_MAX,
    MBXID_MAX,
    MBFID_MAX,
    PORID_MAX,
    MPLID_MAX,
    MPFID_MAX,
    CYCNO_MAX,
    ALMNO_MAX,
    TPRI_MAX,
    TMRQSZ,
    CYCQSZ,
    ALMQSZ,
    ISTKSZ,
    TSTKSZ,
    SYSMSZ,
    MPLMSZ,
    STKMSZ,
    DTQID_MAX,
    MTXID_MAX,
    ISRID_MAX,
    SVCFN_MAX
};

const T_RVER DFAR * const cdecl norti_ver = &_NORTI_VER;
const UH mSEC = MSEC;

/* Kernel Internal Data */

T_TCB SNEAR * SNEAR cdecl _pTCB[TSKID_MAX+1];
T_SEM SNEAR * SNEAR cdecl _pSEM[SEMID_MAX];
T_FLG SNEAR * SNEAR cdecl _pFLG[FLGID_MAX];
T_MBX SNEAR * SNEAR cdecl _pMBX[MBXID_MAX];
T_MBF SNEAR * SNEAR cdecl _pMBF[MBFID_MAX];
T_POR SNEAR * SNEAR cdecl _pPOR[PORID_MAX];
T_MPL SNEAR * SNEAR cdecl _pMPL[MPLID_MAX];
T_MPF SNEAR * SNEAR cdecl _pMPF[MPFID_MAX];
T_CYC SNEAR * SNEAR cdecl _pCYC[CYCNO_MAX];
T_ALM SNEAR * SNEAR cdecl _pALM[ALMNO_MAX];
T_DTQ SNEAR * SNEAR cdecl _pDTQ[DTQID_MAX];
T_MTX SNEAR * SNEAR cdecl _pMTX[MTXID_MAX];
T_ISR SNEAR * SNEAR cdecl _pISR[ISRID_MAX];
T_SVC SNEAR * SNEAR cdecl _pSVC[SVCFN_MAX];
FP SNEAR _kernel_dcall;
ID SNEAR _kernel_mbxfr;
RDVNO SNEAR _kernel_rdv_seqno;
T_ISR_ST SNEAR _kernel_ovrisr;
T_OVR SNEAR _kernel_ovr;
SYSTIME SNEAR cdecl _kernel_clk;
SYSTIME SNEAR cdecl SYSCK;
UW SNEAR cdecl IDLCNT;
T_SYSTCB SNEAR cdecl SYSTCB;
ER SNEAR cdecl SYSER;
volatile TSK_PRI SNEAR cdecl NOWPRI;
volatile B SNEAR cdecl DELAY;
volatile B SNEAR cdecl INEST;
volatile B SNEAR cdecl DDISP;
volatile TSK_ID SNEAR cdecl SDISP;
volatile B SNEAR cdecl TMREQ;
volatile TSK_ID SNEAR cdecl PREVTSK;
volatile TSK_PRI SNEAR cdecl APLPRI;
UB SNEAR cdecl TMQMS;
UB SNEAR cdecl CHQMS;
UB SNEAR cdecl AHQMS;
UINT SNEAR cdecl CTXPTN;
VP SNEAR cdecl CTXPTR;
UINT SNEAR cdecl WID;
T_NMEM SNEAR * SNEAR cdecl SYSTOP;
T_MEM PFAR * SNEAR cdecl MPLTOP;
T_MEM SFAR * SNEAR cdecl STKTOP;
TSK_ID SNEAR cdecl RDQ[TPRI_MAX+2];
TSK_ID SNEAR cdecl TMQ[TMRQSZ];
UB SNEAR cdecl CHQ[CYCQSZ];
UB SNEAR cdecl AHQ[ALMQSZ];
const char _KERNEL_NNM = 0;

#if ((SYSMSZ)/SIZEOF_INT!=0)
int SNEAR cdecl SYSMEM[(SYSMSZ)/SIZEOF_INT];
int SNEAR * const cdecl pSYSMEM = (int SNEAR * cdecl)SYSMEM;
#else
int SNEAR * const cdecl pSYSMEM = (int SNEAR * cdecl)NULL;
#endif

#if ((MPLMSZ)/SIZEOF_INT!=0)
int PFAR * const cdecl pMPLMEM = (int PFAR * cdecl)MPLMEM;
#else
int PFAR * const cdecl pMPLMEM = (int PFAR * cdecl)NULL;
#endif

#if ((STKMSZ)/SIZEOF_INT!=0)
int SFAR * const cdecl pSTKMEM = (int SFAR * cdecl)STKMEM;
#else
int SFAR * const cdecl pSTKMEM = (int SFAR * cdecl)NULL;
#endif

#undef OS_CONFIG
#ifdef __cplusplus
}
#endif
#endif  /* NOCFG4_H */
