/******************************************************************************
* NORTi3 Compatible Common Definition and Declaration                         *
*                                                                             *
*  Copyright (c) 2000-2014, MiSPO Co., Ltd.                                   *
*  All rights reserved.                                                       *
*                                                                             *
* 2000-04-14 Created                                                          *
* 2014-10-20 Moved NADR macro to here from itron.h                         MI *
* 2014-10-20 Moved TCY_OFF/_ON/_INI and TTW_MBF macros from kernel.h       FD *
* 2014-10-20 Added ???CNT_MAX as redefinitions of NORTi4's TMAX_MAX???     FD *
******************************************************************************/

#ifndef NORTI3_H
#define NORTI3_H

#ifndef V3
#define V3
#endif
#include "kernel.h"

/* uITRON3.0 macros removed in kernel.h */

#define NADR        NULL        /* ((void*)(-1)) in uITRON3.0 */

#define TCY_OFF     TCYC_STP    /* do not invoke cyclic handler */
#define TCY_ON      TCYC_STA    /* invoke cyclic handler */
#define TCY_INI     TA_STA      /* initialize cycle count */

#define TTW_MBF     TTW_RMBF    /* wait due to rcv_mbf or trcv_mbf */

/* NORTi3 unique macros removed in kernel.h */

#define SEMCNT_MAX  TMAX_MAXSEM /* maximum semaphore count */
#define WUPCNT_MAX  TMAX_WUPCNT /* maximum wakeup request count */
#define SUSCNT_MAX  TMAX_SUSCNT /* maximum suspension count */
#define ACTCNT_MAX  TMAX_ACTCNT /* maximum activation request count */

#endif /* NORTI3_H */
