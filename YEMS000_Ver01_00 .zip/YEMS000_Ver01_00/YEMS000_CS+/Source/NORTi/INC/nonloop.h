/******************************************************************************
* NORTi Network LOOPBACK I/F(process internal) �h���C�o                       *
*                                                                             *
*  Copyright (c) 2001-2006 MiSPO Co., Ltd.                                    *
*  All rights reserved.                                                       *
*                                                                             *
* 12/Feb/2001 Created                                               OK(MiSPO) *
******************************************************************************/

#ifndef __LOOPBACK_H__
#define __LOOPBACK_H__
#ifdef __cplusplus
extern "C" {
#endif


/* Buffer Descripter */
typedef struct BufferDescript {
    UW status;
    UH reserved;
    UH len;
    UB *buf_p;
    struct BufferDescript *next; /* next BD pointer */
} IIF_BD;

/* Buffer Descripter status */
#define BD_ACT                0x80000000L
#define BD_DL                 0x40000000L


#ifdef __cplusplus
}
#endif
#endif /* __LOOPBACK_H__ */
