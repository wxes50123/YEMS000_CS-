/******************************************************************************
* NORTi3 Compati. system definitions file                                     *
*                                                                             *
*  Copyright (c)  1995-2000, MiSPO Co., Ltd.                                  *
*  All rights reserved.                                                       *
*                                                                             *
* 07/Mar/2000                                                                 *
* 15/Mar/2004  The multiplex definition of V3 macro was corrected.       TA   *
******************************************************************************/

#ifndef NOSYS3_H
#define NOSYS3_H
#ifndef V3
#define V3
#endif

#include "nosys4.h"

#endif /* NOSYS3_H */
