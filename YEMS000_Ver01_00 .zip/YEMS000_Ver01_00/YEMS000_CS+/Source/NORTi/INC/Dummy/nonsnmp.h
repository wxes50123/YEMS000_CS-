#error! The dummy nonsnmp.h is included. 
