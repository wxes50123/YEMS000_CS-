#error! The dummy nonsnmpc.h is included. 
